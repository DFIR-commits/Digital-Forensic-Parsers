# Testing Mount Sleuth

How Mount Sleuth is tested, and the record of what was tested for release 1.0.0 (2026-11-02).
Only what is listed here as passed was actually run.

## 1. Test suites

| Suite | Command | Needs | What it covers |
|---|---|---|---|
| Unit tests (40) | `QT_QPA_PLATFORM=offscreen python3 -m unittest discover -s tests` | Python 3.9+ with PySide6 (e.g. `/opt/mount-evidence-venv/bin/python3`); no root | Backend: parsing (`blkid`, `kpartx`, `sfdisk`), partition roles, classification, naming, LVM table construction, v1 state files, GUI job validation. GUI: a fake backend speaking the real `--json` protocol drives the window (startup, missing tools, queueing, discovery, statuses, cancel, busy unmount, image paths kept off the command line, Settings, filters, closing with mounts, 30 000-event log flood). |
| CLI integration (29 checks) | `sudo bash tests/integration_cli.sh` | root, **disposable machine or privileged container** | Builds five fixture images with `tests/mkimages.sh` (GPT disk with EFI/MSR/NTFS/recovery/swap/ext4/unformatted/LUKS; MBR disk with logical partitions and awkward names; LVM disk and a clone with identical VG UUIDs; an E01 of the GPT disk). Checks: dry run leaves nothing; 15 filesystems mount, all `ro`; all block devices read-only; cloned LVM mounts; rerun is idempotent; `--status`; lock; busy teardown names the holder and keeps the image; `--block-only`; SIGINT; `kill -9`; missing `ewfmount` fails only the E01; `-w` refused; a host VG with the same name and a busy host dm device survive; **SHA-256 of every evidence file unchanged**. |
| GUI integration (36 checks) | `sudo QT_QPA_PLATFORM=offscreen python3 tests/integration_gui.py` | root, PySide6, disposable machine or container | The GUI driving the real backend over the same fixtures: add, discover, statuses, mount, every mount `ro`, open/copy paths, manifest view, external unmount noticed without polling, busy unmount not forced, unmount-selected touches only the selection, unmount all, cancel, one operation at a time, responsiveness, **evidence SHA-256 unchanged**. |
| Clean install | `docker run --rm --privileged -v "$PWD:/src:ro" IMAGE bash /src/tests/clean_install_test.sh` | Docker host (test machine) | Fresh distribution → `scripts/install.sh` → install again (update) → all three suites above → E01 FUSE layer `ro` → `--uninstall` → release leftovers. |
| Manual VM validation | Section 4 | A desktop VM | Real desktop, real polkit prompt, NBD formats, AFF, failure cases, screenshots. |

The integration tests use the default `/mnt/MountSleuth` root and release everything under it. Never
run them on a workstation with real evidence mounted under that root.

## 2. Test matrix (1.0.0)

| Linux distribution | Version | Kernel | Installation | Mounting | Unmounting | Status |
|---|---|---|---|---|---|---|
| Ubuntu (SANS SIFT Workstation VM, GNOME 46 Wayland) | 24.04.4 LTS | 6.8.0-101-generic | Pass (upgrade over a pre-1.0 install; all checks `ok`) | Pass: raw, dd, img, E01, AFF, VMDK, QCOW2, VHDX, VHD; GPT, MBR, LVM; GUI and CLI | Pass (busy and retry included) | Tested |
| Ubuntu (Docker `ubuntu:24.04`) | 24.04.5 LTS | 6.6.87.1-microsoft-standard-WSL2 | Pass (clean, reinstall, uninstall) | Pass (unit 40/40, CLI 29/29, GUI 36/36) | Pass | Tested; no NBD, no desktop |
| Ubuntu (Docker `ubuntu:22.04`) | 22.04.5 LTS | 6.6.87.1-microsoft-standard-WSL2 | Pass | Pass (40/40, 29/29, 36/36) | Pass | Tested; no NBD, no desktop |
| Debian (Docker `debian:12`) | 12 (bookworm) | 6.6.87.1-microsoft-standard-WSL2 | Pass | Pass (40/40, 29/29, 36/36) | Pass | Tested; no NBD, no desktop |

Each container suite was run at least twice against the 1.0.0 code. The final run is recorded in
section 3. Distributions not in this table are untested (see the README's compatibility section).

### Package versions in the tested environments

| Package | Ubuntu 24.04 (SIFT VM) | Ubuntu 24.04 (container) | Ubuntu 22.04 | Debian 12 |
|---|---|---|---|---|
| python3 | 3.12.3 | 3.12.3 | 3.10.12 | 3.11.2 |
| util-linux / fdisk | 2.39.3-9ubuntu6.6 | 2.39.3-9ubuntu6.6 | 2.37.2-4ubuntu3.6 | 2.38.1-5+deb12u3 |
| kpartx | 0.9.4-5ubuntu8.2 | 0.9.4-5ubuntu8.2 | 0.8.8-1ubuntu1.22.04.4 | 0.9.4-3+deb12u2 |
| dmsetup | 2:1.02.185-3ubuntu3.2 | 2:1.02.185-3ubuntu3.2 | 2:1.02.175-2.1ubuntu5 | 2:1.02.185-2 |
| ntfs-3g | 1:2022.10.3-1.2ubuntu3.2 | 1:2022.10.3-1.2ubuntu3.2 | 1:2021.8.22-3ubuntu1.4 | 1:2022.10.3-1+deb12u3 |
| EWF tools | libewf-tools 20140816-1ppa1~noble | ewf-tools 20140814-1build3 | ewf-tools 20140807-2ubuntu2 | ewf-tools 20140813-1+b1 |
| qemu-utils | 1:8.2.2+ds-0ubuntu1.18 | 1:8.2.2+ds-0ubuntu1.18 | 1:6.2+dfsg-2ubuntu6.31 | 1:7.2+dfsg-7+deb12u18+b3 |
| afflib-tools | 3.7.20-1.1ubuntu5 | 3.7.20-1.1ubuntu5 | 3.7.19-2build1 | 3.7.20-1 |
| lvm2 | 2.03.16-3ubuntu3.2 | 2.03.16-3ubuntu3.2 | 2.03.11-2.1ubuntu5 | 2.03.16-2 |
| VSS tools | libvshadow-tools 20240504-1ppa1~noble | libvshadow-utils 20190323-2.1build1 | libvshadow-utils 20190323-2build1 | libvshadow-utils 20190323-2+b2 |
| psmisc | 23.7-1build1 | 23.7-1build1 | 23.4-2build3 | 23.6-1 |
| pkexec | 124-2ubuntu1.24.04.4 | 124-2ubuntu1.24.04.4 | 0.105-33ubuntu0.2 | 122-3 |
| PySide6 (venv) | 6.11.0 | 6.11.0 | 6.11.0 | 6.11.0 |

## 3. Container record (final run)

All three distributions, against the final 1.0.0 code (after the `kill -9` fixes), each run twice;
all six runs gave the results below, including the CLI suite's `kill -9` teardown check. In this
release run the harness cut off the unit-test summary line (fixed since); the 40 unit tests were
run separately on the SIFT VM (Python 3.12, all OK), and the 18 backend tests on the stock Python
of Ubuntu 22.04 (3.10) and Debian 12 (3.11), all OK.

```
Ubuntu 24.04.5 LTS   install rc=0, reinstall rc=0, CLI passed 29 failed 0, GUI 36/36,
                     E01 helper: fuse ro, uninstall clean, no leftover devices
Ubuntu 22.04.5 LTS   (same results)
Debian 12            (same results)
```

Performance figures printed by the GUI integration test (5 images, 15 filesystems, median of 3 warm
runs) were 0.67–1.45 s for the GUI and 0.68–1.22 s for the CLI across the runs; the GUI adds well
under the test's 0.5 s threshold.

## 4. Manual validation on the SIFT Workstation VM

Environment: Ubuntu 24.04.4 LTS (SIFT Workstation), kernel 6.8.0-101-generic, GNOME 46 on Wayland,
4 CPUs. Real evidence of the VM's owner was mounted elsewhere (`/mnt/IOC_SCAN`) throughout; it was
not touched, and its mount count was the same before and after every step.

**Installation.** `sudo sh scripts/install.sh` over an existing pre-1.0 installation: exit 0, all
checklist items `ok` (including `nbd` and PySide6); the old polkit policy was replaced by the new
one; the logrotate rule was accepted by `logrotate -d`.

**Demo evidence** (built with `tests/mkimages.sh` plus `qemu-img convert` and `affconvert`): nine
images, seven formats (raw, dd, img, E01, VMDK, QCOW2, VHDX, VHD) plus a separate AFF.

**CLI, all formats.** `sudo mount-evidence ~/ms-demo-evidence`: exit 0; 9 images ok; 60 volumes,
31 mounted, 29 skipped by design, 0 failed; all 31 mounts `ro` in `/proc/mounts`; the E01 FUSE helper
`ro`; four NBD devices. `sudo mount-evidence --unmount`: exit 0, 9 of 9 released in 2 s; no mounts,
loop devices, NBD connections or `mev-` mappings left; mount roots empty. SHA-256 of all 9 evidence
files unchanged.

**AFF.** An `.aff` made with `affconvert` (afflib 3.7.20) from the LVM fixture: mounted through
`fuse.affuse` with `ro`; ext4 and LVM ext4 volumes mounted `ro`; LVM swap skipped; clean teardown;
SHA-256 unchanged.

**GUI walkthrough** (the README screenshots): launched in the desktop session; Add folder tree through
the GNOME folder chooser; Discover showed the real polkit prompt with Mount Sleuth's policy message;
Discover (9 images, 60 volumes, 31 mountable); Mount all (31 mounted, all `ro`); filters; details;
right-click menu; open in Files; Unmount all with two volumes held busy (a shell process and the Files
window) → 7 of 9 released, the two busy images kept and named in the log; after closing them, Unmount
all → 2 of 2 released, nothing left, SHA-256 unchanged.

**Failure scenarios** and the messages shown:

| Scenario | Result |
|---|---|
| CLI without sudo | `Must run as root: sudo mount-evidence /tmp/fail`, exit 1 |
| Path does not exist | `Not found: /tmp/nope`, exit 2 |
| Folder with no images | `No forensic images found under … (supported: …)`, exit 1 |
| Random bytes named `.raw` | Attached read-only, whole disk "no recognized filesystem signature", image ok, clean teardown |
| Text file named `.vmdk` | Attached through NBD as a 512-byte disk, "no filesystem", clean teardown |
| E01 truncated to 20 MB | `[damaged] the disk device could not be read (sfdisk: cannot open /dev/loopN: Invalid argument); the image may be truncated or corrupt - verify it …`, exit 1 (3 of 3 runs); clean teardown |
| `-w` (read-write) | `Read-write mounting was removed: evidence is always mounted read-only. Work on a copy instead.`, exit 2 |
| Unknown option | argparse usage error, exit 2 |
| Busy volume at unmount | image kept, holder named, other images released, exit 1; retry succeeds |
| pkexec request ended without authenticating | GUI reports the failure and stays usable (the request was ended by signal for the test, so it read "The backend crashed"; a real Cancel returns 126, "Authorisation was dismissed") |
| GUI started from an SSH session | pkexec: "no polkit authentication agent" (expected; documented in Troubleshooting) |

### Crash-recovery stress test (`kill -9`)

The CLI integration suite kills the backend once at a fixed point. During the 1.0.0 regression that
check failed once on Ubuntu 24.04, so it was turned into a randomized loop: start a mount of the five
fixtures, `kill -9` the backend after a random 0–1.5 s, run `--unmount` once, and check for leftover
loop devices, mounts, device-mapper maps and files.

| Code | Environment | Runs | Not clean after one `--unmount` | What was left |
|---|---|---|---|---|
| before fix | Ubuntu 24.04 container | 25 | 1 | `.mount_state.json.tmp` in an image folder (first journal save cut short) |
| before fix | Ubuntu 24.04 container | 40 | 14 | an unrecorded loop device (killed between `losetup` and the journal write), persisting into later runs |
| 1.0.0 | Ubuntu 24.04 container | 40 | **0** | — |
| 1.0.0 | SIFT VM, VMDK/QCOW2/VHDX/VHD (NBD path), 15 runs, 6 of them killed mid-run | 15 | **0** | — |

A unit test (`test_unmount_removes_cut_short_first_journal`) reproduces the temp-file case; it fails
without the fix.

### VMFS (1.0.2)

- **The crash:** the distribution's `vmfs6-fuse` (Ubuntu 24.04, `0.2.1-1build2`) crashed with a segmentation fault on an
  examiner's VMFS 6 image and on upstream's sample volume. The backtrace pointed into `fuse_opt_parse`. The upstream
  source built with Ubuntu's package flags (`dpkg-buildflags`, `-flto` …) reproduced the crash.
- **The fix:** the same build with the `FUSE_OPT_END` fix exits normally with "Unsupported version 3" on that VMFS 3
  volume.
- **Clean-install test** (Ubuntu 24.04, Ubuntu 22.04, Debian 12):
  - The bundled vmfs6-tools builds on all three, and the checklist's `vmfs6-fuse runs` line is `ok`.
  - On upstream's VMFS 3 sample volume (`third_party/vmfs6-tools/test.img`), `vmfs6-fuse` declines with rc 1, then
    `vmfs-fuse` mounts it read-only (`ro` verified) and lists its eight `.vmdk` files.
  - Unit 40/40, CLI 29/29, GUI 36/36; `--uninstall` removes the build.
- **VMFS 6 itself:** an earlier build of the same upstream source mounted the examiner's VMFS 6 image. The bundled
  build had not yet been tried on that image when 1.0.2 was released.

## 5. Not tested for 1.0.0

- Fresh install on a real (non-container) Ubuntu 22.04 or Debian 12 desktop; NBD formats on those.
- Desktops other than GNOME (KDE, Xfce, …); X11 sessions.
- Segmented E01 sets; Ex01, L01, S01, AFD, AFM; VMDK/VHDX produced by VMware or Hyper-V themselves.
- XFS, Btrfs, F2FS, HFS+, UDF, ISO 9660, SquashFS and exFAT mounting; the `ntfs3` driver; VMFS.
- BitLocker detection on a real volume; VSS snapshot mounting (`--vss`); striped LVM on a real image.
- Large real-world evidence (the fixtures are 35 MB–700 MB).

## 6. Screenshots

The screenshots in `docs/screenshots/` were captured on 2026-11-02 from the running application on the
SIFT VM above, with the demo evidence (no real case data). Notes:

- They were taken with a throwaway settings folder, so the VM user's own settings were untouched.
- The authentication prompt and the Settings dialog show the default `pkexec` elevation. For the
  rest of the automated session, elevation was switched to `sudo` (the VM account has passwordless
  sudo), so the log in those shots reads `sudo -n …`. The windows are otherwise identical.
- Numbered red callouts were drawn onto the captures afterwards; nothing else was edited apart from
  cropping to the application window.

## 7. Test-environment notes

- Containers share the host's kernel: loop and device-mapper devices outlive a container, so run
  container tests one at a time. `clean_install_test.sh` releases what the tests attached.
- Without udev (containers), LVM does not create `/dev/<vg>` nodes for the fixture builder;
  `tests/mkimages.sh` and `tests/integration_cli.sh` set `DM_DISABLE_UDEV=1` for their own LVM
  commands only. The backend creates its own nodes when udev is absent.
- Older util-linux (Ubuntu 22.04) has no `mkswap -q`; the fixture builder does not use it.
