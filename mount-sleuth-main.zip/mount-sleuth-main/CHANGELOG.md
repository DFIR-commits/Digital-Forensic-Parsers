# Changelog

All notable changes to Mount Sleuth. Versions follow [Semantic Versioning](https://semver.org/).

## [1.0.0] - 2026-11-02

First production release, Linux only. Mount Sleuth now lives in its own repository; the engine
(`mount_evidence 2.0`) and the GUI were previously part of the forensic-platform project.

### Added
- `mount-evidence --version` (`-V`).
- Installer verification checklist at the end of `scripts/install.sh`: required tools, optional
  tools, `nbd`, pkexec and PySide6; it exits with an error when a required item is missing.
- Log rotation for `/var/log/mount_evidence.log`: compressed monthly, old logs never deleted.
- `tests/clean_install_test.sh`: clean-install validation in a throwaway container.
- Full documentation: README (installation, walkthrough with screenshots, features, troubleshooting,
  FAQ, security considerations), `docs/TESTING.md` with the 1.0.0 test record.

### Changed
- **Evidence safety:** the FUSE helpers for E01 (`ewfmount -X ro`), AFF (`affuse -o ro`) and shadow
  copies (`vshadowmount -X ro`) are now mounted read-only at the FUSE layer as well. Previously they
  showed `rw` in `/proc/mounts`, although the loop device above them was already read-only.
- A disk device that cannot be read at all (for example a truncated E01) is now reported as
  `damaged`, with a pointer to image verification, instead of an "ok" image with no filesystem.
- Clearer message when the command line is run without sudo.
- The installer always uses its own pinned PySide6 (6.11.0) environment, instead of a system PySide6
  that might be the broken 6.12.0; `--no-venv` keeps the old behaviour.
- The installer installs `kmod` and creates the configuration folders it writes to, so it also works
  on minimal systems.
- Installer input validation for `--wheels` and `--nbd-max`; if PySide6 cannot be installed, the
  incomplete environment is removed and the GUI is reported as unavailable.
- polkit action renamed to `local.mount-sleuth.mount-evidence`; the installer removes the old policy file.
- Repository layout: `src/`, `scripts/`, `tests/`, `docs/`. The privileged integration tests are now
  named `integration_*`, so `unittest discover` never runs them.
- Test fixtures work on Ubuntu 22.04 (no `mkswap -q`) and in containers without udev.

### Fixed
- Recovery after the backend is killed (`kill -9`, power loss of the process) mid-run. A randomized
  stress test showed two gaps in the teardown journal; after a single `--unmount`, 14 of 40 runs
  were not clean:
  - a loop device created by `losetup` but killed before it was recorded stayed attached. Loop
    devices are now recorded before they are attached, like every other resource; NBD slots
    likewise are recorded before `qemu-nbd` connects.
  - a journal save cut short left `.mount_state.json.tmp`, which kept the image folder from being
    removed. `--unmount` now removes it.
  - releasing an NBD device now also removes unrecorded mappings stacked on it, as loop devices already did.
  After the fix: 40 of 40 container runs (loop/E01 path) and 15 of 15 VM runs (NBD path) clean.
- The installer failed on systems without `/etc/modprobe.d` (found in a clean container).

### Known limitations
See the README (Features, Security and forensic considerations) and `docs/TESTING.md` (Not tested).
