# Changelog

All notable changes to Mount Sleuth. Versions follow [Semantic Versioning](https://semver.org/).

## [1.0.3] - 2026-11-09

### Fixed
- **vmfs6-tools was not built from a downloaded copy of 1.0.2, so VMFS 6 volumes did not mount.**
  The repository's `*.img` ignore rule had kept upstream's sample volume `test.img` out of the
  commit, and upstream's default build target repacks that file, so `make` failed after compiling
  every tool. The installer now builds only the four programs it installs, and `test.img` is
  committed (an explicit exception in `.gitignore`).
- When the vmfs6-tools build fails, the installer's closing summary says that VMFS 6 volumes will
  not mount, instead of only a `WARNING` line in the middle of the output.

### Changed
- `tests/clean_install_test.sh` is documented to run on a `git archive` export, so it tests what a
  download contains rather than the working folder (the 1.0.2 runs used the working folder, which
  still had `test.img`).

## [1.0.2] - 2026-11-03

### Fixed
- **VMFS 6 mounts failed** on systems with the distribution's `vmfs6-tools` (Ubuntu 24.04:
  `0.2.1-1build2`): its `vmfs6-fuse` crashes with a segmentation fault on every run. The cause is
  a missing `FUSE_OPT_END` in its option table, which the distribution's build flags turn into a
  crash. Mount Sleuth now bundles the upstream source (commit `582b525`, GPL-2.0) with that one-line
  fix in `third_party/vmfs6-tools`, and the installer builds it into `/usr/local/sbin` instead of
  installing the package. See `third_party/README.md`.
- The `mount-evidence` wrapper sets a fixed `PATH` with `/usr/local/sbin` first, so the bundled
  build is used under pkexec, whose own `PATH` has no `/usr/local`.
- A failed VMFS mount now reports each tool's own error. Before, a `vmfs6-fuse` crash (no
  output) was hidden behind `vmfs-fuse`'s "VMFS: unsupported version 6".
- A helper killed by a signal is reported as "crashed (signal N)" instead of a negative exit code.

### Changed
- The installer installs build tools (`gcc`, `make`, `libc6-dev`, `pkg-config`, `libfuse-dev`,
  `uuid-dev`) for the bundled vmfs6-tools, and no longer installs the `vmfs6-tools` package.
  Its checklist runs `vmfs6-fuse` once to confirm it doesn't crash; `--uninstall` removes the build.
- The clean-install test mounts upstream's VMFS 3 sample volume, so the VMFS path (including the
  VMFS 3/5 fallback) is tested on every distribution.

## [1.0.1] - 2026-11-03

### Fixed
- The installer now installs every tool Mount Sleuth runs. Missing before: `vmfs6-tools`
  (VMware VMFS mounts failed with "vmfs6-fuse not installed"), `udev`, `logrotate` and `xdg-utils`.
- On Ubuntu, the installer adds `linux-modules-extra` for the running kernel when a filesystem
  driver Mount Sleuth uses is missing. Minimal Ubuntu installs lack exFAT, ntfs3, F2FS and
  HFS/HFS+ there; before, the package was only added when `nbd` was missing.
- The installer's checklist now covers every program the backend and GUI run, and each kernel
  filesystem driver.
- VMFS 3/5 datastores: when `vmfs6-fuse` (VMFS 6 only) cannot open a volume, `vmfs-fuse` from
  `vmfs-tools` is tried next, still read-only. The installer installs both packages.
- The VMFS "missing dependency" message names the packages to install.

## [1.0.0] - 2026-11-02

First production release, Linux only. Mount Sleuth now lives in its own repository; the engine
(`mount_evidence 2.0`) and the GUI were previously part of the forensic-platform project.

### Added
- `mount-evidence --version` (`-V`).
- Installer verification checklist at the end of `scripts/install.sh`: required tools, optional
  tools, `nbd`, pkexec and PySide6; it exits with an error when a required item is missing.
- Log rotation for `/var/log/mount_evidence.log`: compressed monthly, old logs never deleted.
- `tests/clean_install_test.sh`: clean-install validation in a throwaway container.
- Full documentation: README (installation, walkthrough with screenshots, features, troubleshooting,
  FAQ, security considerations), `docs/TESTING.md` with the 1.0.0 test record.

### Changed
- **Evidence safety:** the FUSE helpers for E01 (`ewfmount -X ro`), AFF (`affuse -o ro`) and shadow
  copies (`vshadowmount -X ro`) are now mounted read-only at the FUSE layer as well. Previously they
  showed `rw` in `/proc/mounts`, although the loop device above them was already read-only.
- A disk device that cannot be read at all (for example a truncated E01) is now reported as
  `damaged`, with a pointer to image verification, instead of an "ok" image with no filesystem.
- Clearer message when the command line is run without sudo.
- The installer always uses its own pinned PySide6 (6.11.0) environment, instead of a system PySide6
  that might be the broken 6.12.0; `--no-venv` keeps the old behaviour.
- The installer installs `kmod` and creates the configuration folders it writes to, so it also works
  on minimal systems.
- Installer input validation for `--wheels` and `--nbd-max`; if PySide6 cannot be installed, the
  incomplete environment is removed and the GUI is reported as unavailable.
- polkit action renamed to `local.mount-sleuth.mount-evidence`; the installer removes the old policy file.
- Repository layout: `src/`, `scripts/`, `tests/`, `docs/`. The privileged integration tests are now
  named `integration_*`, so `unittest discover` never runs them.
- Test fixtures work on Ubuntu 22.04 (no `mkswap -q`) and in containers without udev.

### Fixed
- Recovery after the backend is killed (`kill -9`, power loss of the process) mid-run. A randomized
  stress test showed two gaps in the teardown journal; after a single `--unmount`, 14 of 40 runs
  were not clean:
  - a loop device created by `losetup` but killed before it was recorded stayed attached. Loop
    devices are now recorded before they are attached, like every other resource; NBD slots
    likewise are recorded before `qemu-nbd` connects.
  - a journal save cut short left `.mount_state.json.tmp`, which kept the image folder from being
    removed. `--unmount` now removes it.
  - releasing an NBD device now also removes unrecorded mappings stacked on it, as loop devices already did.
  After the fix: 40 of 40 container runs (loop/E01 path) and 15 of 15 VM runs (NBD path) clean.
- The installer failed on systems without `/etc/modprobe.d` (found in a clean container).

### Known limitations
See the README (Features, Security and forensic considerations) and `docs/TESTING.md` (Not tested).
