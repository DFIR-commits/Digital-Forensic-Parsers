# Mount Sleuth

**Read-only mounting of forensic disk images on Linux, for examiners.**

Version 1.0.2 · Linux (Ubuntu / Debian) · GUI and command line

![Mount Sleuth with an image mounted read-only](docs/screenshots/volume-statuses.png)

---

## At a glance

| | |
|---|---|
| **What it is** | A desktop application (plus a command-line tool) that opens forensic disk images (E01, raw/dd, AFF, VMDK, QCOW2, VHDX, VHD) and makes their contents browsable as ordinary, **read-only** folders. |
| **The problem it solves** | Getting from an image file to its files on Linux normally takes a chain of commands (`ewfmount`, `losetup`, `kpartx`, `mount` with the right options for each filesystem, LVM handling) and a careful teardown afterwards. Mount Sleuth runs the whole chain the same way every time, read-only at every layer, and records everything it attached so it can release exactly that. |
| **Who it is for** | Digital forensic examiners and incident responders who need to look inside disk images: browse files, run scanners or parsers against them, carve unallocated space. The basic workflow needs no Linux expertise. |
| **Supported systems** | Linux only in this release. Tested on Ubuntu 24.04 LTS (including the SANS SIFT Workstation), Ubuntu 22.04 LTS and Debian 12. See [Compatibility](#4-compatibility-and-test-matrix) for exactly what was tested where. Windows support is planned for a future release. |
| **What it does** | Finds every image under a folder, identifies every partition and filesystem, mounts the filesystems read-only under `/mnt/MountSleuth/<host>/<image>/`, exposes every partition as a read-only block device, writes a report of what it found, and releases everything cleanly when you are done. |
| **What you need** | An Ubuntu 22.04/24.04 or Debian 12 computer (with a desktop for the GUI), an account allowed to use `sudo`, internet access during installation (or an offline package set), and about 1 GB of free disk space for the tools. |

> **Forensic integrity in one paragraph.** Mount Sleuth never opens evidence for writing. Images are
> attached through read-only loop, NBD and FUSE devices. Before mounting, the tool checks that every
> device reports read-only. It mounts with read-only options that also skip journal replay, then checks
> the kernel's mount table and undoes any mount that is not read-only. It does **not** verify that an
> image is intact or unaltered: verify acquisition hashes separately. Details and limits are in
> [Security and forensic considerations](#7-security-and-forensic-considerations).

---

## 1. Quick start

Follow these steps on a supported Linux computer. Commands marked **(sudo)** ask for your password
because they change the system.

**Step 1. Check your system.** Open a terminal (<kbd>Ctrl</kbd>+<kbd>Alt</kbd>+<kbd>T</kbd> on Ubuntu) and run:

```sh
grep PRETTY_NAME /etc/os-release
```

You should see `Ubuntu 24.04…`, `Ubuntu 22.04…` or `Debian GNU/Linux 12…`. On anything else, read
[Compatibility](#4-compatibility-and-test-matrix) first.

**Step 2. Install the prerequisite** (git, used to download Mount Sleuth). **(sudo)**

```sh
sudo apt update && sudo apt install -y git
```

**Step 3. Download Mount Sleuth.**

```sh
cd ~
git clone <repository-url> mount-sleuth      # replace <repository-url> with this repository's address
cd mount-sleuth
```

If you received Mount Sleuth as an archive (for example `mount-sleuth-1.0.2.tar.gz`), unpack it and
change into the folder instead: `tar xzf mount-sleuth-1.0.2.tar.gz && cd mount-sleuth`.

**Step 4. Run the installer.** **(sudo)** It installs every tool Mount Sleuth needs, the program
itself and a desktop menu entry. It takes a few minutes and downloads roughly 200 MB (system
packages plus the GUI toolkit).

```sh
sudo sh scripts/install.sh
```

It ends with a checklist. Every **required** line must say `ok`; `warn` lines are optional
features. The last lines should start with `Done.`:

![Installer verification summary](docs/screenshots/installation-dependencies.png)

**Step 5. Start Mount Sleuth.** Open your applications menu and click **Mount Sleuth**, or run
`mount-evidence-gui` in a terminal. **Do not** start it with `sudo`; it asks for your password
itself when it needs to.

**Step 6. Mount your evidence.** Click **Add folder tree** and choose the folder that holds your
images. Then click **Mount all** and enter your password when asked.

**Step 7. Check that it worked.** The image rows turn green and show **Mounted — read-only**.
Double-click a mounted volume to open it in the file manager. Your files are under
`/mnt/MountSleuth/<host>/<image>/`. When you are finished, click **Unmount all**.

![Mount finished](docs/screenshots/successful-mount.png)

The full walkthrough, including what every part of the window does, is in [How to use Mount Sleuth](#5-how-to-use-mount-sleuth).

---

## Contents

1. [Quick start](#1-quick-start)
2. [Installation](#2-installation)
3. [Dependencies](#3-dependencies)
4. [Compatibility and test matrix](#4-compatibility-and-test-matrix)
5. [How to use Mount Sleuth](#5-how-to-use-mount-sleuth)
6. [Features and capabilities](#6-features-and-capabilities)
7. [Security and forensic considerations](#7-security-and-forensic-considerations)
8. [Command line](#8-command-line)
9. [Troubleshooting](#9-troubleshooting)
10. [Frequently asked questions](#10-frequently-asked-questions)
11. [Uninstalling, updating and maintenance](#11-uninstalling-updating-and-maintenance)
12. [Project information](#12-project-information)

Technical references: [docs/REFERENCE.md](docs/REFERENCE.md) (backend, layout, naming, manifest),
[docs/GUI.md](docs/GUI.md) (GUI internals), [docs/TESTING.md](docs/TESTING.md) (test procedures and
results), [CHANGELOG.md](CHANGELOG.md).

---

## 2. Installation

### 2.1 System requirements

| Requirement | Details |
|---|---|
| Operating system | Ubuntu 24.04 LTS, Ubuntu 22.04 LTS or Debian 12, 64-bit (x86-64). See [Compatibility](#4-compatibility-and-test-matrix). |
| Desktop | For the GUI: a graphical desktop with a polkit authentication agent (GNOME, KDE, Xfce, Cinnamon and MATE include one). Only GNOME was tested. The command line needs no desktop. |
| Account | A user account that can run `sudo`. On Ubuntu, the account created during setup can. |
| Python | Python 3.9 or newer for the GUI (Ubuntu 22.04 has 3.10, Debian 12 has 3.11, Ubuntu 24.04 has 3.12). |
| Disk space | About 1 GB for the system packages and the GUI's Python environment (`/opt/mount-evidence-venv` is about 240 MB). Mounting itself needs almost no space: nothing is copied. |
| Network | Internet access while installing, to reach the Ubuntu/Debian package mirrors and the Python package index. For offline computers see [2.5](#25-offline-installation-air-gapped-labs). |
| Kernel features | Loop devices, device-mapper and FUSE, all present on standard Ubuntu/Debian kernels. The `nbd` module for VMDK/QCOW2/VHDX/VHD images, which the installer loads. |

### 2.2 Permissions

- **Installing** needs administrator rights: run the installer with `sudo`.
- **Using the GUI** does not: run it as your normal user. Whenever it needs to attach or release
  images, it asks for your password through the standard system prompt (polkit). The prompt is
  remembered for a few minutes, so Discover followed by Mount asks once.
- **Using the command line** needs `sudo` for every command except `--version` and `--help`.

Why administrator rights are needed at all: on Linux, only the administrator can create loop and
device-mapper devices and mount filesystems. Mount Sleuth confines this to one small, root-owned
program (`/usr/local/sbin/mount-evidence`); the window itself never runs as root.

### 2.3 Install on Ubuntu 24.04 LTS or 22.04 LTS (including SIFT Workstation)

```sh
sudo apt update && sudo apt install -y git      # (sudo) only if git is not installed yet
cd ~ && git clone <repository-url> mount-sleuth && cd mount-sleuth
sudo sh scripts/install.sh                       # (sudo)
```

What the installer does, in order:

1. Installs the system packages listed in [Dependencies](#3-dependencies) with `apt`, skipping any
   tool that is already present from another package. If a kernel filesystem driver Mount Sleuth
   uses is missing (on Ubuntu: exFAT, ntfs3, F2FS, HFS/HFS+), it also installs
   `linux-modules-extra` for the running kernel. On the SIFT Workstation it keeps SIFT's own
   `libewf-tools` and `libvshadow-tools` (Ubuntu's `ewf-tools` and `libvshadow-utils` conflict with them).
2. Configures the `nbd` kernel module (64 slots, loaded at every boot) and loads it now.
3. Copies Mount Sleuth to `/usr/local/lib/mount-evidence/` (root-owned) and creates the
   `mount-evidence` command, the `mount-evidence-gui` launcher, the desktop menu entry, the polkit
   policy and a log-rotation rule.
4. Creates `/opt/mount-evidence-venv` and installs the tested GUI toolkit version (PySide6 6.11.0).
5. Prints the verification checklist and exits with an error if a required item failed.

You can run the installer again at any time; it updates in place. It writes only to the paths listed
in [11.3](#113-where-mount-sleuth-keeps-its-files).

Ubuntu 22.04 needs no extra steps: the installer picks the right package names itself. See the matrix
for what the 22.04 test does and does not cover.

### 2.4 Install on Debian 12

Debian does not give the first user `sudo` rights by default. If `sudo` says you are not in the
sudoers file, add yourself once as root, then log out and back in:

```sh
su -c 'apt install -y sudo git && usermod -aG sudo YOUR_USERNAME'
```

Then install exactly as on Ubuntu:

```sh
cd ~ && git clone <repository-url> mount-sleuth && cd mount-sleuth
sudo sh scripts/install.sh
```

### 2.5 Offline installation (air-gapped labs)

The installer downloads two things: system packages (apt) and PySide6 for the GUI (pip).

1. **System packages**: install them from your internal mirror or offline repository (the list is in
   [Dependencies](#3-dependencies)), then run the installer with `--no-apt`.
2. **PySide6**: on a connected computer **with the same Python version** as the lab machine
   (`python3 --version`), download the packages and copy the folder across:

   ```sh
   python3 -m pip download 'PySide6-Essentials==6.11.0' -d wheels/
   ```

3. On the lab machine:

   ```sh
   sudo sh scripts/install.sh --no-apt --wheels /path/to/wheels
   ```

Without PySide6 the command line still works; only the GUI needs it.

### 2.6 Installer options

| Option | Effect |
|---|---|
| *(none)* | Install or update everything. |
| `--no-apt` | Skip `apt`; the system packages must already be installed. |
| `--wheels DIR` | Install PySide6 from a local folder instead of the internet. |
| `--no-venv` | Do not create the PySide6 environment; the system `python3` must already have a working PySide6. |
| `--nbd-max N` | How many VMDK/QCOW2/VHDX/VHD images can be attached at once (default 64). |
| `--uninstall` | Remove Mount Sleuth's program files (see [11.1](#111-uninstall)). |

### 2.7 Verify the installation

The installer's checklist is the main check. You can repeat the key checks at any time:

```sh
mount-evidence --version                     # prints: mount_evidence 2.0   (the engine version)
cat /usr/local/lib/mount-evidence/VERSION    # prints: 1.0.2                (the Mount Sleuth release)
sudo mount-evidence --status                 # (sudo) prints: Nothing is mounted by this tool.
ls /dev/nbd0                                 # exists when VMDK/QCOW2/VHDX/VHD support is ready
```

### 2.8 Launch

- **GUI:** applications menu → **Mount Sleuth**, or `mount-evidence-gui` in a terminal. Run it as
  yourself, never with `sudo`.
- **Command line:** `sudo mount-evidence --help`. See [Command line](#8-command-line).

---

## 3. Dependencies

`scripts/install.sh` installs everything in this table automatically on Ubuntu and Debian, unless
the table says otherwise. The versions are the ones Mount Sleuth 1.0.0 was tested with; older
versions may work but were not tested.

| Dependency (package) | What Mount Sleuth uses it for | Required? | Installed automatically? | Tested versions (Ubuntu 24.04 / 22.04 / Debian 12) |
|---|---|---|---|---|
| `python3` | Runs Mount Sleuth (backend and GUI) | Required | Yes | 3.12.3 / 3.10.12 / 3.11.2 |
| `util-linux` | `losetup` (read-only loop devices), `blkid`, `blockdev`, `mount`, `umount` | Required | Yes (normally preinstalled) | 2.39.3 / 2.37.2 / 2.38.1 |
| `fdisk` | `sfdisk`: reads partition tables | Required | Yes | 2.39.3 / 2.37.2 / 2.38.1 |
| `kpartx` | Read-only partition mappings | Required | Yes | 0.9.4 / 0.8.8 / 0.9.4 |
| `dmsetup` | Device-mapper (partitions, LVM volumes) | Required | Yes | 1.02.185 / 1.02.175 / 1.02.185 |
| `kmod` | `modprobe`, to load the `nbd` module | Required for VMDK/QCOW2/VHDX/VHD | Yes (normally preinstalled) | 31 (Ubuntu 24.04) |
| `udev` | `udevadm settle`: waits for new partition devices to appear | Optional (more reliable timing) | Yes (normally preinstalled) | distribution version |
| `ewf-tools` (Ubuntu/Debian) or `libewf-tools` (SIFT) | `ewfmount`, `ewfinfo`: E01 images | Optional (E01) | Yes; skipped if `ewfmount` is already present | 20140814 / 20140807 / 20140813; SIFT 20140816 |
| `qemu-utils` | `qemu-nbd`, `qemu-img`: VMDK, QCOW2, VHDX, VHD | Optional (those formats) | Yes | 8.2.2 / 6.2 / 7.2 |
| `afflib-tools` | `affuse`: AFF images | Optional (AFF) | Yes | 3.7.20 / 3.7.19 / 3.7.20 |
| `ntfs-3g` | Mounting NTFS volumes | Optional (NTFS, so most Windows evidence) | Yes | 2022.10.3 / 2021.8.22 / 2022.10.3 |
| `lvm2` | Reading LVM metadata (`lvs`, `pvs`) | Optional (Linux LVM) | Yes | 2.03.16 / 2.03.11 / 2.03.16 |
| `libvshadow-utils` (Ubuntu/Debian) or `libvshadow-tools` (SIFT) | Detecting (and, experimentally, mounting) Volume Shadow Copies | Optional | Yes; skipped if `vshadowinfo` is present | 20190323; SIFT 20240504 |
| `psmisc` | `fuser`: names the programs keeping a volume busy | Optional (clearer messages) | Yes | 23.7 / 23.4 / 23.6 |
| `pkexec` (`policykit-1` on older releases) | The GUI's password prompt | Required for the GUI (or use sudo, see the FAQ) | Yes | 124 / 0.105 / 122 |
| `python3-venv` | Creates the GUI's Python environment | Required for the GUI | Yes | matches python3 |
| Qt runtime libraries (`libgl1`, `libegl1`, `libfontconfig1`, `libdbus-1-3`, `libxkbcommon-x11-0`, `libxcb-cursor0`, `libxcb-icccm4`, `libxcb-image0`, `libxcb-keysyms1`, `libxcb-render-util0`, `libxcb-shape0`, `libxcb-xkb1`) | Needed by the PySide6 GUI toolkit | Required for the GUI | Yes | distribution versions |
| PySide6-Essentials (pip) | The GUI toolkit, in `/opt/mount-evidence-venv` | Required for the GUI | Yes (from the internet, or `--wheels`) | 6.11.0 (pinned; 6.12.0 is refused because it crashes) |
| `nbd` kernel module | Attaches VMDK/QCOW2/VHDX/VHD images | Optional (those formats) | Configured and loaded by the installer | kernel 6.8.0 (Ubuntu 24.04) |
| vmfs6-tools (bundled source, `third_party/vmfs6-tools`) | `vmfs6-fuse`: mounting VMware VMFS 6 datastores | Optional (VMFS) | Yes: built from the bundled source into `/usr/local/sbin`, not from the distribution package, whose `vmfs6-fuse` crashes ([third_party/README.md](third_party/README.md)) | upstream 0.2.1 (commit `582b525`) plus one crash fix; builds on all three; VMFS 6 mount verified with an earlier build of the same source |
| Build tools (`gcc`, `make`, `libc6-dev`, `pkg-config`, `libfuse-dev`, `uuid-dev`) | Compiling the bundled vmfs6-tools | Optional (VMFS 6) | Yes | distribution versions |
| `vmfs-tools` | `vmfs-fuse`: mounting VMware VMFS 3 and 5 datastores (tried when `vmfs6-fuse` cannot open the volume) | Optional (VMFS) | Yes; skipped if `vmfs-fuse` is already present | 0.2.5; mounts upstream's VMFS 3 sample volume (clean-install test) |
| `logrotate` | Compresses the backend log monthly | Optional | Yes (normally preinstalled) | 3.21.0 |
| `xdg-utils` | `xdg-open`: the GUI's *Open folder* when no file manager is set | Optional (GUI) | Yes (normally preinstalled on desktops) | distribution version |
| Kernel filesystem drivers (`linux-modules-extra-<kernel>` on Ubuntu) | `exfat`, `ntfs3`, `f2fs`, `hfsplus`, `hfs` (and on some kernels `nbd`) live in this package on Ubuntu; `xfs`, `btrfs`, `udf`, `isofs`, `squashfs`, `vfat` are in the standard kernel | Optional (those filesystems) | Yes: the installer adds it when any of these drivers is missing. Debian's kernel includes them all | 6.8.0 (Ubuntu 24.04) |

**Installing the system packages by hand** (only needed for `--no-apt` setups or troubleshooting):

```sh
sudo apt install util-linux fdisk mount kmod kpartx dmsetup udev ntfs-3g ewf-tools qemu-utils \
     afflib-tools lvm2 libvshadow-utils vmfs-tools psmisc logrotate xdg-utils python3 python3-venv pkexec \
     gcc make libc6-dev pkg-config libfuse-dev uuid-dev
sudo apt install linux-modules-extra-$(uname -r)     # Ubuntu only: exFAT, ntfs3, F2FS, HFS/HFS+ drivers
# vmfs6-tools: build the bundled source (what the installer does); not `apt install vmfs6-tools`
cp -r third_party/vmfs6-tools /tmp/v6 && (cd /tmp/v6 && sh ./configure && make) && \
  sudo install -m 0755 /tmp/v6/vmfs6-fuse/vmfs6-fuse /tmp/v6/debugvmfs6/debugvmfs6 /usr/local/sbin/
```

On Ubuntu, `linux-modules-extra` is per kernel version. After a kernel update, run the installer
again (or the second command above) so the drivers match the new kernel; the installer's checklist
shows any driver that is missing.

On the SIFT Workstation, leave out `ewf-tools` and `libvshadow-utils`: SIFT's own `libewf-tools` and
`libvshadow-tools` provide the same commands and conflict with them.

---

## 4. Compatibility and test matrix

Only the configurations marked **Tested** were actually run for this release. Procedures and
per-test results are in [docs/TESTING.md](docs/TESTING.md).

| Linux distribution | Version | Kernel | Installation | Mounting | Unmounting | Status |
|---|---|---|---|---|---|---|
| Ubuntu (SANS SIFT Workstation VM, GNOME 46 desktop) | 24.04.4 LTS | 6.8.0-101-generic | Pass: upgrade over a pre-1.0 install, all checks `ok` | Pass: raw, dd, img, E01, AFF, VMDK, QCOW2, VHDX, VHD; GPT, MBR, LVM; GUI and CLI | Pass, including busy volumes and a retry | **Tested**, on a real desktop with the real polkit prompt |
| Ubuntu (clean container) | 24.04.5 LTS | 6.6.87.1 (WSL2) | Pass: clean install, reinstall, uninstall | Pass: raw, dd, img, E01, LVM (29/29 CLI and 36/36 GUI integration checks) | Pass | **Tested**, without NBD formats or a desktop |
| Ubuntu (clean container) | 22.04.5 LTS | 6.6.87.1 (WSL2) | Pass: clean install, reinstall, uninstall | Pass: as above | Pass | **Tested**, without NBD formats or a desktop |
| Debian (clean container) | 12 (bookworm) | 6.6.87.1 (WSL2) | Pass: clean install, reinstall, uninstall | Pass: as above | Pass | **Tested**, without NBD formats or a desktop |
| Ubuntu 22.04 / Debian 12 on a desktop or VM | | distribution kernel | | | | Expected to work, **not tested**. VMDK/QCOW2/VHDX/VHD and the GUI on a real desktop were tested only on Ubuntu 24.04. |
| Other Ubuntu/Debian derivatives (Linux Mint, Pop!_OS, Kali, Tsurugi) | | | | | | Expected to work, **not tested** |
| Ubuntu 26.04 and newer | | | | | | **Not tested** |
| Ubuntu 20.04 | | | | | | **Not supported** for the GUI (Python 3.8). The command line may work; not tested. |
| Fedora, RHEL, openSUSE, Arch | | | | | | **Not supported** by the installer, which needs `apt`. The program itself is distribution-neutral; manual installation is untested. |
| Windows Subsystem for Linux (WSL) | | | | | | **Not supported** for real use (no `nbd` module, no desktop polkit agent). The containers above ran on a WSL2 kernel only as a test harness. |
| Containers | | | | | | **Not supported** for real use (needs a privileged container). Used for testing only. |

**Differences between distributions** seen during testing:

- **SIFT Workstation** ships `libewf-tools` and `libvshadow-tools` from its own repository, and the
  installer keeps them. SIFT also ships `/etc/modprobe.d/nbd-client.conf` with `max_part=15`, so NBD
  images get kernel partition devices instead of kpartx mappings. Both paths are read-only and both
  were tested.
- **Ubuntu 22.04** has older tools (util-linux 2.37, qemu 6.2, ewf-tools 20140807). All checks passed.
- **Debian 12** does not set up `sudo` for the first user (see [2.4](#24-install-on-debian-12)).
- **Containers** (testing only) run without udev. Mount Sleuth then creates device nodes itself.

---

## 5. How to use Mount Sleuth

This walkthrough assumes you have never used Mount Sleuth. The screenshots are from Mount Sleuth 1.0.0
on Ubuntu 24.04 (SIFT Workstation) with disposable demo images.

### 5.1 Key ideas in plain English

- **Image:** a file (or set of files) that holds a copy of a disk: `.E01`, `.dd`, `.vmdk` and so on.
- **Partition / volume:** a disk is divided into sections. Each can hold a **filesystem** (NTFS for
  Windows, ext4 for Linux, FAT for USB sticks and EFI, …), which is what holds the files and folders.
- **Mounting:** making a filesystem's contents appear as an ordinary folder you can browse.
- **Read-only:** nothing can be written, changed or deleted through the mount. Mount Sleuth only
  ever mounts read-only.
- **Block device:** a raw, byte-for-byte view of a partition or of the whole disk, for forensic
  tools that read raw data (carvers, The Sleuth Kit). Mount Sleuth provides one for every partition,
  including the ones it cannot mount.
- **Host:** Mount Sleuth treats each first-level subfolder of your evidence folder as one computer
  (a "host"). For example, `Evidence/WEB01/disk.E01` belongs to host `WEB01`.

Organising evidence like this gives the clearest results (any depth below the host folder works):

```
Evidence/
├── WEB01/            ← host
│   └── web01.E01     (plus web01.E02, … for segmented sets)
├── LNX01/
│   └── lnx01.dd
└── WKS03/
    └── wks03.vmdk
```

### 5.2 Launch, and the main window

Open the applications menu and click **Mount Sleuth** (or run `mount-evidence-gui`). The window opens empty:

![Main window, numbered](docs/screenshots/application-main-interface.png)

| # | Area | What it does |
|---|---|---|
| 1 | **Add images / Add folder / Add folder tree** | Put images in the queue: pick individual image files; take every image in one folder; or take every image in a folder and all its subfolders (first-level subfolders become hosts). Adding never attaches anything. |
| 2 | **Discover / Mount selected / Mount all** | **Discover** identifies partitions and filesystems, then releases everything (a preview). **Mount selected** and **Mount all** attach the images read-only and mount every filesystem. |
| 3 | **Unmount selected / Unmount all** | Release images: all of their mounts, devices and folders. Nothing is forced. |
| 4 | **Refresh / Open mount root / Cancel** | Re-read the current state; open `/mnt/MountSleuth` in the file manager; stop a running operation after its current step. |
| 5 | **Log / Settings / Help** | Show or hide the log; change settings; open a short help text. |
| 6 | **Search and filters** | Search by image, path, label, filesystem or mount path (<kbd>Ctrl</kbd>+<kbd>F</kbd>). Filter the volume list by filesystem, by status, or to warnings only. |
| 7 | **Image queue** | One row per image: host, source path, format, size, discovery state, number of partitions, number mounted, status. |
| 8 | **Partitions and volumes** | Every image and, under it, every partition and LVM volume, with its classification, status, filesystem, label, size and mount path. |
| 9 | **Details** | Everything recorded about the selected image or volume (partition offsets, UUIDs, live mount options, …). |
| 10 | **Log** | What happened, with time, level and image. Can be limited to warnings and errors. **Copy selected** and **Save…** export it. |
| 11 | **Status bar** | Totals (images, volumes, mounted, skipped, warnings, failures), the current operation, elapsed time and a **Cancel** button. |

Buttons are greyed out when they do not apply (for example **Unmount all** when nothing is mounted).
Hover over a button to see what it does.

### 5.3 Select your evidence

Click **Add folder tree**. In the folder chooser:

![Choosing the evidence folder](docs/screenshots/select-evidence.png)

1. Press <kbd>Ctrl</kbd>+<kbd>L</kbd> and type the full path of your evidence folder (or navigate into it).
2. Click **Open**.

> **Tip:** in the GNOME folder chooser, if a subfolder is highlighted when you click **Open**, that
> subfolder is chosen instead of the folder you are in. Typing the path with <kbd>Ctrl</kbd>+<kbd>L</kbd>
> avoids this. If the queue shows fewer images than expected, check in the log which folder was added.

The queue fills with every supported image found. Segment files (`.E02`, `.E03`, …) and VMDK data
extents are recognised as parts of their image and are not listed separately.

![Images added to the queue](docs/screenshots/images-added.png)

① the button used; ② one row per image, each still **Queued**: nothing has been attached yet.

To queue single images instead, use **Add images** (<kbd>Ctrl</kbd>+<kbd>O</kbd>) and select the first
file of each image (the `.E01`, not the `.E02`). **Add folder** (<kbd>Ctrl</kbd>+<kbd>Shift</kbd>+<kbd>O</kbd>)
takes the images in one folder without looking into subfolders.

### 5.4 Preview the contents with Discover (optional)

**Discover** looks inside each image without leaving anything mounted, so you can see what is there
before mounting. Click **Discover**. The first privileged action asks for your password:

![The system password prompt](docs/screenshots/authentication-prompt.png)

This prompt comes from your desktop, not from Mount Sleuth. It reads *"Authentication is required to
attach or release forensic images (read-only)"*. Enter **your own** password; it is remembered for a
few minutes.

When discovery finishes, a summary appears and the volume list shows what each image contains:

![Discovery results](docs/screenshots/discover-results.png)

① **Discover**; ② each image expanded into its partitions, with a plain-English classification
("NTFS volume", "MBR extended partition", "LVM physical volume"); ③ **Details** for the selected volume.

Discovery is optional: **Mount all** performs the same identification while it mounts.

### 5.5 Configure the mount (optional)

Click **Settings** (<kbd>Ctrl</kbd>+<kbd>,</kbd>). The defaults suit most cases.

![Settings](docs/screenshots/mount-configuration.png)

| Setting | Default | When to change it |
|---|---|---|
| Default evidence folder | empty | Where the Add dialogs start. |
| Mount root | `/mnt/MountSleuth` | Where mounted evidence appears. Block devices go to `<mount root>_dev`. Locked while anything is mounted. |
| Mount mode | Mount filesystems (and expose block devices) | **Block devices only** attaches the images and writes the report but mounts nothing, for tools that read raw devices. |
| NTFS driver | `ntfs-3g` | `ntfs3` is the in-kernel driver. It is usually faster but was **not tested** for this release. |
| Shadow copies | off | **Experimental:** also mount Windows Volume Shadow Copies. Not validated for this release; see [6.6](#66-volume-shadow-copies-experimental). |
| NBD slots | leave as is | How many VMDK/QCOW2/VHDX/VHD images can be attached at once (installer default: 64). |
| Logging | off | Debug logging records every command the backend runs, for troubleshooting. |
| Privilege elevation | `pkexec` | Change to `sudo` only if your administrator set up a rule for it (see the [FAQ](#10-frequently-asked-questions)). |
| File manager command | empty (desktop default) | A specific file manager for opening folders, e.g. `nautilus`. |
| Columns | off | Show partition name, partition type and UUID columns. |

Read-only cannot be turned off. There is no setting for it, and the backend refuses any request to
mount read-write.

### 5.6 Mount the evidence

Click **Mount all** to mount every queued image, or select images and click **Mount selected**
(<kbd>Ctrl</kbd>+<kbd>M</kbd>). Progress shows in the status bar. **Cancel** stops after the current
step and never leaves anything half-attached. When the operation finishes:

![Mount finished](docs/screenshots/successful-mount.png)

The summary counts images (**ok**, **partial**, **failed**) and volumes (**mounted**, **skipped by
design**, **failed**). "Skipped by design" is not a problem: those partitions have nothing to mount
(see the next step).

### 5.7 Verify that the mount succeeded

Look at the **Status** column. Typing part of an image name in the search box narrows the list:

![Volume statuses for one image](docs/screenshots/volume-statuses.png)

① the search box; ② the status of each partition. What the statuses mean:

| Status | Meaning | Anything to do? |
|---|---|---|
| **Mounted — read-only** (green) | Mounted, and the kernel's live mount table confirms read-only. | No. |
| Not mountable — special partition | Microsoft Reserved or BIOS boot: no filesystem by design. | No. |
| Container — contents listed separately | MBR extended partition or LVM physical volume; its contents appear as their own rows. | No. |
| Linux swap — never activated | Swap space is never activated; read it through its block device. | Optionally carve it. |
| No recognised filesystem | Unformatted, wiped, encrypted with an unknown method, or damaged. | Examine the block device with forensic tools. |
| Encrypted — additional access required (amber) | BitLocker or LUKS. Mount Sleuth identifies these but does not unlock them. | Unlock with dedicated tools if you hold the key. |
| Mount failed — *reason* (red) | For example `dirty`, `hibernated`, `damaged`, `missing dependency`. | See [Troubleshooting](#9-troubleshooting). |
| Block device only (read-only) | Block-devices-only mode: attached, not mounted. | No. |
| Unmounted (grey) | Was mounted; no longer is. | No. |
| MOUNTED READ-WRITE — investigate | A mount without the read-only flag. The backend refuses and removes such mounts, so you should never see this. | Stop and investigate. |

Select a volume to see everything recorded about it in **Details**, including the live mount
options (`ro,…`):

![Volume details](docs/screenshots/volume-details.png)

Each mounted image also gets two report files in its folder (`/mnt/MountSleuth/<host>/<image>/`):
`image_info.txt` (human-readable) and `mount_manifest.json` (machine-readable). Right-click →
**View manifest…** shows both.

### 5.8 Access the mounted contents

- **Double-click** a mounted volume, or right-click it → **Open mount folder**, to open it in the file manager:

  ![A mounted NTFS volume in the file manager](docs/screenshots/mounted-evidence.png)

- Right-click for more:

  ![Right-click menu](docs/screenshots/context-menu.png)

  ① open or copy the mount path or the read-only block-device path, open the image's folder, view
  the report; ② unmount this image.

- Mounted evidence lives at `/mnt/MountSleuth/<host>/<image>/<partition>/`, for example
  `/mnt/MountSleuth/WEB01/web01.E01/p03_ntfs_OS/`. Folder names start with the partition number and
  filesystem (`p03_ntfs_OS` = partition 3, NTFS, label "OS"). Point any tool (scanners, parsers,
  `grep`, a file manager) at these folders.
- Read-only block devices for raw tools are under `/mnt/MountSleuth_dev/<host>/<image>/`: `disk` is
  the whole disk, and each partition has its own entry, including those that could not be mounted.
- On ext4 and XFS volumes, files keep their original owners and permissions, so some folders say
  "permission denied" to your user. Read them with `sudo` (they are still read-only). NTFS and FAT
  volumes are readable by everyone.

> **Do not use the desktop's own drive controls on evidence.** GNOME lists mounted evidence volumes
> as drives in the dock and in the file manager's sidebar, and may offer to "unlock" encrypted
> partitions. Do not eject, unlock or mount evidence from there: that bypasses Mount Sleuth's
> read-only checks and its records. Use Mount Sleuth's Unmount buttons.

### 5.9 Unmount safely when finished

1. Close every program that has files open on the evidence: file-manager windows showing a mounted
   folder, terminals whose current folder is inside a mount, viewers, scanners.
2. Click **Unmount all** (or select images and click **Unmount selected**, <kbd>Ctrl</kbd>+<kbd>U</kbd>).
   Confirm:

   ![Unmount confirmation](docs/screenshots/unmount-confirm.png)

3. The result is reported. If a program still had files open, that image **stays attached**.
   Nothing is ever forced, so a running tool never has evidence pulled out from under it:

   ![Two images still busy](docs/screenshots/unmount-busy.png)

   Set the log's **Show** to **Warnings and errors** to see which volumes are busy. Hover over a
   "cannot unmount" line (or select it and use **Copy selected**) to see which programs hold it:

   ![Busy volumes in the log](docs/screenshots/unmount-busy-log.png)

4. Close those programs and click **Unmount all** again:

   ![All released](docs/screenshots/unmount-operation.png)

When everything is released, the image rows show **Unmounted** and `/mnt/MountSleuth` is empty.

**Closing the window** while images are mounted asks what to do: **Leave mounted** (they stay
usable and reappear the next time you start Mount Sleuth), **Unmount and close**, or **Cancel**.
Images mounted from the command line also appear in the GUI, and the other way round.

---

## 6. Features and capabilities

Everything in this section is in the 1.0.0 Linux release unless marked otherwise.

### 6.1 Image formats

| Format | Extensions | How it is opened | 1.0.0 status |
|---|---|---|---|
| Raw / dd | `.raw` `.dd` `.img` `.bin` | Read-only loop device | Tested (`.bin` shares the code; no test image) |
| Expert Witness (EnCase) | `.E01` (+ `.E02`…) | `ewfmount` (FUSE, mounted read-only) → read-only loop | Tested with a single segment. Segmented sets use the same code but were not tested. |
| EWF variants | `.Ex01` `.L01` `.S01` | As E01 | Recognised, **not tested**. L01/Lx01 hold logical files, not a disk, and will not produce partitions. |
| AFF | `.aff` (`.afd` `.afm`) | `affuse` (FUSE, mounted read-only) → read-only loop | `.aff` tested; `.afd`/`.afm` not tested |
| VMware | `.vmdk` (sparse, and descriptor + flat) | `qemu-nbd --read-only` | Tested with images made by `qemu-img` |
| QEMU | `.qcow2` `.qcow` | `qemu-nbd --read-only` | `.qcow2` tested |
| Hyper-V / Virtual PC | `.vhdx` `.vhd` | `qemu-nbd --read-only` | Tested with images made by `qemu-img` |

**Why it is useful:** one workflow for every common format, with no per-format commands to remember.
**How to access it:** automatic, by file extension.
**Limitations:** formats are recognised by extension, so rename misnamed files (for example a raw
image called `.001`) to a supported extension. Split raw sets (`.001`, `.002`, …) are not supported;
join them first.

### 6.2 Partition and filesystem discovery

**What it does:** reads GPT and MBR partition tables (including MBR logical partitions), or treats a
disk without a partition table as one volume, and identifies each filesystem by its on-disk signature.
Each partition gets a plain-English classification and a status. Partition type and filesystem are
cross-checked, and disagreements are recorded as **discrepancies** instead of being resolved silently
(for example an EFI partition without a FAT filesystem).
**Why it is useful:** you see the whole disk, including what cannot be mounted and why.
**How to access it:** Discover, or automatically during Mount. **Options:** none.
**Limitations:** Apple partition maps and BSD disklabels are not interpreted (the whole disk is still
available as a block device).

### 6.3 Read-only mounting

**What it does:** mounts every recognised filesystem read-only, with the options that prevent
journal replay:

| Filesystem | Options used | Tested for 1.0.0 |
|---|---|---|
| NTFS | `ntfs-3g` `ro` (or the kernel's `ntfs3` `ro`) | ntfs-3g yes; ntfs3 no |
| FAT12/16/32, EFI | `vfat` `ro` | Yes |
| exFAT | `exfat` `ro` | Detection yes; mounting not tested |
| ext2/3/4 | `ro,noload` (no journal replay) | ext4 yes |
| XFS | `ro,norecovery,nouuid` | No |
| Btrfs | `ro,rescue=nologreplay` | No |
| F2FS, HFS+, HFS, UDF, ISO 9660, SquashFS | `ro` (plus no-recovery where the driver has it) | No |
| VMware VMFS | `vmfs6-fuse -o ro` (VMFS 6), then `vmfs-fuse -o ro` (VMFS 3/5) | No |

**Why it is useful:** the filesystem is shown as it is on disk. Nothing is repaired, replayed or updated.
**How to access it:** Mount selected / Mount all. **Options:** NTFS driver (Settings).
**Limitations:** because journals are not replayed, very recent changes still sitting in a journal
are not visible in the mounted view. A Windows volume that was hibernated or used Fast Startup is
mounted read-only with a note that `hiberfil.sys` holds data that is not in the view. "Dirty" NTFS
volumes are not flagged.

### 6.4 Read-only block devices for every partition

**What it does:** every partition (mounted or not), every LVM volume and the whole disk are exposed as
read-only block devices under `/mnt/MountSleuth_dev/<host>/<image>/`.
**Why it is useful:** forensic tools that read raw data (The Sleuth Kit's `fls`/`icat`/`blkls`,
`bulk_extractor`, carvers) can analyse unallocated space, slack, swap, and encrypted or unknown
partitions. Gaps between partitions are listed in `image_info.txt` as "Unallocated regions".
**How to access it:** right-click → **Copy block device path** / **Open block-device folder**.
**Options:** *Block devices only* mode attaches everything and writes the report without mounting.
Examples: [docs/REFERENCE.md](docs/REFERENCE.md#block-devices-slack-and-unallocated-space).

### 6.5 Linux LVM

**What it does:** finds logical volumes on LVM physical volumes from the LVM metadata (read with
`--readonly`) and maps them itself, read-only. Linear and striped volumes are supported. Images
cloned from the same system (same volume group names and UUIDs, even matching the workstation's own)
mount side by side.
**Why it is useful:** the standard LVM tools would activate volume groups system-wide, could clash
with the examiner's own LVM, and refuse duplicate UUIDs.
**Limitations:** thin, RAID and cache volumes, and volume groups spread over several images, are
reported but not mapped. Striped volumes are covered by unit tests only.

### 6.6 Volume Shadow Copies (experimental)

**What it does:** detects and reports the number of Windows Volume Shadow Copies on every NTFS
volume. With **Settings → Shadow copies** (CLI: `--vss`), each snapshot is also mounted read-only as
`pNN_…_vssNN`.
**Status:** detection was tested (on volumes with no snapshots). Mounting snapshots is
**experimental and was not validated** for 1.0.0 because no test image with real snapshots was
available. Cross-check the results with another tool before relying on them.

### 6.7 Special, encrypted and unsupported partitions

Microsoft Reserved, BIOS boot, MBR extended containers, Linux swap, BitLocker, LUKS, software RAID
members, Windows dynamic disks (LDM) and Storage Spaces are identified and reported with a reason,
and their block devices stay available. They are never unlocked, assembled, activated or mounted.
Unlocking encrypted volumes and assembling RAID, LDM or Storage Spaces are **not part of this release**.

### 6.8 Reports: manifest and image information

**What it does:** for every mounted image, `mount_manifest.json` and `image_info.txt` in
`/mnt/MountSleuth/<host>/<image>/` record the format, size and partition table, and every volume:
offsets, sizes, types, labels, UUIDs, status and reason. They also record the mount options actually
in effect (read from the kernel), discrepancies and unallocated regions. E01 acquisition metadata
from `ewfinfo` (case number, examiner, acquisition hashes) and VMDK/QCOW2 metadata from `qemu-img info`
are included too.
**Why it is useful:** a record for your notes of what was mounted, how, and what was skipped.
**How to access it:** right-click → **View manifest…**, or open the files directly. They are removed
when the image is unmounted, so copy them to your case folder if you need to keep them. Field
reference: [docs/REFERENCE.md](docs/REFERENCE.md#example-output).

### 6.9 Safe, recorded teardown

**What it does:** every device, mapping, FUSE helper, mount, folder and link is recorded in a journal
(`.mount_state.json`) the moment it is created. Unmount releases exactly those, newest first, and
nothing else on the system. Busy volumes are never forced; the programs holding them are named.
Interrupted runs (Cancel, Ctrl-C, even a crash of the tool) leave a journal that the next Unmount
uses to clean up.
**Why it is useful:** no stray loop devices or mounts, and the examiner's own disks, LVM volumes and
mounts are never touched.
**How to access it:** Unmount selected / Unmount all; CLI `--unmount`. Command-line-only option:
`--lazy` detaches busy mounts lazily; their devices are released when the last program closes them.
**Limitation:** unmounting works per image, not per volume.

### 6.10 Bulk operation and organisation

You can queue hundreds of images. Host and image folders are named from your evidence folder
structure, and the same names come out on every run. Images that are already mounted are skipped.
One operation runs at a time: a system-wide lock keeps a command-line run and the GUI from colliding.

### 6.11 GUI conveniences

Search and filters; sortable columns; live status (the GUI watches the kernel's mount table, so a
volume unmounted elsewhere shows as Unmounted at once); log export (**Save…** as TSV); copying of
paths and details; images mounted in an earlier session or from the command line appear
automatically; optional columns for partition name, type and UUID.

### 6.12 Planned for future releases (not in 1.0.0)

- Windows support.
- Unlocking BitLocker/LUKS volumes read-only with a key the examiner supplies.
- Assembling software RAID, LDM and multi-image LVM volume groups.
- Per-volume unmount.
- Flagging "dirty" NTFS volumes.
- Validation of VSS mounting, segmented E01 sets, and images produced natively by VMware and Hyper-V.

---

## 7. Security and forensic considerations

### 7.1 How evidence is handled

Mount Sleuth reads evidence. It does not copy, convert, index or hash it. The chain for each image is:

```
image file ──(read-only)──▶ loop device, or NBD device (qemu-nbd --read-only),
                            or FUSE view (ewfmount -X ro / affuse -o ro), then a read-only loop
           ──▶ read-only partition mappings (kpartx -r, dmsetup --readonly)
           ──▶ filesystem mounted ro, without journal replay
```

### 7.2 What is enforced and checked at run time

| Protection | Enforced by | Checked |
|---|---|---|
| Image file opened read-only | `losetup --read-only`, `qemu-nbd --read-only`, read-only FUSE helpers | The FUSE mounts show `ro` in `/proc/mounts` (verified in testing) |
| Every block device is read-only | Read-only loop, NBD and device-mapper devices | `blockdev --getro` must report read-only **before** any mount, or the volume is refused (`safety`) |
| Every mount is read-only | `ro` in every mount option set, plus `noload`/`norecovery`/`nologreplay` | After mounting, the kernel's mount table must show `ro`, or the volume is unmounted at once and reported (`safety`). The GUI shows "Mounted — read-only" only from the live mount table. |
| Read-write cannot be requested | No option exists; the old `-w` flag is refused | Integration test |
| No repairs | `fsck`, `ntfsfix`, `swapon`, `vgchange` and `mdadm --assemble` are never run | Code review |
| LVM metadata is never written | `lvs`/`pvs --readonly` with `metadata_read_only=1` and a filter that shows only the image's devices | Integration test |
| Workstation storage is untouched | Teardown releases only journaled resources | Integration test with a busy host device-mapper device and a host volume group of the same name |

**Test evidence:** in every 1.0.0 test run (three clean distributions plus the Ubuntu 24.04 VM),
the SHA-256 of every evidence file was identical before and after discovery, mounting, busy unmount,
cancel and unmount. See [docs/TESTING.md](docs/TESTING.md).

### 7.3 What Mount Sleuth does **not** guarantee

- **It does not verify image integrity.** It cannot tell whether an image is complete or unaltered
  since acquisition. A truncated or corrupt image is reported as `damaged` only when its device cannot
  be read at all; otherwise it may simply show fewer filesystems, or none. Verify images with
  `ewfverify` or the acquisition hashes **before** relying on them.
- **The image file's access time may change.** Opening an image read-only does not change its
  contents, but the filesystem that *stores* the image may update the file's last-access timestamp
  (Ubuntu's default `relatime` does so at most once a day). To prevent even that, keep evidence on a
  volume mounted read-only or with `noatime`, or behind a hardware write blocker.
- **Mounted views leave out pending journal data** (see [6.3](#63-read-only-mounting)).
- **Root privileges are involved.** The backend runs as root. Anyone who can run it (through the
  GUI's password prompt or a sudo rule) can mount, read-only, any image file on the computer.
- **Other programs can bypass it.** The desktop's own drive controls, or any administrator, can still
  act on the attached devices. The kernel refuses writes to them, but unlocking an encrypted partition
  through the desktop, for example, happens outside Mount Sleuth. See the warning in
  [5.8](#58-access-the-mounted-contents).

### 7.4 Files Mount Sleuth creates

Mount Sleuth writes **nothing next to your evidence**. It creates:

| Location | Contents | Lifetime |
|---|---|---|
| `/mnt/MountSleuth/<host>/<image>/` | Mount folders, `mount_manifest.json`, `image_info.txt`, `.mount_state.json` (journal) | Removed at unmount |
| `/mnt/MountSleuth_dev/<host>/<image>/` | Links to read-only block devices; FUSE helper mounts for E01/AFF | Removed at unmount |
| `/run/mount_evidence/dry/` | Temporary journals and helper mounts during Discover | Removed after each Discover; `/run` is cleared at reboot |
| `/run/lock/mount_evidence.lock` | Lock file (one operation at a time) | Cleared at reboot |
| `/var/log/mount_evidence.log` | Log of every run (every command, with debug logging) | Kept; compressed monthly, never deleted by Mount Sleuth |
| `~/.config/MountSleuth/mount-evidence-gui.conf` | GUI settings and window layout (no case data, no passwords) | Kept |

### 7.5 Recommended evidence-handling practice

1. Work from a **verified working copy**, and keep the original on write-protected media.
2. Record the image's hash before you start (`sha256sum image.E01`, or `ewfverify image.E01`).
3. Where possible, keep evidence on a volume mounted read-only (`sudo mount -o remount,ro /path`) or
   behind a write blocker.
4. Use **Discover** first on unfamiliar images.
5. Copy `image_info.txt` and `mount_manifest.json` into your case notes if you need a record of what
   was mounted; they are deleted at unmount.
6. Unmount when you are finished, and confirm that `/mnt/MountSleuth` is empty.
7. Re-verify the image hash at the end if your procedures require it.

---

## 8. Command line

The command line uses the same engine as the GUI. It is useful on servers, over SSH and in scripts.

```sh
sudo mount-evidence /cases/2026-001/Evidence                    # mount everything read-only
sudo mount-evidence -d /cases/2026-001/Evidence                 # dry run (= Discover): identify, mount nothing
sudo mount-evidence /cases/2026-001/Evidence/WEB01/web01.E01    # one image
sudo mount-evidence --block-only /cases/2026-001/Evidence       # devices and report only
sudo mount-evidence --status                                    # what is mounted now
sudo mount-evidence --unmount                                   # release everything this tool mounted
sudo mount-evidence --unmount --lazy                            # … detaching busy mounts lazily
mount-evidence --version
sudo mount-evidence --help                                      # all options
```

| Option | Meaning |
|---|---|
| `-o DIR`, `--mount-base DIR` | Mount root (default `/mnt/MountSleuth`) |
| `--dev-base DIR` | Block-device folder (default `<mount root>_dev`) |
| `-d`, `--dry-run` | Identify only; leave nothing attached |
| `--block-only` | Attach and record, mount nothing |
| `--vss` | Experimental: also mount Volume Shadow Copies |
| `--ntfs-driver ntfs-3g\|ntfs3` | NTFS driver |
| `-u`, `--unmount`; `--lazy` | Release everything recorded under the mount root; detach busy mounts lazily |
| `--status` | List what is attached |
| `--nbd-max N` | Reload `nbd` with N slots first |
| `-l FILE`, `--log FILE` | Log file (default `/var/log/mount_evidence.log`) |
| `-v`, `--verbose` | Debug output |
| `-V`, `--version` | Print the engine version |

**Exit codes:** `0` everything succeeded (skipped-by-design partitions are not failures); `1`
something needs attention (a failed image or volume, a busy unmount, missing tools); `2` usage
error; `130` interrupted (run `--unmount` to release what was attached).

The GUI and the command line share `/mnt/MountSleuth` by default and see each other's mounts. Full
reference: [docs/REFERENCE.md](docs/REFERENCE.md).

---

## 9. Troubleshooting

Start with the **Log** (set **Show** to *Warnings and errors*) or `/var/log/mount_evidence.log`.
For more detail, turn on **Settings → Logging → Debug logging** (CLI: `-v`) and repeat the operation.
Each entry below gives the symptom, the likely cause, the fix and, where useful, a diagnostic command.

### Installation

**The installer stops with "run as root"**
- *Cause:* it was started without `sudo`.
- *Fix:* `sudo sh scripts/install.sh`.

**"run from an unpacked Mount Sleuth folder"**
- *Cause:* the installer was copied out of its folder, or the download is incomplete.
- *Fix:* run `sudo sh scripts/install.sh` from the top folder of the download (the one containing `README.md`).

**A checklist line says `FAIL`, or the installer prints "Install INCOMPLETE"**
- *Cause:* a required tool could not be installed (no network, a broken apt source, a package conflict).
- *Fix:* look for `WARNING: apt could not install …` further up, fix apt (`sudo apt update` must succeed), and run the installer again.
- *Diagnose:* `sudo apt update; apt-cache policy kpartx dmsetup`

**"ERROR: could not install PySide6-Essentials==6.11.0"**
- *Cause:* no access to the Python package index (offline, proxy, firewall).
- *Fix:* use the offline procedure in [2.5](#25-offline-installation-air-gapped-labs). The command line already works without it.
- *Diagnose:* `python3 -m pip download PySide6-Essentials==6.11.0 -d /tmp/w`

**`warn  nbd kernel module loaded`**
- *Cause:* the running kernel has no `nbd` module (some cloud and minimal kernels, WSL).
- *Fix:* `sudo apt install linux-modules-extra-$(uname -r)`, then `sudo modprobe nbd`. Without it, everything except VMDK/QCOW2/VHDX/VHD works.

**`warn  vmfs6-fuse runs`, or a VMFS mount fails with `vmfs6-fuse: crashed (signal 11)`**
- *Cause:* the bundled vmfs6-tools did not build (build tools missing, for example with `--no-apt`), so the distribution's `vmfs6-fuse` is used, which crashes on every run.
- *Fix:* `sudo apt install gcc make libc6-dev pkg-config libfuse-dev uuid-dev`, then run the installer again. The distribution's `vmfs6-tools` package can stay installed; Mount Sleuth uses the build in `/usr/local/sbin`.
- *Diagnose:* `ls -l /usr/local/sbin/vmfs6-fuse; sudo grep -A1 'CMD: vmfs' /var/log/mount_evidence.log | tail -4`

**`… is not in the sudoers file` (Debian)** — see [2.4](#24-install-on-debian-12).

### Starting the GUI

**Mount Sleuth is not in the applications menu**
- *Fix:* log out and back in, or run `mount-evidence-gui` in a terminal.
- *Diagnose:* `ls /usr/share/applications/mount-evidence-gui.desktop`

**"PySide6 is required" when starting**
- *Cause:* the GUI's Python environment is missing or incomplete.
- *Fix:* run `sudo sh scripts/install.sh` again.
- *Diagnose:* `/opt/mount-evidence-venv/bin/python3 -c 'import PySide6; print(PySide6.__version__)'`

**"PySide6 6.12.0 has a reference-counting bug"**
- *Cause:* a broken PySide6 version is in use (only possible after `--no-venv`).
- *Fix:* run the installer again without `--no-venv`.

**The log warns "The GUI itself is running as root"**
- *Cause:* it was started with `sudo`. *Fix:* close it and start it as your normal user.

### Permissions and the password prompt

**"Authorisation was dismissed or refused (pkexec)"**
- *Cause:* the password prompt was cancelled. *Fix:* repeat the operation and enter your password.

**"Not authorised, or no polkit authentication agent is running (pkexec)"**
- *Cause:* a wrong password; an account that is not an administrator; or a session with no authentication agent (minimal window managers, remote X sessions, or the GUI started from an SSH session).
- *Fix:* start Mount Sleuth from the desktop's own menu. On minimal window managers, start an agent (`lxpolkit`, or `/usr/lib/policykit-1-gnome/polkit-gnome-authentication-agent-1`). Alternatively, ask your administrator for a sudo rule and set **Settings → Privilege elevation** to `sudo` (see the [FAQ](#10-frequently-asked-questions)).
- *Diagnose:* `groups` should list `sudo`.

**"sudo -n needs a NOPASSWD rule for the backend"**
- *Cause:* elevation is set to `sudo`, but no rule exists. *Fix:* switch back to `pkexec`, or add the rule (see the [FAQ](#10-frequently-asked-questions)).

**"pkexec is not installed"** — `sudo apt install pkexec` (running the installer again also fixes it).

**"Another mount_evidence is running (pid N); wait for it to finish"**
- *Cause:* another Mount Sleuth operation (GUI or command line) is running. *Fix:* wait for it to finish.

**"Must run as root: sudo mount-evidence …"** — the command line was run without `sudo`.

### Adding and mounting

**"No forensic images found" / "no supported images in …"**
- *Cause:* the folder holds no files with supported extensions, or a subfolder was chosen by mistake (see the tip in [5.3](#53-select-your-evidence)).
- *Fix:* check the extensions in [6.1](#61-image-formats); rename misnamed files.

**"cannot read folder …: permission denied" when adding**
- *Cause:* the GUI lists folders as your user. *Fix:* make the evidence readable to your account (it is only read), for example `sudo chmod -R a+rX /path/to/working-copy`.

**"ewfmount not found (apt install ewf-tools)", "qemu-nbd not found", or `[missing_dependency]`**
- *Cause:* the optional tool for that format is not installed. Other images still mount.
- *Fix:* run the installer again, or install the package named in the message.

**"NBD devices missing and modprobe nbd failed"** — see `warn  nbd kernel module loaded` above.

**"all NBD slots in use"**
- *Cause:* more VMDK/QCOW2/VHDX/VHD images attached than there are slots. *Fix:* unmount some, or raise **Settings → NBD slots** (or `sudo sh scripts/install.sh --nbd-max 128`).

**Mount failed — `dirty` or `hibernated`**
- *Cause:* Windows was not shut down cleanly, or was hibernated or used Fast Startup. Mount Sleuth never repairs a volume.
- *Fix:* analyse the volume through its block device with forensic tools (The Sleuth Kit reads it as is), or mount a separate *working copy* with your own procedures.

**Mount failed — `damaged`, or "the disk device could not be read … truncated or corrupt"**
- *Cause:* the image or its filesystem structures cannot be read (incomplete download or copy, bad media).
- *Fix:* verify the image (`ewfverify image.E01`, or compare its hash with the acquisition record). Copy or acquire it again.

**Mount failed — `missing_dependency: no driver for this filesystem`**
- *Cause:* the kernel lacks that filesystem driver (for example exFAT or HFS+ on a minimal kernel).
- *Diagnose:* `grep -w exfat /proc/filesystems; modinfo exfat`. *Fix:* on Ubuntu, `sudo apt install linux-modules-extra-$(uname -r)` (or run the installer again); on other distributions, install the full kernel modules package.

**Mount failed — `collision`**
- *Cause:* the same filesystem identity is already mounted (some cloned Btrfs disks), or a folder name collides. *Fix:* unmount the other image first.

**"No recognised filesystem" on a partition you expected to mount**
- *Cause:* it is encrypted with an unknown method, wiped, unformatted or damaged. *Fix:* examine its block device (right-click → **Copy block device path**) with forensic tools.

**Warnings such as "sfdisk: GPT PMBR size mismatch … will be corrected by write" or "The backup GPT table is not on the end of the device"**
- *Cause:* common with VHD files and with images of disks that were resized after partitioning. These messages come from `sfdisk`, which Mount Sleuth uses only to *read* the table (`sfdisk --json`). **Nothing is written**, and the partitions are still found.
- *Fix:* none needed; note it in your records if relevant.

**An image shows "Recorded but nothing attached (stale)"**
- *Cause:* the computer was restarted (or the devices were removed some other way) while images were mounted. *Fix:* click **Unmount**; it clears the record.

**"… is in use by another image"**
- *Cause:* two different image files would use the same host/image folder. *Fix:* unmount the other one first, or rename one of the files.

**The first mount after copying images is slow**
- *Cause:* first-time device and metadata caching. Later mounts are faster. This is not a fault.

### Unmounting

**"Still attached (busy)" / "cannot unmount … target is busy"**
- *Cause:* a program has a file or folder open inside the mount: a file-manager window, a terminal whose current folder is inside it, a viewer, a running scan.
- *Fix:* close it and unmount again. Mount Sleuth never forces an unmount.
- *Diagnose:* `sudo fuser -vm /mnt/MountSleuth/HOST/IMAGE/p03_ntfs_OS` lists the programs (`sudo lsof +D <folder>` is slower but more detailed).
- *Last resort (command line):* `sudo mount-evidence --unmount --lazy` detaches the folders now and releases the devices when the programs exit.

**"Still present and not released (check before removing)"**
- *Cause:* something under Mount Sleuth's folders that is in no record (for example a mount made by hand). Mount Sleuth only reports it, with the command that would remove it. Check what it is before running that command.

**A volume shows "Unmounted" but its image still shows as mounted** — another program or user unmounted that volume by hand. Click **Unmount** on the image to release the rest.

### Unexpected behaviour

**The window does not update** — click **Refresh** (<kbd>F5</kbd>).

**Collecting information for a bug report**

```sh
mount-evidence --version; cat /usr/local/lib/mount-evidence/VERSION
grep PRETTY_NAME /etc/os-release; uname -r
sudo mount-evidence --status
sudo tail -n 200 /var/log/mount_evidence.log
```

In the GUI: **Log → Show: Everything → Save…**. Remove case-sensitive paths before sharing.

---

## 10. Frequently asked questions

**Will Mount Sleuth change my evidence?**
No. The image is opened read-only at every layer, and every mount is verified as read-only. Repeated
tests confirmed that image hashes do not change. The one thing outside its control is the *access
timestamp* of the image file on your storage (see [7.3](#73-what-mount-sleuth-does-not-guarantee)).

**Does it verify my image's hash?**
No. Use `ewfverify` or your acquisition hashes. E01 acquisition metadata (including the stored hashes)
is copied into the report for reference.

**Can I mount read-write to recover or change something?**
No, deliberately. Make a separate working copy and use your own procedures on it.

**Why does it ask for my password?**
Attaching disk images is an administrator operation on Linux. The window runs as you; only the small
backend runs with administrator rights, and only for the operation you asked for.

**Can I avoid the password prompt?**
An administrator can let members of a group run the backend without a password; then choose
**Settings → Privilege elevation → sudo**:

```sh
sudo visudo -f /etc/sudoers.d/mount-evidence
# add this line:  %forensics ALL=(root) NOPASSWD: /usr/local/sbin/mount-evidence
```

Only do this for people who are allowed to read any image on the computer.

**Where are my files after mounting?**
Under `/mnt/MountSleuth/<host>/<image>/`. Double-click a mounted volume, or use **Open mount root**.

**Why are some partitions not mounted?**
They have no filesystem to mount (Microsoft Reserved, extended containers, swap), are encrypted, or
are damaged. Each has a status, a reason and a read-only block device for forensic tools.

**Can I open BitLocker or LUKS volumes?**
Not in this release. They are identified, and their block devices are available for dedicated tools.

**Can I see deleted files?**
Not through the mounted folders, which show only existing files. Use forensic tools on the read-only
block devices (`fls -r`, `icat`, carving).

**What happens if I close the window while images are mounted?**
You are asked whether to leave them mounted, unmount and close, or cancel. If you leave them mounted,
they stay usable and reappear in Mount Sleuth the next time it starts.

**What happens after a reboot?**
All mounts and devices disappear with the reboot; the evidence is not affected. Mount Sleuth shows
the old records as *stale*; click **Unmount** to clear them.

**Can several people use it on the same computer at once?**
Operations run one at a time, and everyone sees the same mount root. It is designed for one examiner
per workstation.

**How many images can I mount?**
Raw, E01 and AFF images are limited only by system resources. VMDK/QCOW2/VHDX/VHD images are limited
by the NBD slots (64 by default); twenty NBD images at once were tested during development.

**Does it work over SSH, or on a server without a desktop?**
Yes, with the command line (`sudo mount-evidence …`). The GUI needs a desktop session.

**Is my data sent anywhere?**
No. Mount Sleuth makes no network connections. The installer downloads packages from your
distribution's mirrors and PySide6 from the Python package index.

---

## 11. Uninstalling, updating and maintenance

### 11.1 Uninstall

1. Unmount everything first (**Unmount all**, or `sudo mount-evidence --unmount`).
2. From the Mount Sleuth folder: **(sudo)**

   ```sh
   sudo sh scripts/install.sh --uninstall
   ```

   This removes the program, the commands, the menu entry, the polkit policy, the `nbd` boot
   configuration and the log-rotation rule.
3. Optionally, remove the GUI's Python environment, the logs and your settings:

   ```sh
   sudo rm -rf /opt/mount-evidence-venv
   sudo rm -f /var/log/mount_evidence.log*        # only if your procedures allow deleting logs
   rm -rf ~/.config/MountSleuth
   ```

4. **Dependencies** stay installed because other forensic tools often use them. To remove them,
   review the list first. Do **not** remove `util-linux`, `fdisk`, `mount`, `kmod`, `dmsetup`,
   `python3` or the Qt/X libraries, which the system itself needs:

   ```sh
   sudo apt remove kpartx ewf-tools qemu-utils afflib-tools libvshadow-utils
   ```

### 11.2 Update to a newer release

1. Unmount everything.
2. Get the new version: `cd ~/mount-sleuth && git pull` (or unpack the new archive).
3. Read [CHANGELOG.md](CHANGELOG.md).
4. Run the installer again: `sudo sh scripts/install.sh`. Your settings are kept.

### 11.3 Where Mount Sleuth keeps its files

| Path | What |
|---|---|
| `/usr/local/lib/mount-evidence/` | Program, README, docs, version |
| `/usr/local/sbin/mount-evidence` | Command line (runs as root) |
| `/usr/local/bin/mount-evidence-gui` | GUI launcher |
| `/opt/mount-evidence-venv/` | Python environment with PySide6 |
| `/usr/share/applications/mount-evidence-gui.desktop` | Menu entry |
| `/usr/share/polkit-1/actions/local.mount-sleuth.mount-evidence.policy` | Password-prompt policy |
| `/etc/modprobe.d/mount-sleuth-nbd.conf`, `/etc/modules-load.d/mount-sleuth-nbd.conf` | `nbd` settings and loading at boot |
| `/etc/logrotate.d/mount-sleuth` | Log compression rule (monthly, never deletes) |
| `/var/log/mount_evidence.log` | **Log** of every operation |
| `~/.config/MountSleuth/mount-evidence-gui.conf` | **GUI settings** |
| `/mnt/MountSleuth/`, `/mnt/MountSleuth_dev/` | Mounted evidence and block devices (empty when nothing is mounted) |

### 11.4 Reporting bugs and requesting features

Open an issue in this repository's issue tracker. Include the Mount Sleuth and engine versions, the
distribution and kernel, what you did, what you expected, what happened, and the relevant log lines
(see *Collecting information for a bug report* in [Troubleshooting](#9-troubleshooting)).
**Never attach evidence or unredacted case data.**

---

## 12. Project information

**Versioning.** Mount Sleuth follows [Semantic Versioning](https://semver.org/) (`MAJOR.MINOR.PATCH`).
The release number is in [`VERSION`](VERSION) and appears in the GUI's log and Help; releases are
tagged `vX.Y.Z`. The backend reports its own engine version (`mount_evidence 2.0`), which is recorded
in every manifest and changes only when the engine changes.

**Repository layout.**

```
mount-sleuth/
├── README.md              this document
├── CHANGELOG.md           release notes
├── VERSION                release number
├── src/
│   ├── mount_evidence_prod.py   backend and command line (runs as root)
│   ├── mount_evidence_gui.py    desktop GUI (runs as the user)
│   └── mount-sleuth.png         application icon
├── scripts/
│   ├── install.sh         installer, updater and uninstaller
│   └── bench_mount.sh     read-only performance measurement of a mounted volume
├── tests/                 unit tests, privileged integration tests, clean-install test, fixture builder
├── third_party/
│   ├── README.md          where the bundled source comes from, its licence and our change
│   └── vmfs6-tools/       VMFS 6 tools (GPL-2.0), built by install.sh
└── docs/
    ├── REFERENCE.md       backend and command-line reference
    ├── GUI.md             GUI internals and privilege model
    ├── TESTING.md         test procedures and the 1.0.0 test record
    └── screenshots/       images used in this README
```

**Running the tests.** The unit tests need no privileges:
`QT_QPA_PLATFORM=offscreen /opt/mount-evidence-venv/bin/python3 -m unittest discover -s tests`
(any Python with PySide6 works). The integration tests create devices and must run only on a
disposable machine or in a privileged container; see [docs/TESTING.md](docs/TESTING.md).

**License.** No license has been chosen for this release yet. Until a `LICENSE` file is added, ask
the maintainer before redistributing or modifying Mount Sleuth.
