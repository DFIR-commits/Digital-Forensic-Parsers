REQUIRES := libvmfs fuse
