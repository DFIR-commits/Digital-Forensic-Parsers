# Third-party source

## vmfs6-tools

`vmfs6-tools/` is [github.com/teward/vmfs6-tools](https://github.com/teward/vmfs6-tools) at commit
`582b5252d74ff96102220af62202a3548fe7128f` (tag `0.2.1`), licensed GPL-2.0 (`vmfs6-tools/LICENSE`).
It is the same source Debian and Ubuntu package as `vmfs6-tools 0.2.1`.

`scripts/install.sh` builds `vmfs6-fuse`, `debugvmfs6`, `fsck.vmfs6` and `vmfs6-lvm` from it into
`/usr/local/sbin`, instead of installing the distribution package.

**Why not the distribution package:** the `vmfs6-fuse` option table has no `FUSE_OPT_END`
terminator, so libfuse reads past the end of it. Whether that crashes depends on what the compiler
places after the table. The Ubuntu 24.04 package (`0.2.1-1build2`) crashes on every run with a
segmentation fault in `fuse_opt_parse`, before it reads the volume.

**Change from upstream** (the only one; `git log third_party/vmfs6-tools` shows it):

```diff
--- vmfs6-fuse/vmfs6-fuse.c
+++ vmfs6-fuse/vmfs6-fuse.c
@@ static const struct fuse_opt vmfs_fuse_args[] = {
   FUSE_OPT_KEY("-d", FUSE_OPT_KEY_KEEP),
+  FUSE_OPT_END
 };
```

**Verify against upstream:**

```sh
curl -sL https://codeload.github.com/teward/vmfs6-tools/tar.gz/582b5252d74ff96102220af62202a3548fe7128f | tar xz
diff -r vmfs6-tools-582b5252d74ff96102220af62202a3548fe7128f third_party/vmfs6-tools   # only the line above
```

`vmfs6-tools/test.img` is upstream's sample volume (VMFS 3, in the `imager` format);
`tests/clean_install_test.sh` uses it to check the VMFS mount path.
