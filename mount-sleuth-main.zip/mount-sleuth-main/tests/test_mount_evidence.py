"""Unit tests for mount_evidence_prod.py - no root, no devices.  python3 -m unittest discover tests"""
import unittest

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
import mount_evidence_prod as me  # noqa: E402


def vol(**kw):
    v = me.Volume(id=kw.pop("id", "p01"), source=kw.pop("source", "partition"), number=kw.pop("number", 1))
    for k, val in kw.items():
        setattr(v, k, val)
    return v


class Parsing(unittest.TestCase):
    def test_udev_enc_keeps_spaces_and_utf8(self):
        d = me.parse_udev("ID_FS_TYPE=ext4\nID_FS_LABEL=data_1__\nID_FS_LABEL_ENC=data\\x2f1\\x20\\xc3\\xa9\n")
        self.assertEqual(d["ID_FS_LABEL"], "data/1 é")
        self.assertEqual(d["ID_FS_TYPE"], "ext4")

    def test_kpartx_numbers_come_from_map_names(self):
        out = ("add map loop2p1 (254:0): 0 204800 linear 7:2 2048\n"
               "add map loop2p2 (254:1): 0 2 linear 7:2 206848\n"
               "add map loop2p5 (254:2): 0 122880 linear 7:2 208896\n"
               "add map loop2p10 (254:3): 0 8 linear 7:2 999\n")
        self.assertEqual([m["number"] for m in me.parse_kpartx(out)], [1, 2, 5, 10])

    def test_part_roles(self):
        self.assertEqual(me.part_role("gpt", "E3C9E316-0B5C-4DB8-817D-F92DF00215AE")[0], "msr")
        self.assertEqual(me.part_role("dos", "5")[0], "extended")
        self.assertEqual(me.part_role("dos", "07")[0], "basic")
        self.assertEqual(me.part_role("gpt", "00000000-1111-2222-3333-444444444444")[0], "unknown")


class Classify(unittest.TestCase):
    def check(self, expect_action, expect_category, **kw):
        v = vol(**kw)
        me.classify(v)
        self.assertEqual((v.action, v.category), (expect_action, expect_category), kw)

    def test_cases(self):
        self.check("mount", "", fs_type="ntfs", role="basic")
        self.check("mount", "", fs_type="vfat", role="efi")
        self.check("skip", "special_partition", role="msr")
        self.check("skip", "container", role="extended")
        self.check("skip", "swap", fs_type="swap", role="swap")
        self.check("skip", "encrypted", fs_type="bitlocker", role="basic")
        self.check("skip", "encrypted", fs_type="crypto_luks")
        self.check("lvm", "container", fs_type="lvm2_member", role="lvm")
        self.check("skip", "needs_tooling", fs_type="linux_raid_member")
        self.check("skip", "needs_tooling", role="ldm")
        self.check("skip", "no_filesystem", role="basic")
        self.check("mount", "", fs_type="reiserfs", fs_usage="filesystem")
        self.check("skip", "unsupported", fs_type="zfs_member", fs_usage="filesystem_other")

    def test_msr_with_a_filesystem_is_a_discrepancy_and_still_mounted(self):
        v = vol(role="msr", part_type_name="Microsoft Reserved", fs_type="ntfs")
        self.assertTrue(me.discrepancies(v, {}))
        me.classify(v)
        self.assertEqual(v.action, "mount")

    def test_tools_disagree_on_offset(self):
        v = vol(start_sector=2048, sectors=100)
        self.assertIn("ID_PART_ENTRY_OFFSET", me.discrepancies(v, {"ID_PART_ENTRY_OFFSET": "4096"})[0])


class Naming(unittest.TestCase):
    def test_names(self):
        self.assertEqual(me.volume_name(vol(number=3, fs_type="ntfs", fs_label="OS")), "p03_ntfs_OS")
        self.assertEqual(me.volume_name(vol(number=1, fs_type="vfat", role="efi", fs_label="SYSTEM")), "p01_vfat_efi_SYSTEM")
        self.assertEqual(me.volume_name(vol(number=4, fs_type="ntfs", role="recovery", fs_label="Recovery")), "p04_ntfs_recovery")
        self.assertEqual(me.volume_name(vol(number=2, role="msr")), "p02_msr")
        self.assertEqual(me.volume_name(vol(number=7, role="basic")), "p07_nofs")
        self.assertEqual(me.volume_name(vol(number=6, fs_type="ext4", fs_label="data/1 é")), "p06_ext4_data_1_e")
        lv = vol(number=2, source="lvm", fs_type="ext4", fs_label="root", lvm={"vg": "ubuntu-vg", "lv": "root"})
        self.assertEqual(me.volume_name(lv), "p02_ubuntu-vg-root_ext4_root")
        ss = vol(number=3, source="vss", fs_type="ntfs", fs_label="OS", vss={"store": 2})
        self.assertEqual(me.volume_name(ss), "p03_ntfs_OS_vss02")
        self.assertEqual(me.volume_name(vol(number=None, source="whole_disk", fs_type="xfs")), "disk_xfs")

    def test_hostile_labels(self):
        for label in ["../../etc", "a b\tc", "$(rm -rf /)", "x" * 200, "....", "‮evil"]:
            name = me.volume_name(vol(number=1, fs_type="ntfs", fs_label=label))
            self.assertRegex(name, r"^p01_ntfs(_[A-Za-z0-9][A-Za-z0-9._-]*)?$")
            self.assertLessEqual(len(name), 8 + 1 + 32)
            self.assertNotIn("/", name)


class Errors(unittest.TestCase):
    def test_categories(self):
        c = me.classify_mount_error
        self.assertEqual(c("Windows is hibernated, refused to mount.")[0], "hibernated")
        self.assertEqual(c("The disk contains an unclean file system (0, 0).")[0], "dirty")
        self.assertEqual(c("mount: unknown filesystem type 'ntfs3'.")[0], "missing_dependency")
        self.assertEqual(c("Failed to read bootsector: Input/output error")[0], "damaged")
        self.assertEqual(c("Filesystem has duplicate UUID - can't mount")[0], "collision")
        self.assertEqual(c("something odd")[0], "mount_failed")


class Layout(unittest.TestCase):
    def test_unallocated_skips_extended_container(self):
        parts = [vol(start_sector=2048, sectors=2048), vol(role="extended", start_sector=4096, sectors=8192),
                 vol(start_sector=6144, sectors=1024)]
        gaps = me.unallocated(parts, 1, 20000)
        self.assertEqual(gaps[0], {"start_sector": 1, "sectors": 2047})
        self.assertEqual(gaps[1], {"start_sector": 4096, "sectors": 2048})
        self.assertEqual(gaps[-1], {"start_sector": 7168, "sectors": 20000 - 7168 + 1})


class Lvm(unittest.TestCase):
    PVS = [{"pv_name": "/dev/mapper/loop2p2", "pe_start": "2048"}, {"pv_name": "/dev/mapper/loop2p3", "pe_start": "2048"}]

    def seg(self, **kw):
        s = {"vg_name": "vg", "lv_name": "root", "lv_size": "163840", "vg_extent_size": "8192", "segtype": "linear",
             "seg_start": "0", "seg_size": "163840", "stripes": "1", "stripe_size": "0",
             "seg_pe_ranges": "/dev/mapper/loop2p2:0-19"}
        s.update(kw)
        return s

    def test_linear_offset_is_pe_start_plus_extents(self):
        t = me.lvm_tables([self.seg(seg_pe_ranges="/dev/mapper/loop2p2:20-39")], self.PVS, {"/dev/mapper/loop2p2"})
        self.assertEqual(t[0]["table"], ["0 163840 linear /dev/mapper/loop2p2 165888"])

    def test_multi_segment_and_striped(self):
        segs = [self.seg(seg_size="81920", seg_pe_ranges="/dev/mapper/loop2p2:0-9"),
                self.seg(seg_start="81920", seg_size="81920", segtype="striped", stripes="2", stripe_size="128",
                         seg_pe_ranges="/dev/mapper/loop2p2:10-14 /dev/mapper/loop2p3:0-4")]
        t = me.lvm_tables(segs, self.PVS, {"/dev/mapper/loop2p2", "/dev/mapper/loop2p3"})[0]
        self.assertEqual(t["table"][1], "81920 81920 striped 2 128 /dev/mapper/loop2p2 83968 /dev/mapper/loop2p3 2048")
        self.assertEqual(t["problem"], "")

    def test_unsupported_and_missing_pv_are_reported_not_mapped(self):
        t = me.lvm_tables([self.seg(segtype="thin-pool"), self.seg(lv_name="other", seg_pe_ranges="/dev/sdz1:0-1"),
                           self.seg(lv_name="[lvol0_pmspare]")], self.PVS, {"/dev/mapper/loop2p2"})
        self.assertEqual(len(t), 2)
        self.assertIn("thin-pool", t[0]["problem"])
        self.assertIn("not in this image", t[1]["problem"])


class State(unittest.TestCase):
    def test_v1_state_reverse_order_is_mounts_dm_kpartx_devices_fuse(self):
        v1 = {"image_path": "/ev/a.E01", "mount_base": "/mnt/MountSleuth/h/a.E01", "loop_devices": ["/dev/loop3"],
              "nbd_devices": [], "fuse_mounts": ["/mnt/MountSleuth/h/a.E01/.ewf_fuse"],
              "partitions": ["/mnt/MountSleuth/h/a.E01/part1"], "lvm_volume_groups": ["/dev/mapper/vg-root"]}
        kinds = [r["kind"] for r in reversed(me.from_v1(v1)["resources"])]
        self.assertEqual(kinds, ["mount", "dm", "kpartx", "loop", "fuse"])


class GuiJob(unittest.TestCase):
    """--json jobs come from an unprivileged process: everything is checked again as root."""
    def setUp(self):
        import tempfile
        from pathlib import Path
        self.tmp = Path(tempfile.mkdtemp()).resolve()
        self.img = self.tmp / "ev" / "H" / "a disk.raw"
        self.img.parent.mkdir(parents=True)
        self.img.write_bytes(b"\0" * 512)
        self.ctx = me.Ctx(mount_base=self.tmp / "mnt", dev_base=self.tmp / "mnt_dev")

    def job(self, **kw):
        it = {"path": str(self.img), "host": "H", "label": "a_disk.raw", **kw}
        return me.job_images({"images": [it]}, self.ctx)

    def test_valid_job(self):
        self.assertEqual(self.job(), [(self.img, "H", "a_disk.raw")])

    def test_rejected(self):
        bad = [dict(host=".."), dict(host="a/b"), dict(label="../x.raw"), dict(label=".hidden"), dict(host=""),
               dict(path="relative.raw"), dict(path=str(self.tmp / "missing.raw")), dict(host=None)]
        txt = self.tmp / "ev" / "H" / "x.txt"
        txt.write_text("x")
        seg = self.tmp / "ev" / "H" / "x.E02"
        seg.write_text("x")
        inside = self.ctx.mount_base / "H" / "x.raw"
        inside.parent.mkdir(parents=True)
        inside.write_text("x")
        bad += [dict(path=str(txt)), dict(path=str(seg)), dict(path=str(inside))]
        for kw in bad:
            with self.assertRaises(ValueError, msg=kw):
                self.job(**kw)

    def test_unmount_removes_cut_short_first_journal(self):
        # kill -9 inside the journal's first save: only the folders and the temp file exist
        img = self.ctx.mount_base / "H" / "a_disk.raw"
        img.mkdir(parents=True)
        (img / (me.STATE_FILE + ".tmp")).write_text('{"version": 2, "resou')
        me.unmount_all(self.ctx, lazy=False)
        self.assertFalse((self.ctx.mount_base / "H").exists())

    def test_duplicates_rejected(self):
        it = {"path": str(self.img), "host": "H", "label": "a.raw"}
        with self.assertRaises(ValueError):
            me.job_images({"images": [it, dict(it, label="b.raw")]}, self.ctx)
        other = self.img.with_name("b.raw")
        other.write_bytes(b"\0")
        with self.assertRaises(ValueError):
            me.job_images({"images": [it, dict(it, path=str(other))]}, self.ctx)


if __name__ == "__main__":
    unittest.main()
