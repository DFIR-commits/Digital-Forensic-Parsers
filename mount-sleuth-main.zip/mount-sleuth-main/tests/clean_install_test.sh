#!/bin/bash
# Clean-install validation in a throwaway container: fresh distribution image -> scripts/install.sh
# (twice: install, then update in place) -> unit tests -> CLI and GUI integration tests -> read-only
# FUSE check -> uninstall. Run from the repository folder on a Docker host:
#
#   docker run --rm --privileged -v "$PWD:/src:ro" ubuntu:24.04 bash /src/tests/clean_install_test.sh
#   (likewise ubuntu:22.04, debian:12)
#
# --privileged is needed for loop, device-mapper and FUSE. Containers share the host kernel: run one
# at a time, and only on a test machine. The last step releases anything the tests left attached.
# The host kernel decides whether the nbd module exists (Docker Desktop/WSL2: no, so VMDK/QCOW2/VHDX
# are not covered here; test those on a VM).
set -u
step() { printf '\n######## %s\n' "$*"; }
step "system"; . /etc/os-release; echo "$PRETTY_NAME / kernel $(uname -r)"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null
# what a user has before running the installer: python3 to run nothing yet, plus the fixture builders
apt-get install -y -qq python3 dosfstools e2fsprogs cryptsetup-bin >/dev/null 2>&1
cp -r /src /ms && cd /ms
step "install.sh"
sh scripts/install.sh; echo "install rc=$?"
step "install.sh again (update in place)"
sh scripts/install.sh >/tmp/reinstall.log 2>&1; echo "reinstall rc=$?"; tail -3 /tmp/reinstall.log
step "versions"
mount-evidence --version
for p in util-linux fdisk kpartx dmsetup ntfs-3g ewf-tools qemu-utils afflib-tools lvm2 libvshadow-utils psmisc pkexec python3 python3-venv; do
  dpkg-query -W -f '${Package} ${Version}\n' "$p" 2>/dev/null || echo "$p (not installed)"
done
/opt/mount-evidence-venv/bin/python3 -c 'import sys, PySide6; print("python", sys.version.split()[0], "PySide6", PySide6.__version__)'
step "unit tests"
QT_QPA_PLATFORM=offscreen /opt/mount-evidence-venv/bin/python3 -m unittest discover -s tests 2>&1 | grep -E "^(Ran|OK|FAILED)"
step "CLI integration"
bash tests/integration_cli.sh 2>&1 | grep -E "^(PASS|FAIL|SKIP|passed)"; grep -E "ERRO|FAIL|failed|Error" /tmp/me-test.log | sort | uniq -c | sort -rn | head -25
step "GUI integration"
QT_QPA_PLATFORM=offscreen /opt/mount-evidence-venv/bin/python3 tests/integration_gui.py 2>&1 | grep -E '^(PASS|FAIL|[0-9]+/[0-9]+|   )'
step "FUSE layer read-only (E01)"
mount-evidence -l /tmp/x.log /tmp/me-ev/WEB01/web01_e01.E01 >/dev/null 2>&1
grep ' fuse ' /proc/mounts | grep MountSleuth
mount-evidence -l /tmp/x.log -u >/dev/null 2>&1; echo "after unmount: $(grep -c MountSleuth /proc/mounts) mounts"
step "uninstall"
sh scripts/install.sh --uninstall; ls /usr/local/lib/mount-evidence /usr/local/sbin/mount-evidence 2>&1 | head -2
step "release anything the tests left in the shared kernel"
python3 /ms/src/mount_evidence_prod.py -l /tmp/x.log -u >/dev/null 2>&1
for l in $(losetup -a | grep -E "/tmp/me-ev|me-host.img" | cut -d: -f1); do echo "leftover $l"; losetup -d $l; done
dmsetup ls | grep -E "^(mev-|evvg-|hostroot|loop[0-9]+p)" && echo "leftover dm above" || echo "no leftover dm devices"
