#!/bin/sh
# Build disposable test evidence under $1 (default /tmp/me-ev) for
# tests/integration_cli.sh and tests/integration_gui.py. Runs as root on a DISPOSABLE box or
# privileged container. Filesystems are made through per-partition loop
# devices (offset/sizelimit), so no partition device nodes are needed.
set -eu
EV=${1:-/tmp/me-ev}
# no udev (containers): LVM must create its device nodes itself or /dev/evvg never appears
[ -e /run/udev/control ] || export DM_DISABLE_UDEV=1
mkdir -p "$EV/WEB01" "$EV/DC 02" "$EV/LNX01" "$EV/LNX02"

# fmt IMG PARTNO CMD... : run CMD on a loop device covering one partition
fmt() {
  img=$1; n=$2; shift 2
  start=$(sfdisk -J "$img" | python3 -c "import json,sys; p=json.load(sys.stdin)['partitiontable']['partitions'][$n-1]; print(p['start']*512, p['size']*512)")
  off=${start% *}; size=${start#* }
  dev=$(losetup -f --show -o "$off" --sizelimit "$size" "$img")
  "$@" "$dev" >/dev/null 2>&1
  echo "$dev"
}
put() {  # put DEV FSTYPE : write a few files
  dev=$1; mkdir -p /tmp/w; mount -t "$2" "$dev" /tmp/w
  mkdir -p "/tmp/w/Users/svc app/AppData/Local/Temp"
  echo 'test content' > "/tmp/w/Users/svc app/AppData/Local/Temp/sample.txt"
  head -c 3000000 /dev/urandom > /tmp/w/big.bin
  for i in $(seq 1 300); do echo "file $i" > "/tmp/w/Users/f$i.txt"; done
  umount /tmp/w; losetup -d "$dev"
}

# --- GPT Windows-style disk with the awkward partitions -------------------
G="$EV/WEB01/web01 disk.raw"
truncate -s 700M "$G"
sfdisk -q "$G" <<'P'
label: gpt
size=64M,  type=C12A7328-F81F-11D2-BA4B-00A0C93EC93B, name="EFI system partition"
size=16M,  type=E3C9E316-0B5C-4DB8-817D-F92DF00215AE, name="Microsoft reserved partition"
size=200M, type=EBD0A0A2-B9E5-4433-87C0-68B6B72699C7, name="Basic data partition"
size=64M,  type=DE94BBA4-06D1-4D40-A16A-BFD50179D6AC, name="Recovery"
size=32M,  type=0657FD6D-A4AB-43C4-84E5-0933C84B4F4F
size=64M,  type=0FC63DAF-8483-4772-8E79-3D69D8477DE4, name="linux data"
size=16M,  type=EBD0A0A2-B9E5-4433-87C0-68B6B72699C7, name="Basic data partition"
size=32M,  type=CA7D7CCB-63ED-4C53-861C-1742536059CC, name="luks"
P
put "$(fmt "$G" 1 mkfs.vfat -F 32 -n SYSTEM)" vfat
put "$(fmt "$G" 3 mkntfs -Q -L OS)" ntfs-3g
put "$(fmt "$G" 4 mkntfs -Q -L Recovery)" ntfs-3g
losetup -d "$(fmt "$G" 5 mkswap -L swap)"
put "$(fmt "$G" 6 mkfs.ext4 -q -L OS)" ext4         # duplicate label "OS"
dd if=/dev/urandom of=/tmp/k bs=32 count=1 2>/dev/null
losetup -d "$(fmt "$G" 8 cryptsetup luksFormat -q --pbkdf pbkdf2 --pbkdf-force-iterations 1000 --key-file /tmp/k)"

# --- MBR disk with an extended container and logical partitions ---------
M="$EV/DC 02/dc02 'odd' \$name.dd"
truncate -s 300M "$M"
sfdisk -q "$M" <<'P'
label: dos
size=100M, type=7
type=5
size=60M, type=c
size=60M, type=83
P
put "$(fmt "$M" 1 mkntfs -Q -L "Local Disk")" ntfs-3g
put "$(fmt "$M" 3 mkfs.vfat -F 32 -n "DATA 1")" vfat
put "$(fmt "$M" 4 mkfs.ext4 -q -L "data/1 é")" ext4

# --- LVM disk, and a clone of it on a second host (same VG name + UUIDs) --
L="$EV/LNX01/lnx01.img"
truncate -s 200M "$L"
printf 'label: gpt\nsize=32M, type=0FC63DAF-8483-4772-8E79-3D69D8477DE4\ntype=E6D6D379-F507-44C2-A23C-238F2A3DF928\n' | sfdisk -q "$L"
put "$(fmt "$L" 1 mkfs.ext4 -q -L boot)" ext4
pv=$(fmt "$L" 2 true)
vgs evvg >/dev/null 2>&1 || rm -rf /dev/evvg      # stale node folder where no udev runs
pvcreate -q "$pv"; vgcreate -q evvg "$pv"; lvcreate -q -y -Zn -L 80M -n root evvg; lvcreate -q -y -Zn -l 100%FREE -n swap evvg
mkfs.ext4 -q -L root /dev/evvg/root; mkswap /dev/evvg/swap >/dev/null   # no -q: util-linux < 2.38 lacks it
mkdir -p /tmp/w; mount /dev/evvg/root /tmp/w; echo hi > /tmp/w/etc_passwd; umount /tmp/w
vgchange -q -an evvg >/dev/null; losetup -d "$pv"
cp "$L" "$EV/LNX02/lnx02.img"

# --- E01 of the GPT disk --------------------------------------------------
ewfacquire -q -u -t "$EV/WEB01/web01_e01" "$G" >/dev/null 2>&1
ls -la "$EV"/*
