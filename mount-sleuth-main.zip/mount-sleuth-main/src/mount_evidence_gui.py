#!/usr/bin/env python3
"""
mount_evidence_gui.py - desktop front end for mount_evidence_prod.py
====================================================================
Runs as the logged-in user. Every privileged step (loop devices, kpartx,
mounts, teardown) is done by the mount_evidence backend, started once per
operation through pkexec (or sudo -n) in its --json mode:

  GUI (user) --pkexec--> mount_evidence --json        (root, one run per operation)
     stdin : {"images": [{"path", "host", "label"}]}   then "cancel" to stop early
     stdout: one JSON event per line (start, image_start, image_done, log, exit)

Image paths travel inside the JSON job, never on a command line, and the
backend validates them again. Status needs no privileges: the backend's
journals and manifests under the mount root, and /proc/self/mountinfo.
The GUI is never in the data path: files are read straight from the mounts.

  mount-evidence-gui                      (installed; or python3 src/mount_evidence_gui.py)
"""
from __future__ import annotations

import importlib.util
import json
import logging
import os
import shutil
import sys
import threading
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

try:
    from PySide6.QtCore import (QElapsedTimer, QObject, QProcess, QSettings, QSocketNotifier,
                                QSortFilterProxyModel, Qt, QTimer, QUrl, Signal)
    from PySide6.QtGui import (QAction, QBrush, QColor, QDesktopServices, QGuiApplication, QIcon, QKeySequence,
                               QStandardItem, QStandardItemModel)
    from PySide6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog,
                                   QDialogButtonBox, QDockWidget, QFileDialog, QFormLayout, QHBoxLayout,
                                   QHeaderView, QLabel, QLineEdit, QMainWindow, QMenu, QMessageBox,
                                   QPlainTextEdit, QProgressBar, QPushButton, QSpinBox, QSplitter, QStyle,
                                   QTableView, QTabWidget, QToolBar, QTreeView, QVBoxLayout, QWidget)
except ImportError as e:                                   # pragma: no cover
    sys.exit(f"PySide6 is required ({e}).\n  apt install python3-pyside6.qtwidgets\n"
             f"  or: pip install PySide6-Essentials")

VERSION = "1.0.0"
APP_NAME = "Mount Sleuth"
HERE = Path(__file__).resolve().parent
BACKEND = HERE / "mount_evidence_prod.py"
ICON = HERE / "mount-sleuth.png"      # optional: a square PNG (256 or 512 px) for the window, taskbar and menu
INSTALL_DIR = Path("/usr/local/lib/mount-evidence")        # install_gui.sh layout
WRAPPER = Path("/usr/local/sbin/mount-evidence")           # root-owned; the polkit policy names it
SYS_PYTHON = "/usr/bin/python3"                            # never a (user-writable) venv python as root
for _d in ("/usr/sbin", "/sbin"):                          # tool checks only: user PATHs often lack sbin
    if _d not in os.environ.get("PATH", "").split(":"):
        os.environ["PATH"] = os.environ.get("PATH", "") + ":" + _d

SORT, DATA, KIND, STAT, TEXT, WARN, FSR, IMG = (Qt.ItemDataRole.UserRole + i for i in range(1, 9))

GREEN, RED, AMBER, GREY = QColor("#2e8b57"), QColor("#c62828"), QColor("#b26a00"), QColor("#808080")


def load_backend(path: Path = BACKEND):
    spec = importlib.util.spec_from_file_location("mount_evidence_backend", path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod                           # dataclasses look their module up
    spec.loader.exec_module(mod)
    return mod


# ── Presentation (pure functions over the backend's manifest dicts) ───────────
FS_NAMES = {"ntfs": "NTFS", "vfat": "FAT", "exfat": "exFAT", "ext2": "ext2", "ext3": "ext3", "ext4": "ext4",
            "xfs": "XFS", "btrfs": "Btrfs", "f2fs": "F2FS", "hfsplus": "HFS+", "hfs": "HFS", "apfs": "APFS",
            "udf": "UDF", "iso9660": "ISO 9660", "squashfs": "SquashFS", "refs": "ReFS", "zfs_member": "ZFS",
            "vmfs_volume_member": "VMFS", "swap": "swap", "bitlocker": "BitLocker", "crypto_luks": "LUKS",
            "lvm2_member": "LVM PV", "linux_raid_member": "RAID member"}

def fs_name(v: dict) -> str:
    fs = v.get("fs_type") or ""
    if fs == "vfat" and (v.get("fs_version") or "").upper().startswith("FAT"):
        return v["fs_version"].upper()
    return FS_NAMES.get(fs, fs)

def describe(v: dict) -> str:
    """Human classification: 'NTFS volume', 'FAT32 EFI System Partition', ..."""
    fs, role, name = v.get("fs_type") or "", v.get("role") or "", fs_name(v)
    if v.get("source") == "lvm":
        lv = v.get("lvm") or {}
        return f"LVM logical volume {lv.get('vg', '?')}/{lv.get('lv', '?')}" + (f" ({name})" if fs else "")
    if v.get("source") == "vss":
        return f"Volume shadow copy {(v.get('vss') or {}).get('store', '?')} ({name})"
    if fs == "bitlocker":
        return "BitLocker-encrypted volume"
    if fs == "crypto_luks" or role == "luks":
        return "LUKS-encrypted volume"
    if fs == "swap" or role == "swap":
        return "Linux swap"
    if role == "efi":
        return f"{name} EFI System Partition" if fs else "EFI System Partition (no filesystem)"
    if role == "msr":
        return "Microsoft Reserved (MSR)"
    if role == "recovery":
        return f"Windows Recovery ({name})" if fs else "Windows Recovery"
    if role == "extended":
        return "MBR extended partition (container)"
    if role == "protective":
        return "GPT protective entry"
    if role == "bios_boot":
        return "BIOS boot partition"
    if role == "ldm":
        return "Windows dynamic disk (LDM)"
    if role == "storage_spaces":
        return "Windows Storage Spaces member"
    if fs == "lvm2_member":
        return "LVM physical volume"
    if fs.endswith("raid_member"):
        return "Software RAID member"
    if fs == "vmfs_volume_member":
        return "VMware VMFS datastore"
    if fs:
        return f"{name} volume" + (" (whole disk)" if v.get("source") == "whole_disk" else "")
    return "Unknown / no filesystem"

SKIPPED = {"special_partition": ("special", "Not mountable — special partition"),
           "container": ("container", "Container — contents listed separately"),
           "swap": ("special", "Linux swap — never activated"),
           "encrypted": ("encrypted", "Encrypted — additional access required"),
           "unsupported": ("unsupported", "Unsupported filesystem"),
           "no_filesystem": ("unsupported", "No recognised filesystem"),
           "needs_tooling": ("unsupported", "Needs other tooling"),
           "damaged": ("failed", "Damaged — not mounted"),
           "ambivalent": ("failed", "Ambiguous signatures — not mounted")}

def vol_status(v: dict, mounts: dict) -> tuple[str, str]:
    """(filter key, label). Mount state comes from the live mount table, not the manifest."""
    s, cat = v.get("status") or "", v.get("category") or ""
    if s == "mounted":
        m = mounts.get(v.get("mount_point") or "")
        if not m:
            return "unmounted", "Unmounted"
        if "ro" in m["opts"].split(","):
            return "mounted", "Mounted — read-only"
        return "failed", "MOUNTED READ-WRITE — investigate"
    if s == "planned":
        return "mountable", "Discovery complete — mountable"
    if s == "block_device":
        return "block", "Block device only (read-only)"
    if s == "failed":
        return "failed", "Mount failed — " + (cat.replace("_", " ") or "see details")
    if s == "skipped":
        return SKIPPED.get(cat, ("unsupported", f"Not mounted — {cat or 'skipped'}"))
    return "", s or "—"

STATUS_FILTERS = {"Mounted — read-only": {"mounted"}, "Not mounted": {"unmounted", "mountable", "block", "special",
                  "container", "encrypted", "unsupported", "failed"}, "Unmounted": {"unmounted"},
                  "Discovered — mountable": {"mountable"}, "Block device only": {"block"},
                  "Special partitions": {"special", "container"}, "Encrypted": {"encrypted"},
                  "Unsupported / no filesystem": {"unsupported"}, "Failed / damaged": {"failed"}}

def human(n) -> str:
    if n is None:
        return ""
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if n < 1024 or unit == "TiB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024

def guess_format(path: str) -> str:
    ext = Path(path).suffix.lower()
    return {".e01": "ewf", ".ex01": "ewf", ".l01": "ewf", ".s01": "ewf", ".aff": "aff", ".afd": "aff",
            ".afm": "aff"}.get(ext, ext.lstrip(".") if ext in (".vmdk", ".qcow2", ".qcow", ".vhdx", ".vhd") else "raw")

def warnings_of(v: dict) -> list[str]:
    return list(v.get("discrepancies") or []) + list(v.get("notes") or [])


@dataclass
class Img:
    path: str
    host: str
    label: str
    size: Optional[int] = None
    report: Optional[dict] = None
    kind: str = ""                   # discovery | mount (where report came from)
    journal: Optional[dict] = None   # the backend's live journal: this image is managed
    busy: str = ""
    error: str = ""
    manifest_mtime: float = 0.0
    sig: object = None

    @property
    def name(self) -> str:
        return f"{self.host}/{self.label}"


# ── Backend process ───────────────────────────────────────────────────────────
class Runner(QObject):
    """One backend run at a time. QProcess keeps it off the GUI thread without threads."""
    event = Signal(object)       # object, not dict: no QVariantMap round trip (JSON nulls hit a shiboken refcount bug)
    line = Signal(str)
    done = Signal(int, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.proc: Optional[QProcess] = None
        self.op = ""
        self.got_events = False
        self.cancelled = False
        self._buf = b""

    def running(self) -> bool:
        return self.proc is not None

    def start(self, op: str, argv: list[str], job: dict):
        self.op, self.got_events, self.cancelled, self._buf = op, False, False, b""
        p = self.proc = QProcess(self)
        p.setProgram(argv[0])
        p.setArguments(argv[1:])
        p.readyReadStandardOutput.connect(self._out)
        p.readyReadStandardError.connect(self._err)
        p.finished.connect(self._finished)
        p.errorOccurred.connect(self._error)
        p.start()
        p.write((json.dumps(job) + "\n").encode())       # stdin stays open for "cancel"

    def cancel(self):
        if self.proc and not self.cancelled:
            self.cancelled = True
            self.proc.write(b"cancel\n")

    def _out(self):
        if not self.proc:
            return
        self._buf += bytes(self.proc.readAllStandardOutput())
        *lines, self._buf = self._buf.split(b"\n")
        for raw in lines:
            try:
                e = json.loads(raw)
            except ValueError:
                if raw.strip():
                    self.line.emit(raw.decode(errors="replace"))
                continue
            self.got_events = True
            self.event.emit(e)

    def _err(self):
        if self.proc:
            for l in bytes(self.proc.readAllStandardError()).decode(errors="replace").splitlines():
                if l.strip():
                    self.line.emit(l)

    def _finished(self, code, status):
        self._out()
        self._err()
        p, self.proc = self.proc, None
        self.done.emit(code if status == QProcess.ExitStatus.NormalExit else -1, self.op)
        if p:
            p.deleteLater()

    def _error(self, err):
        if err == QProcess.ProcessError.FailedToStart and self.proc:
            p, self.proc = self.proc, None
            self.line.emit(f"could not start {p.program()}: {p.errorString()}")
            self.done.emit(-2, self.op)
            p.deleteLater()


class Scanner(QObject):
    """Finds images in added files/folders on a worker thread (slow shares must not freeze the window)."""
    done = Signal(object, object)

    def __init__(self, me, parent=None):
        super().__init__(parent)
        self.me = me

    def scan(self, paths: list[str], recursive: bool, skip: list[Path]):
        threading.Thread(target=self._work, args=(paths, recursive, skip), daemon=True).start()

    def _work(self, paths, recursive, skip):
        found, errs = [], []
        for p in map(Path, paths):
            try:
                if p.is_file():
                    hits = self.me.discover(p, [])
                    if not hits:
                        errs.append(f"not a supported image (or a segment / VMDK extent): {p}")
                elif p.is_dir():
                    if not os.access(p, os.R_OK | os.X_OK):
                        errs.append(f"cannot read folder {p}: permission denied")
                        continue
                    if recursive:
                        for _ in os.walk(p, onerror=lambda e: errs.append(f"cannot read {e.filename}: {e.strerror}")):
                            pass
                        hits = self.me.discover(p, skip)
                    else:
                        hits = [h for f in sorted(p.iterdir()) if f.is_file() for h in self.me.discover(f, [])]
                    if not hits:
                        errs.append(f"no supported images in {p}" + ("" if recursive else " (this folder only)"))
                else:
                    errs.append(f"not found: {p}")
                    continue
            except OSError as e:
                errs.append(f"{p}: {e}")
                continue
            found += [(str(f.resolve()), h, l) for f, h, l in hits]
        self.done.emit(found, errs)


# ── Log panel ─────────────────────────────────────────────────────────────────
def refilter(proxy: QSortFilterProxyModel):
    if hasattr(proxy, "endFilterChange"):                  # Qt 6.9+; invalidateFilter() is deprecated there
        proxy.beginFilterChange()
        proxy.endFilterChange()
    else:
        proxy.invalidateFilter()

LEVEL_RANK = {"DEBUG": 0, "OUT": 1, "INFO": 2, "WARNING": 3, "ERROR": 4, "CRITICAL": 4}

class LevelFilter(QSortFilterProxyModel):
    min_rank = 2

    def filterAcceptsRow(self, row, parent):
        lvl = self.sourceModel().index(row, 1, parent).data() or "INFO"
        return LEVEL_RANK.get(lvl, 2) >= self.min_rank

class LogPanel(QWidget):
    MAX_ROWS = 50000
    PER_TICK = 2000                      # rows added per 150 ms: floods never freeze the window

    def __init__(self, parent=None):
        super().__init__(parent)
        self.model = QStandardItemModel(0, 4)
        self.model.setHorizontalHeaderLabels(["Time", "Level", "Image", "Message"])
        self.proxy = LevelFilter()
        self.proxy.setSourceModel(self.model)
        self.view = QTableView()
        self.view.setModel(self.proxy)
        self.view.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.view.setWordWrap(False)
        self.view.verticalHeader().hide()
        self.view.verticalHeader().setDefaultSectionSize(20)
        self.view.horizontalHeader().setStretchLastSection(True)
        for c, w in ((0, 70), (1, 70), (2, 200)):
            self.view.setColumnWidth(c, w)
        self.level = QComboBox()
        self.level.addItems(["Everything (incl. backend output)", "Info and above", "Warnings and errors", "Errors only"])
        self.level.setCurrentIndex(1)
        self.level.currentIndexChanged.connect(self._level)
        copy, save, clear = QPushButton("Copy selected"), QPushButton("Save…"), QPushButton("Clear")
        copy.clicked.connect(self.copy_selected)
        save.clicked.connect(self.save)
        clear.clicked.connect(lambda: self.model.removeRows(0, self.model.rowCount()))
        bar = QHBoxLayout()
        bar.addWidget(QLabel("Show:"))
        bar.addWidget(self.level)
        bar.addStretch(1)
        for b in (copy, save, clear):
            bar.addWidget(b)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 2, 4, 4)
        lay.addLayout(bar)
        lay.addWidget(self.view)
        self.pending: deque = deque()
        self.timer = QTimer(self)
        self.timer.setInterval(150)
        self.timer.timeout.connect(self.flush)
        self.timer.start()

    def _level(self, i):
        self.proxy.min_rank = [0, 2, 3, 4][i]
        refilter(self.proxy)

    def add(self, level: str, msg: str, image: str = ""):
        self.pending.append((time.strftime("%H:%M:%S"), level.upper(), image, msg))

    def flush(self):
        if not self.pending:
            return
        bottom = self.view.verticalScrollBar().value() >= self.view.verticalScrollBar().maximum() - 2
        for _ in range(min(self.PER_TICK, len(self.pending))):
            t, lvl, img, msg = self.pending.popleft()
            row = [QStandardItem(x) for x in (t, lvl, img, msg)]
            row[3].setToolTip(msg if len(msg) < 2000 else msg[:2000] + "…")
            colour = RED if LEVEL_RANK.get(lvl, 2) >= 4 else AMBER if lvl == "WARNING" else GREY if lvl in ("DEBUG", "OUT") else None
            for it in row:
                it.setEditable(False)
                if colour:
                    it.setForeground(QBrush(colour))
            self.model.appendRow(row)
        if self.model.rowCount() > self.MAX_ROWS:
            self.model.removeRows(0, self.model.rowCount() - self.MAX_ROWS)
        if bottom:
            self.view.scrollToBottom()

    def rows(self, selected_only=False) -> list[list[str]]:
        while self.pending:
            self.flush()
        if selected_only:
            idx = sorted({self.proxy.mapToSource(i).row() for i in self.view.selectionModel().selectedIndexes()})
        else:
            idx = range(self.model.rowCount())
        return [[self.model.item(r, c).text() for c in range(4)] for r in idx]

    def copy_selected(self):
        QGuiApplication.clipboard().setText("\n".join("\t".join(r) for r in self.rows(True)))

    def save(self, path: str = ""):
        if not path:
            path, _ = QFileDialog.getSaveFileName(self, "Save log", str(Path.home() / time.strftime(
                "mount_evidence_gui_%Y%m%d_%H%M%S.tsv")), "Tab-separated (*.tsv);;All files (*)")
        if path:
            Path(path).write_text("Time\tLevel\tImage\tMessage\n" + "".join("\t".join(r) + "\n" for r in self.rows()),
                                  encoding="utf-8")
        return path


class VolumeFilter(QSortFilterProxyModel):
    def __init__(self):
        super().__init__()
        self.text, self.fs, self.status, self.warn = "", "", "", False
        self.setRecursiveFilteringEnabled(True)
        self.setSortRole(SORT)

    def set(self, **kw):
        self.__dict__.update(kw)
        refilter(self)

    def filterAcceptsRow(self, row, parent):
        it = self.sourceModel().index(row, 0, parent)
        if self.text and self.text not in (it.data(TEXT) or ""):
            return False
        if self.fs and it.data(FSR) != self.fs:
            return False
        if self.status and it.data(STAT) not in STATUS_FILTERS[self.status]:
            return False
        return not self.warn or bool(it.data(WARN))


# ── Settings ──────────────────────────────────────────────────────────────────
DEFAULTS = {"mount_base": "/mnt/MountSleuth", "evidence_dir": "", "elevation": "pkexec", "ntfs_driver": "ntfs-3g",
            "block_only": False, "vss": False, "verbose": False, "nbd_max": 0, "file_manager": "",
            "optional_columns": False}

class SettingsDialog(QDialog):
    def __init__(self, win: "MainWindow"):
        super().__init__(win)
        self.setWindowTitle("Settings")
        self.win = win
        g = win.cfg
        f = QFormLayout(self)
        self.evdir = QLineEdit(g("evidence_dir"))
        self.base = QLineEdit(g("mount_base"))
        self.base.setEnabled(not win.managed())
        f.addRow("Default evidence folder", self._browse(self.evdir))
        f.addRow("Mount root", self._browse(self.base))
        f.addRow("", QLabel("Block devices go to <mount root>_dev." +
                            ("  Unmount everything to change the root." if win.managed() else "")))
        self.mode = QComboBox()
        self.mode.addItems(["Mount filesystems (and expose block devices)", "Block devices only (no mounts)"])
        self.mode.setCurrentIndex(1 if g("block_only") else 0)
        f.addRow("Mount mode", self.mode)
        self.ntfs = QComboBox()
        self.ntfs.addItems(["ntfs-3g", "ntfs3"])
        self.ntfs.setCurrentText(g("ntfs_driver"))
        f.addRow("NTFS driver", self.ntfs)
        self.vss = QCheckBox("Also mount NTFS volume shadow copies (experimental, vshadowmount)")
        self.vss.setChecked(g("vss"))
        f.addRow("Shadow copies", self.vss)
        self.nbd = QSpinBox()
        self.nbd.setRange(0, 128)
        self.nbd.setValue(g("nbd_max"))
        self.nbd.setSpecialValueText("leave as is")
        f.addRow("NBD slots (VMDK/QCOW2/VHDX)", self.nbd)
        self.verbose = QCheckBox("Debug logging (every command the backend runs)")
        self.verbose.setChecked(g("verbose"))
        f.addRow("Logging", self.verbose)
        self.elev = QComboBox()
        self.elev.addItems(["pkexec", "sudo"])
        self.elev.setCurrentText(g("elevation"))
        f.addRow("Privilege elevation", self.elev)
        f.addRow("", QLabel("pkexec asks through the desktop's polkit agent; sudo needs a NOPASSWD rule (sudo -n)."))
        self.fm = QLineEdit(g("file_manager"))
        self.fm.setPlaceholderText("empty = desktop default (xdg-open)")
        f.addRow("File manager command", self.fm)
        self.cols = QCheckBox("Show partition name, partition type and UUID columns")
        self.cols.setChecked(g("optional_columns"))
        f.addRow("Columns", self.cols)
        exts = QLabel(" ".join(sorted(win.me.ALL_EXTS)))
        exts.setWordWrap(True)
        f.addRow("Image types (fixed)", exts)
        f.addRow("Concurrency", QLabel("1: the backend works one image at a time under a system-wide lock"))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        f.addRow(bb)

    def _browse(self, edit: QLineEdit) -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        b = QPushButton("Browse…")
        b.clicked.connect(lambda: edit.setText(QFileDialog.getExistingDirectory(self, "Choose folder", edit.text()) or edit.text()))
        b.setEnabled(edit.isEnabled())
        h.addWidget(edit)
        h.addWidget(b)
        return w

    def values(self) -> dict:
        return {"evidence_dir": self.evdir.text().strip(), "mount_base": self.base.text().strip(),
                "block_only": self.mode.currentIndex() == 1, "ntfs_driver": self.ntfs.currentText(),
                "vss": self.vss.isChecked(), "nbd_max": self.nbd.value(), "verbose": self.verbose.isChecked(),
                "elevation": self.elev.currentText(), "file_manager": self.fm.text().strip(),
                "optional_columns": self.cols.isChecked()}

    def accept(self):
        v, problems = self.values(), []
        base = Path(v["mount_base"])
        if not base.is_absolute() or base == Path("/") or ".." in base.parts:
            problems.append("Mount root must be an absolute folder other than /")
        if v["evidence_dir"] and not Path(v["evidence_dir"]).is_dir():
            problems.append(f"Evidence folder not found: {v['evidence_dir']}")
        if v["file_manager"] and not shutil.which(v["file_manager"]):
            problems.append(f"File manager not found: {v['file_manager']} (give a program name, no arguments)")
        if v["elevation"] == "pkexec" and os.geteuid() != 0 and not shutil.which("pkexec"):
            problems.append("pkexec is not installed (apt install pkexec), or choose sudo")
        if problems:
            QMessageBox.warning(self, "Settings", "\n".join(problems))
            return
        super().accept()


# ── Main window ───────────────────────────────────────────────────────────────
QUEUE_COLS = ["Image", "Host", "Source path", "Format", "Size", "Discovery", "Partitions", "Mounted", "Status",
              "Warnings / errors"]
TREE_COLS = ["Image / volume", "Classification", "Status", "Filesystem", "Label", "Size", "Mount path",
             "Read-only", "Partition name", "Partition type", "UUID", "Notes"]
OPTIONAL_COLS = {8, 9, 10}
OP_TEXT = {"discover": "Discovering", "mount": "Mounting", "unmount": "Unmounting"}
OP_NOUN = {"discover": "Discovery", "mount": "Mount", "unmount": "Unmount"}

class MainWindow(QMainWindow):
    def __init__(self, me, settings: Optional[QSettings] = None, backend_cmd: Optional[list[str]] = None,
                 elevate: Optional[list[str]] = None):
        super().__init__()
        self.me = me
        self.settings = settings or app_settings()
        self._backend_cmd, self._elevate = backend_cmd, elevate
        self.imgs: dict[str, Img] = {}
        self.qrow: dict[str, list[QStandardItem]] = {}
        self.trow: dict[str, QStandardItem] = {}
        self.mounts: dict = {}
        self.journals: dict[str, dict] = {}
        self.stderr_tail: deque = deque(maxlen=30)
        self.op_reports: list[dict] = []
        self.op_summary: dict = {}
        self.close_after = ""           # "close" | "unmount": continue closing when the run ends
        self.active = "queue"
        self.scanning = 0
        self.deps_problem = ""
        self.setWindowTitle(APP_NAME)
        self.resize(1360, 840)

        self.runner = Runner(self)
        self.runner.event.connect(self.on_event)
        self.runner.line.connect(self.on_line)
        self.runner.done.connect(self.on_done)
        self.scanner = Scanner(me, self)
        self.scanner.done.connect(self.on_scanned)

        self._build_ui()
        self._watch_mounts()
        self.startup_checks()
        self.refresh()
        for key, fn in (("geometry", self.restoreGeometry), ("state", self.restoreState),
                        ("split_main", self.split_main.restoreState), ("split_left", self.split_left.restoreState)):
            val = self.settings.value(key)
            if val is not None:
                fn(val)

    # settings helpers
    def cfg(self, key):
        d = DEFAULTS[key]
        v = self.settings.value(key, d)
        if isinstance(d, bool):
            return v in (True, "true", "1", 1)
        if isinstance(d, int):
            try:
                return int(v)
            except (TypeError, ValueError):
                return d
        return str(v)

    @property
    def mount_base(self) -> Path:
        return Path(self.cfg("mount_base"))

    @property
    def dev_base(self) -> Path:
        return self.mount_base.with_name(self.mount_base.name + "_dev")

    def backend_cmd(self) -> list[str]:
        if self._backend_cmd is not None:
            return list(self._backend_cmd)
        if WRAPPER.exists() and BACKEND == INSTALL_DIR / BACKEND.name:
            return [str(WRAPPER)]
        return [SYS_PYTHON, "-I", str(BACKEND)]

    def elevation(self) -> list[str]:
        if self._elevate is not None:
            return list(self._elevate)
        if os.geteuid() == 0:
            return []
        return ["sudo", "-n"] if self.cfg("elevation") == "sudo" else ["pkexec"]

    # ── UI construction ──
    def _act(self, text, icon, slot, key=None, tip=""):
        a = QAction(self.style().standardIcon(icon), text, self)
        a.triggered.connect(slot)
        if key:
            a.setShortcut(QKeySequence(key))
        a.setToolTip(tip or text)
        a.setStatusTip(tip or text)
        return a

    def _build_ui(self):
        S = QStyle.StandardPixmap
        self.a_files = self._act("Add images", S.SP_FileIcon, self.add_files, "Ctrl+O", "Add one or more image files")
        self.a_dir = self._act("Add folder", S.SP_DirIcon, lambda: self.add_dir(False), "Ctrl+Shift+O",
                               "Add the images in one folder (not its subfolders)")
        self.a_rdir = self._act("Add folder tree", S.SP_DirOpenIcon, lambda: self.add_dir(True), None,
                                "Add every image under a folder; the first level of subfolders are the hosts")
        self.a_remove = self._act("Remove", S.SP_TrashIcon, self.remove_selected, "Delete",
                                  "Remove the selected images from the queue (mounted images stay until unmounted)")
        self.a_discover = self._act("Discover", S.SP_FileDialogContentsView, self.discover, "Ctrl+D",
                                    "Identify partitions and filesystems read-only; nothing is left attached")
        self.a_mount = self._act("Mount selected", S.SP_DriveHDIcon, lambda: self.mount(True), "Ctrl+M",
                                 "Mount the selected images read-only")
        self.a_mount_all = self._act("Mount all", S.SP_DialogApplyButton, lambda: self.mount(False), "Ctrl+Shift+M",
                                     "Discover and mount every queued image that is not mounted yet")
        self.a_unmount = self._act("Unmount selected", S.SP_DialogCancelButton, lambda: self.unmount(True), "Ctrl+U",
                                   "Release the selected images (all of each image's volumes)")
        self.a_unmount_all = self._act("Unmount all", S.SP_DialogCloseButton, lambda: self.unmount(False), None,
                                       "Release everything this tool attached")
        self.a_refresh = self._act("Refresh", S.SP_BrowserReload, self.refresh, "F5", "Re-read mount state")
        self.a_open_root = self._act("Open mount root", S.SP_DirHomeIcon, lambda: self.open_path(self.mount_base),
                                     None, "Open the mount root in the file manager")
        self.a_cancel = self._act("Cancel", S.SP_BrowserStop, self.cancel, "Esc",
                                  "Stop after the current step (everything attached so far stays recorded)")
        self.a_settings = self._act("Settings", S.SP_FileDialogDetailedView, self.open_settings, "Ctrl+,")
        self.a_help = self._act("Help", S.SP_DialogHelpButton, self.show_help, "F1")

        tb = QToolBar("Main")
        tb.setObjectName("toolbar")
        tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        tb.setMovable(False)
        for a in (self.a_files, self.a_dir, self.a_rdir, self.a_remove, None, self.a_discover, self.a_mount,
                  self.a_mount_all, None, self.a_unmount, self.a_unmount_all, None, self.a_refresh, self.a_open_root,
                  self.a_cancel, None):
            tb.addSeparator() if a is None else tb.addAction(a)
        self.addToolBar(tb)

        # filter bar
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search image, path, label, filesystem, mount path…  (Ctrl+F)")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.apply_filters)
        find = QAction(self)
        find.setShortcut(QKeySequence("Ctrl+F"))
        find.triggered.connect(lambda: self.search.setFocus())
        self.addAction(find)
        self.f_fs = QComboBox()
        self.f_fs.addItem("All filesystems", "")
        self.f_fs.currentIndexChanged.connect(self.apply_filters)
        self.f_status = QComboBox()
        self.f_status.addItem("Any status", "")
        for k in STATUS_FILTERS:
            self.f_status.addItem(k, k)
        self.f_status.currentIndexChanged.connect(self.apply_filters)
        self.f_warn = QCheckBox("Warnings / errors only")
        self.f_warn.toggled.connect(self.apply_filters)
        fbar = QHBoxLayout()
        fbar.setContentsMargins(6, 4, 6, 0)
        fbar.addWidget(self.search, 3)
        fbar.addWidget(self.f_fs, 1)
        fbar.addWidget(self.f_status, 1)
        fbar.addWidget(self.f_warn)

        # queue
        self.qmodel = QStandardItemModel(0, len(QUEUE_COLS))
        self.qmodel.setHorizontalHeaderLabels(QUEUE_COLS)
        self.qproxy = QSortFilterProxyModel()
        self.qproxy.setSourceModel(self.qmodel)
        self.qproxy.setSortRole(SORT)
        self.qproxy.setFilterRole(TEXT)
        self.qproxy.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.queue = QTableView()
        self.queue.setModel(self.qproxy)
        self._table_defaults(self.queue)
        for c, w in enumerate((170, 80, 240, 55, 75, 80, 70, 65, 190, 200)):
            self.queue.setColumnWidth(c, w)
        self.queue.selectionModel().selectionChanged.connect(lambda *_: self.on_select("queue"))
        self.queue.doubleClicked.connect(self.on_queue_double)
        self.queue.customContextMenuRequested.connect(lambda pos: self.context_menu(self.queue, pos))

        # explorer
        self.tmodel = QStandardItemModel(0, len(TREE_COLS))
        self.tmodel.setHorizontalHeaderLabels(TREE_COLS)
        self.tproxy = VolumeFilter()
        self.tproxy.setSourceModel(self.tmodel)
        self.tree = QTreeView()
        self.tree.setModel(self.tproxy)
        self.tree.setSortingEnabled(True)
        self.tree.sortByColumn(0, Qt.SortOrder.AscendingOrder)
        self.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tree.setUniformRowHeights(True)
        self.tree.setAlternatingRowColors(True)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.header().setStretchLastSection(True)
        for c, w in enumerate((230, 200, 200, 70, 95, 70, 380, 130, 150, 170, 150, 200)):
            self.tree.setColumnWidth(c, w)
        self.tree.selectionModel().selectionChanged.connect(lambda *_: self.on_select("tree"))
        self.tree.doubleClicked.connect(self.on_tree_double)
        self.tree.customContextMenuRequested.connect(lambda pos: self.context_menu(self.tree, pos))
        self.apply_column_settings()

        # details
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.details.setPlaceholderText("Select an image or a volume to see everything the backend recorded about it.")
        f = self.details.font()
        f.setFamily("monospace")
        f.setStyleHint(f.StyleHint.Monospace)
        self.details.setFont(f)

        def boxed(title, w):
            box = QWidget()
            v = QVBoxLayout(box)
            v.setContentsMargins(6, 4, 6, 2)
            lab = QLabel(f"<b>{title}</b>")
            v.addWidget(lab)
            v.addWidget(w)
            return box, lab

        qbox, self.q_title = boxed("Image queue", self.queue)
        tbox, _ = boxed("Partitions and volumes", self.tree)
        dbox, _ = boxed("Details", self.details)
        self.split_left = QSplitter(Qt.Orientation.Vertical)
        self.split_left.addWidget(qbox)
        self.split_left.addWidget(tbox)
        self.split_left.setSizes([260, 440])
        self.split_main = QSplitter(Qt.Orientation.Horizontal)
        self.split_main.addWidget(self.split_left)
        self.split_main.addWidget(dbox)
        self.split_main.setSizes([1080, 300])
        central = QWidget()
        cv = QVBoxLayout(central)
        cv.setContentsMargins(0, 0, 0, 0)
        cv.addLayout(fbar)
        cv.addWidget(self.split_main)
        self.setCentralWidget(central)

        # log dock
        self.log = LogPanel()
        self.dock = QDockWidget("Log", self)
        self.dock.setObjectName("log")
        self.dock.setWidget(self.log)
        self.dock.setFeatures(QDockWidget.DockWidgetFeature.DockWidgetClosable | QDockWidget.DockWidgetFeature.DockWidgetMovable)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, self.dock)
        self.a_log = self.dock.toggleViewAction()
        self.a_log.setText("Log")
        self.a_log.setIcon(self.style().standardIcon(S.SP_FileDialogInfoView))
        self.a_log.setShortcut(QKeySequence("Ctrl+L"))
        for a in (self.a_log, self.a_settings, self.a_help):
            tb.addAction(a)

        # status bar
        sb = self.statusBar()
        self.counts = QLabel()
        self.op_label = QLabel("Idle")
        self.elapsed_label = QLabel("")
        self.progress = QProgressBar()
        self.progress.setMaximumWidth(220)
        self.progress.setTextVisible(True)
        self.progress.hide()
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.cancel)
        self.cancel_btn = cancel
        cancel.hide()
        sb.addWidget(self.counts, 1)
        for w in (self.op_label, self.elapsed_label, self.progress, cancel):
            sb.addPermanentWidget(w)
        self.clock = QElapsedTimer()
        self.tick = QTimer(self)
        self.tick.setInterval(1000)
        self.tick.timeout.connect(self._tick)
        self.update_actions()

    def _table_defaults(self, v: QTableView):
        v.setSortingEnabled(True)
        v.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        v.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        v.setWordWrap(False)
        v.setAlternatingRowColors(True)
        v.verticalHeader().hide()
        v.verticalHeader().setDefaultSectionSize(22)
        v.horizontalHeader().setStretchLastSection(True)
        v.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        v.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)

    def apply_column_settings(self):
        show = self.cfg("optional_columns")
        for c in OPTIONAL_COLS:
            self.tree.setColumnHidden(c, not show)

    def _watch_mounts(self):
        """Event-driven mount-table watch: the kernel flags /proc/self/mounts (POLLPRI)
        whenever anything is mounted or unmounted. No polling."""
        self.debounce = QTimer(self)
        self.debounce.setSingleShot(True)
        self.debounce.setInterval(400)
        self.debounce.timeout.connect(self.refresh)
        try:
            self._mounts_file = open("/proc/self/mounts", "rb")
            self._mnt_notifier = QSocketNotifier(self._mounts_file.fileno(), QSocketNotifier.Type.Exception, self)
            self._mnt_notifier.activated.connect(lambda *_: self.debounce.start())
        except OSError:
            self._mnt_notifier = None

    # ── startup checks ──
    def startup_checks(self):
        me = self.me
        self.log.add("INFO", f"{APP_NAME} {VERSION}, backend {BACKEND} (mount_evidence {me.VERSION})")
        cmd = self.elevation() + self.backend_cmd()
        self.log.add("INFO", "Privileged steps run as: " + " ".join(cmd) + " --json …")
        if os.geteuid() == 0 and self._elevate is None:
            self.log.add("WARNING", "The GUI itself is running as root. That is not needed: run it as your user; "
                                    "only the backend is elevated, per operation.")
        elif self._backend_cmd is None and self.backend_cmd()[0] != str(WRAPPER) and os.access(BACKEND, os.W_OK):
            self.log.add("WARNING", f"{BACKEND} runs as root but is writable by you. For production use "
                                    "install_gui.sh (root-owned copy and a polkit rule).")
        if "pkexec" in self.elevation() and not shutil.which("pkexec"):
            self.deps_problem = "pkexec is not installed (apt install pkexec), or choose sudo in Settings"
            self.log.add("ERROR", self.deps_problem)

        class Capture(logging.Handler):
            def emit(h, r):
                self.log.add("ERROR" if r.levelno >= logging.ERROR else "DEBUG", r.getMessage())
        me.log.handlers[:] = [Capture()]
        me.log.setLevel(logging.DEBUG)
        me.log.propagate = False
        if not me.check_deps():
            self.deps_problem = self.deps_problem or "required tools are missing (see the log)"
        self.update_actions()

    # ── state ──
    def managed(self) -> list[Img]:
        return [i for i in self.imgs.values() if i.journal]

    def scan_journals(self) -> dict[str, dict]:
        out = {}
        try:
            files = sorted(self.mount_base.glob(f"*/*/{self.me.STATE_FILE}"))
        except OSError:
            files = []
        for sf in files:
            st = self.me.load_state(sf)
            if st and st.get("image_path"):
                st["_file"] = str(sf)
                st["_live"] = self.journal_live(st)
                out[st["image_path"]] = st
        return out

    def journal_live(self, st: dict) -> bool:
        """Like the backend's state_live, but only unprivileged reads (no dmsetup)."""
        for r in st.get("resources", []):
            k = r.get("kind")
            if k in ("mount", "fuse") and r.get("path") in self.mounts:
                return True
            if k == "loop" and self.me.loop_backing(r.get("dev", "")):
                return True
            if k == "nbd" and self.me.nbd_live(r.get("dev", ""), r.get("image")):
                return True
        return False

    def refresh(self):
        self.mounts = self.me.mountinfo()
        self.journals = self.scan_journals()
        for path, st in self.journals.items():
            if path not in self.imgs:
                self._add(path, st.get("host", "?"), st.get("label", Path(path).name), note="(attached earlier)")
        for img in self.imgs.values():
            st = self.journals.get(img.path)
            img.journal = st
            if st:
                mf = Path(st["_file"]).with_name(self.me.MANIFEST_FILE)
                try:
                    mt = mf.stat().st_mtime
                    if mt != img.manifest_mtime:
                        img.report, img.kind, img.manifest_mtime = json.loads(mf.read_text()), "mount", mt
                except (OSError, ValueError):
                    pass
            self.render(img)
        self.update_fs_filter()
        self.update_counts()
        self.update_actions()

    def update_fs_filter(self):
        seen = sorted({fs_name(v) for i in self.imgs.values() if i.report for v in i.report.get("volumes", [])
                       if v.get("fs_type")})
        have = {self.f_fs.itemData(i) for i in range(1, self.f_fs.count())}
        for fs in seen:
            if fs not in have:
                self.f_fs.addItem(fs, fs)

    # ── queue ──
    def unique_label(self, host: str, label: str) -> str:
        used = {(i.host, i.label) for i in self.imgs.values()} | \
               {(s.get("host"), s.get("label")) for s in self.journals.values()}
        p = Path(label)
        cand, n = label, 1
        while (host, cand) in used:
            cand, n = f"{p.stem}_{n}{p.suffix}", n + 1
        return cand

    def _add(self, path: str, host: str, label: str, note: str = "") -> Img:
        try:
            size = os.stat(path).st_size
        except OSError:
            size = None
        img = self.imgs[path] = Img(path=path, host=host, label=label, size=size)
        row = [QStandardItem() for _ in QUEUE_COLS]
        for it in row:
            it.setEditable(False)
            it.setData(path, DATA)
        self.qmodel.appendRow(row)
        self.qrow[path] = row
        top = [QStandardItem() for _ in TREE_COLS]
        for it in top:
            it.setEditable(False)
            it.setData(path, IMG)
        top[0].setData("image", KIND)
        self.tmodel.appendRow(top)
        self.trow[path] = top[0]
        if note:
            self.log.add("INFO", f"{img.name} {note}: {path}")
        return img

    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Add forensic images", self.cfg("evidence_dir"),
                                                "Forensic images (" + " ".join(f"*{e} *{e.upper()}" for e in sorted(self.me.ALL_EXTS))
                                                + ");;All files (*)")
        if files:
            self.add_paths(files, False)

    def add_dir(self, recursive: bool):
        d = QFileDialog.getExistingDirectory(self, "Add images from folder" + (" (and subfolders)" if recursive else ""),
                                             self.cfg("evidence_dir"))
        if d:
            self.add_paths([d], recursive)

    def add_paths(self, paths: list[str], recursive: bool):
        self.scanning += 1
        if not self.runner.running():
            self.op_label.setText("Looking for images…")
        self.scanner.scan(paths, recursive, [self.mount_base, self.dev_base])

    def on_scanned(self, found, errs):
        self.scanning -= 1
        for e in errs:
            self.log.add("WARNING", e)
        added = dup = 0
        for path, host, label in found:
            if path in self.imgs:
                dup += 1
                continue
            st = self.journals.get(path)
            if st:
                host, label = st.get("host", host), st.get("label", label)
            else:
                new = self.unique_label(host, label)
                if new != label:
                    self.log.add("INFO", f"{host}/{label} is already queued from another folder; "
                                         f"this one is {host}/{new}: {path}")
                label = new
            self.render(self._add(path, host, label))
            added += 1
        if found or not errs:
            self.log.add("INFO", f"Added {added} image(s)" + (f", {dup} already queued" if dup else ""))
        if not self.runner.running():
            self.op_label.setText("Idle")
        self.refresh()

    def remove_selected(self):
        sel = self.selected_images()
        kept = [i for i in sel if i.journal]
        for img in sel:
            if img.journal or img.busy:
                continue
            self.qmodel.removeRow(self.qrow.pop(img.path)[0].row())
            self.tmodel.removeRow(self.trow.pop(img.path).row())
            del self.imgs[img.path]
        if kept:
            self.log.add("INFO", f"{len(kept)} attached image(s) kept in the queue: unmount them first")
        self.update_counts()
        self.update_actions()

    # ── rendering ──
    def image_state(self, img: Img) -> tuple[str, str, QColor | None]:
        """(status key, text, colour) for the image as a whole."""
        rep = img.report or {}
        if img.busy:
            return "", img.busy, None
        if img.error:
            return "failed", f"Error — {img.error}", RED
        vols = rep.get("volumes", [])
        mounted = sum(vol_status(v, self.mounts)[0] == "mounted" for v in vols)
        if img.journal:
            if not img.journal["_live"]:
                return "unmounted", "Recorded but nothing attached (stale) — Unmount clears it", AMBER
            if rep.get("status") == "interrupted":
                return "failed", "Interrupted — partly attached; Unmount releases it", AMBER
            failed = sum(v.get("status") == "failed" for v in vols)
            if mounted:
                return "mounted", f"Mounted — read-only ({mounted})" + (f", {failed} failed" if failed else ""), GREEN
            return "block", "Attached — block devices only", GREEN
        if rep.get("errors") or rep.get("status") == "failed":
            e = (rep.get("errors") or [{}])[0]
            return "failed", f"Failed — {e.get('category', '')}: {e.get('message', '')}", RED
        if img.kind == "mount" and vols:
            return "unmounted", "Unmounted", None
        if img.kind == "discovery":
            return "", "Discovery complete", None
        if not os.path.exists(img.path):
            return "failed", "Source file missing", RED
        return "", "Queued", None

    def render(self, img: Img):
        if img.path not in self.qrow:
            return
        rep = img.report or {}
        vols = rep.get("volumes", [])
        key, text, colour = self.image_state(img)
        mounted = sum(vol_status(v, self.mounts)[0] == "mounted" for v in vols)
        problems = [f"{e.get('category')}: {e.get('message')}" for e in rep.get("errors", [])] + \
                   list(rep.get("warnings", [])) + [f"{v.get('id')}: {w}" for v in vols for w in warnings_of(v)] + \
                   ([img.error] if img.error else [])
        size = rep.get("size_bytes") or img.size
        disc = "Failed" if rep.get("status") == "failed" and not vols else "Complete" if img.report else \
            ("Running…" if img.busy.startswith("Discover") else "Not run")
        cells = [(img.label, img.label.lower()), (img.host, img.host.lower()), (img.path, img.path),
                 (rep.get("format") or guess_format(img.path), rep.get("format") or ""),
                 (human(size), size or 0), (disc, disc), (str(len(vols)) if img.report else "", len(vols)),
                 (str(mounted) if img.report else "", mounted), (text, text),
                 (f"{len(problems)}: {problems[0]}" if problems else "", len(problems))]
        row = self.qrow[img.path]
        blob = f"{img.name} {img.path} {text}".lower()
        for it, (t, s) in zip(row, cells):
            it.setText(t)
            it.setData(s, SORT)
            it.setData(blob, TEXT)
        row[2].setToolTip(img.path)
        row[8].setForeground(QBrush(colour) if colour else QBrush())
        row[9].setToolTip("\n".join(problems))

        top = self.trow[img.path]
        trow = [self.tmodel.item(top.row(), c) for c in range(len(TREE_COLS))]
        table = (rep.get("table") or {}).get("type", "")
        ivals = [img.name, f"{rep.get('format') or guess_format(img.path)} image" + (f", {table.upper()}" if table else ""),
                 text, "", "", human(size), rep.get("image_dir", "") if img.journal else "", "", "", "", "",
                 "; ".join(problems)]
        for c, (it, t) in enumerate(zip(trow, ivals)):
            it.setText(t)
            it.setData(t.lower() if c else img.name.lower(), SORT)
        top.setData(f"{img.name} {img.path}".lower(), TEXT)
        top.setData(key, STAT)
        top.setData(bool(problems), WARN)
        top.setData("", FSR)        # never None or dicts as item data: shiboken refcount bug (none_dealloc)
        top.setData("image", KIND)
        trow[2].setForeground(QBrush(colour) if colour else QBrush())
        trow[0].setToolTip(img.path)

        sig = (id(img.report), tuple((v.get("mount_point"), str(self.mounts.get(v.get("mount_point") or "", {}).get("opts")))
                                     for v in vols))
        if sig != img.sig:
            img.sig = sig
            self._render_volumes(img, top, vols)

    def _render_volumes(self, img: Img, top: QStandardItem, vols: list[dict]):
        was = self.tree.isExpanded(self.tproxy.mapFromSource(top.index()))
        top.removeRows(0, top.rowCount())
        parents: dict[str, QStandardItem] = {}
        for v in vols:
            key, stext = vol_status(v, self.mounts)
            live = key == "mounted"
            ro = "Yes (mount verified)" if live else "Yes (device)" if v.get("device_read_only") else ""
            ptype = v.get("part_type_name") or v.get("source", "")
            notes = warnings_of(v) + ([v["reason"]] if v.get("reason") and v.get("status") != "mounted" else [])
            vals = [v.get("name") or v.get("id"), describe(v), stext, fs_name(v), v.get("fs_label", ""),
                    human(v.get("size_bytes")), v.get("mount_point", "") if live else "", ro, v.get("part_name", ""),
                    ptype, v.get("fs_uuid", "") or v.get("part_uuid", ""), "; ".join(notes)]
            sorts = [(v.get("number") if v.get("number") is not None else 999, v.get("id", "")), None, None, None, None,
                     v.get("size_bytes") or 0]
            row = []
            for c, t in enumerate(vals):
                it = QStandardItem(t)
                it.setEditable(False)
                s = sorts[c] if c < len(sorts) else None
                it.setData(f"{s[0]:04d}{s[1]}" if isinstance(s, tuple) else s if s is not None else t.lower(), SORT)
                it.setData(img.path, IMG)
                row.append(it)
            row[0].setData("volume", KIND)
            row[0].setData(v.get("id", ""), DATA)
            row[0].setData(key, STAT)
            row[0].setData(fs_name(v), FSR)
            row[0].setData(bool(warnings_of(v)) or key == "failed", WARN)
            row[0].setData(" ".join([img.name, img.path, v.get("name", ""), v.get("fs_label", ""), fs_name(v), describe(v),
                                     stext, v.get("mount_point", ""), v.get("part_name", ""),
                                     v.get("fs_uuid", "")]).lower(), TEXT)
            row[0].setToolTip(v.get("dev_link") or v.get("dev", ""))
            row[2].setToolTip(v.get("reason") or stext)
            row[11].setToolTip("\n".join(notes))
            colour = {"mounted": GREEN, "failed": RED, "encrypted": AMBER, "unmounted": GREY}.get(key)
            if colour:
                row[2].setForeground(QBrush(colour))
            vid = v.get("id", "")
            parent = parents.get(vid.split(".")[0]) if "." in vid else None
            (parent or top).appendRow(row)
            parents.setdefault(vid, row[0])
        if was or vols:
            self.tree.expand(self.tproxy.mapFromSource(top.index()))

    def update_counts(self):
        vols = [(i, v) for i in self.imgs.values() if i.report for v in i.report.get("volumes", [])]
        st = [vol_status(v, self.mounts)[0] for _, v in vols]
        warns = sum(len(i.report.get("warnings", [])) for i in self.imgs.values() if i.report) + \
            sum(len(warnings_of(v)) for _, v in vols)
        fails = st.count("failed") + sum(len(i.report.get("errors", [])) for i in self.imgs.values() if i.report) + \
            sum(bool(i.error) for i in self.imgs.values())
        skipped = sum(v.get("status") == "skipped" and vol_status(v, {})[0] != "failed" for _, v in vols)
        self.counts.setText(f"Images {len(self.imgs)}  ·  processed {sum(i.report is not None for i in self.imgs.values())}"
                            f"  ·  volumes {len(vols)}  ·  mounted {st.count('mounted')}  ·  skipped by design {skipped}"
                            f"  ·  warnings {warns}  ·  failures {fails}")
        self.q_title.setText(f"<b>Image queue</b> ({len(self.imgs)})")

    def apply_filters(self):
        t = self.search.text().strip().lower()
        self.qproxy.setFilterFixedString(t)
        self.tproxy.set(text=t, fs=self.f_fs.currentData() or "", status=self.f_status.currentData() or "",
                        warn=self.f_warn.isChecked())
        if t or self.tproxy.fs or self.tproxy.status or self.tproxy.warn:
            self.tree.expandAll()

    # ── selection ──
    def on_select(self, which: str):
        self.active = which
        img, v = self.current()
        self.details.setPlainText(self.details_text(img, v) if img else "")
        if which == "queue" and img:
            self.tree.scrollTo(self.tproxy.mapFromSource(self.trow[img.path].index()))
        self.update_actions()

    def current(self) -> tuple[Optional[Img], Optional[dict]]:
        view = self.queue if self.active == "queue" else self.tree
        idx = view.currentIndex()
        if not idx.isValid() or not view.selectionModel().isSelected(idx) and not view.selectionModel().selectedRows():
            return None, None
        if view is self.queue:
            return self.imgs.get(idx.data(DATA)), None
        return self.vol_at(idx)

    def vol_at(self, idx) -> tuple[Optional[Img], Optional[dict]]:
        first = idx.siblingAtColumn(0)
        img = self.imgs.get(first.data(IMG))
        if not img or first.data(KIND) != "volume" or not img.report:
            return img, None
        return img, next((v for v in img.report.get("volumes", []) if v.get("id") == first.data(DATA)), None)

    def selected_images(self) -> list[Img]:
        view = self.queue if self.active == "queue" else self.tree
        role = DATA if view is self.queue else IMG
        paths = []
        for i in view.selectionModel().selectedRows(0):
            p = i.data(role)
            if p in self.imgs and p not in paths:
                paths.append(p)
        return [self.imgs[p] for p in paths]

    def details_text(self, img: Img, v: Optional[dict]) -> str:
        def lines(d: dict, skip=()):
            out = []
            for k, val in d.items():
                if k in skip or val in ("", None, [], {}):
                    continue
                if isinstance(val, (dict, list)):
                    val = json.dumps(val, indent=2, default=str).replace("\n", "\n    ")
                out.append(f"{k}: {val}")
            return out
        if v:
            key, stext = vol_status(v, self.mounts)
            head = [f"{img.name}  {v.get('name')}", f"{describe(v)} — {stext}", ""]
            if key == "mounted":
                m = self.mounts.get(v.get("mount_point"), {})
                head.insert(2, f"live mount: {m.get('fstype')} {m.get('opts')} from {m.get('source')}")
            return "\n".join(head + lines(v))
        rep = img.report or {}
        key, text, _ = self.image_state(img)
        head = [img.name, text, "", f"source: {img.path}"]
        if img.journal:
            head += [f"state file: {img.journal['_file']}"]
        return "\n".join(head + [""] + lines(rep, skip=("volumes",)) + ["", f"{len(rep.get('volumes', []))} volume(s)"])

    # ── operations ──
    def update_actions(self):
        busy = self.runner.running()
        sel = self.selected_images()
        free = [i for i in self.imgs.values() if not i.journal]
        ok = not self.deps_problem
        tip = f" — unavailable: {self.deps_problem}" if self.deps_problem else ""
        self.a_remove.setEnabled(not busy and any(not i.journal for i in sel))
        self.a_discover.setEnabled(ok and not busy and bool([i for i in (sel or free) if not i.journal]))
        self.a_mount.setEnabled(ok and not busy and any(not i.journal for i in sel))
        self.a_mount_all.setEnabled(ok and not busy and bool(free))
        self.a_unmount.setEnabled(not busy and not self.deps_problem.startswith("pkexec") and any(i.journal for i in sel))
        self.a_unmount_all.setEnabled(not busy and not self.deps_problem.startswith("pkexec") and bool(self.journals))
        self.a_refresh.setEnabled(not busy)
        self.a_settings.setEnabled(not busy)
        self.a_cancel.setEnabled(busy and self.runner.op in ("discover", "mount", "unmount") and not self.runner.cancelled)
        self.a_open_root.setEnabled(self.mount_base.is_dir())
        for a in (self.a_discover, self.a_mount, self.a_mount_all):
            a.setToolTip(a.statusTip() + tip)

    def job(self, imgs: list[Img]) -> dict:
        return {"images": [{"path": i.path, "host": i.host, "label": i.label} for i in imgs]}

    def discover(self):
        imgs = [i for i in (self.selected_images() or self.imgs.values()) if not i.journal]
        self.start_op("discover", imgs, ["-d"])

    def mount(self, selected: bool):
        imgs = [i for i in (self.selected_images() if selected else self.imgs.values()) if not i.journal]
        flags = ["--block-only"] if self.cfg("block_only") else []
        if self.cfg("vss"):
            flags.append("--vss")
        if self.cfg("ntfs_driver") != "ntfs-3g":
            flags += ["--ntfs-driver", self.cfg("ntfs_driver")]
        if self.cfg("nbd_max") > 0:
            flags += ["--nbd-max", str(self.cfg("nbd_max"))]
        self.start_op("mount", imgs, flags)

    def unmount(self, selected: bool, confirm: bool = True) -> bool:
        imgs = [i for i in (self.selected_images() if selected else self.imgs.values()) if i.journal]
        if not imgs and not (not selected and self.journals):
            return False
        if confirm:
            names = "\n".join(f"  {i.name}" for i in imgs[:15]) + (f"\n  … and {len(imgs) - 15} more" if len(imgs) > 15 else "")
            r = QMessageBox.question(self, "Unmount", f"Release these image(s) — all of each image's volumes, block "
                                     f"devices and folders?\n\n{names}\n\nNothing is forced: if a program still has files "
                                     "open on a volume, that image stays attached and the log names the program.",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel)
            if r != QMessageBox.StandardButton.Yes:
                return False
        job = self.job(imgs) if selected else {}
        return self.start_op("unmount", imgs, ["-u"], job=job, allow_empty=not selected)

    def start_op(self, op: str, imgs: list[Img], flags: list[str], job: Optional[dict] = None,
                 allow_empty: bool = False) -> bool:
        if self.runner.running():
            return False
        if op != "unmount":
            missing = [i for i in imgs if not os.path.exists(i.path)]
            for i in missing:
                i.error = "source file missing"
                self.log.add("ERROR", f"source file missing: {i.path}", i.name)
                self.render(i)
            imgs = [i for i in imgs if i not in missing]
            for i in imgs:
                i.error = ""
            try:
                anc = next(p for p in [self.mount_base, *self.mount_base.parents] if p.exists())
                free = shutil.disk_usage(anc).free
                if free < 64 * 1024 * 1024:
                    self.log.add("WARNING", f"only {human(free)} free under {anc}: manifests and logs may not fit")
            except (OSError, StopIteration):
                pass
        if not imgs and not allow_empty:
            self.log.add("INFO", "Nothing to do: no eligible images selected")
            return False
        argv = self.elevation() + self.backend_cmd() + ["--json", "-o", str(self.mount_base)] + flags
        if self.cfg("verbose"):
            argv.append("-v")
        for i in imgs:
            i.busy = f"Waiting to {'discover' if op == 'discover' else op}"
            self.render(i)
        self.op_reports, self.op_summary = [], {}
        self.stderr_tail.clear()
        self.op_total = len(imgs)
        self.log.add("INFO", f"{OP_TEXT[op]} {len(imgs) or 'all recorded'} image(s)")
        self.op_label.setText(f"{OP_TEXT[op]}: waiting for authorisation…" if self.elevation() else f"{OP_TEXT[op]}…")
        self.progress.setRange(0, 0)
        self.progress.show()
        self.cancel_btn.show()
        self.cancel_btn.setEnabled(True)
        self.clock.start()
        self.tick.start()
        self._tick()
        self.runner.start(op, argv, self.job(imgs) if job is None else job)
        self.update_actions()
        return True

    def cancel(self):
        if self.runner.running():
            self.runner.cancel()
            self.cancel_btn.setEnabled(False)
            self.op_label.setText(f"Stopping after the current step (finishing safe cleanup)…")
            self.log.add("WARNING", "Cancel requested: the backend finishes its current step and records everything "
                                    "it attached; nothing is left half-done")
            self.update_actions()

    def _tick(self):
        s = int(self.clock.elapsed() / 1000) if self.clock.isValid() else 0
        self.elapsed_label.setText(f"{s // 60}:{s % 60:02d}")

    def img_name(self, path: str) -> str:
        i = self.imgs.get(path or "")
        return i.name if i else (Path(path).name if path else "")

    def on_line(self, line: str):
        self.stderr_tail.append(line)
        self.log.add("OUT", line)

    def on_event(self, e: dict):
        ev = e.get("event")
        if ev == "log":
            self.log.add(e.get("level", "INFO"), e.get("msg", ""), self.img_name(e.get("image", "")))
        elif ev == "start":
            self.progress.setRange(0, max(1, e.get("total", 0)))
            self.progress.setValue(0)
        elif ev == "image_start":
            if self.progress.maximum() == 0:
                self.progress.setRange(0, max(1, e.get("total", 0)))
            img = self.imgs.get(e.get("path", ""))
            name = img.name if img else e.get("path", "")
            self.op_label.setText(f"{OP_TEXT.get(self.runner.op, '')} {e.get('index', 0) + 1}/{e.get('total', '?')}: {name}")
            if img:
                img.busy = f"{OP_TEXT.get(self.runner.op, '')}…"
                self.render(img)
        elif ev == "image_done":
            rep = e.get("report") or {}
            img = self.imgs.get(rep.get("path", ""))
            self.op_reports.append(rep)
            self.progress.setValue(self.progress.value() + 1)
            if img:
                img.busy = ""
                img.report, img.kind, img.manifest_mtime = rep, ("discovery" if self.runner.op == "discover" else "mount"), 0
                self.render(img)
                self.update_counts()
        elif ev == "image_released":
            img = self.imgs.get(e.get("path", ""))
            self.progress.setValue(self.progress.value() + 1)
            if img:
                img.busy = "" if e.get("ok") else "Busy — still attached"
                self.render(img)
        elif ev == "unmount_done":
            self.op_summary = e
        elif ev == "error":
            self.log.add("ERROR", f"{e.get('category')}: {e.get('message')}")

    def on_done(self, rc: int, op: str):
        self.tick.stop()
        self._tick()
        self.progress.hide()
        self.cancel_btn.hide()
        busy_left = []
        for i in self.imgs.values():
            if i.busy.startswith("Busy"):
                busy_left.append(i)
            i.busy = ""
        explain = ""
        if not self.runner.got_events:
            explain = {126: "Authorisation was dismissed or refused (pkexec).",
                       127: "Not authorised, or no polkit authentication agent is running (pkexec).",
                       -2: "The backend could not be started.", -1: "The backend crashed."}.get(rc, "")
            if "sudo" in self.elevation() and rc == 1:
                explain = "sudo -n needs a NOPASSWD rule for the backend (README: Privileges)."
            for l in self.stderr_tail:
                self.log.add("ERROR", l)
        elif rc == -1:
            explain = "The backend stopped unexpectedly. Everything it attached is journaled; Refresh shows it."
        self.refresh()
        reps = self.op_reports
        if op == "unmount":
            s = self.op_summary
            msg = f"Released {s.get('released', 0)} of {s.get('total', 0)} image(s)."
            if s.get("busy"):
                msg += f"\n{len(s['busy'])} still attached because files are open (see the log for the programs)."
            if s.get("leftovers"):
                msg += f"\n{len(s['leftovers'])} leftover item(s) not released — see the log."
        else:
            vols = [v for r in reps for v in r.get("volumes", [])]
            cnt = lambda s: sum(v.get("status") == s for v in vols)
            msg = (f"{OP_NOUN[op]} finished: {len(reps)} image(s) — ok {sum(r.get('status') == 'ok' for r in reps)}, "
                   f"partial {sum(r.get('status') == 'partial' for r in reps)}, failed {sum(r.get('status') == 'failed' for r in reps)}"
                   + (f", already mounted {sum(r.get('status') == 'already_mounted' for r in reps)}" if op == "mount" else "")
                   + f".\nVolumes: {len(vols)} — " + (f"mountable {cnt('planned')}" if op == "discover" else
                                                     f"mounted {cnt('mounted')}, block-only {cnt('block_device')}")
                   + f", skipped by design {cnt('skipped')}, failed {cnt('failed')}.")
        if rc == 130 or self.runner.cancelled:
            msg = "Cancelled after the current step.\n" + msg + ("\nWhat was attached before the cancel stays recorded; "
                                                                "Unmount releases it." if op == "mount" else "")
        if explain:
            msg = explain + ("\n\n" + msg if self.runner.got_events else "")
        self.log.add("ERROR" if explain else "INFO", msg.replace("\n", " "))
        self.op_label.setText("Idle")
        self.update_actions()
        if self.close_after:
            todo, self.close_after = self.close_after, ""
            if todo == "unmount" and not self.journals_live():
                self.close()
                return
            if todo == "close":
                self.close()
                return
            QMessageBox.warning(self, "Not closed", "Some images are still attached (busy). Close the programs using "
                                                    "them and unmount again, or close and leave them mounted.")
            return
        box = QMessageBox(QMessageBox.Icon.Warning if explain or rc not in (0, 130) else QMessageBox.Icon.Information,
                          APP_NAME, msg, QMessageBox.StandardButton.Ok, self)
        box.setModal(False)
        box.open()
        self._last_box = box

    def journals_live(self) -> bool:
        return any(st.get("_live") for st in self.journals.values())

    # ── direct access ──
    def open_path(self, path):
        path = str(path)
        if not os.path.exists(path):
            self.log.add("WARNING", f"not found: {path}")
            return
        fm = self.cfg("file_manager")
        ok = QProcess.startDetached(fm, [path])[0] if fm else QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        if not ok:
            self.log.add("ERROR", f"could not open {path} " + (f"with {fm}" if fm else "(no file manager registered for folders)"))

    def copy(self, text: str):
        QGuiApplication.clipboard().setText(text)
        self.statusBar().showMessage("Copied: " + (text if len(text) < 120 else text[:120] + "…"), 4000)

    def on_queue_double(self, idx):
        img = self.imgs.get(idx.data(DATA))
        if img and img.journal:
            self.open_path(img.report.get("image_dir") if img.report else Path(img.journal["_file"]).parent)

    def on_tree_double(self, idx):
        img, v = self.vol_at(idx)
        if v and vol_status(v, self.mounts)[0] == "mounted":
            self.open_path(v["mount_point"])
        elif img and img.journal and not v:
            self.open_path((img.report or {}).get("image_dir") or Path(img.journal["_file"]).parent)

    def context_menu(self, view, pos):
        idx = view.indexAt(pos)
        if not idx.isValid():
            return
        img, v = self.current()
        if not img:
            return
        m = QMenu(self)
        add = lambda text, fn, on=True: m.addAction(text, fn).setEnabled(bool(on))
        rep = img.report or {}
        if v:
            live = vol_status(v, self.mounts)[0] == "mounted"
            add("Open mount folder", lambda: self.open_path(v["mount_point"]), live)
            add("Copy mount path", lambda: self.copy(v["mount_point"]), live)
            add("Copy block device path", lambda: self.copy(v.get("dev_link") or v.get("dev", "")),
                img.journal and (v.get("dev_link") or v.get("dev")))
            m.addSeparator()
        add("Open image's mount folder", lambda: self.open_path(rep.get("image_dir")), img.journal and rep.get("image_dir"))
        add("Open block-device folder", lambda: self.open_path(rep.get("dev_dir")),
            img.journal and rep.get("dev_dir") and os.path.isdir(rep.get("dev_dir", "")))
        add("Open folder holding the image file", lambda: self.open_path(Path(img.path).parent))
        add("Copy image path", lambda: self.copy(img.path))
        add("Copy details", lambda: self.copy(self.details_text(img, v)))
        add("View manifest…", lambda: self.show_manifest(img), img.report)
        m.addSeparator()
        busy = self.runner.running()
        add("Discover", self.discover, not busy and not img.journal and not self.deps_problem)
        add("Mount", lambda: self.mount(True), not busy and not img.journal and not self.deps_problem)
        add("Unmount image…" if v else "Unmount…", lambda: self.unmount(True), not busy and img.journal)
        add("Remove from queue", self.remove_selected, not busy and not img.journal)
        m.exec(view.viewport().mapToGlobal(pos))

    def show_manifest(self, img: Img):
        d = QDialog(self)
        d.setWindowTitle(f"Manifest — {img.name}")
        d.resize(980, 640)
        tabs = QTabWidget()
        texts = []
        if img.journal:
            base = Path(img.journal["_file"]).parent
            for f in (self.me.INFO_FILE, self.me.MANIFEST_FILE):
                try:
                    texts.append((f, (base / f).read_text(errors="replace")))
                except OSError as e:
                    texts.append((f, f"cannot read {base / f}: {e}"))
        else:
            texts.append(("Discovery report (not written to disk)", json.dumps(img.report, indent=2, default=str)))
        for title, t in texts:
            w = QPlainTextEdit(t)
            w.setReadOnly(True)
            w.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
            w.setFont(self.details.font())
            tabs.addTab(w, title)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(d.reject)
        lay = QVBoxLayout(d)
        lay.addWidget(tabs)
        lay.addWidget(bb)
        d.open()
        return d

    # ── settings / help ──
    def open_settings(self):
        dlg = SettingsDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            for k, val in dlg.values().items():
                self.settings.setValue(k, val)
            self.apply_column_settings()
            self.log.add("INFO", "Settings saved; privileged steps run as: " + " ".join(self.elevation() + self.backend_cmd()))
            self.deps_problem = ""
            self.startup_checks()
            self.refresh()

    def show_help(self):
        box = QMessageBox(QMessageBox.Icon.Information, APP_NAME, f"""{APP_NAME} {VERSION} — read-only forensic image mounting

1. Add images, a folder, or a folder tree (first-level subfolders are hosts).
2. Discover: identify partitions and filesystems; nothing stays attached.
3. Mount selected / Mount all: read-only mounts under {self.mount_base},
   every partition as a read-only block device under {self.dev_base}.
4. Double-click a mounted volume to open it in the file manager.
5. Unmount selected / Unmount all when finished. Nothing is forced; busy
   volumes stay attached and the log names the programs holding them.

Only images this tool attached are ever unmounted. Swap is never
activated, nothing is repaired or replayed, nothing is mounted read-write.

Command line, same backend: sudo mount-evidence --help
Guide: README.md next to this program ({HERE}).""", QMessageBox.StandardButton.Ok, self)
        if ICON.is_file():
            box.setIconPixmap(QIcon(str(ICON)).pixmap(96, 96))
        box.exec()

    # ── closing ──
    def closeEvent(self, ev):
        for k, v in (("geometry", self.saveGeometry()), ("state", self.saveState()),
                     ("split_main", self.split_main.saveState()), ("split_left", self.split_left.saveState())):
            self.settings.setValue(k, v)
        if self.runner.running():
            if self.close_after:
                ev.ignore()
                return
            r = QMessageBox.question(self, "Operation running",
                                     f"{OP_TEXT.get(self.runner.op, 'An operation')} is still running.\n\n"
                                     "Stop and close: the backend finishes its current step, records what it attached, "
                                     "then the window closes (attached images stay mounted).\n"
                                     "Keep running: return to the window.",
                                     QMessageBox.StandardButton.Close | QMessageBox.StandardButton.Cancel,
                                     QMessageBox.StandardButton.Cancel)
            if r == QMessageBox.StandardButton.Close:
                self.close_after = "close"
                self.cancel()
            ev.ignore()
            return
        self.refresh()
        if self.journals_live():
            n = sum(1 for st in self.journals.values() if st.get("_live"))
            box = QMessageBox(QMessageBox.Icon.Question, "Images still mounted",
                              f"{n} image(s) attached by this tool are still mounted.\n\n"
                              "Leave mounted: close the window; the mounts stay usable and the next start of this "
                              "program (or mount_evidence --unmount) can release them.\n"
                              "Unmount and close: release this tool's images first (nothing is forced; busy ones "
                              "stay and the window stays open).\n"
                              "Cancel: keep working.", QMessageBox.StandardButton.NoButton, self)
            leave = box.addButton("Leave mounted", QMessageBox.ButtonRole.AcceptRole)
            unmount = box.addButton("Unmount and close", QMessageBox.ButtonRole.DestructiveRole)
            box.addButton(QMessageBox.StandardButton.Cancel)
            box.exec()
            if box.clickedButton() is unmount:
                if self.unmount(False, confirm=False):
                    self.close_after = "unmount"
                ev.ignore()
                return
            if box.clickedButton() is not leave:
                ev.ignore()
                return
            self.log.add("INFO", f"Closed with {n} image(s) left mounted")
        ev.accept()


def app_settings() -> QSettings:
    """~/.config/MountSleuth/. Settings saved by versions that used the IOC_SCAN name come along once,
    except the old default mount root, so the new default applies."""
    s, old = QSettings("MountSleuth", "mount-evidence-gui"), QSettings("IOC_SCAN", "mount-evidence-gui")
    if not s.allKeys():
        for k in old.allKeys():
            if not (k == "mount_base" and old.value(k) == "/mnt/IOC_SCAN"):
                s.setValue(k, old.value(k))
        s.sync()
    return s


BAD_PYSIDE = {"6.12.0"}      # shiboken refcount regression: crashes (none_dealloc / bool_dealloc) mid-operation

def main() -> int:
    import PySide6
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName("MountSleuth")
    app.setDesktopFileName("mount-evidence-gui")           # Wayland docks take the taskbar icon from this .desktop
    if ICON.is_file():
        app.setWindowIcon(QIcon(str(ICON)))                # X11 taskbars use the window icon itself
    if PySide6.__version__ in BAD_PYSIDE:
        QMessageBox.critical(None, APP_NAME, f"PySide6 {PySide6.__version__} has a reference-counting bug "
                             "that crashes this program part-way through an operation.\n\nInstall another version, e.g.\n"
                             "  pip install 'PySide6-Essentials==6.11.0'")
        return 2
    try:
        me = load_backend(BACKEND)
    except Exception as e:                                 # missing or broken backend: say so, don't crash
        QMessageBox.critical(None, APP_NAME, f"Cannot load the backend {BACKEND}:\n{e}")
        return 2
    w = MainWindow(me)
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
