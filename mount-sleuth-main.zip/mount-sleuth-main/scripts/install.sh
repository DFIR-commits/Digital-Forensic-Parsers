#!/bin/sh
# Install or update Mount Sleuth (GUI + mount_evidence backend). From the repository folder:
#
#   sudo sh scripts/install.sh                  everything: apt packages (kpartx, ewf-tools, ...,
#                                               pkexec, Qt libraries), vmfs6-tools built from third_party/
#                                               and PySide6 in /opt/mount-evidence-venv
#   sudo sh scripts/install.sh --wheels DIR     same, PySide6 offline from `pip download` output
#   sudo sh scripts/install.sh --no-venv        no venv: the system python3 must already import PySide6
#   sudo sh scripts/install.sh --no-apt         skip apt (offline box with the packages already there)
#   sudo sh scripts/install.sh --nbd-max N      NBD slots, i.e. VMDK/QCOW2/VHDX attached at once (default 64)
#   sudo sh scripts/install.sh --uninstall      remove the program files (not the venv, logs or mounts)
#
# Why: the backend runs as root, so the copy pkexec runs must be root-owned (a
# user-writable script elevated by pkexec is a way to root). The polkit rule
# names that one file and keeps the authorisation for a few minutes, so a
# discover-then-mount session asks for the password once.
set -eu
HERE=$(cd "$(dirname "$0")/.." && pwd)
SRC=$HERE/src
LIB=/usr/local/lib/mount-evidence
WRAP=/usr/local/sbin/mount-evidence
LAUNCH=/usr/local/bin/mount-evidence-gui
POLICY=/usr/share/polkit-1/actions/local.mount-sleuth.mount-evidence.policy
OLD_POLICY=/usr/share/polkit-1/actions/local.ioc-scan.mount-evidence.policy   # name before 1.0.0
V6TOOLS="vmfs6-fuse debugvmfs6 fsck.vmfs6 vmfs6-lvm"   # built from third_party/ into /usr/local/sbin
DESKTOP=/usr/share/applications/mount-evidence-gui.desktop
LOGROTATE=/etc/logrotate.d/mount-sleuth
VENV=/opt/mount-evidence-venv
NBD_CONF=/etc/modprobe.d/mount-sleuth-nbd.conf        # mount_evidence_prod.py's NBD_CONF
NBD_LOAD=/etc/modules-load.d/mount-sleuth-nbd.conf
NBD_MAX=64                                            # VMDK/QCOW2/VHDX images attached at once
PYSIDE="PySide6-Essentials==6.11.0"         # 6.12.0 crashes (shiboken refcount bug); see README

[ "$(id -u)" = 0 ] || { echo "run as root: sudo sh $0 $*"; exit 1; }
[ -f "$SRC/mount_evidence_prod.py" ] || { echo "run from an unpacked Mount Sleuth folder ($SRC/mount_evidence_prod.py missing)"; exit 1; }
MAKE_VENV=auto WHEELS="" APT=1
while [ $# -gt 0 ]; do
  case "$1" in
    --uninstall) rm -f "$WRAP" "$LAUNCH" "$POLICY" "$OLD_POLICY" "$DESKTOP" "$NBD_CONF" "$NBD_LOAD" "$LOGROTATE"; rm -rf "$LIB"
                 for t in $V6TOOLS; do rm -f "/usr/local/sbin/$t"; done
                 echo "removed Mount Sleuth (left alone: $VENV, /var/log/mount_evidence.log*, apt packages, anything still mounted)"
                 echo "to remove the venv as well: sudo rm -rf $VENV"; exit 0 ;;
    --venv) MAKE_VENV=1 ;;                  # the default; kept for older instructions
    --no-venv) MAKE_VENV=0 ;;
    --no-apt) APT=0 ;;
    --wheels) WHEELS=${2:?--wheels needs a folder}; shift
              [ -d "$WHEELS" ] || { echo "--wheels: no such folder: $WHEELS"; exit 2; } ;;
    --nbd-max) NBD_MAX=${2:?--nbd-max needs a number}; shift
               case $NBD_MAX in ''|*[!0-9]*|0) echo "--nbd-max: a whole number from 1, not '$NBD_MAX'"; exit 2 ;; esac ;;
    *) echo "unknown option $1 (see the top of $0)"; exit 2 ;;
  esac
  shift
done

# Backend tools (README: Dependencies), pkexec for the password prompt, python3-venv,
# and the X11/GL libraries the PySide6 wheel loads but desktops don't always have.
# package:tool = skip the package when the tool is already there from elsewhere (SIFT ships
# libewf-tools / libvshadow-tools, which conflict with Ubuntu's ewf-tools / libvshadow-utils).
PKGS="util-linux fdisk mount kmod:modprobe kpartx:kpartx dmsetup:dmsetup udev:udevadm ntfs-3g:ntfs-3g
      ewf-tools:ewfmount qemu-utils:qemu-nbd afflib-tools:affuse lvm2:lvs libvshadow-utils:vshadowinfo
      vmfs-tools:vmfs-fuse psmisc:fuser logrotate:logrotate xdg-utils:xdg-open
      gcc make libc6-dev pkg-config libfuse-dev uuid-dev
      python3 python3-venv pkexec:pkexec
      libgl1 libegl1 libfontconfig1 libdbus-1-3 libxkbcommon-x11-0 libxcb-cursor0
      libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-render-util0 libxcb-shape0 libxcb-xkb1"
if [ $APT = 1 ] && command -v apt-get >/dev/null; then
  apt-get update || echo "WARNING: apt-get update failed, installing from the cached package lists"
  # pkexec is its own package from Ubuntu 22.04 / Debian 12, policykit-1 before that;
  # skip any name this release doesn't have (e.g. libxcb-cursor0 on 20.04) instead of failing the lot
  have=""
  for e in $PKGS; do
    p=${e%%:*} t=${e#*:}
    [ "$t" != "$e" ] && command -v "$t" >/dev/null && continue
    [ $p = pkexec ] && ! apt-cache show pkexec >/dev/null 2>&1 && p=policykit-1
    if apt-cache show "$p" >/dev/null 2>&1; then have="$have $p"; else echo "note: no package $p here, skipped"; fi
  done
  # one conflicting package must not block the rest: retry one at a time
  # shellcheck disable=SC2086
  DEBIAN_FRONTEND=noninteractive apt-get install -y $have || for p in $have; do
    DEBIAN_FRONTEND=noninteractive apt-get install -y "$p" >/dev/null 2>&1 || echo "WARNING: apt could not install $p"
  done
elif [ $APT = 1 ]; then
  echo "WARNING: no apt-get - install the tools in README > Dependencies with your package manager"
fi

# VMFS 6: build vmfs6-tools from third_party/ (pinned upstream source + a crash fix) instead of
# the distribution package, whose vmfs6-fuse crashes on every run (third_party/README.md).
# The mount-evidence wrapper puts /usr/local/sbin first on PATH, so this build wins.
b=$(mktemp -d)
if cp -r "$HERE/third_party/vmfs6-tools/." "$b/" && (cd "$b" && sh ./configure && make) >"$b/build.log" 2>&1; then
  for t in $V6TOOLS; do install -o root -g root -m 0755 "$b/$t/$t" /usr/local/sbin/; done
  echo "built vmfs6-tools (third_party/, upstream 582b525 + fix) into /usr/local/sbin"
else
  echo "WARNING: could not build vmfs6-tools - VMFS 6 volumes won't mount. End of the build log:"
  tail -5 "$b/build.log"
fi
rm -rf "$b"

# NBD for VMDK/QCOW2/VHDX: one slot per attached image; partitions come from kpartx (max_part=0).
# Stock Ubuntu doesn't load nbd, so set the options and load it at every boot, and now.
mkdir -p "$(dirname "$NBD_CONF")" "$(dirname "$NBD_LOAD")" "$(dirname "$LOGROTATE")"
echo "options nbd nbds_max=$NBD_MAX max_part=0" > "$NBD_CONF"
echo nbd > "$NBD_LOAD"
# Kernel drivers the read-only mounts use. Ubuntu keeps exfat, ntfs3, f2fs, hfsplus and hfs
# (and on some kernels nbd) in linux-modules-extra-<kernel>, which minimal installs lack.
FSMODS="nbd exfat ntfs3 xfs btrfs f2fs hfsplus hfs udf isofs squashfs vfat"
missing=""
for m in $FSMODS; do
  modprobe -n -q "$m" 2>/dev/null || grep -qw "$m" /proc/filesystems || missing="$missing $m"
done
if [ -n "$missing" ] && [ $APT = 1 ] && command -v apt-get >/dev/null \
   && apt-cache show "linux-modules-extra-$(uname -r)" >/dev/null 2>&1; then
  echo "kernel drivers missing:$missing - installing linux-modules-extra-$(uname -r)"
  apt-get install -y "linux-modules-extra-$(uname -r)" || echo "WARNING: could not install linux-modules-extra-$(uname -r)"
fi
if [ -d /sys/module/nbd ] && [ "$(cat /sys/module/nbd/parameters/nbds_max)" != "$NBD_MAX" ]; then
  rmmod nbd 2>/dev/null || echo "note: nbd is in use with $(cat /sys/module/nbd/parameters/nbds_max) slots; $NBD_MAX after a reboot"
fi
modprobe nbd || echo "WARNING: could not load the nbd module - VMDK/QCOW2/VHDX images won't mount"

if [ $MAKE_VENV = auto ]; then
  # Always the pinned, tested PySide6 in its own venv: a distribution or pip-installed
  # PySide6 may be the broken 6.12.0. Python too old for the wheel: no venv (see README).
  MAKE_VENV=1
  python3 -c 'import sys; sys.exit(sys.version_info < (3, 9))' || { MAKE_VENV=0; echo "note: python3 < 3.9, not creating the PySide6 venv"; }
fi

install -d -o root -g root -m 0755 "$LIB" "$LIB/docs"
install -o root -g root -m 0644 "$SRC/mount_evidence_prod.py" "$SRC/mount_evidence_gui.py" "$SRC/mount-sleuth.png" \
  "$HERE/README.md" "$HERE/VERSION" "$LIB/"
install -o root -g root -m 0644 "$HERE"/docs/*.md "$LIB/docs/"
rm -f "$LIB/MOUNT_EVIDENCE.md" "$LIB/MOUNT_EVIDENCE_GUI.md" "$OLD_POLICY"    # names before 1.0.0

# The backend logs every run here. Compress it monthly but never delete old logs:
# they may be part of a case's audit trail (rotate -1 = keep all).
cat > "$LOGROTATE" <<'EOF'
/var/log/mount_evidence.log {
    monthly
    rotate -1
    compress
    delaycompress
    missingok
    notifempty
}
EOF
chmod 0644 "$LOGROTATE"

cat > "$WRAP" <<'EOF'
#!/bin/sh
# Root side of Mount Sleuth. pkexec runs exactly this file (see the polkit policy).
# A fixed PATH (pkexec's own lacks /usr/local), /usr/local/sbin first for install.sh's vmfs6-tools.
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin; export PATH
exec /usr/bin/python3 -I /usr/local/lib/mount-evidence/mount_evidence_prod.py "$@"
EOF
chown root:root "$WRAP"; chmod 0755 "$WRAP"

cat > "$LAUNCH" <<EOF
#!/bin/sh
PY=$VENV/bin/python3
[ -x "\$PY" ] || PY=python3
exec "\$PY" $LIB/mount_evidence_gui.py "\$@"
EOF
chmod 0755 "$LAUNCH"

mkdir -p "$(dirname "$POLICY")"
cat > "$POLICY" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE policyconfig PUBLIC "-//freedesktop//DTD PolicyKit Policy Configuration 1.0//EN"
 "http://www.freedesktop.org/standards/PolicyKit/1/policyconfig.dtd">
<policyconfig>
  <action id="local.mount-sleuth.mount-evidence">
    <description>Attach forensic images read-only</description>
    <message>Authentication is required to attach or release forensic images (read-only)</message>
    <defaults>
      <allow_any>auth_admin</allow_any>
      <allow_inactive>auth_admin</allow_inactive>
      <allow_active>auth_admin_keep</allow_active>
    </defaults>
    <annotate key="org.freedesktop.policykit.exec.path">$WRAP</annotate>
  </action>
</policyconfig>
EOF
chmod 0644 "$POLICY"

ICON=drive-harddisk                       # stock icon unless mount-sleuth.png sits next to this script
[ -f "$LIB/mount-sleuth.png" ] && ICON=$LIB/mount-sleuth.png
mkdir -p "$(dirname "$DESKTOP")"
cat > "$DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=Mount Sleuth
Comment=Mount forensic disk images read-only
Exec=$LAUNCH
Icon=$ICON
StartupWMClass=Mount Sleuth
Terminal=false
Categories=System;Utility;
EOF
chmod 0644 "$DESKTOP"

if [ $MAKE_VENV = 1 ]; then
  # Debian/Ubuntu ship venv support separately (python3-venv), not installed by default
  if ! python3 -c 'import ensurepip' 2>/dev/null; then
    command -v apt-get >/dev/null || { echo "Python venv support is missing: install your distribution's python3-venv"; exit 1; }
    apt-get install -y python3-venv
  fi
  # a half-made venv would be picked by the launcher and has no PySide6
  python3 -m venv "$VENV" || { rm -rf "$VENV"; echo "could not create $VENV"; exit 1; }
  if [ -n "$WHEELS" ]; then
    set -- --no-index --find-links "$WHEELS"
  else
    set --
  fi
  echo "Installing $PYSIDE into $VENV (downloads about 100 MB unless --wheels)..."
  "$VENV/bin/pip" install -q "$@" "$PYSIDE" || {
    rm -rf "$VENV"
    echo "ERROR: could not install $PYSIDE (no internet? use --wheels DIR, see README). The GUI is not usable;"
    echo "       the command line (sudo mount-evidence) is installed and works without it."
    exit 1; }
  chown -R root:root "$VENV"
fi

# ── Verify ────────────────────────────────────────────────────────────────────
echo
echo "Mount Sleuth $(cat "$LIB/VERSION") installed:"
echo "  $LIB/   backend + GUI + docs (root-owned)"
echo "  $WRAP          command line, and what pkexec runs (polkit: $POLICY)"
echo "  $LAUNCH        the GUI (also in the desktop menu: Mount Sleuth)"
echo
fail=0
check() {   # check LEVEL WHAT CMD...  (LEVEL FAIL makes the install exit 1)
  lvl=$1 what=$2; shift 2
  if "$@" >/dev/null 2>&1; then echo "  ok    $what"; else echo "  $lvl  $what"; [ "$lvl" = FAIL ] && fail=1; fi
  return 0
}
check FAIL "backend runs ($WRAP --version)" "$WRAP" --version
for t in losetup sfdisk blkid blockdev mount umount kpartx dmsetup; do
  check FAIL "required tool $t" command -v $t
done
for t in modprobe:"loading the nbd module" udevadm:"waiting for new devices to appear" \
         ewfmount:"E01 images" ewfinfo:"E01 case details" qemu-nbd:"VMDK/QCOW2/VHDX/VHD images" \
         qemu-img:"VMDK/QCOW2/VHDX/VHD details" affuse:"AFF images" ntfs-3g:"NTFS volumes" \
         lvs:"LVM volumes" pvs:"LVM volumes" vshadowinfo:"shadow-copy detection" \
         vshadowmount:"shadow-copy mounting" vmfs-fuse:"VMware VMFS 3/5" \
         fuser:"naming programs that keep a volume busy" logrotate:"monthly log compression" \
         xdg-open:"GUI: opening a mounted folder"; do
  check "warn" "optional tool ${t%%:*} (${t#*:})" command -v "${t%%:*}"
done
# exit 128+ = killed by a signal: the crash the distribution's vmfs6-fuse has
check "warn" "vmfs6-fuse runs (VMware VMFS 6; /usr/local/sbin, built from third_party/)" \
  sh -c '[ -x /usr/local/sbin/vmfs6-fuse ] && { /usr/local/sbin/vmfs6-fuse /dev/null /nonexistent -o ro; [ $? -lt 128 ]; }'
check "warn" "nbd kernel module loaded (VMDK/QCOW2/VHDX/VHD)" test -e /dev/nbd0
for m in $FSMODS; do
  [ $m = nbd ] && continue
  check "warn" "kernel driver $m (mounting $m volumes)" sh -c "modprobe -n -q $m || grep -qw $m /proc/filesystems"
done
check "warn" "pkexec (GUI password prompt)" command -v pkexec
if [ -x "$VENV/bin/python3" ]; then PY="$VENV/bin/python3"; else PY=python3; fi
u=${SUDO_USER:-root}
check "warn" "GUI: PySide6 importable for $u ($PY)" su "$u" -s /bin/sh -c "$PY -c 'import PySide6.QtWidgets'"
if grep -q " /mnt/IOC_SCAN" /proc/mounts; then   # mount root before the MountSleuth rename
  echo "note: images an older version attached are still under /mnt/IOC_SCAN; the default root is now"
  echo "      /mnt/MountSleuth. Release them with: sudo mount-evidence -o /mnt/IOC_SCAN --unmount"
fi
echo
if [ $fail = 1 ]; then
  echo "Install INCOMPLETE: a required item above is FAIL. See README > Troubleshooting."
  exit 1
fi
echo "Done. 'warn' lines are optional features; see README > Dependencies for what each adds."
echo "Start the GUI from the applications menu (Mount Sleuth) or run: mount-evidence-gui"
