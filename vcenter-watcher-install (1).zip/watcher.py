"""
watcher.py

Webhook listener that, on a validated trigger:
  1. Creates a memory snapshot of the target VM via the vCenter/ESXi API
  2. Locates and downloads the resulting .vmem/.vmsn files to local disk
  3. Removes the snapshot from the VM to free datastore space

Config is supplied via environment / systemd EnvironmentFile (.env).
"""

from flask import Flask, request, abort
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl, time, hmac, hashlib, os, json, datetime, logging, urllib.parse
import requests

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

WEBHOOK_SECRET = os.environ["WEBHOOK_SECRET"].encode()
VCENTER_HOST = os.environ["VCENTER_HOST"]
VCENTER_USER = os.environ["VCENTER_USER"]
VCENTER_PWD = os.environ["VCENTER_PWD"]
VM_NAME = os.environ["VM_NAME"]
CA_CERT_PATH = os.environ.get("CA_CERT_PATH")
SKIP_SSL_VERIFY = os.environ.get("SKIP_SSL_VERIFY", "false").lower() == "true"
OUTPUT_DIR = os.environ.get("OUTPUT_DIR", "/opt/vcenter-watcher/output")
LISTEN_PORT = int(os.environ.get("LISTEN_PORT", "8443"))
REMOVE_SNAPSHOT_AFTER_DOWNLOAD = os.environ.get("REMOVE_SNAPSHOT_AFTER_DOWNLOAD", "true").lower() == "true"

os.makedirs(OUTPUT_DIR, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("watcher")

if SKIP_SSL_VERIFY:
    log.warning("SKIP_SSL_VERIFY is enabled - TLS verification is DISABLED. Do not run this way in production.")

# ---------------------------------------------------------------------------
# vCenter / ESXi connection helpers
# ---------------------------------------------------------------------------

def _ssl_context():
    if SKIP_SSL_VERIFY:
        return ssl._create_unverified_context()
    if CA_CERT_PATH:
        return ssl.create_default_context(cafile=CA_CERT_PATH)
    return None  # system default trust store


def connect_vcenter():
    ctx = _ssl_context()
    return SmartConnect(host=VCENTER_HOST, user=VCENTER_USER, pwd=VCENTER_PWD, sslContext=ctx)


def find_vm(si, vm_name):
    content = si.RetrieveContent()
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    vm = next((v for v in container.view if v.name == vm_name), None)
    if not vm:
        raise RuntimeError(f"VM '{vm_name}' not found")
    return vm


def get_datacenter_name(si):
    """Assumes a single datacenter, which is the common case for standalone
    ESXi (default name 'ha-datacenter') and small labs. If you have multiple
    datacenters, this needs to walk the VM's parent chain instead."""
    content = si.RetrieveContent()
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.Datacenter], True)
    dc = container.view[0]
    return dc.name

# ---------------------------------------------------------------------------
# Snapshot lifecycle
# ---------------------------------------------------------------------------

def snapshot_vm(si, vm_name, snapshot_name, description="Auto-snapshot triggered by watcher"):
    vm = find_vm(si, vm_name)

    task = vm.CreateSnapshot_Task(
        name=snapshot_name,
        description=description,
        memory=True,
        quiesce=False
    )

    while task.info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
        time.sleep(1)

    if task.info.state == vim.TaskInfo.State.error:
        raise RuntimeError(f"Snapshot task failed: {task.info.error.msg}")

    return {
        "vm": vm.name,
        "snapshot_name": snapshot_name,
        "state": str(task.info.state),
        "start_time": str(task.info.startTime),
        "completion_time": str(task.info.completeTime),
    }


def find_snapshot_obj(vm, snapshot_name):
    """Walk the VM's snapshot tree and return the vim.vm.Snapshot object
    matching snapshot_name."""
    if vm.snapshot is None:
        return None

    def recurse(tree_list):
        for node in tree_list:
            if node.name == snapshot_name:
                return node
            found = recurse(node.childSnapshotList)
            if found:
                return found
        return None

    return recurse(vm.snapshot.rootSnapshotList)


def get_snapshot_files(vm, snapshot_ref):
    """Return the list of datastore-relative file paths (as strings, e.g.
    '[datastore1] myvm/myvm-Snapshot1.vmsn') associated with a given
    snapshot moref, by matching against the VM's layoutEx."""
    layout = vm.layoutEx
    files = []
    for snap_layout in layout.snapshot:
        if snap_layout.key == snapshot_ref:
            files.extend(snap_layout.snapshotFile)
    return files


def _parse_datastore_path(ds_path):
    """'[datastore1] folder/sub/file.vmem' -> ('datastore1', 'folder/sub/file.vmem')"""
    ds_name = ds_path[ds_path.index("[") + 1: ds_path.index("]")]
    rel_path = ds_path[ds_path.index("]") + 1:].strip()
    return ds_name, rel_path


def download_snapshot_files(si, vm, snapshot_name, output_dir):
    """Locate the .vmem/.vmsn files for a snapshot and download them to
    output_dir over HTTPS, reusing the authenticated API session's cookie."""
    snap_obj = find_snapshot_obj(vm, snapshot_name)
    if not snap_obj:
        raise RuntimeError(f"Could not find snapshot object for '{snapshot_name}' after creation")

    ds_paths = get_snapshot_files(vm, snap_obj.snapshot)
    if not ds_paths:
        raise RuntimeError(f"No files found in layoutEx for snapshot '{snapshot_name}'")

    dc_name = get_datacenter_name(si)
    cookie_value = si._stub.cookie  # e.g. 'vmware_soap_session="52xxxx...."'
    session = requests.Session()
    session.headers.update({"Cookie": cookie_value})

    verify = False if SKIP_SSL_VERIFY else (CA_CERT_PATH if CA_CERT_PATH else True)

    downloaded = []
    for ds_path in ds_paths:
        # Only pull the files we actually want for forensics; skip disk
        # deltas etc if present in this list.
        if not (ds_path.lower().endswith(".vmem") or ds_path.lower().endswith(".vmsn")):
            continue

        ds_name, rel_path = _parse_datastore_path(ds_path)
        url = (
            f"https://{VCENTER_HOST}/folder/{urllib.parse.quote(rel_path)}"
            f"?dcPath={urllib.parse.quote(dc_name)}&dsName={urllib.parse.quote(ds_name)}"
        )

        local_filename = os.path.basename(rel_path)
        local_path = os.path.join(output_dir, local_filename)

        log.info(f"Downloading {ds_path} -> {local_path}")
        with session.get(url, stream=True, verify=verify, timeout=300) as r:
            r.raise_for_status()
            with open(local_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=1024 * 1024):
                    f.write(chunk)

        downloaded.append(local_path)

    if not downloaded:
        raise RuntimeError(f"No .vmem/.vmsn files matched for snapshot '{snapshot_name}' (found: {ds_paths})")

    return downloaded


def remove_snapshot(vm, snapshot_name):
    """Remove the named snapshot (consolidating its delta into the base
    disk) to free datastore space for future snapshots."""
    snap_obj = find_snapshot_obj(vm, snapshot_name)
    if not snap_obj:
        raise RuntimeError(f"Could not find snapshot '{snapshot_name}' to remove")

    task = snap_obj.snapshot.RemoveSnapshot_Task(removeChildren=False, consolidate=True)

    while task.info.state not in [vim.TaskInfo.State.success, vim.TaskInfo.State.error]:
        time.sleep(1)

    if task.info.state == vim.TaskInfo.State.error:
        raise RuntimeError(f"Snapshot removal failed: {task.info.error.msg}")

    return {"removed": snapshot_name, "state": str(task.info.state)}

# ---------------------------------------------------------------------------
# Flask app
# ---------------------------------------------------------------------------

app = Flask(__name__)


@app.route("/trigger", methods=["POST"])
def trigger():
    signature = request.headers.get("X-Signature", "")
    expected = hmac.new(WEBHOOK_SECRET, request.data, hashlib.sha256).hexdigest()

    if not hmac.compare_digest(signature, expected):
        log.warning("Rejected webhook: invalid signature from %s", request.remote_addr)
        abort(403)

    log.info("Valid webhook received from %s", request.remote_addr)

    timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    snap_name = f"watcher-triggered-{timestamp}"
    result = {"snapshot_name": snap_name}

    si = None
    try:
        si = connect_vcenter()
        vm = find_vm(si, VM_NAME)

        log.info("Creating snapshot...")
        snap_info = snapshot_vm(si, VM_NAME, snapshot_name=snap_name)
        result["snapshot"] = snap_info

        log.info("Downloading snapshot files...")
        vm_output_dir = os.path.join(OUTPUT_DIR, snap_name)
        os.makedirs(vm_output_dir, exist_ok=True)
        downloaded_files = download_snapshot_files(si, vm, snap_name, vm_output_dir)
        result["downloaded_files"] = downloaded_files

        if REMOVE_SNAPSHOT_AFTER_DOWNLOAD:
            log.info("Removing snapshot to free datastore space...")
            removal_info = remove_snapshot(vm, snap_name)
            result["removal"] = removal_info
        else:
            log.info("REMOVE_SNAPSHOT_AFTER_DOWNLOAD is false, leaving snapshot in place.")

    except Exception as e:
        log.error("Pipeline failed: %s", e)
        result["error"] = str(e)
        if si:
            Disconnect(si)
        return {"status": "error", "detail": str(e), "partial_result": result}, 500

    Disconnect(si)

    out_path = os.path.join(OUTPUT_DIR, f"result_{timestamp}.json")
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

    log.info(f"Pipeline complete, wrote result to {out_path}")
    return {"status": "ok", "file": out_path, "result": result}, 200


@app.route("/health", methods=["GET"])
def health():
    return {"status": "ok"}, 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=LISTEN_PORT)
