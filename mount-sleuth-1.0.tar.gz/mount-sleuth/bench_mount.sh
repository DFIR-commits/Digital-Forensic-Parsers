#!/bin/bash
# Read-only benchmark of one mounted evidence volume. Never writes to evidence:
# it only reads files and the read-only block device, and changes read-ahead
# on the tool's own loop / device-mapper devices (restored at the end).
#
#   sudo bash bench_mount.sh /mnt/MountSleuth/<host>/<image>/p03_ntfs_OS [--readahead KB] [--ntfs3]
#
# One read-ahead value per run. Between runs, remount (mount_evidence -u, then
# mount again): ewfmount and ntfs-3g keep their own caches, which dropping the
# page cache does not clear, so a second run on the same mount looks faster.
#
# Cold-cache runs drop the page cache (echo 3 > /proc/sys/vm/drop_caches) before
# each measurement; that slows other work on the box for a moment.
# Needs: fio (random reads), /usr/bin/time (CPU / memory)
set -u
MP=$(readlink -f "$1"); shift
NTFS3=0; RA=""
while [ $# -gt 0 ]; do case "$1" in --ntfs3) NTFS3=1 ;; --readahead) RA=$2; shift ;; esac; shift; done
mountpoint -q "$MP" || { echo "$MP is not a mount point"; exit 2; }
DEV=$(findmnt -n -o SOURCE --target "$MP")
FST=$(findmnt -n -o FSTYPE --target "$MP")
drop() { sync; echo 3 > /proc/sys/vm/drop_caches; }
t() {
  if [ -x /usr/bin/time ]; then /usr/bin/time -f "%e s  cpu %P  maxrss %M KB" "$@" 2>&1 >/dev/null | tail -1
  else local TIMEFORMAT="%R s  (user %U s, sys %S s)"; { time "$@" >/dev/null 2>&1; } 2>&1; fi
}
big=$(find "$MP" -xdev -type f -size +50M -printf '%s %p\n' 2>/dev/null | sort -rn | head -1 | cut -d' ' -f2-)

echo "volume: $MP  ($FST on $DEV)"
echo "image : $(losetup -n -O BACK-FILE "$(dmsetup deps -o devname "$(basename "$DEV")" 2>/dev/null | grep -o 'loop[0-9]*' | head -1 | sed 's|^|/dev/|')" 2>/dev/null)"
echo "kernel: $(uname -r)   cpus: $(nproc)"
echo

run_set() {
  echo "-- $1"
  drop; echo "  traversal (find, cold):        $(t find "$MP" -xdev)"
  echo "  traversal (find, warm):        $(t find "$MP" -xdev)"
  drop; echo "  small files <64K cat (cold):   $(t sh -c "find '$MP' -xdev -type f -size -64k -print0 | head -z -n 20000 | xargs -0 cat")"
  if [ -n "$big" ]; then
    drop; echo "  sequential file read (cold):   $(dd if="$big" of=/dev/null bs=1M 2>&1 | tail -1)"
    if command -v fio >/dev/null; then
      drop; echo "  random 4K reads 20s (cold):    $(fio --name=r --readonly --filename="$big" --rw=randread --bs=4k \
                --runtime=20 --time_based --ioengine=psync --numjobs=4 --group_reporting 2>/dev/null | grep -m1 -o 'IOPS=[^,]*, BW=[^ ]*')"
    fi
  else
    echo "  (no file over 50 MB on this volume: sequential/random skipped)"
  fi
  drop; echo "  block device sequential (cold): $(dd if="$DEV" of=/dev/null bs=1M count=2048 2>&1 | tail -1)"
}

# read-ahead applies to the device the filesystem sits on and the loop under it
devs="$DEV $(dmsetup deps -o devname "$(basename "$DEV")" 2>/dev/null | grep -o 'loop[0-9]*' | sed 's|^|/dev/|')"
orig=$(blockdev --getra "$DEV")
if [ -n "$RA" ]; then
  for d in $devs; do blockdev --setra $((RA * 2)) "$d"; done          # setra counts 512-byte sectors
fi
run_set "$FST, read_ahead $(( $(blockdev --getra "$DEV") / 2 )) KB"
for d in $devs; do blockdev --setra "$orig" "$d"; done

if [ $NTFS3 = 1 ] && [ "$FST" = fuseblk ]; then
  if grep -qw ntfs3 /proc/filesystems || modprobe ntfs3 2>/dev/null; then
    umount "$MP" && mount -t ntfs3 -o ro,noatime "$DEV" "$MP" && grep -q " $MP .* ro[, ]" /proc/mounts && {
      run_set "ntfs3 (kernel driver), read_ahead default"
      umount "$MP"; }
    mount -t ntfs-3g -o ro,noatime,windows_names,show_sys_files,streams_interface=windows "$DEV" "$MP"
    echo "(remounted with ntfs-3g as the tool mounts it)"
  else
    echo "ntfs3 driver not available on this kernel"
  fi
fi
