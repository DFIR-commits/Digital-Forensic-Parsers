# Mount Sleuth (GUI)

A desktop front end for `mount_evidence_prod.py`: queue forensic images, see their partitions and
filesystems, mount them read-only, open them in the file manager, and release them when you are done.
The command line keeps working exactly as before; both use the same backend.

![Mounted images](docs/gui_mounted.png)

## How it works

```
 GUI (your user, PySide6)                         backend (root, one run per operation)
 ─────────────────────────                        ─────────────────────────────────────
 queue, tree, filters, log   ── pkexec ──────▶    mount_evidence --json
                             stdin:  {"images": [{"path", "host", "label"}]}   then "cancel"
                             ◀── stdout: JSON events: start, image_start, image_done, log, exit
 status, without root:  <mount root>/*/*/.mount_state.json  (the backend's journals)
                        <mount root>/*/*/mount_manifest.json
                        /proc/self/mountinfo                (the live mount table)
```

- **The GUI never runs as root.** Each Discover, Mount or Unmount starts the backend once through
  `pkexec` (or `sudo -n`). Everything privileged — loop devices, kpartx, LVM tables, ewfmount/qemu-nbd,
  mounts, teardown — is the backend's existing, tested code. Nothing was rewritten for the GUI.
- **Image paths never go on a command line.** They travel in the JSON job on stdin, and the backend
  checks them again as root (`job_images`): absolute, an existing regular file, a supported image type,
  not inside the mount tree, safe host/label names, no duplicates. No shell is involved at any step.
- **Status is read, not remembered.** Mounted/unmounted comes from `/proc/self/mountinfo` each time,
  and the GUI shows "Mounted — read-only" only when that mount's options actually say `ro`. Images
  attached in an earlier session (or by the CLI) show up on start, found through the backend's journals.
- **No polling.** The kernel flags `/proc/self/mounts` whenever anything is mounted or unmounted. The
  GUI waits for that signal, then refreshes once.
- **The GUI is not in the data path.** Files are read straight from the mounts by whatever program
  you use. Closing the GUI does not unmount anything unless you ask it to.

## Install

Needs Python 3.9+ and PySide6 for the GUI, plus the backend's usual tools (see `MOUNT_EVIDENCE.md`).

| PySide6 | Status |
|---|---|
| 6.8.3, 6.10.1, 6.11.0 | tested |
| **6.12.0** | **do not use**: a shiboken reference-counting bug crashes Python part-way through an operation. The GUI refuses to start on it. |

### Workstation (production)

```sh
sudo sh install_gui.sh                          # apt packages (backend tools, pkexec, Qt libs) + root-owned venv with PySide6 6.11.0
# offline enclave: on a connected box with the same Python version:
#   pip download 'PySide6-Essentials==6.11.0' -d wheels/      then copy wheels/ over and:
sudo sh install_gui.sh --wheels /path/to/wheels     # add --no-apt if the packages are already there
```

If the system `python3` already imports PySide6 (`python3-pyside6.qtwidgets`), the venv is skipped;
`--venv` forces it, `--no-venv` never makes it.

`install_gui.sh` installs:

| Path | What |
|---|---|
| `/usr/local/lib/mount-evidence/` | backend + GUI, root-owned |
| `/usr/local/sbin/mount-evidence` | the only thing pkexec runs: `python3 -I` on the root-owned backend |
| `/usr/share/polkit-1/actions/local.ioc-scan.mount-evidence.policy` | names that one file; admin authentication, remembered for a few minutes |
| `/usr/local/bin/mount-evidence-gui` | launcher (uses `/opt/mount-evidence-venv` if present) |
| `/usr/share/applications/mount-evidence-gui.desktop` | "Mount Sleuth" in the desktop menu |
| `/usr/local/lib/mount-evidence/mount-sleuth.png` | window/taskbar/menu icon, if `mount-sleuth.png` was next to `install_gui.sh` (else the stock drive icon) |

Update: run `install_gui.sh` again. Remove: `sudo sh install_gui.sh --uninstall` (anything still
mounted stays mounted; unmount first).

### Running from the folder (testing)

```sh
python3 mount_evidence_gui.py
```

This elevates `/usr/bin/python3 -I mount_evidence_prod.py` from the folder with the generic pkexec rule
(a password every time). Because that file is writable by you while it runs as root, the log warns
about it. Use the installed copy for real work.

## Launch

Desktop menu → **Mount Sleuth**, or `mount-evidence-gui`. Do not start it with `sudo`; it asks for
authorisation itself, per operation.

## The window

| Area | What it shows |
|---|---|
| **Toolbar** | Add images · Add folder (this folder only) · Add folder tree (subfolders; the first level are hosts) · Remove · Discover · Mount selected · Mount all · Unmount selected · Unmount all · Refresh · Open mount root · Cancel · Log · Settings · Help. Actions grey out when they don't apply, and the tooltip says why (for example, tools missing). |
| **Filter bar** | Search across image name, path, volume label, filesystem, mount path and UUID (Ctrl+F); filesystem; status (mounted, unmounted, mountable, block device only, special partitions, encrypted, unsupported, failed); warnings/errors only. The search filters the queue and the tree; the other filters apply to the tree. |
| **Image queue** | One row per image: name, host, source path, format, size, discovery state, partitions, mounted volumes, status, warnings/errors. Sortable; several can be selected. |
| **Partitions and volumes** | Image → partition → LVM logical volume / shadow copy. Classification ("FAT32 EFI System Partition", "Microsoft Reserved (MSR)", "BitLocker-encrypted volume", …), status, filesystem, label, size, mount path, read-only, notes. Partition name, partition type and UUID are optional columns (Settings). |
| **Details** | Everything the backend recorded about the selected image or volume, plus the live mount options. Selectable text. |
| **Log** (Ctrl+L) | Time, level, image, message. Show everything / info / warnings / errors. Copy selected, Save… (TSV), Clear. Debug level and the backend's own console output are under "Everything". |
| **Status bar** | Images, processed, volumes, mounted, skipped by design, warnings, failures · current operation ("Mounting 3/12: WEB01/web01.E01") · elapsed time · progress per image · Cancel. |

Status words never rely on colour alone:

| Shown | Meaning |
|---|---|
| Mounted — read-only | in the live mount table with `ro` |
| Discovery complete — mountable | Discover found a filesystem it will mount |
| Block device only (read-only) | `--block-only` mode: exposed as a device, not mounted |
| Not mountable — special partition | MSR, BIOS boot: no filesystem by design |
| Container — contents listed separately | MBR extended partition, LVM physical volume |
| Linux swap — never activated | always left as a read-only block device |
| Encrypted — additional access required | BitLocker / LUKS: needs a key, not automated |
| Unsupported filesystem / No recognised filesystem / Needs other tooling | RAID members, LDM, Storage Spaces, unknown signatures |
| Mount failed — *category* | hibernated, dirty, damaged, missing dependency, collision…; the reason is in Details and Notes |
| Unmounted | was mounted, no longer in the mount table |
| MOUNTED READ-WRITE — investigate | a managed mount without `ro` (should never happen; the backend refuses those) |

## Workflows

**Look before mounting**

1. Add images, a folder, or a folder tree. Duplicates are skipped. When two images in different
   folders share a name under the same host, the second becomes `name_1.ext` (logged).
2. **Discover** (selected images, or all that aren't mounted). This is the backend's `--dry-run`:
   it attaches read-only, identifies everything, then releases it all. Nothing is mounted and nothing
   is left behind.
3. Review the tree: filesystems, labels, special partitions, encrypted volumes, discrepancies.
4. **Mount selected** or **Mount all**.

**Routine:** add, then **Mount all**. Mounting discovers as it goes, so it is one step.

**Use the evidence**

- Double-click a mounted volume to open it in the file manager. Double-click an image to open its
  folder under the mount root.
- Right-click for: Open mount folder, Copy mount path, Copy block-device path, Open image's mount
  folder, Open block-device folder (`<mount root>_dev`, for carvers and Sleuth Kit), Open folder
  holding the image file, Copy image path, Copy details, View manifest (`image_info.txt` +
  `mount_manifest.json`), and Discover / Mount / Unmount / Remove.
- Nothing opens automatically. Nothing is copied, indexed or read to fill the window.

**Finish**

- **Unmount selected** releases whole images (all of each image's volumes, devices, folders).
  Selecting one volume unmounts its image; the confirmation lists exactly which.
- **Unmount all** releases everything recorded under the mount root, including images attached in
  earlier sessions or by the CLI. Nothing else.
- Nothing is forced. If a program has a file open, that image stays attached, the log names the
  program (via `fuser`), and the others are still released. Close it and unmount again. A lazy
  unmount is deliberately not offered here; `mount_evidence --unmount --lazy` is on the CLI if you
  really need it.

**Closing the window**

- With nothing mounted, it just closes.
- With images mounted, you choose: **Leave mounted** (the mounts stay usable; the next start, or
  `mount_evidence --unmount`, can release them), **Unmount and close** (the window stays open if
  anything is busy), or **Cancel**.
- During an operation, you choose: **Close** (the backend finishes its current step and records what it
  attached, then the window closes) or **Cancel**.

**Cancel** stops after the current step, never in the middle of one, so nothing is left half-attached.
What was attached before it stays recorded, and Unmount releases it. If the GUI itself is killed, the
backend finishes the run normally; everything is in its journals.

## Privileges

- **pkexec (default).** With `install_gui.sh` the policy asks for admin authentication once and remembers
  it for a few minutes (`auth_admin_keep`), for that one program only. Without the install, the generic
  pkexec rule asks every time. pkexec needs a polkit agent in your desktop session; GNOME, KDE, Xfce,
  Cinnamon and MATE all have one.
- **sudo (Settings → Privilege elevation).** Runs `sudo -n`, so it needs a rule; it cannot prompt:

  ```
  # /etc/sudoers.d/mount-evidence   (visudo -f)
  %forensics ALL=(root) NOPASSWD: /usr/local/sbin/mount-evidence
  ```

  Only give this to people who may read any image on the box: the backend mounts, as root, whatever
  image file they name (read-only).
- The GUI stores no passwords and keeps no case data. It saves only window layout and Settings in
  `~/.config/IOC_SCAN/mount-evidence-gui.conf`. The queue is not saved; attached images are
  found again from the journals.
- The backend log stays at `/var/log/mount_evidence.log` (root). Save the GUI's log with Log → Save….

## Settings

| Setting | Backend option |
|---|---|
| Default evidence folder | (where the file dialogs start) |
| Mount root (block devices go to `<root>_dev`) | `-o`; locked while anything is attached |
| Mount mode: filesystems / block devices only | `--block-only` |
| NTFS driver: ntfs-3g / ntfs3 | `--ntfs-driver` |
| Shadow copies (experimental) | `--vss` |
| NBD slots | `--nbd-max` |
| Debug logging | `-v` |
| Privilege elevation: pkexec / sudo | — |
| File manager command (empty = desktop default) | — |
| Optional columns | — |

Read-only cannot be turned off; the backend refuses `-w`. Image types are fixed by the backend.
Concurrency is one image at a time, because the backend holds a system-wide lock (loop, dm and NBD
resources are shared).

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| "Authorisation was dismissed or refused" | pkexec exit 126: the prompt was cancelled. |
| "Not authorised, or no polkit authentication agent" | pkexec exit 127: wrong password, or no agent in this session (minimal window managers: start `lxpolkit` / `polkit-gnome-authentication-agent-1`), or use sudo with a NOPASSWD rule. |
| "sudo -n needs a NOPASSWD rule" | see Privileges. |
| "pkexec is not installed" | `apt install pkexec`, or switch to sudo in Settings. |
| Discover/Mount greyed out, tooltip says tools are missing | the log lists them: `apt install kpartx dmsetup …` (see `MOUNT_EVIDENCE.md`). |
| "Another mount_evidence is running" | a CLI run (or another GUI) holds the lock; wait for it. |
| "cannot read folder …: permission denied" when adding | the GUI lists folders as your user. Make the evidence readable to you (it is only read). |
| A volume opens but some folders are "permission denied" | ext4/XFS keep their real owners and modes; NTFS and FAT mounts are readable by everyone. Use `sudo` for the restricted paths, read-only. |
| Busy: image stays attached after Unmount | the log names the program holding it (`fuser`). Close it and unmount again. |
| "Recorded but nothing attached (stale)" | e.g. after a reboot. Unmount clears the record. |
| "… is in use by another image" | two different image files would get the same host/label folder. Unmount the other one first, or rename. |
| Window crashes with `none_dealloc` / `bool_dealloc` | PySide6 6.12.0. Install 6.11.0. |
| First mount after creating or copying images is slow (~9 s for 5 test images, ~1 s after) | the same on the CLI: first-time device and metadata caching, not the GUI. |

## Tests

| Test | Needs | Result (Debian 12, PySide6 6.11.0) |
|---|---|---|
| `python3 -m unittest test_mount_evidence` | nothing | 17/17 (14 backend + 3 GUI-job validation) |
| `QT_QPA_PLATFORM=offscreen python3 -m unittest test_mount_evidence_gui` | PySide6 | 22/22, also on PySide6 6.8.3. Fake backend, no root. |
| `sudo bash test_mount_evidence_integration.sh` | root, disposable box | 30/30 (CLI behaviour unchanged) |
| `sudo QT_QPA_PLATFORM=offscreen python3 test_mount_evidence_gui_integration.py` | root, disposable box | 36/36: the GUI driving the real backend |
| pkexec end-to-end (unprivileged user, installed policy, polkitd) | root, disposable box | 5 images, 15 volumes mounted and fully released through pkexec |

The GUI unit tests cover: startup, missing dependencies, a backend that cannot start, adding several
images, duplicate paths and duplicate names, folder-only vs tree, empty or invalid input,
discovery → tree, special/encrypted/swap/container statuses, LVM nesting, live mount-state changes
(mounted → read-write → unmounted), partial failure, cancel, responsiveness under a 30 000-event flood,
log copy/save, manifest view, open/copy mount path, unmount-selected touching only the selection, busy
unmount not forced, image paths kept off argv (a file named `$(touch pwned) 'q' "d".raw`), Settings
reaching the backend, filters, close with mounts (all three choices), and close during a run.

## How safety and performance were checked

- **Read-only.** Every evidence mount in `/proc/mounts` is `ro` (integration test), and the GUI derives
  "read-only" from the live mount options. The backend's own guarantees are unchanged: `blockdev
  --getro` before mounting, `ro` verified after, no journal replay or repair, swap never activated,
  MSR never mounted, `-w` refused.
- **Evidence unchanged.** The SHA-256 of every fixture file is identical before and after discover,
  mount, busy unmount, unmount, cancel and remount.
- **Cleanup.** After unmount-all and after a cancelled run, there are no mounts, loop devices or
  device-mapper maps from the tool, and the mount roots are empty. The workstation's own LVM volume
  group and dm device are untouched (CLI integration test).
- **Responsiveness.** A 20 ms timer never stalled more than 0.25 s during real discovery and mounting,
  or during a 30 000-line log flood. The log takes at most 2 000 rows per 150 ms, and the tree rebuilds only
  the image whose state changed.
- **Speed.** Mounting 5 images (15 filesystems), median of 3 warm runs, across three test runs: GUI
  0.94–1.01 s, CLI 0.95–1.03 s. Cold reads of a file through a mount, GUI open vs CLI only: 564/564,
  561/590, 606/650 MB/s. That is one small file, and it varies by about that much between runs in
  either direction. The GUI is not in the read path.

## Supported / not supported

Supported: everything the backend mounts (E01/Ex01/L01/S01, raw/dd/img/bin, VMDK, QCOW2, VHDX/VHD, AFF;
NTFS, FAT, exFAT, ext2/3/4, XFS, Btrfs, HFS+, UDF, ISO, LVM including cloned VGs, VMFS via vmfs6-fuse,
VSS via `--vss`), block-device-only mode, and the CLI unchanged alongside.

Limitations:

- Unmount works per image, not per volume. The backend releases an image's devices together, so
  pulling one volume out from under its loop or kpartx device is not offered.
- One operation at a time, one image at a time (the backend's lock).
- Discover attaches and releases each image, and Mount does the same identification again; for
  routine work, use Mount all directly.
- Progress is per image; there is no percentage within an image (the backend does not report one).
- Encrypted volumes, RAID, LDM and Storage Spaces are identified, not opened.
- No custom file browser: folders open in your desktop's file manager.
- Not yet tested on a real desktop polkit agent prompt or Wayland. pkexec was tested with polkitd and a
  rule, and the window offscreen. Tested on Debian 12 with Python 3.11.
