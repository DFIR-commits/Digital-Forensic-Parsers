"""GUI tests without root or devices: a fake backend speaks the same --json protocol.

    QT_QPA_PLATFORM=offscreen python3 -m unittest test_mount_evidence_gui
"""
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtCore import QModelIndex, QSettings, QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

import mount_evidence_gui as g

FAKE = r'''
import json, os, sys, threading, time
from pathlib import Path
args = sys.argv[1:]
base = Path(args[args.index("-o") + 1])
job = json.loads(sys.stdin.readline() or "{}")
stop = []
def watch():
    for line in sys.stdin:
        if line.strip() == "cancel":
            stop.append(1)
threading.Thread(target=watch, daemon=True).start()
def emit(ev, **kw):
    print(json.dumps({"event": ev, **kw}), flush=True)
Path(os.environ["FAKE_ARGV"]).write_text(json.dumps(args))
for i in range(int(os.environ.get("FAKE_FLOOD", "0"))):
    emit("log", level="INFO", msg=f"line {i}", image="")
def vols(d):
    V = lambda **k: {"discrepancies": [], "notes": [], "reason": "", "mount_point": "", **k}
    st = "planned" if "-d" in args else "mounted"
    mp = lambda n: "" if st == "planned" else str(d / n)
    return [V(id="p01", number=1, source="partition", role="efi", fs_type="vfat", fs_version="FAT32", fs_label="SYSTEM",
              name="p01_vfat_efi_SYSTEM", status=st, mount_point=mp("p01_vfat_efi_SYSTEM"), size_bytes=67108864),
            V(id="p02", number=2, source="partition", role="msr", name="p02_msr", status="skipped",
              category="special_partition", reason="Microsoft Reserved partition: no filesystem by design"),
            V(id="p03", number=3, source="partition", role="basic", fs_type="ntfs", fs_label="OS", name="p03_ntfs_OS",
              status=st, mount_point=mp("p03_ntfs_OS"), size_bytes=209715200, notes=["hiberfil.sys present"]),
            V(id="p04", number=4, source="partition", role="swap", fs_type="swap", name="p04_swap", status="skipped",
              category="swap"),
            V(id="p05", number=5, source="partition", role="basic", fs_type="bitlocker", name="p05_bitlocker",
              status="skipped", category="encrypted"),
            V(id="p06", number=6, source="partition", role="linux", fs_type="ext4", name="p06_ext4",
              status="planned" if st == "planned" else "failed", category="" if st == "planned" else "damaged",
              reason="" if st == "planned" else "filesystem structures could not be read"),
            V(id="p07", number=7, source="partition", role="lvm", fs_type="lvm2_member", name="p07_lvm",
              status="skipped", category="container"),
            V(id="p07.vg-root", number=7, source="lvm", fs_type="ext4", fs_label="root", lvm={"vg": "vg", "lv": "root"},
              name="p07_vg-root_ext4_root", status=st, mount_point=mp("p07_vg-root_ext4_root"))]
if "-u" in args:
    files = sorted(base.glob("*/*/.mount_state.json"))
    only = {i["path"] for i in job.get("images", [])}
    files = [f for f in files if not only or json.loads(f.read_text())["image_path"] in only]
    for i, f in enumerate(files):
        p = json.loads(f.read_text())["image_path"]
        emit("image_start", index=i, total=len(files), path=p)
        if "busy" in p:
            emit("log", level="ERROR", msg="cannot unmount: target is busy", image=p)
            emit("image_released", index=i, path=p, ok=False)
            continue
        for x in f.parent.iterdir():
            x.unlink() if x.is_file() else x.rmdir()
        f.parent.rmdir()
        emit("image_released", index=i, path=p, ok=True)
    emit("unmount_done", released=len(files), total=len(files), busy=[], leftovers=[])
    emit("exit", rc=0)
    sys.exit(0)
imgs = job.get("images", [])
emit("start", total=len(imgs), mode="")
for i, it in enumerate(imgs):
    if stop:
        emit("log", level="WARNING", msg="Cancel requested: finishing the current step, then stopping", image="")
        emit("exit", rc=130)
        sys.exit(130)
    emit("image_start", index=i, total=len(imgs), path=it["path"], host=it["host"], label=it["label"])
    if "slow" in it["path"]:
        time.sleep(0.6)
    d = base / it["host"] / it["label"]
    rep = {"path": it["path"], "host": it["host"], "label": it["label"], "format": "raw", "image_dir": str(d),
           "dev_dir": str(d) + "_dev", "size_bytes": 734003200, "table": {"type": "gpt"}, "warnings": [], "errors": [],
           "status": "ok", "volumes": vols(d)}
    if "bad" in it["path"]:
        rep.update(status="failed", volumes=[], errors=[{"category": "damaged", "message": "no partition table"}])
    elif "-d" not in args:
        rep["status"] = "partial"
        d.mkdir(parents=True, exist_ok=True)
        res = [{"kind": "mount", "path": v["mount_point"]} for v in rep["volumes"] if v["mount_point"]]
        (d / ".mount_state.json").write_text(json.dumps({"version": 2, "image_path": it["path"], "host": it["host"],
                                                         "label": it["label"], "resources": res}))
        (d / "mount_manifest.json").write_text(json.dumps(rep))
        (d / "image_info.txt").write_text("Image: " + it["path"] + "\n")
    emit("image_done", index=i, total=len(imgs), report=rep)
emit("exit", rc=0)
'''

app = QApplication.instance() or QApplication(sys.argv)
me = g.load_backend()


class GuiTest(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.fake = self.tmp / "fake_backend.py"
        self.fake.write_text(FAKE)
        self.argv_file = self.tmp / "argv.json"
        os.environ["FAKE_ARGV"] = str(self.argv_file)
        os.environ.pop("FAKE_FLOOD", None)
        self.base = self.tmp / "mnt"
        self.ev = self.tmp / "ev"
        s = QSettings(str(self.tmp / "s.ini"), QSettings.Format.IniFormat)
        s.setValue("mount_base", str(self.base))
        self.live = {}                                         # fake mount table
        self._mi = me.mountinfo
        me.mountinfo = lambda: dict(self.live)
        self.w = g.MainWindow(me, s, backend_cmd=[sys.executable, str(self.fake)], elevate=[])
        self.w.deps_problem = ""                               # this box may lack kpartx etc.
        self.w.update_actions()

    def tearDown(self):
        if self.w.runner.running():
            self.w.runner.proc.kill()
            self.wait(lambda: not self.w.runner.running())
        self.live.clear()                                      # nothing live: closing asks nothing
        self.w.close()
        me.mountinfo = self._mi
        self.w.deleteLater()
        app.processEvents()

    def wait(self, pred, timeout=20):
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            app.processEvents()
            if pred():
                return True
            time.sleep(0.005)
        self.fail("timed out")

    def images(self, *names):
        out = []
        for n in names:
            p = self.ev / n
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b"\0" * 4096)
            out.append(p)
        return out

    def add(self, paths, recursive=False):
        self.w.add_paths([str(p) for p in paths], recursive)
        self.wait(lambda: self.w.scanning == 0)

    def run_op(self, fn):
        fn()
        self.wait(lambda: not self.w.runner.running())
        self.w.log.flush()

    def mounted_from_reports(self):
        for img in self.w.imgs.values():
            for v in (img.report or {}).get("volumes", []):
                if v.get("status") == "mounted":
                    self.live[v["mount_point"]] = {"opts": "ro,noatime", "fstype": "ext4", "source": "/dev/x", "super": ""}
        self.w.refresh()

    def tree_children(self, name):
        top = next(self.w.trow[p] for p, i in self.w.imgs.items() if i.name == name)
        out = {}
        def walk(item, depth):
            for r in range(item.rowCount()):
                c = item.child(r)
                out[c.data(g.DATA)] = (depth, [self.w.tmodel.itemFromIndex(c.index().siblingAtColumn(k)).text()
                                               for k in range(len(g.TREE_COLS))])
                walk(c, depth + 1)
        walk(top, 1)
        return out

    def select_image(self, name):
        path = next(p for p, i in self.w.imgs.items() if i.name == name)
        row = next(r for r in range(self.w.qproxy.rowCount()) if self.w.qproxy.index(r, 0).data(g.DATA) == path)
        self.w.queue.selectRow(row)
        self.w.on_select("queue")

    # ── tests ──
    def test_startup_actions_disabled_without_images(self):
        self.assertFalse(self.w.a_mount_all.isEnabled())
        self.assertFalse(self.w.a_discover.isEnabled())
        self.assertFalse(self.w.a_unmount_all.isEnabled())
        self.assertTrue(self.w.a_files.isEnabled())

    def test_missing_dependency_disables_mounting(self):
        self.add(self.images("H/a.raw"))
        self.w.deps_problem = "required tools are missing"
        self.w.update_actions()
        self.assertFalse(self.w.a_mount_all.isEnabled())
        self.assertIn("unavailable", self.w.a_mount_all.toolTip())

    def test_backend_that_cannot_start(self):
        self.w._backend_cmd = [str(self.tmp / "no_such_backend")]
        self.add(self.images("H/a.raw"))
        self.run_op(lambda: self.w.mount(False))
        self.assertTrue(any("could not start" in r[3] for r in self.w.log.rows()))
        self.assertTrue(self.w.a_mount_all.isEnabled())

    def test_add_multiple_duplicates_and_same_names(self):
        a, b = self.images("H/x.raw", "H/sub/x.raw")
        self.add([self.ev], recursive=True)
        self.assertEqual(sorted(i.label for i in self.w.imgs.values()), ["x.raw", "x_1.raw"])
        other = self.tmp / "elsewhere" / "H" / "x.raw"
        other.parent.mkdir(parents=True)
        other.write_bytes(b"\0" * 512)
        self.add([other])
        self.add([a])                                          # duplicate path
        self.assertEqual(len(self.w.imgs), 3)
        self.assertEqual(sorted(i.label for i in self.w.imgs.values() if i.host == "H"), ["x.raw", "x_1.raw", "x_2.raw"])
        self.assertTrue(any("1 already queued" in r[3] for r in self.w.log.rows()))

    def test_folder_only_vs_tree(self):
        self.images("H/a.E01", "H/a.E02", "H/deep/b.raw", "H/notes.txt")
        self.add([self.ev / "H"])
        self.assertEqual([i.label for i in self.w.imgs.values()], ["a.E01"])     # segments and .txt ignored

    def test_empty_and_invalid_input(self):
        (self.tmp / "empty").mkdir()
        txt = self.tmp / "notes.txt"
        txt.write_text("x")
        self.add([self.tmp / "empty", txt, self.tmp / "missing.E01"])
        rows = " ".join(r[3] for r in self.w.log.rows())
        self.assertIn("no supported images", rows)
        self.assertIn("not a supported image", rows)
        self.assertIn("not found", rows)
        self.assertEqual(len(self.w.imgs), 0)

    def test_discovery_populates_tree_and_statuses(self):
        self.add(self.images("WEB01/web01.raw"))
        self.run_op(self.w.discover)
        kids = self.tree_children("WEB01/web01.raw")
        self.assertEqual(kids["p02"][1][1:3], ["Microsoft Reserved (MSR)", "Not mountable — special partition"])
        self.assertEqual(kids["p01"][1][1], "FAT32 EFI System Partition")
        self.assertEqual(kids["p04"][1][2], "Linux swap — never activated")
        self.assertEqual(kids["p05"][1][1:3], ["BitLocker-encrypted volume", "Encrypted — additional access required"])
        self.assertEqual(kids["p03"][1][2], "Discovery complete — mountable")
        self.assertEqual(kids["p07.vg-root"][0], 2)                                # LV nested under its PV
        self.assertEqual(kids["p07"][1][2], "Container — contents listed separately")
        img = next(iter(self.w.imgs.values()))
        self.assertEqual(self.w.image_state(img)[1], "Discovery complete")
        self.assertEqual(self.w.qrow[img.path][5].text(), "Complete")

    def test_mount_status_follows_the_live_mount_table(self):
        self.add(self.images("WEB01/web01.raw"))
        self.run_op(lambda: self.w.mount(False))
        self.mounted_from_reports()
        img = next(iter(self.w.imgs.values()))
        self.assertTrue(img.journal)
        kids = self.tree_children("WEB01/web01.raw")
        self.assertEqual(kids["p03"][1][2], "Mounted — read-only")
        self.assertEqual(kids["p03"][1][7], "Yes (mount verified)")
        self.assertEqual(kids["p06"][1][2], "Mount failed — damaged")
        mp = img.report["volumes"][2]["mount_point"]
        self.live[mp] = dict(self.live[mp], opts="rw,relatime")
        self.w.refresh()
        self.assertEqual(self.tree_children("WEB01/web01.raw")["p03"][1][2], "MOUNTED READ-WRITE — investigate")
        del self.live[mp]
        self.w.refresh()
        self.assertEqual(self.tree_children("WEB01/web01.raw")["p03"][1][2], "Unmounted")

    def test_partial_failure_keeps_successful_mounts(self):
        self.add(self.images("A/good.raw", "B/bad.raw"))
        self.run_op(lambda: self.w.mount(False))
        self.mounted_from_reports()
        st = {i.host: self.w.image_state(i)[1] for i in self.w.imgs.values()}
        self.assertTrue(st["A"].startswith("Mounted — read-only (3)"), st)
        self.assertTrue(st["B"].startswith("Failed — damaged"), st)
        self.assertIn("failures 2", self.w.counts.text())                          # p06 + the bad image
        self.assertTrue(any("ok 0, partial 1, failed 1" in r[3] for r in self.w.log.rows()))

    def test_cancel_stops_after_current_image(self):
        self.add(self.images("A/slow1.raw", "B/slow2.raw", "C/slow3.raw"))
        self.w.mount(False)
        self.wait(lambda: any(i.busy.startswith("Mounting") for i in self.w.imgs.values()))
        self.w.cancel()
        self.assertFalse(self.w.a_cancel.isEnabled())
        self.wait(lambda: not self.w.runner.running())
        self.assertEqual(sum(i.report is not None for i in self.w.imgs.values()), 1)
        self.assertTrue(any(r[3].startswith("Cancelled after the current step") for r in self.w.log.rows()))
        self.assertTrue(all(not i.busy for i in self.w.imgs.values()))

    def test_window_stays_responsive_during_event_flood(self):
        os.environ["FAKE_FLOOD"] = "30000"
        self.add(self.images("H/a.raw"))
        gaps, last = [], [time.monotonic()]
        def probe():
            now = time.monotonic()
            gaps.append(now - last[0])
            last[0] = now
        t = QTimer()
        t.timeout.connect(probe)
        t.start(10)
        self.run_op(self.w.discover)
        t.stop()
        self.assertLess(max(gaps), 0.25, f"max gap {max(gaps):.3f}s")
        self.assertGreaterEqual(len(self.w.log.rows()), 30000)

    def test_log_copy_and_save(self):
        self.w.log.add("ERROR", "boom: something failed", "H/a.raw")
        self.w.log.flush()
        self.w.log.view.selectAll()
        self.w.log.copy_selected()
        self.assertIn("boom: something failed", QApplication.clipboard().text())
        out = self.w.log.save(str(self.tmp / "log.tsv"))
        self.assertIn("ERROR\tH/a.raw\tboom", Path(out).read_text())

    def test_manifest_and_open_and_copy(self):
        self.add(self.images("WEB01/web01.raw"))
        self.run_op(lambda: self.w.mount(False))
        self.mounted_from_reports()
        opened = []
        orig = g.QDesktopServices.openUrl
        g.QDesktopServices.openUrl = staticmethod(lambda url: opened.append(url.toLocalFile()) or True)
        try:
            img = next(iter(self.w.imgs.values()))
            top = self.w.trow[img.path]
            p03 = next(top.child(r) for r in range(top.rowCount()) if top.child(r).data(g.DATA) == "p03")
            self.w.on_tree_double(self.w.tproxy.mapFromSource(p03.index()))
            mp = img.report["volumes"][2]["mount_point"]
            Path(mp).mkdir(parents=True, exist_ok=True)
            self.w.on_tree_double(self.w.tproxy.mapFromSource(p03.index()))
            self.assertEqual(opened, [mp])                     # first try: folder missing, logged instead
            self.w.copy(mp)
            self.assertEqual(QApplication.clipboard().text(), mp)
            d = self.w.show_manifest(img)
            tabs = d.findChild(g.QTabWidget)
            self.assertEqual([tabs.tabText(i) for i in range(tabs.count())], ["image_info.txt", "mount_manifest.json"])
            d.close()
        finally:
            g.QDesktopServices.openUrl = orig

    def test_unmount_selected_only_touches_selection(self):
        self.add(self.images("A/a.raw", "B/b.raw"))
        self.run_op(lambda: self.w.mount(False))
        self.mounted_from_reports()
        self.select_image("A/a.raw")
        self.run_op(lambda: self.w.unmount(True, confirm=False))
        self.assertEqual(json.loads(self.argv_file.read_text())[-1:], ["-u"])
        self.assertEqual({i.name: bool(i.journal) for i in self.w.imgs.values()}, {"A/a.raw": False, "B/b.raw": True})

    def test_busy_unmount_is_reported_not_forced(self):
        self.add(self.images("A/busy.raw"))
        self.run_op(lambda: self.w.mount(False))
        self.mounted_from_reports()
        self.run_op(lambda: self.w.unmount(False, confirm=False))
        self.assertTrue(next(iter(self.w.imgs.values())).journal)
        self.assertNotIn("--lazy", json.loads(self.argv_file.read_text()))
        self.assertTrue(any("target is busy" in r[3] for r in self.w.log.rows()))

    def test_paths_travel_in_the_job_never_on_argv(self):
        nasty = self.images("H/$(touch pwned) 'q' \"d\".raw")[0]
        self.add([nasty])
        seen = {}
        orig = self.w.runner.start
        self.w.runner.start = lambda op, argv, job: (seen.update(argv=argv, job=job), orig(op, argv, job))
        self.run_op(lambda: self.w.mount(False))
        self.assertNotIn(str(nasty), " ".join(seen["argv"]))
        self.assertEqual(seen["job"]["images"][0]["path"], str(nasty))
        self.assertIn("--json", seen["argv"])
        self.assertFalse({"-w", "--readwrite", "--lazy"} & set(seen["argv"]))
        self.assertFalse((self.tmp / "pwned").exists() or Path("pwned").exists())

    def test_settings_flags_reach_the_backend(self):
        for k, v in (("block_only", True), ("vss", True), ("ntfs_driver", "ntfs3"), ("nbd_max", 32), ("verbose", True)):
            self.w.settings.setValue(k, v)
        self.add(self.images("H/a.raw"))
        self.run_op(lambda: self.w.mount(False))
        argv = json.loads(self.argv_file.read_text())
        for f in ("--block-only", "--vss", "--ntfs-driver", "ntfs3", "--nbd-max", "32", "-v"):
            self.assertIn(f, argv)

    def test_filters(self):
        self.add(self.images("WEB01/web01.raw", "DC/dc.raw"))
        self.run_op(self.w.discover)
        def visible():
            out = []
            def walk(parent):
                for r in range(self.w.tproxy.rowCount(parent)):
                    i = self.w.tproxy.index(r, 0, parent)
                    out.append(i.data())
                    walk(i)
            walk(QModelIndex())
            return out
        self.w.f_status.setCurrentText("Encrypted")
        self.assertEqual(sorted(x for x in visible() if x.startswith("p")), ["p05_bitlocker", "p05_bitlocker"])
        self.w.f_status.setCurrentIndex(0)
        self.w.search.setText("dc/dc")
        self.assertIn("DC/dc.raw", visible())
        self.assertNotIn("WEB01/web01.raw", visible())
        self.w.search.setText("")
        self.w.f_fs.setCurrentText("FAT32")
        self.assertEqual(sorted(x for x in visible() if x.startswith("p")), ["p01_vfat_efi_SYSTEM"] * 2)

    def test_close_with_active_mounts(self):
        self.add(self.images("A/a.raw"))
        self.run_op(lambda: self.w.mount(False))
        self.mounted_from_reports()
        choice = {}
        orig = QMessageBox.exec
        QMessageBox.exec = lambda box: next(b for b in box.buttons() if b.text() == choice["t"]).click()
        try:
            choice["t"] = "Cancel"
            self.w.show()
            self.w.close()
            self.assertTrue(self.w.isVisible())
            choice["t"] = "Unmount and close"
            self.w.close()
            self.wait(lambda: not self.w.isVisible())
            self.assertFalse(any(i.journal for i in self.w.imgs.values()))
            self.w.show()
            self.run_op(lambda: self.w.mount(False))
            self.mounted_from_reports()
            choice["t"] = "Leave mounted"
            self.w.close()
            self.assertFalse(self.w.isVisible())
            self.assertTrue(all(i.journal for i in self.w.imgs.values()))
        finally:
            QMessageBox.exec = orig

    def test_close_while_running_cancels_then_closes(self):
        self.add(self.images("A/slow1.raw", "B/slow2.raw"))
        self.w.show()
        self.w.mount(False)
        self.wait(lambda: any(i.busy.startswith("Mounting") for i in self.w.imgs.values()))
        orig = QMessageBox.question
        QMessageBox.question = staticmethod(lambda *a, **k: QMessageBox.StandardButton.Close)
        try:
            self.w.close()
            self.assertTrue(self.w.isVisible())                 # waits for the backend's safe stop
            self.wait(lambda: not self.w.isVisible())
            self.assertEqual(sum(i.report is not None for i in self.w.imgs.values()), 1)
        finally:
            QMessageBox.question = orig


class Presentation(unittest.TestCase):
    def test_describe(self):
        self.assertEqual(g.describe({"role": "recovery", "fs_type": "ntfs"}), "Windows Recovery (NTFS)")
        self.assertEqual(g.describe({"role": "basic", "fs_type": "crypto_luks"}), "LUKS-encrypted volume")
        self.assertEqual(g.describe({"role": "basic"}), "Unknown / no filesystem")
        self.assertEqual(g.describe({"source": "vss", "vss": {"store": 2}, "fs_type": "ntfs"}), "Volume shadow copy 2 (NTFS)")

    def test_unknown_skip_category_is_still_labelled(self):
        self.assertEqual(g.vol_status({"status": "skipped", "category": "weird"}, {}), ("unsupported", "Not mounted — weird"))


if __name__ == "__main__":
    unittest.main()
