"""Privileged end-to-end test: the GUI drives the real backend. DISPOSABLE MACHINE OR
CONTAINER ONLY (loop devices, device-mapper, mounts). Run as root:

    QT_QPA_PLATFORM=offscreen python3 test_mount_evidence_gui_integration.py [--shots DIR]

Builds its own fixtures with mkimages.sh (EV, default /tmp/me-ev)."""
import hashlib
import os
import subprocess
import sys
import time
from pathlib import Path

from PySide6.QtCore import QSettings, QTimer
from PySide6.QtWidgets import QApplication

import mount_evidence_gui as g

HERE = Path(__file__).resolve().parent
EV = Path(os.environ.get("EV", "/tmp/me-ev"))
SHOTS = Path(sys.argv[sys.argv.index("--shots") + 1]) if "--shots" in sys.argv else None
results = []

def check(name, cond, detail=""):
    results.append(bool(cond))
    print(("PASS  " if cond else "FAIL  ") + name + (f"   [{detail}]" if detail and not cond else ""), flush=True)

def wait(pred, timeout=300):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        app.processEvents()
        if pred():
            return True
        time.sleep(0.01)
    return False

def sha_tree():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(EV.rglob("*")) if p.is_file()}

def ev_mounts():
    return [l.split() for l in Path("/proc/mounts").read_text().splitlines() if "/mnt/MountSleuth/" in l.split()[1]]

def ours_loops():
    return [l for l in subprocess.run(["losetup", "-a"], capture_output=True, text=True).stdout.splitlines()
            if str(EV) in l or "MountSleuth" in l]

def vols(w, name):
    img = next(i for i in w.imgs.values() if i.name == name)
    return {v["id"]: v for v in img.report["volumes"]}

def shot(w, name):
    if SHOTS:
        SHOTS.mkdir(parents=True, exist_ok=True)
        app.processEvents()
        w.grab().save(str(SHOTS / name))

if not (EV / "WEB01").is_dir():
    subprocess.run(["sh", str(HERE / "mkimages.sh"), str(EV)], check=True, capture_output=True)
before = sha_tree()
# loop and device-mapper devices outlive a container: always release what the test attached
import atexit
atexit.register(lambda: subprocess.run([sys.executable, str(HERE / "mount_evidence_prod.py"), "-l", "/tmp/me-cli.log",
                                        "-u"], capture_output=True))

app = QApplication(sys.argv)
me = g.load_backend()
ini = Path("/tmp/me-gui-test.ini")
ini.unlink(missing_ok=True)
w = g.MainWindow(me, QSettings(str(ini), QSettings.Format.IniFormat), elevate=[])
w.resize(1500, 900)
w.show()
opened = []
g.QDesktopServices.openUrl = staticmethod(lambda url: opened.append(url.toLocalFile()) or True)

# responsiveness probe: the longest gap between 20 ms timer ticks while work runs
gaps, last = [], [time.monotonic()]
def probe():
    now = time.monotonic()
    gaps.append(now - last[0])
    last[0] = now
t = QTimer()
t.timeout.connect(probe)
t.start(20)

print("== add")
w.add_paths([str(EV)], True)
check("folder tree scan finishes", wait(lambda: w.scanning == 0, 30))
check("5 images queued with hosts from the first folder level",
      sorted(i.name for i in w.imgs.values()) == ["DC_02/dc02__odd___name.dd", "LNX01/lnx01.img", "LNX02/lnx02.img",
                                                  "WEB01/web01_disk.raw", "WEB01/web01_e01.E01"],
      sorted(i.name for i in w.imgs.values()))
w.add_paths([str(EV / "WEB01" / "web01 disk.raw")], False)
wait(lambda: w.scanning == 0, 30)
check("re-adding a queued image is a duplicate, not a second row", w.qmodel.rowCount() == 5)

print("== discover")
gaps.clear()
w.discover()
check("discovery runs and finishes", wait(lambda: not w.runner.running(), 300))
web = vols(w, "WEB01/web01_disk.raw")
check("discovery found 8 WEB01 volumes", len(web) == 8, list(web))
S = lambda v: g.vol_status(v, w.mounts)[1]
check("MSR shown as special partition", S(web["p02"]) == "Not mountable — special partition" and
      g.describe(web["p02"]) == "Microsoft Reserved (MSR)")
check("EFI shown as FAT32 EFI System Partition", g.describe(web["p01"]) == "FAT32 EFI System Partition", g.describe(web["p01"]))
check("swap never activated", S(web["p05"]) == "Linux swap — never activated")
check("LUKS shown as encrypted", S(web["p08"]) == "Encrypted — additional access required")
check("NTFS shown as mountable", S(web["p03"]) == "Discovery complete — mountable" and g.describe(web["p03"]) == "NTFS volume")
check("discovery leaves nothing attached", not ev_mounts() and not ours_loops())
check("discovery wrote nothing under the mount root", not any(Path("/mnt/MountSleuth").glob("*/*")))
check("window stayed responsive during discovery (max tick gap < 0.25 s)", max(gaps, default=0) < 0.25, f"{max(gaps):.3f}s")
shot(w, "gui_discovered.png")

print("== mount")
gaps.clear()
t0 = time.monotonic()
w.mount(False)
check("mount runs and finishes", wait(lambda: not w.runner.running(), 600))
gui_mount_s = time.monotonic() - t0
m = ev_mounts()
check("15 filesystems mounted", len(m) >= 15, len(m))
check("every evidence mount is read-only", all(x[3].split(",")[0] == "ro" for x in m))
check("GUI counts 15 mounted volumes", sum(g.vol_status(v, w.mounts)[0] == "mounted"
                                         for i in w.imgs.values() for v in i.report["volumes"]) >= 15)
check("all 5 images managed (journals found)", len(w.managed()) == 5)
check("window stayed responsive during mounting (max tick gap < 0.25 s)", max(gaps, default=0) < 0.25, f"{max(gaps):.3f}s")
w.tree.expandAll()
w.log.flush()
web_top = w.trow[next(p for p, i in w.imgs.items() if i.name == "WEB01/web01_disk.raw")]
p03 = next(web_top.child(r) for r in range(web_top.rowCount()) if web_top.child(r).data(g.DATA) == "p03")
w.tree.setCurrentIndex(w.tproxy.mapFromSource(p03.index()))
w.tree.scrollTo(w.tproxy.mapFromSource(p03.index()))
w.on_select("tree")
shot(w, "gui_mounted.png")

print("== access")
ntfs = vols(w, "WEB01/web01_disk.raw")["p03"]
top = w.trow[next(p for p, i in w.imgs.items() if i.name == "WEB01/web01_disk.raw")]
item = next(top.child(r) for r in range(top.rowCount()) if top.child(r).data(g.DATA) == "p03")
w.on_tree_double(w.tproxy.mapFromSource(item.index()))
check("double-click opens the mount folder", opened[-1:] == [ntfs["mount_point"]], opened)
w.copy(ntfs["mount_point"])
check("copy mount path", QApplication.clipboard().text() == ntfs["mount_point"])
check("files readable through the mount", (Path(ntfs["mount_point"]) / "Users/svc app/AppData/Local/Temp/sample.txt").read_text() == "test content\n")
d = w.show_manifest(w.imgs[top.data(g.IMG)])
check("manifest dialog shows image_info.txt and the JSON", d.findChild(g.QTabWidget).count() == 2)
d.close()

print("== mount table watch (no polling)")
mp = vols(w, "DC_02/dc02__odd___name.dd")["p05"]["mount_point"]
subprocess.run(["umount", mp], check=True)
check("external umount shows as Unmounted without Refresh",
      wait(lambda: g.vol_status(vols(w, "DC_02/dc02__odd___name.dd")["p05"], w.mounts)[1] == "Unmounted", 5))

print("== busy unmount")
busy_img = next(i for i in w.imgs.values() if i.name == "LNX01/lnx01.img")
held = open(Path(vols(w, "LNX01/lnx01.img")["p01"]["mount_point"]) / "big.bin", "rb")
w.queue.selectRow(next(r for r in range(w.qproxy.rowCount()) if w.qproxy.index(r, 0).data(g.DATA) == busy_img.path))
w.on_select("queue")
w.unmount(True, confirm=False)
wait(lambda: not w.runner.running(), 120)
check("busy image stays attached (nothing forced)", busy_img.journal is not None and len(ev_mounts()) > 0)
check("other images untouched by unmount-selected", len(w.managed()) == 5)
check("log names the reason", any("busy" in r[3].lower() or "held" in r[3].lower() or "fuser" in r[3].lower()
                                  for r in w.log.rows()))
held.close()

print("== unmount all")
w.unmount(False, confirm=False)
check("unmount all finishes", wait(lambda: not w.runner.running(), 300))
check("no evidence mounts or loop devices left", not ev_mounts() and not ours_loops(), (ev_mounts(), ours_loops()))
check("mount roots empty", not any(Path("/mnt/MountSleuth").glob("*")) and not any(Path("/mnt/MountSleuth_dev").glob("*")))
check("images show Unmounted", all(w.image_state(i)[1] == "Unmounted" for i in w.imgs.values()),
      [w.image_state(i)[1] for i in w.imgs.values()])
check("evidence files unchanged (SHA-256)", sha_tree() == before)

print("== cancel")
w.mount(False)
wait(lambda: any(i.busy.startswith("Mounting") for i in w.imgs.values()), 60)
check("only one backend process at a time (second start refused while running)",
      w.start_op("discover", list(w.imgs.values()), ["-d"]) is False and w.runner.op == "mount")
w.cancel()
wait(lambda: not w.runner.running(), 300)
n = len(w.managed())
check("cancel stops after the current image", 0 < n < 5, n)
w.unmount(False, confirm=False)
wait(lambda: not w.runner.running(), 300)
check("cancelled run fully released afterwards", not ev_mounts() and not ours_loops())

print("== timing: GUI vs CLI, warm (the first mount after building fixtures is slow on any path)")
ME = [sys.executable, str(HERE / "mount_evidence_prod.py"), "-l", "/tmp/me-cli.log"]
gui, cli = [], []
for _ in range(3):
    t0 = time.monotonic()
    w.mount(False)
    wait(lambda: not w.runner.running(), 600)
    gui.append(time.monotonic() - t0)
    w.unmount(False, confirm=False)
    wait(lambda: not w.runner.running(), 300)
    t0 = time.monotonic()
    subprocess.run(ME + [str(EV)], capture_output=True)
    cli.append(time.monotonic() - t0)
    subprocess.run(ME + ["-u"], capture_output=True)
    w.refresh()
gui_s, cli_s = sorted(gui)[1], sorted(cli)[1]
print(f"   mount 5 images, median of 3: GUI {gui_s:.2f} s, CLI {cli_s:.2f} s   (first GUI mount: {gui_mount_s:.2f} s)")
check("GUI adds under 0.5 s over the CLI", gui_s - cli_s < 0.5, f"{gui_s:.2f} vs {cli_s:.2f}")

print("== read throughput through a mount (the GUI is not in the data path)")
w.mount(False)
wait(lambda: not w.runner.running(), 600)
big = Path(vols(w, "WEB01/web01_disk.raw")["p03"]["mount_point"]) / "big.bin"
def read_all():
    subprocess.run(["sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches"])
    t0 = time.monotonic()
    n = len(big.read_bytes())
    return n / (time.monotonic() - t0) / 1e6
gui_open = sorted(read_all() for _ in range(3))[1]
print(f"   big.bin cold read with the GUI running: {gui_open:.0f} MB/s")
subprocess.run(ME + ["-u"], capture_output=True)
subprocess.run(ME + [str(EV)], capture_output=True)
cli_only = sorted(read_all() for _ in range(3))[1]
print(f"   big.bin cold read, CLI mount, no GUI: {cli_only:.0f} MB/s")
subprocess.run(ME + ["-u"], capture_output=True)

w.close()
print(f"\n{sum(results)}/{len(results)} passed")
sys.exit(0 if all(results) else 1)
