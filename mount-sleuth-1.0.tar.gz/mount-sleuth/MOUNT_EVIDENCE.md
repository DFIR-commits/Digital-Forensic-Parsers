# mount_evidence_prod.py v2

This script mounts forensic disk images read-only, in bulk. Each folder under the evidence root is
one host. Every partition is identified. Filesystems are mounted read-only, and everything else
(swap, reserved, encrypted, unknown, damaged) is reported and exposed as a read-only block device.
Everything the script attaches is recorded as it goes, so `--unmount` can release exactly that and
nothing else.

The original v1 script is saved next to it as `mount_evidence_prod.py.orig`.

## Install

```sh
sudo apt install util-linux fdisk kpartx dmsetup ntfs-3g ewf-tools qemu-utils afflib-tools \
                 lvm2 libvshadow-utils psmisc
```

Required: `losetup`, `sfdisk`, `blkid`, `blockdev`, `mount`, `kpartx`, `dmsetup`, and Python 3.8 or newer.
Each of the others enables one feature and can be left out:

| Package | Needed for |
|---|---|
| `ewf-tools` | E01 images |
| `qemu-utils` | VMDK / QCOW2 / VHDX / VHD images |
| `afflib-tools` | AFF images |
| `ntfs-3g` | NTFS |
| `lvm2` | reading LVM metadata |
| `libvshadow-utils` | finding and mounting volume shadow copies |
| `psmisc` | `fuser`, which names the programs holding a busy mount |

## Use

```sh
sudo python3 mount_evidence_prod.py /evidence                 # mount everything read-only
sudo python3 mount_evidence_prod.py -d /evidence              # dry run: identify, print the plan, leave nothing attached
sudo python3 mount_evidence_prod.py --block-only /evidence    # read-only devices and manifest, no mounts
sudo python3 mount_evidence_prod.py --vss /evidence           # also mount NTFS shadow copies (experimental)
sudo python3 mount_evidence_prod.py /evidence/HOST1/disk.E01  # one image
sudo python3 mount_evidence_prod.py --status                  # what is attached right now
sudo python3 mount_evidence_prod.py --unmount                 # release everything this tool attached
```

Options: `-o/--mount-base` (default `/mnt/MountSleuth`), `--dev-base` (default `<mount-base>_dev`),
`-l/--log`, `-v`, `--ntfs-driver ntfs-3g|ntfs3`, `--lazy` (with `--unmount`), `--nbd-max N`.

VMDK/QCOW2/VHDX/VHD each take one NBD slot while attached. `install_gui.sh` sets 64 slots and loads
`nbd` at boot (`--nbd-max N` on the installer for another number); without it the backend loads `nbd`
with 64 slots the first time it needs one.

Exit code 0 means nothing failed. Partitions that are skipped on purpose (MSR, swap and so on) are
not failures. Exit code 1 means something needs attention, 2 means a usage error, and 130 means
the run was interrupted.

**GUI:** `mount_evidence_gui.py` (see `MOUNT_EVIDENCE_GUI.md`) drives this script through `--json`:
JSON events on stdout, the job (`{"images": [{"path", "host", "label"}]}`) and an optional `cancel`
line on stdin. With `--unmount`, a job limits the teardown to those images. Jobs are validated as
root (`job_images`). If the reader goes away, the run finishes normally.

**Changes from v1:**
- `-w/--readwrite` is removed and is now refused with an error.
- `-r` is accepted and ignored; read-only is always on.
- Partition folders are `pNN_<fs>_<label>` instead of `partN`, using the real partition number.
- LVM volumes are siblings of the partitions (`p02_<vg>-<lv>_<fs>`), not one level deeper.
- The E01 and AFF FUSE helpers moved out of the mount tree into the device tree.
- `--unmount` also releases mounts made by v1, using v1's `.mount_state.json` files.

## Layout

```
/mnt/MountSleuth/WEB01/web01_disk.raw/
    mount_manifest.json          everything found, machine-readable
    image_info.txt               the same, for people
    .mount_state.json            teardown journal (do not edit)
    p01_vfat_efi_SYSTEM/         mounted filesystems only
    p03_ntfs_OS/
    p04_ntfs_recovery/
    p06_ext4_OS/
/mnt/MountSleuth_dev/WEB01/web01_disk.raw/
    disk -> /dev/loop5           whole disk, read-only (unallocated space, partition gaps)
    p01_vfat_efi_SYSTEM -> /dev/mapper/loop5p1
    p02_msr -> /dev/mapper/loop5p2
    p05_swap -> /dev/mapper/loop5p5
    p07_nofs -> /dev/mapper/loop5p7
    p08_luks -> /dev/mapper/loop5p8
    .ewf/ewf1                    E01 only: ewfmount's raw view
```

**Names:**
- The pattern is `pNN_<fs>[_efi|_recovery][_<label>]`.
- Labels are transliterated to ASCII, characters other than letters, digits, `.` and `-` become
  `_`, and labels are cut to 32 characters.
- The partition number keeps names unique, so duplicate labels can't collide.
- Names are the same on every run.
- LVM volumes: `pNN_<vg>-<lv>_<fs>[_<label>]`. Shadow copies: `pNN_..._vssNN`.
- Image folders keep v1's naming: the file name with unsafe characters as `_`, plus `_1`, `_2` if
  two images on the same host collide.
- The depth stays host/image/partition, which is what yarax-scanner `--host-from-path` reads.
  Splunk's `evidence_partition` becomes the descriptive name.

**Why block devices are a separate tree:** a YARA scan of `/mnt/MountSleuth` with `--follow-links`
would otherwise read every whole-disk device as one file. In v1, `.ewf_fuse/ewf1` (the entire disk)
sat inside the scan tree, and yarax-scanner does not skip dot-folders.

**Folder names are hints.** Use the manifest for anything you report.

## Block devices, slack and unallocated space

A mounted filesystem never shows file slack, unallocated clusters or space between partitions. Use
the read-only devices instead; they are listed in `image_info.txt`, `mount_manifest.json` and the
`_dev` tree. For example:

```sh
D=/mnt/MountSleuth_dev/WEB01/web01_disk.raw
fls -r $D/p03_ntfs_OS                      # Sleuth Kit file listing, including deleted files
blkls -s $D/p03_ntfs_OS > p03.slack        # file slack only
blkls $D/p03_ntfs_OS > p03.unalloc         # unallocated clusters
bulk_extractor -o be_swap $D/p05_swap      # carve swap
dd if=$D/disk bs=512 skip=247808 count=161759 of=gap.bin   # a gap listed under "Unallocated regions"
```

`--block-only` attaches and identifies everything but mounts nothing. Use it when you only need
those tools.

## What each partition type gets

**Image formats and storage stacks:**

| | Handling | Tested in this round |
|---|---|---|
| raw / dd / img | read-only loop, then `kpartx -r` | yes |
| E01 (single or segmented) | `ewfmount`, then read-only loop | yes (single segment) |
| AFF | `affuse`, then read-only loop | no (code unchanged from v1) |
| VMDK / QCOW2 / VHDX / VHD | `qemu-nbd --read-only` | yes, on an Ubuntu 24.04 VM: 20 at once, kernel partitions and kpartx |
| GPT / MBR, including logical partitions (p5+) | `sfdisk --json` | yes |
| Corrupt primary GPT | backup header used, warning shown | yes |
| LVM, linear and striped | mappings built from LVM metadata, no `vgchange` | linear yes, striped unit test only |
| Cloned LVM (same VG name and UUIDs as another image or the host) | mounts | yes |
| LVM thin / RAID / cache, or a VG spread over several images | reported, not mapped | unit test only |

**Filesystems:**

| | Handling | Tested in this round |
|---|---|---|
| NTFS | `ntfs-3g ro`, or `--ntfs-driver ntfs3` | ntfs-3g yes, ntfs3 no (driver not in the test kernel) |
| FAT32 / EFI | `vfat ro` | yes |
| exFAT | `exfat ro` | detection yes, mount no (no driver in the test kernel; reported as `missing_dependency`) |
| ext2 / ext3 / ext4 | `ro,noload` (no journal replay) | ext4 yes |
| XFS, Btrfs, F2FS, HFS+, UDF, ISO, SquashFS | `ro` plus the driver's no-replay option | no |
| Hibernated NTFS | mounted read-only, with a note that `hiberfil.sys` holds memory | yes |
| Damaged NTFS (boot sector says NTFS, structures unreadable) | `damaged`, use the block device | yes |

**Special partitions and containers:**

| | Handling | Tested in this round |
|---|---|---|
| MSR | `special_partition`, not mounted, not an error | yes |
| MBR extended container | `container` | yes |
| Linux swap (partition or LV) | never activated or mounted; block device only | yes |
| Unformatted / unknown | `no_filesystem`, block device only | yes |
| LUKS | `encrypted`, block device only | yes |
| BitLocker | `encrypted` (detected by blkid) | no fixture |
| Software RAID, Windows LDM, Storage Spaces | `needs_tooling` (identified, not assembled) | unit test only |
| VMFS | `vmfs6-fuse -o ro` | no (vmfs6-fuse not installed) |

**Volume shadow copies (VSS):**

| | Handling | Tested in this round |
|---|---|---|
| Detection | `vshadowinfo` on every NTFS volume; the count is shown in the report | yes (0 snapshots) |
| Mounting (`--vss`, experimental) | `vshadowmount`, then read-only loop and NTFS mount, as `pNN_..._vssNN` | no: no test image with snapshots |

Shadow copies live inside the NTFS volume (`System Volume Information`), not in a partition of
their own. A normal mount shows only the live filesystem. `--vss` uses libvshadow to rebuild each
snapshot as a read-only volume. Treat it as unvalidated until it has been checked against a real
image, for example against a snapshot listing from another tool.

## Evidence safety

- **Read-only at every layer:**
  - loop devices are created with `--read-only` and partition mappings with `kpartx -r`
  - LVM mappings are created with `dmsetup create --readonly`, and NBD connects with `--read-only`
  - `blockdev --getro` must return 1 before anything is mounted, otherwise the volume is refused
- **Every mount is checked afterwards.**
  - Every mount option chain includes `ro` and the driver's no-replay option: `noload` (ext3/4),
    `norecovery` (XFS, F2FS), `rescue=nologreplay` (Btrfs).
  - After mounting, `/proc/self/mountinfo` must show `ro`, otherwise the volume is unmounted at
    once and reported as `safety`.
  - The manifest records the options actually in effect.
- **What is never run:**
  - `fsck`, `ntfsfix`, `swapon`, `vgchange` or `mdadm --assemble`
  - any read-write mount
  - anything that changes a system-wide setting, except loading the `nbd` module for a VMDK/QCOW2/VHDX
    image when it isn't loaded (64 slots, or what `install_gui.sh` set), and `--nbd-max` when you ask for it
- **LVM metadata is only read.** The script runs `lvs` and `pvs` with `--readonly`,
  `metadata_read_only=1`, and a filter that shows only this image's devices.
- **Your workstation's own storage is never touched.** That covers loop devices, mappings and
  volume groups the script didn't create.
  - v1's `--unmount` ran `dmsetup remove --force` on *every* device-mapper device on the machine.
    For a device in use, that switches it to one that fails every read and write, which breaks a
    system disk on LVM or LUKS.
  - v1 also ran `vgchange -ay/-an` on every volume group on the machine.
  - The integration test runs a busy "host" device-mapper device and a host volume group with the
    same name as an evidence one, and checks that both survive.
- **Temporary files** (journals, manifests, FUSE helper mounts) are written only under the mount and
  device trees and `/run/mount_evidence`, never next to the evidence.

**Limits of read-only mounting:**
- It stops writes through this tool. It does not prove the image was unaltered before acquisition;
  check that with `ewfverify` or the acquisition hashes.
- `noload` and `norecovery` show the filesystem *without* its pending journal. Very recent changes
  may be missing from the mounted view (and from YARA scans of it).
- A dirty NTFS volume is mounted by ntfs-3g without a warning. Only hibernation is detected, through
  `hiberfil.sys`.

## Teardown

**How resources are recorded:** each resource is written to `<image>/.mount_state.json`.
- Resources with a name known in advance (folders, symlinks, mounts, FUSE helpers, device-mapper
  names) are recorded *before* they are created.
- Loop devices are recorded right after `losetup` returns. When a loop is released, any mappings
  stacked on it are removed too, even unrecorded ones.

**What `--unmount` does:**
1. Releases each image's resources newest first, by exact name, after checking the name still
   refers to the same image. After a reboot, a reused `/dev/loop5` is left alone.
2. If a mount is busy, it stops for that image and lists the processes holding it (`fuser -vm`),
   then carries on with the other images. Close those programs and run `--unmount` again.
   `--lazy` detaches busy mounts lazily instead; their devices are released once the last user
   closes them.
3. Finally, it lists anything that still looks like this tool's but is in no journal, with the
   command to remove it. These are only reported, never removed.

**Interrupting a run:**
- **Ctrl-C:** finishes the current step and stops (exit 130). Run `--unmount` afterwards.
- **`kill -9`:** `--unmount` cleans up as well.

**Re-runs and parallel runs:**
- Running the mount again skips images that are already mounted.
- A lock file stops two runs at once.

## Example output

```
── WEB01 / web01_disk.raw   (/ev/WEB01/web01 disk.raw)
  raw, 700.0M, gpt   disk /dev/loop5
  ID   Type                  FS           Label     Size    Status                      Location / reason
  p01  EFI System            vfat         SYSTEM    64.0M   mounted                     p01_vfat_efi_SYSTEM/  (vfat, ro verified)
  p02  Microsoft Reserved    -            -         16.0M   skipped: special_partition  Microsoft Reserved partition: no filesystem by design
  p03  Microsoft basic data  ntfs         OS        200.0M  mounted                     p03_ntfs_OS/  (fuseblk, ro verified)
  p04  Windows Recovery      ntfs         Recovery  64.0M   mounted                     p04_ntfs_recovery/  (fuseblk, ro verified)
  p05  Linux swap            swap         swap      32.0M   skipped: swap               Linux swap: never activated or mounted; read the block device with forensic tools
  p06  Linux filesystem      ext4         OS        64.0M   mounted                     p06_ext4_OS/  (ext4, ro verified)
  p07  Microsoft basic data  -            -         16.0M   skipped: no_filesystem      no recognized filesystem signature (unformatted, wiped, encrypted or unknown)
  p08  Linux LUKS            crypto_luks  -         32.0M   skipped: encrypted          LUKS encrypted volume: needs the key (cryptsetup open --readonly), not automated
```

Representative errors:

```
p02: [damaged] boot sector says NTFS but blkid could not validate the filesystem (damaged or partly overwritten); try a forensic parser on the block device
p01: [missing_dependency] no driver for this filesystem on this system: mount: ...: unknown filesystem type 'exfat'.
web01_e01.E01: [missing_dependency] ewfmount not found (apt install ewf-tools)
cannot unmount /mnt/MountSleuth/WEB01/web01_e01.E01/p03_ntfs_OS: target is busy.
      held by:  root  ..c..  sleep
```

Error categories:
- **Failures:** `missing_dependency`, `device_error`, `damaged`, `dirty`, `hibernated`, `collision`,
  `safety`, `mount_failed`
- **By design, not errors:** `special_partition`, `container`, `swap`, `encrypted`,
  `needs_tooling`, `no_filesystem`, `unsupported`, `ambivalent` (more than one filesystem
  signature found)

`mount_manifest.json` holds one record per volume:

```json
{"id": "p03", "source": "partition", "number": 3, "dev": "/dev/mapper/loop2p3",
 "start_sector": 165888, "sectors": 409600, "size_bytes": 209715200,
 "part_type": "EBD0A0A2-B9E5-4433-87C0-68B6B72699C7", "part_type_name": "Microsoft basic data",
 "part_name": "Basic data partition", "part_uuid": "3F4587E0-...", "role": "basic",
 "fs_type": "ntfs", "fs_usage": "filesystem", "fs_label": "OS", "fs_uuid": "2039CBC6068755E5",
 "vss": {"checked": true, "stores": 0, "creation_times": [], "source": "vshadowinfo"},
 "status": "mounted", "name": "p03_ntfs_OS",
 "mount_point": "/mnt/MountSleuth/WEB01/web01_disk.raw/p03_ntfs_OS", "mount_fstype": "fuseblk",
 "mount_options": "ro,noatime (ro,user_id=0,group_id=0,allow_other,blksize=4096)",
 "read_only_verified": true, "device_read_only": true,
 "dev_link": "/mnt/MountSleuth_dev/WEB01/web01_disk.raw/p03_ntfs_OS",
 "discrepancies": [], "notes": [],
 "sources": {"partition": "sfdisk --json", "filesystem": "blkid -p", "mount_options": "/proc/self/mountinfo"}}
```

- The GPT partition name (`part_name`) and the filesystem label (`fs_label`) are separate fields.
- When tools disagree, the disagreement is recorded under `discrepancies` and nothing is chosen
  silently. Examples: an MSR partition with a filesystem on it, or blkid's offset differing from
  sfdisk's.
- E01 images also carry their `ewfinfo` header (case number, examiner, acquisition hashes) under
  `meta.ewfinfo`. VMDK/QCOW2 images carry `qemu-img info` output.

## Tests

```sh
python3 -m unittest test_mount_evidence              # no root: parsing, naming, classification, LVM tables, v1 state, GUI jobs
sudo bash test_mount_evidence_integration.sh          # DISPOSABLE box/container only: builds images with mkimages.sh
```

The integration test passed 30/30 three times in a row, in a privileged Debian 12 container on a
WSL2 6.6 kernel. A separate `kill -9` at 15 random points mid-run was cleaned up fully by
`--unmount` every time. Each run checks that:
- 15 filesystems mount and every one is `ro`
- all 33 block devices are read-only
- the cloned LVM image mounts
- a re-run is idempotent
- the lock stops a second run
- busy teardown, `--block-only`, SIGINT, `kill -9` and v1 state files all end with nothing left
  attached
- the host volume group and busy host device-mapper device survive
- a missing `ewfmount` fails only the E01
- `-w` is refused
- every evidence file's SHA-256 is unchanged

## Performance

The read path is the same as v1: loop, then device-mapper, then the kernel driver or ntfs-3g. No
copies, extraction, indexing or hashing are added, so reading mounted files should be as fast as
before.

Mount and teardown time for the five test images, 3 runs each:

| | Mount | Teardown | Filesystems mounted |
|---|---|---|---|
| v1 | 2.95–2.99 s | 2.59–2.63 s | 13 (the cloned LVM image failed) |
| v2 | 1.00–1.08 s | 1.04–1.05 s | 15 |

The saving comes from v1's fixed `sleep`s and its mount-tree printout. It is not a read-speed
change.

**Not measured, and why:** the test machine is a WSL2 VM on a virtual disk with no `ntfs3` driver,
so its read numbers say nothing about your hardware. No mount options were changed for speed.
`bench_mount.sh` measures on your box:

```sh
sudo bash bench_mount.sh /mnt/MountSleuth/HOST/disk.E01/p03_ntfs_OS                 # current settings
sudo python3 mount_evidence_prod.py -u; sudo python3 mount_evidence_prod.py /evidence
sudo bash bench_mount.sh /mnt/MountSleuth/HOST/disk.E01/p03_ntfs_OS --readahead 2048 # compare
sudo bash bench_mount.sh /mnt/MountSleuth/HOST/disk.E01/p03_ntfs_OS --ntfs3          # kernel NTFS driver
```

It measures:
- directory traversal, cold and warm
- reading small files
- one large file sequentially
- random 4K reads (`fio --readonly`)
- the block device sequentially
- time and memory

Remount between runs: ewfmount and ntfs-3g keep caches that dropping the page cache doesn't clear.
In a first sanity run on the test box, a second pass looked 7× faster purely from ewfmount's cache.

**Worth measuring on real evidence:**
1. **ntfs-3g against ntfs3.** ntfs-3g runs in user space (FUSE). ntfs3 is in the kernel, is usually
   faster on large trees, and also returns creation times through `statx`, which the scanner reads.
   ntfs3 has had more stability problems on damaged volumes.
2. **`read_ahead_kb` on hard disks or network storage**, where the default of 128 KB is often low.
3. **E01 decompression.** It is single-threaded in libewf, so scanning several E01s at once spreads
   across cores, but one large E01 is bound by that one thread.

## Known issues and next steps

**Not exercised in this round:**
- AFF, BitLocker, real VSS snapshots, VMFS, XFS/Btrfs/HFS+, ntfs3, exFAT mounting
  (the kernel has no exFAT driver; detection and error reporting were tested)

Run `--dry-run` first on representative real images.

**Not detected or not supported:**
- **Dirty NTFS volumes** are not flagged. Possible addition: `ntfsinfo -m` reports the dirty flag
  but reads more of the volume.
- **A VG spread over several images** of one host is reported, not assembled. Possible addition:
  map such VGs per host rather than per image.
- **Btrfs on cloned disks:** two volumes with the same filesystem UUID can't be mounted at once on
  older kernels. The second is reported as `collision`.
- **Image folder `_1` suffixes** depend on sorted order, so adding a same-named image to a host can
  shift them. The manifest records the source path.
- **Parallel mounting** was not added. Mounting takes about 0.2 s per image, so it isn't the
  bottleneck.

**Container testing only:** the integration test leaves stale `/dev/mapper` nodes where no udev
runs. The script handles them by checking device numbers.
