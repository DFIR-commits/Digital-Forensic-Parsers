#!/bin/sh
# Install Mount Sleuth (GUI + mount_evidence backend) for production use. As root:
#
#   sudo sh install_gui.sh                  install or update everything: apt packages (kpartx,
#                                           ewf-tools, ... pkexec, Qt libraries) and, unless the
#                                           system python3 already has PySide6, /opt/mount-evidence-venv
#   sudo sh install_gui.sh --wheels DIR     same, PySide6 offline from `pip download` output
#   sudo sh install_gui.sh --no-venv        never create the venv (bring your own PySide6)
#   sudo sh install_gui.sh --no-apt         skip apt (offline box with the packages already there)
#   sudo sh install_gui.sh --nbd-max N      NBD slots, i.e. VMDK/QCOW2/VHDX attached at once (default 64)
#   sudo sh install_gui.sh --uninstall
#
# Why: the backend runs as root, so the copy pkexec runs must be root-owned (a
# user-writable script elevated by pkexec is a way to root). The polkit rule
# names that one file and keeps the authorisation for a few minutes, so a
# discover-then-mount session asks for the password once.
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=/usr/local/lib/mount-evidence
WRAP=/usr/local/sbin/mount-evidence
LAUNCH=/usr/local/bin/mount-evidence-gui
POLICY=/usr/share/polkit-1/actions/local.ioc-scan.mount-evidence.policy
DESKTOP=/usr/share/applications/mount-evidence-gui.desktop
VENV=/opt/mount-evidence-venv
NBD_CONF=/etc/modprobe.d/mount-sleuth-nbd.conf        # mount_evidence_prod.py's NBD_CONF
NBD_LOAD=/etc/modules-load.d/mount-sleuth-nbd.conf
NBD_MAX=64                                            # VMDK/QCOW2/VHDX images attached at once
PYSIDE="PySide6-Essentials==6.11.0"         # 6.12.0 crashes (shiboken refcount bug); see MOUNT_EVIDENCE_GUI.md

[ "$(id -u)" = 0 ] || { echo "run as root: sudo sh $0 $*"; exit 1; }
MAKE_VENV=auto WHEELS="" APT=1
while [ $# -gt 0 ]; do
  case "$1" in
    --uninstall) rm -f "$WRAP" "$LAUNCH" "$POLICY" "$DESKTOP" "$NBD_CONF" "$NBD_LOAD"; rm -rf "$LIB"
                 echo "removed (left alone: $VENV, /var/log/mount_evidence.log, anything still mounted)"; exit 0 ;;
    --venv) MAKE_VENV=1 ;;                  # force it even if the system python3 has PySide6
    --no-venv) MAKE_VENV=0 ;;
    --no-apt) APT=0 ;;
    --wheels) WHEELS=$2; shift ;;
    --nbd-max) NBD_MAX=$2; shift ;;
    *) echo "unknown option $1"; exit 2 ;;
  esac
  shift
done

# Backend tools (see MOUNT_EVIDENCE.md), pkexec for the password prompt, python3-venv,
# and the X11/GL libraries the PySide6 wheel loads but desktops don't always have.
# package:tool = skip the package when the tool is already there from elsewhere (SIFT ships
# libewf-tools / libvshadow-tools, which conflict with Ubuntu's ewf-tools / libvshadow-utils).
PKGS="util-linux fdisk mount kpartx:kpartx dmsetup:dmsetup ntfs-3g:ntfs-3g ewf-tools:ewfmount
      qemu-utils:qemu-nbd afflib-tools:affuse lvm2:lvs libvshadow-utils:vshadowinfo psmisc:fuser
      python3 python3-venv pkexec:pkexec
      libgl1 libegl1 libfontconfig1 libdbus-1-3 libxkbcommon-x11-0 libxcb-cursor0
      libxcb-icccm4 libxcb-image0 libxcb-keysyms1 libxcb-render-util0 libxcb-shape0 libxcb-xkb1"
if [ $APT = 1 ] && command -v apt-get >/dev/null; then
  apt-get update || echo "WARNING: apt-get update failed, installing from the cached package lists"
  # pkexec is its own package from Ubuntu 22.04 / Debian 12, policykit-1 before that;
  # skip any name this release doesn't have (e.g. libxcb-cursor0 on 20.04) instead of failing the lot
  have=""
  for e in $PKGS; do
    p=${e%%:*} t=${e#*:}
    [ "$t" != "$e" ] && command -v "$t" >/dev/null && continue
    [ $p = pkexec ] && ! apt-cache show pkexec >/dev/null 2>&1 && p=policykit-1
    if apt-cache show "$p" >/dev/null 2>&1; then have="$have $p"; else echo "note: no package $p here, skipped"; fi
  done
  # one conflicting package must not block the rest: retry one at a time
  # shellcheck disable=SC2086
  DEBIAN_FRONTEND=noninteractive apt-get install -y $have || for p in $have; do
    DEBIAN_FRONTEND=noninteractive apt-get install -y "$p" >/dev/null 2>&1 || echo "WARNING: apt could not install $p"
  done
elif [ $APT = 1 ]; then
  echo "WARNING: no apt-get - install the tools in MOUNT_EVIDENCE.md with your package manager"
fi

# NBD for VMDK/QCOW2/VHDX: one slot per attached image; partitions come from kpartx (max_part=0).
# Stock Ubuntu doesn't load nbd, so set the options and load it at every boot, and now.
echo "options nbd nbds_max=$NBD_MAX max_part=0" > "$NBD_CONF"
echo nbd > "$NBD_LOAD"
if ! modprobe -n nbd 2>/dev/null && [ $APT = 1 ] && command -v apt-get >/dev/null; then
  apt-get install -y "linux-modules-extra-$(uname -r)" || true    # some kernels keep nbd there
fi
if [ -d /sys/module/nbd ] && [ "$(cat /sys/module/nbd/parameters/nbds_max)" != "$NBD_MAX" ]; then
  rmmod nbd 2>/dev/null || echo "note: nbd is in use with $(cat /sys/module/nbd/parameters/nbds_max) slots; $NBD_MAX after a reboot"
fi
modprobe nbd || echo "WARNING: could not load the nbd module - VMDK/QCOW2/VHDX images won't mount"

if [ $MAKE_VENV = auto ]; then
  MAKE_VENV=1
  # distribution PySide6 already works, or Python too old for the pinned wheel (Ubuntu 20.04: see README)
  python3 -c 'import PySide6.QtWidgets' 2>/dev/null && MAKE_VENV=0
  python3 -c 'import sys; sys.exit(sys.version_info < (3, 9))' || { MAKE_VENV=0; echo "note: python3 < 3.9, not creating the PySide6 venv"; }
fi

install -d -o root -g root -m 0755 "$LIB"
install -o root -g root -m 0644 "$HERE/mount_evidence_prod.py" "$HERE/mount_evidence_gui.py" "$LIB/"
for f in MOUNT_EVIDENCE.md MOUNT_EVIDENCE_GUI.md mount-sleuth.png; do
  [ ! -f "$HERE/$f" ] || install -o root -g root -m 0644 "$HERE/$f" "$LIB/"
done

cat > "$WRAP" <<'EOF'
#!/bin/sh
# Root side of Mount Sleuth. pkexec runs exactly this file (see the polkit policy).
exec /usr/bin/python3 -I /usr/local/lib/mount-evidence/mount_evidence_prod.py "$@"
EOF
chown root:root "$WRAP"; chmod 0755 "$WRAP"

cat > "$LAUNCH" <<EOF
#!/bin/sh
PY=$VENV/bin/python3
[ -x "\$PY" ] || PY=python3
exec "\$PY" $LIB/mount_evidence_gui.py "\$@"
EOF
chmod 0755 "$LAUNCH"

mkdir -p "$(dirname "$POLICY")"
cat > "$POLICY" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE policyconfig PUBLIC "-//freedesktop//DTD PolicyKit Policy Configuration 1.0//EN"
 "http://www.freedesktop.org/standards/PolicyKit/1/policyconfig.dtd">
<policyconfig>
  <action id="local.ioc-scan.mount-evidence">
    <description>Attach forensic images read-only</description>
    <message>Authentication is required to attach or release forensic images (read-only)</message>
    <defaults>
      <allow_any>auth_admin</allow_any>
      <allow_inactive>auth_admin</allow_inactive>
      <allow_active>auth_admin_keep</allow_active>
    </defaults>
    <annotate key="org.freedesktop.policykit.exec.path">$WRAP</annotate>
  </action>
</policyconfig>
EOF
chmod 0644 "$POLICY"

ICON=drive-harddisk                       # stock icon unless mount-sleuth.png sits next to this script
[ -f "$LIB/mount-sleuth.png" ] && ICON=$LIB/mount-sleuth.png
mkdir -p "$(dirname "$DESKTOP")"
cat > "$DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=Mount Sleuth
Comment=Mount forensic disk images read-only
Exec=$LAUNCH
Icon=$ICON
StartupWMClass=Mount Sleuth
Terminal=false
Categories=System;Utility;
EOF
chmod 0644 "$DESKTOP"

if [ $MAKE_VENV = 1 ]; then
  # Debian/Ubuntu ship venv support separately (python3-venv), not installed by default
  if ! python3 -c 'import ensurepip' 2>/dev/null; then
    command -v apt-get >/dev/null || { echo "Python venv support is missing: install your distribution's python3-venv"; exit 1; }
    apt-get install -y python3-venv
  fi
  # a half-made venv would be picked by the launcher and has no PySide6
  python3 -m venv "$VENV" || { rm -rf "$VENV"; echo "could not create $VENV"; exit 1; }
  if [ -n "$WHEELS" ]; then
    "$VENV/bin/pip" install -q --no-index --find-links "$WHEELS" "$PYSIDE"
  else
    "$VENV/bin/pip" install -q "$PYSIDE"
  fi
  chown -R root:root "$VENV"
fi

echo "Installed:"
echo "  $LIB/            backend + GUI (root-owned)"
echo "  $WRAP     what pkexec runs (polkit: $POLICY)"
echo "  $LAUNCH   start the GUI (also in the desktop menu: Mount Sleuth)"
command -v pkexec >/dev/null || echo "WARNING: pkexec not found - apt install pkexec (or policykit-1), or use sudo in Settings"
for t in losetup sfdisk blkid blockdev mount umount kpartx dmsetup; do
  command -v $t >/dev/null || echo "WARNING: required tool $t is missing - Mount Sleuth can't mount anything without it"
done
for t in ewfmount qemu-nbd affuse ntfs-3g lvs vshadowinfo fuser; do
  command -v $t >/dev/null || echo "note: optional tool $t is missing (see MOUNT_EVIDENCE.md for what it adds)"
done
if grep -q " /mnt/IOC_SCAN" /proc/mounts; then   # mount root before the MountSleuth rename
  echo "note: images an older version attached are still under /mnt/IOC_SCAN; the default root is now"
  echo "      /mnt/MountSleuth. Release them with: sudo mount-evidence -o /mnt/IOC_SCAN --unmount"
fi
u=${SUDO_USER:-}
if [ -x "$VENV/bin/python3" ]; then PY="$VENV/bin/python3"; else PY=python3; fi
if [ -n "$u" ] && ! su "$u" -s /bin/sh -c "$PY -c 'import PySide6.QtWidgets'" 2>/dev/null; then
  echo "WARNING: PySide6 is not importable for $u with $PY:"
  echo "  apt install python3-pyside6.qtwidgets     (where your distribution packages it), or"
  echo "  sudo sh $0 --venv                         (online), or --venv --wheels DIR (offline)"
fi
