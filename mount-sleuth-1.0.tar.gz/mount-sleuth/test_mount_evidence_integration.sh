#!/bin/bash
# Privileged integration tests for mount_evidence_prod.py. DISPOSABLE MACHINE
# OR CONTAINER ONLY: it creates loop devices, device-mapper devices and a fake
# "host" LVM volume group. Builds its own test images (mkimages.sh).
#
#   docker run --privileged ... ; bash test_mount_evidence_integration.sh
#
# Needs: python3 sfdisk kpartx lvm2 dmsetup ntfs-3g dosfstools e2fsprogs
#        ewf-tools cryptsetup-bin psmisc util-linux
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
ME="python3 $HERE/mount_evidence_prod.py -l /tmp/me-test.log"
EV=$(readlink -f "${EV:-/tmp/me-ev}")
pass=0 fail=0
ok()   { echo "PASS  $1"; pass=$((pass+1)); }
bad()  { echo "FAIL  $1"; fail=$((fail+1)); }
check() { if eval "$2"; then ok "$1"; else bad "$1"; fi; }
ours() { losetup -a | grep -c -e "$EV" -e IOC_SCAN; }       # our loop devices
evmounts() { awk '$2 ~ /IOC_SCAN/' /proc/mounts | wc -l; }
clean() { [ "$(ours)" = 0 ] && [ "$(evmounts)" = 0 ] && ! dmsetup ls | grep -q -e '^mev-' -e '^loop[0-9]*p' && \
          [ -z "$(find /mnt/IOC_SCAN /mnt/IOC_SCAN_dev -mindepth 1 2>/dev/null)" ]; }

[ -d "$EV/WEB01" ] || sh "$HERE/mkimages.sh" "$EV" >/dev/null
( cd "$EV" && find . -type f -exec sha256sum {} + | sort ) > /tmp/me-ev.sha

# A stand-in for the workstation's own storage: a VG with the same name as the
# evidence VG (evvg), and an unrelated device-mapper device held open.
vgs evvg >/dev/null 2>&1 || rm -rf /dev/evvg   # stale node dir where no udev runs
rm -f /tmp/me-host.img; truncate -s 64M /tmp/me-host.img
H=$(losetup -f --show /tmp/me-host.img)
pvcreate -q "$H" >/dev/null && vgcreate -q evvg "$H" >/dev/null && lvcreate -q -y -L 16M -n hostlv evvg >/dev/null
dmsetup create hostroot --table "0 2048 zero" && dmsetup mknodes hostroot
sleep 600 < /dev/mapper/hostroot & HOLD=$!
HCFG="devices { filter=[\"a|^$H\$|\",\"r|.*|\"] }"
host_ok() { dmsetup info hostroot >/dev/null 2>&1 && [ "$(dmsetup info -c --noheadings -o open hostroot)" -ge 1 ] && \
            dmsetup table hostroot | grep -q zero && \
            lvs --config "$HCFG" --noheadings -o lv_attr evvg/hostlv 2>/dev/null | grep -q '^ *....a'; }
started() { for i in $(seq 1 200); do ls /mnt/IOC_SCAN/*/*/.mount_state.json >/dev/null 2>&1 && return; sleep 0.05; done; }

echo "== dry run"
$ME -d "$EV" > /tmp/me-out 2>&1; rc=$?
check "dry run exits 0" "[ $rc = 0 ]"
check "dry run leaves nothing attached" "clean"
check "dry run plans the MBR logical partition as p05" "grep -q 'p05_vfat_DATA_1' /tmp/me-out"

echo "== mount"
$ME "$EV" > /tmp/me-out 2>&1; rc=$?
check "mount exits 0" "[ $rc = 0 ]"
check "15 filesystems mounted" "[ \$(evmounts) -ge 15 ]"
check "every evidence filesystem mount is ro" "! awk '\$2 ~ /\/mnt\/IOC_SCAN\// && \$2 !~ /_dev/ {print \$4}' /proc/mounts | grep -qv '^ro'"
check "every exposed block device is read-only" "! for l in \$(find /mnt/IOC_SCAN_dev -type l); do blockdev --getro \$(readlink \$l); done | grep -qv 1"
check "cloned LVM image (same VG name/UUID as LNX01 and the host) mounts" "mountpoint -q /mnt/IOC_SCAN/LNX02/lnx02.img/p02_evvg-root_ext4_root"
check "no mount dir for MSR / swap / unformatted / LUKS" "! ls /mnt/IOC_SCAN/WEB01/web01_disk.raw | grep -qE 'p0[2578]_'"
check "block-device links for MSR / swap / LUKS exist" "[ -L /mnt/IOC_SCAN_dev/WEB01/web01_disk.raw/p02_msr ] && [ -L /mnt/IOC_SCAN_dev/WEB01/web01_disk.raw/p05_swap ] && [ -L /mnt/IOC_SCAN_dev/WEB01/web01_disk.raw/p08_luks ]"
check "manifest is valid JSON with 8 volumes" "python3 -c \"import json;d=json.load(open('/mnt/IOC_SCAN/WEB01/web01_disk.raw/mount_manifest.json'));assert len(d['volumes'])==8\""
check "host VG and host dm device untouched by mounting" "host_ok"

echo "== rerun"
n=$(ours); $ME "$EV" > /tmp/me-out 2>&1
check "rerun skips mounted images (no new loop devices)" "[ \$(ours) = $n ] && [ \$(grep -c 'already mounted by an earlier run' /tmp/me-out) = 5 ]"

echo "== status"
check "--status lists mounts" "$ME --status | grep -q 'mounted: /mnt/IOC_SCAN/WEB01'"

echo "== lock"
flock /run/lock/mount_evidence.lock sleep 5 & L=$!; sleep 0.5
$ME "$EV" > /tmp/me-out 2>&1; rc=$?
check "second instance refused while lock held" "[ $rc = 1 ] && grep -q 'Another mount_evidence is running' /tmp/me-out"
wait $L

echo "== busy teardown"
( cd /mnt/IOC_SCAN/WEB01/web01_disk.raw/p03_ntfs_OS && exec sleep 600 ) & B=$!; sleep 0.5
$ME -u > /tmp/me-out 2>&1; rc=$?
check "busy teardown exits 1 and names the holder" "[ $rc = 1 ] && grep -q 'sleep' /tmp/me-out"
check "busy image keeps its devices and state" "[ -f '/mnt/IOC_SCAN/WEB01/web01_disk.raw/.mount_state.json' ] && [ \$(ours) -ge 1 ]"
kill $B; wait $B 2>/dev/null
$ME -u > /tmp/me-out 2>&1; rc=$?
check "second teardown exits 0" "[ $rc = 0 ]"
check "nothing left after teardown" "clean"
check "host VG and busy host dm device survived teardown" "host_ok"

echo "== block-only"
$ME --block-only "$EV/WEB01/web01 disk.raw" > /tmp/me-out 2>&1
check "block-only mounts nothing but links devices" "[ \$(evmounts) = 0 ] && [ -L /mnt/IOC_SCAN_dev/WEB01/web01_disk.raw/p03_ntfs_OS ] && [ -f /mnt/IOC_SCAN/WEB01/web01_disk.raw/mount_manifest.json ]"
$ME -u > /dev/null 2>&1
check "block-only teardown clean" "clean"

echo "== interrupt (SIGINT mid-run)"
$ME "$EV" > /tmp/me-out 2>&1 & P=$!; started; kill -INT $P; wait $P; rc=$?
check "interrupted run exits 130" "[ $rc = 130 ]"
$ME -u > /tmp/me-out 2>&1
check "teardown after interrupt leaves nothing" "clean"

echo "== kill -9 mid-run"
$ME "$EV" > /tmp/me-out 2>&1 & P=$!; started; sleep 0.3; kill -9 $P; wait $P 2>/dev/null
$ME -u > /tmp/me-out 2>&1
check "teardown after kill -9 leaves nothing" "clean"

echo "== state from the previous script version"
if [ -f "$HERE/orig.py" ]; then
  python3 "$HERE/orig.py" -o /mnt/IOC_SCAN -l /tmp/me-orig.log "$EV" > /dev/null 2>&1
  $ME -u > /tmp/me-out 2>&1
  check "v1 mounts torn down without touching host devices" "host_ok && [ \$(evmounts) = 0 ] && [ \$(ours) = 0 ]"
  # v1 activated evvg with vgchange (all VGs), so its LVs are named evvg-* - not ours to judge;
  # clean them so later tests start fresh
  for n in $(dmsetup ls | awk '/^evvg-(root|swap)/ {print $1}'); do dmsetup remove "$n"; done
  for n in $(dmsetup ls | awk '/^loop[0-9]+p/ {print $1}'); do dmsetup remove "$n"; done
else
  echo "SKIP  orig.py (previous version) not next to this script"
fi

echo "== missing dependency"
EWF=$(command -v ewfmount); chmod -x "$EWF"
$ME "$EV" > /tmp/me-out 2>&1; rc=$?
chmod +x "$EWF"
check "E01 fails as missing_dependency, other images still mount" "[ $rc = 1 ] && grep -q 'missing_dependency' /tmp/me-out && [ \$(evmounts) -ge 11 ]"
$ME -u > /dev/null 2>&1
check "teardown clean" "clean"

echo "== read-write refused"
$ME -w "$EV" > /tmp/me-out 2>&1; rc=$?
check "-w is refused" "[ $rc = 2 ]"

echo "== evidence unchanged"
check "SHA-256 of every evidence file unchanged" "( cd $EV && find . -type f -exec sha256sum {} + | sort ) | diff -q - /tmp/me-ev.sha >/dev/null"

kill $HOLD 2>/dev/null; wait $HOLD 2>/dev/null
dmsetup remove hostroot; vgchange -q -an evvg >/dev/null; losetup -d "$H"
echo; echo "passed $pass, failed $fail"
[ $fail = 0 ]
