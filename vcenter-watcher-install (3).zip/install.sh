#!/bin/bash
#
# install.sh
# Installs the vCenter snapshot watcher as a systemd service.
# Run as root: sudo ./install.sh
#
set -e

INSTALL_DIR="/opt/vcenter-watcher"
SERVICE_USER="vwatcher"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root (use sudo)."
    exit 1
fi

echo "=== vCenter Watcher Install ==="
echo ""

# ---------------------------------------------------------------------------
# 1. System package check (python3 + venv module)
# ---------------------------------------------------------------------------
if ! command -v python3 &>/dev/null; then
    echo "python3 not found. Please install Python 3.9+ before running this script."
    exit 1
fi

PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "Found python3 version: $PY_VER"

# `python3 -m venv --help` succeeds even when venv can't actually create an
# environment (it doesn't exercise ensurepip), so test with a real venv
# creation in a throwaway directory instead of trusting --help.
VENV_TEST_DIR="$(mktemp -d)"
if ! python3 -m venv "$VENV_TEST_DIR/test" &>/dev/null; then
    echo "python3 venv module is not fully functional. Installing required packages..."
    if command -v apt-get &>/dev/null; then
        apt-get update
        # Prefer the exact version-matched package (e.g. python3.10-venv);
        # fall back to the generic package if that specific one isn't found.
        apt-get install -y "python${PY_VER}-venv" python3-pip \
            || apt-get install -y python3-venv python3-pip
    elif command -v dnf &>/dev/null; then
        dnf install -y python3-venv python3-pip
    else
        echo "Could not auto-install the venv module for this OS. Please install it manually and re-run."
        rm -rf "$VENV_TEST_DIR"
        exit 1
    fi

    # Re-test after install to confirm it actually took
    rm -rf "$VENV_TEST_DIR/test"
    if ! python3 -m venv "$VENV_TEST_DIR/test" &>/dev/null; then
        echo "venv still not functional after install attempt. Please investigate manually."
        rm -rf "$VENV_TEST_DIR"
        exit 1
    fi
    echo "venv module installed successfully."
else
    echo "python3 venv module is functional."
fi
rm -rf "$VENV_TEST_DIR"

# ---------------------------------------------------------------------------
# 2. Service account
# ---------------------------------------------------------------------------
if ! id -u "$SERVICE_USER" &>/dev/null; then
    echo "Creating service user '$SERVICE_USER'..."
    useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
else
    echo "Service user '$SERVICE_USER' already exists, skipping creation."
fi

# ---------------------------------------------------------------------------
# 3. Directory layout + file copy
# ---------------------------------------------------------------------------
echo "Creating install directory at $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR/output"

cp "$SCRIPT_DIR/watcher.py" "$INSTALL_DIR/watcher.py"

if [[ -f "$SCRIPT_DIR/vcenter.pem" ]]; then
    cp "$SCRIPT_DIR/vcenter.pem" "$INSTALL_DIR/vcenter.pem"
    HAVE_CERT=1
else
    HAVE_CERT=0
fi

# ---------------------------------------------------------------------------
# 4. Python virtual environment + dependencies
# ---------------------------------------------------------------------------
echo "Creating virtual environment..."
python3 -m venv "$INSTALL_DIR/venv"

echo "Installing dependencies (flask, pyvmomi)..."
"$INSTALL_DIR/venv/bin/pip" install --upgrade pip --quiet
"$INSTALL_DIR/venv/bin/pip" install flask pyvmomi --quiet

# ---------------------------------------------------------------------------
# 5. Interactive .env configuration
# ---------------------------------------------------------------------------
echo ""
echo "=== Configuration ==="

read -rp "vCenter host (hostname or IP): " VCENTER_HOST
read -rp "vCenter username (e.g. svc-watcher@vsphere.local): " VCENTER_USER

while true; do
    read -rsp "vCenter password: " VCENTER_PWD
    echo ""
    read -rsp "Confirm password: " VCENTER_PWD_CONFIRM
    echo ""
    if [[ "$VCENTER_PWD" == "$VCENTER_PWD_CONFIRM" ]]; then
        break
    else
        echo "Passwords did not match, try again."
    fi
done

read -rp "Target VM name (exact match as shown in vCenter inventory): " VM_NAME

echo ""
echo "--- File retrieval (SCP from ESXi host) ---"
echo "Snapshot .vmem/.vmsn files are pulled directly from the ESXi host's"
echo "local filesystem via SCP, using a dedicated SSH key restricted to the"
echo "target VM's folder (see README for the authorized_keys setup)."
read -rp "ESXi host (the actual host backing the target VM's datastore): " ESXI_SSH_HOST
read -rp "SSH user on ESXi host [root]: " ESXI_SSH_USER
ESXI_SSH_USER="${ESXI_SSH_USER:-root}"
read -rp "Path to the dedicated SSH private key for this: " ESXI_SSH_KEY_PATH

if [[ "$HAVE_CERT" -eq 1 ]]; then
    echo "Found vcenter.pem bundled with installer, will use it for TLS verification."
    CA_CERT_PATH="$INSTALL_DIR/vcenter.pem"
else
    read -rp "Path to CA cert for vCenter TLS verification (leave blank to use system trust store): " CA_CERT_PATH
fi

read -rp "Listen port [8443]: " LISTEN_PORT
LISTEN_PORT="${LISTEN_PORT:-8443}"

echo ""
read -rp "Generate a random webhook secret automatically? [Y/n]: " GEN_SECRET
if [[ "$GEN_SECRET" =~ ^[Nn]$ ]]; then
    read -rsp "Enter webhook shared secret: " WEBHOOK_SECRET
    echo ""
else
    WEBHOOK_SECRET=$(openssl rand -hex 32)
    echo "Generated webhook secret (save this — the caller/trigger side needs it too):"
    echo "$WEBHOOK_SECRET"
fi

# ---------------------------------------------------------------------------
# 6. Write .env
# ---------------------------------------------------------------------------
cat > "$INSTALL_DIR/.env" <<EOF
WEBHOOK_SECRET=$WEBHOOK_SECRET
VCENTER_HOST=$VCENTER_HOST
VCENTER_USER=$VCENTER_USER
VCENTER_PWD=$VCENTER_PWD
VM_NAME=$VM_NAME
CA_CERT_PATH=$CA_CERT_PATH
OUTPUT_DIR=$INSTALL_DIR/output
LISTEN_PORT=$LISTEN_PORT
REMOVE_SNAPSHOT_AFTER_DOWNLOAD=true
ESXI_SSH_HOST=$ESXI_SSH_HOST
ESXI_SSH_USER=$ESXI_SSH_USER
ESXI_SSH_KEY_PATH=$ESXI_SSH_KEY_PATH
EOF

# ---------------------------------------------------------------------------
# 7. Permissions
# ---------------------------------------------------------------------------
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
chmod 600 "$INSTALL_DIR/.env"
[[ -f "$INSTALL_DIR/vcenter.pem" ]] && chmod 600 "$INSTALL_DIR/vcenter.pem"
chmod 700 "$INSTALL_DIR/output"

if [[ -n "$ESXI_SSH_KEY_PATH" && -f "$ESXI_SSH_KEY_PATH" ]]; then
    chown "$SERVICE_USER:$SERVICE_USER" "$ESXI_SSH_KEY_PATH"
    chmod 600 "$ESXI_SSH_KEY_PATH"
fi

# ---------------------------------------------------------------------------
# 8. systemd service
# ---------------------------------------------------------------------------
echo "Installing systemd service..."
cp "$SCRIPT_DIR/vcenter-watcher.service" /etc/systemd/system/vcenter-watcher.service
systemctl daemon-reload
systemctl enable vcenter-watcher
systemctl restart vcenter-watcher

sleep 2

echo ""
echo "=== Install complete ==="
systemctl status vcenter-watcher --no-pager -l | head -15
echo ""
echo "Check logs with:   sudo journalctl -u vcenter-watcher -f"
echo "Health check:      curl http://127.0.0.1:${LISTEN_PORT}/health"
echo ""
echo "Webhook secret (store this securely, needed by whatever calls /trigger):"
echo "$WEBHOOK_SECRET"
