#!/bin/sh
# Install Evidence Mounter (GUI + mount_evidence backend) for production use. As root:
#
#   sudo sh install_gui.sh                       install or update
#   sudo sh install_gui.sh --venv [--wheels DIR] also create /opt/mount-evidence-venv with PySide6
#                                                (--wheels: offline, from `pip download` output)
#   sudo sh install_gui.sh --uninstall
#
# Why: the backend runs as root, so the copy pkexec runs must be root-owned (a
# user-writable script elevated by pkexec is a way to root). The polkit rule
# names that one file and keeps the authorisation for a few minutes, so a
# discover-then-mount session asks for the password once.
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
LIB=/usr/local/lib/mount-evidence
WRAP=/usr/local/sbin/mount-evidence
LAUNCH=/usr/local/bin/mount-evidence-gui
POLICY=/usr/share/polkit-1/actions/local.ioc-scan.mount-evidence.policy
DESKTOP=/usr/share/applications/mount-evidence-gui.desktop
VENV=/opt/mount-evidence-venv
PYSIDE="PySide6-Essentials==6.11.0"         # 6.12.0 crashes (shiboken refcount bug); see MOUNT_EVIDENCE_GUI.md

[ "$(id -u)" = 0 ] || { echo "run as root: sudo sh $0 $*"; exit 1; }
MAKE_VENV=0 WHEELS=""
while [ $# -gt 0 ]; do
  case "$1" in
    --uninstall) rm -f "$WRAP" "$LAUNCH" "$POLICY" "$DESKTOP"; rm -rf "$LIB"
                 echo "removed (left alone: $VENV, /var/log/mount_evidence.log, anything still mounted)"; exit 0 ;;
    --venv) MAKE_VENV=1 ;;
    --wheels) WHEELS=$2; shift ;;
    *) echo "unknown option $1"; exit 2 ;;
  esac
  shift
done

install -d -o root -g root -m 0755 "$LIB"
install -o root -g root -m 0644 "$HERE/mount_evidence_prod.py" "$HERE/mount_evidence_gui.py" "$LIB/"
for f in MOUNT_EVIDENCE.md MOUNT_EVIDENCE_GUI.md; do
  [ -f "$HERE/$f" ] && install -o root -g root -m 0644 "$HERE/$f" "$LIB/"
done

cat > "$WRAP" <<'EOF'
#!/bin/sh
# Root side of Evidence Mounter. pkexec runs exactly this file (see the polkit policy).
exec /usr/bin/python3 -I /usr/local/lib/mount-evidence/mount_evidence_prod.py "$@"
EOF
chown root:root "$WRAP"; chmod 0755 "$WRAP"

cat > "$LAUNCH" <<EOF
#!/bin/sh
PY=$VENV/bin/python3
[ -x "\$PY" ] || PY=python3
exec "\$PY" $LIB/mount_evidence_gui.py "\$@"
EOF
chmod 0755 "$LAUNCH"

mkdir -p "$(dirname "$POLICY")"
cat > "$POLICY" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE policyconfig PUBLIC "-//freedesktop//DTD PolicyKit Policy Configuration 1.0//EN"
 "http://www.freedesktop.org/standards/PolicyKit/1/policyconfig.dtd">
<policyconfig>
  <action id="local.ioc-scan.mount-evidence">
    <description>Attach forensic images read-only</description>
    <message>Authentication is required to attach or release forensic images (read-only)</message>
    <defaults>
      <allow_any>auth_admin</allow_any>
      <allow_inactive>auth_admin</allow_inactive>
      <allow_active>auth_admin_keep</allow_active>
    </defaults>
    <annotate key="org.freedesktop.policykit.exec.path">$WRAP</annotate>
  </action>
</policyconfig>
EOF
chmod 0644 "$POLICY"

mkdir -p "$(dirname "$DESKTOP")"
cat > "$DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=Evidence Mounter
Comment=Mount forensic disk images read-only
Exec=$LAUNCH
Icon=drive-harddisk
Terminal=false
Categories=System;Utility;
EOF
chmod 0644 "$DESKTOP"

if [ $MAKE_VENV = 1 ]; then
  python3 -m venv "$VENV"
  if [ -n "$WHEELS" ]; then
    "$VENV/bin/pip" install -q --no-index --find-links "$WHEELS" "$PYSIDE"
  else
    "$VENV/bin/pip" install -q "$PYSIDE"
  fi
  chown -R root:root "$VENV"
fi

echo "Installed:"
echo "  $LIB/            backend + GUI (root-owned)"
echo "  $WRAP     what pkexec runs (polkit: $POLICY)"
echo "  $LAUNCH   start the GUI (also in the desktop menu: Evidence Mounter)"
command -v pkexec >/dev/null || echo "WARNING: pkexec not found - apt install pkexec (or policykit-1), or use sudo in Settings"
u=${SUDO_USER:-}
if [ -x "$VENV/bin/python3" ]; then PY="$VENV/bin/python3"; else PY=python3; fi
if [ -n "$u" ] && ! su "$u" -s /bin/sh -c "$PY -c 'import PySide6'" 2>/dev/null; then
  echo "WARNING: PySide6 is not importable for $u with $PY:"
  echo "  apt install python3-pyside6.qtwidgets     (where your distribution packages it), or"
  echo "  sudo sh $0 --venv                         (online), or --venv --wheels DIR (offline)"
fi
