"""
watcher.py

Webhook listener that triggers a PowerShell memory snapshot script
when it receives a validated request.

Config is supplied via environment / systemd EnvironmentFile (.env).
"""

from flask import Flask, request, abort
import hmac, hashlib, os, json, datetime, logging, subprocess

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

WEBHOOK_SECRET   = os.environ["WEBHOOK_SECRET"].encode()
VCENTER_HOST     = os.environ["VCENTER_HOST"]
VCENTER_USER     = os.environ["VCENTER_USER"]
VCENTER_PWD      = os.environ["VCENTER_PWD"]
VM_NAME          = os.environ["VM_NAME"]
OUTPUT_DIR       = os.environ.get("OUTPUT_DIR", "/opt/vcenter-watcher/output")
LISTEN_PORT      = int(os.environ.get("LISTEN_PORT", "8443"))
PWSH_PATH        = os.environ.get("PWSH_PATH", "/usr/bin/pwsh")
PS_SCRIPT_PATH   = os.environ.get("PS_SCRIPT_PATH", "/opt/vcenter-watcher/Test-MemorySnapshotCapture.ps1")
MIN_DS_FREE_GB   = os.environ.get("MIN_DATASTORE_FREE_GB", "5")
MAX_SNAPSHOTS    = os.environ.get("MAX_EXISTING_SNAPSHOTS", "1")
KEEP_SNAPSHOT       = os.environ.get("KEEP_SNAPSHOT", "false").lower() == "true"
DOWNLOAD_SNAPSHOT   = os.environ.get("DOWNLOAD_SNAPSHOT", "false").lower() == "true"
DATACENTER_NAME     = os.environ.get("DATACENTER_NAME", "ha-datacenter")

os.makedirs(OUTPUT_DIR, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("watcher")

# ---------------------------------------------------------------------------
# PowerShell snapshot runner
# ---------------------------------------------------------------------------

def run_snapshot_script():
    """Invoke Test-MemorySnapshotCapture.ps1 via pwsh as a subprocess.

    Credentials are passed via environment variables rather than command-line
    arguments so they don't appear in `ps aux` output or shell history on the
    watcher VM.
    """
    env = os.environ.copy()
    env["CAPTURE_USER"] = VCENTER_USER
    env["CAPTURE_PWD"]  = VCENTER_PWD

    cmd = [
        PWSH_PATH,
        "-NonInteractive",
        "-NoProfile",
        "-File", PS_SCRIPT_PATH,
        "-Server", VCENTER_HOST,
        "-VMName", VM_NAME,
        "-MinimumDatastoreFreeGB", MIN_DS_FREE_GB,
        "-MaximumExistingSnapshots", MAX_SNAPSHOTS,
    ]

    if KEEP_SNAPSHOT:
        cmd.append("-KeepSnapshot")

    if DOWNLOAD_SNAPSHOT:
        cmd.extend([
            "-DownloadSnapshot",
            "-DestinationPath", OUTPUT_DIR,
            "-DatacenterName", DATACENTER_NAME,
        ])

    log.info("Invoking snapshot script for VM '%s' on '%s'", VM_NAME, VCENTER_HOST)
    proc = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=600,   # 10 min ceiling - large RAM VMs can take a while
        env=env
    )

    stdout = proc.stdout.strip()
    stderr = proc.stderr.strip()

    if stdout:
        log.info("Script output:\n%s", stdout)
    if stderr:
        log.warning("Script stderr:\n%s", stderr)

    if proc.returncode != 0:
        raise RuntimeError(
            f"Snapshot script exited with code {proc.returncode}: {stderr or stdout}"
        )

    return {
        "exit_code": proc.returncode,
        "output": stdout,
        "timestamp": datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ"),
    }

# ---------------------------------------------------------------------------
# Flask app
# ---------------------------------------------------------------------------

app = Flask(__name__)


@app.route("/trigger", methods=["POST"])
def trigger():
    signature = request.headers.get("X-Signature", "")
    expected = hmac.new(WEBHOOK_SECRET, request.data, hashlib.sha256).hexdigest()

    if not hmac.compare_digest(signature, expected):
        log.warning("Rejected webhook: invalid signature from %s", request.remote_addr)
        abort(403)

    log.info("Valid webhook received from %s, triggering snapshot", request.remote_addr)

    timestamp = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")

    try:
        result = run_snapshot_script()
    except subprocess.TimeoutExpired:
        log.error("Snapshot script timed out after 600 seconds")
        return {"status": "error", "detail": "snapshot script timed out"}, 500
    except Exception as e:
        log.error("Snapshot script failed: %s", e)
        return {"status": "error", "detail": str(e)}, 500

    out_path = os.path.join(OUTPUT_DIR, f"snapshot_result_{timestamp}.json")
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

    log.info("Snapshot complete, result written to %s", out_path)
    return {"status": "ok", "file": out_path, "result": result}, 200


@app.route("/health", methods=["GET"])
def health():
    return {"status": "ok"}, 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=LISTEN_PORT)
