//! yarax-scanner library root.
//!
//! `run()` wires the pipeline and is callable from tests and the binary:
//!
//! ```text
//! walker (1 thread) ──bounded channel──▶ workers × N ──channel──▶ writer (1 thread)
//!                                            │
//!                                       ArchiveCtx (streaming, recursive)
//! ```

pub mod archives;
pub mod config;
pub mod engine;
pub mod gui_core;
pub mod hashing;
pub mod metadata;
pub mod models;
pub mod progress;
pub mod stats;
pub mod utils;
pub mod walker;
pub mod worker;
pub mod writer;

use crate::config::Config;
use crate::engine::Engine;
use crate::stats::{Snapshot, Stats};
use crate::utils::{human_bytes, now_iso};
use anyhow::Result;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Instant;

pub fn run(cfg: &Config) -> Result<Snapshot> {
    let start_iso = now_iso();
    let t0 = Instant::now();

    // Compile rules ONCE, before any thread exists.
    let engine = Engine::load(cfg)?;

    let stats = Arc::new(Stats::default());
    let stop_progress = Arc::new(AtomicBool::new(false));

    // Bounded MPMC work queue: backpressure keeps memory flat.
    let (task_tx, task_rx) = crossbeam_channel::bounded(cfg.queue_depth);
    // Hit channel to the writer; bounded so a hit storm can't balloon RAM.
    let (hit_tx, hit_rx) = crossbeam_channel::bounded(10_000);

    let (sink, hit_count) = std::thread::scope(|s| -> Result<_> {
        // Writer thread: owns the output sink, returns it for finalize.
        let writer_handle = s.spawn(|| writer::write_hits(cfg, hit_rx));

        // Worker threads: each owns a Scanner borrowing the shared rules.
        let mut workers = Vec::with_capacity(cfg.threads);
        for _ in 0..cfg.threads {
            let rx = task_rx.clone();
            let tx = hit_tx.clone();
            let engine_ref = &engine;
            let stats_ref = &stats;
            workers.push(s.spawn(move || {
                worker::run_worker(cfg, engine_ref, rx, tx, stats_ref);
            }));
        }
        // Scope's own clones must drop so disconnects propagate.
        drop(task_rx);
        drop(hit_tx);

        // Progress thread.
        {
            let stats = Arc::clone(&stats);
            let stop = Arc::clone(&stop_progress);
            let quiet = cfg.quiet;
            s.spawn(move || {
                if !quiet {
                    progress::run_progress(stats, stop, 0);
                }
            });
        }

        // Walker runs on this thread — it's the producer; when it returns,
        // task_tx drops, the channel disconnects, and workers drain + exit.
        walker::walk(cfg, task_tx, &stats);

        for w in workers {
            let _ = w.join();
        }
        // All hit_tx clones are gone now -> writer sees disconnect.
        stop_progress.store(true, Ordering::Relaxed);
        writer_handle.join().expect("writer thread panicked")
    })?;

    let elapsed = t0.elapsed().as_secs_f64();
    let snap = stats.snapshot();
    let info = writer::build_scan_information(cfg, &snap, start_iso,
                                              now_iso(), elapsed);
    writer::finalize(sink, &info)?;

    if !cfg.quiet {
        eprintln!(
            "scanned {} files ({}) in {:.1}s -> {:.1} MB/s, {} hits ({} written), {} errors",
            snap.files_scanned, human_bytes(snap.bytes_scanned as f64),
            elapsed, info.scan_rate_mb_per_second, snap.matches, hit_count,
            snap.errors);
    }
    Ok(snap)
}
