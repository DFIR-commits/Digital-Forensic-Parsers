//! Pipeline data models.
//!
//! `FileTask` is deliberately tiny (one `PathBuf` + a `u64`): millions of
//! them flow through the bounded channel and small tasks stay cache-hot.
//! `Hit` derives `Serialize` so the writer thread emits it with zero
//! intermediate representation.

use serde::Serialize;
use std::path::PathBuf;

/// One unit of work.  `size` arrives from the walker's metadata call so
/// workers never re-stat a file.
#[derive(Debug)]
pub struct FileTask {
    pub path: PathBuf,
    pub size: u64,
}

#[derive(Debug, Serialize)]
pub struct StringMatchOut {
    pub identifier: String,
    pub offset: u64,
    /// matched bytes, printable-escaped and truncated
    pub data: String,
}

#[derive(Debug, Serialize)]
pub struct Hit {
    pub rule: String,
    pub namespace: String,
    pub file: String,
    pub relative_path: String,
    pub size: u64,
    pub sha256: String,
    pub md5: String,
    pub offsets: Vec<u64>,
    pub matched_strings: Vec<StringMatchOut>,
    pub tags: Vec<String>,
    pub metadata: serde_json::Map<String, serde_json::Value>,

    #[serde(skip_serializing_if = "Option::is_none")]
    pub archive: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub internal_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub full_path: Option<String>,

    #[serde(skip_serializing_if = "Option::is_none")]
    pub modified_time: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub created_time: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub accessed_time: Option<String>,

    pub is_executable: bool,
    pub is_archive: bool,
    pub is_hidden: bool,
    pub entropy: f64,

    #[serde(skip_serializing_if = "Option::is_none")]
    pub magic: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub mime_type: Option<String>,

    pub scan_time_ms: f64,
}

impl Hit {
    /// Skeleton hit with rule/match data; enrichment fills the rest.
    pub fn new(rule: String, namespace: String, file: String,
               relative_path: String, size: u64) -> Self {
        Hit {
            rule,
            namespace,
            file,
            relative_path,
            size,
            sha256: String::new(),
            md5: String::new(),
            offsets: Vec::new(),
            matched_strings: Vec::new(),
            tags: Vec::new(),
            metadata: serde_json::Map::new(),
            archive: None,
            internal_path: None,
            full_path: None,
            modified_time: None,
            created_time: None,
            accessed_time: None,
            is_executable: false,
            is_archive: false,
            is_hidden: false,
            entropy: 0.0,
            magic: None,
            mime_type: None,
            scan_time_ms: 0.0,
        }
    }
}
