//! Built-in archive formats.
//!
//! Registry order matters: Tar is first so `.tar.gz` beats the plain `.gz`
//! single-stream handler.
//!
//! * **TAR** — `tar::Archive` over a streaming decompressor: strictly
//!   forward reads, no index, no seeks; memory = one header + one buffer
//!   regardless of archive size.  Ideal for tar.gz on NAS.
//! * **ZIP** — `zip::ZipArchive` (needs Seek: File at top level, Cursor for
//!   nested).  `by_index` returns a *streaming* inflater per member.
//!   Encrypted members are skipped individually.
//! * **Single-stream** (.gz/.bz2/.xz) — modeled as a one-member archive so
//!   `access.log.gz` flows through the same member policy as zip members.
//! * **7z / RAR** — feature-gated (`--features sevenz,rar`).

use super::{ArchiveCtx, ArchiveFormat, ArchiveInput};
use crate::config::ARCHIVE_SEP;
use crate::utils::strip_last_ext;
use anyhow::{Context, Result};
use std::fs::File;
use std::io::{BufReader, Cursor, Read, Seek};

pub fn builtin_formats() -> Vec<Box<dyn ArchiveFormat>> {
    let mut v: Vec<Box<dyn ArchiveFormat>> = vec![
        Box::new(TarFormat),
        Box::new(ZipFormat),
        Box::new(SingleStreamFormat),
    ];
    #[cfg(feature = "sevenz")]
    v.push(Box::new(sevenz::SevenZFormat));
    #[cfg(feature = "rar")]
    v.push(Box::new(rar::RarFormat));
    v
}

fn name_ends(name: &str, exts: &[&str]) -> bool {
    let low = name.to_ascii_lowercase();
    exts.iter().any(|e| low.ends_with(e))
}

// ===========================================================================
// TAR family
// ===========================================================================
pub struct TarFormat;

const TAR_EXTS: [&str; 8] = [".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2",
                             ".tbz", ".tar.xz", ".txz"];

impl TarFormat {
    /// Wrap the raw reader in the right decompressor by name, or passthrough.
    fn decompressor<'a>(name: &str, raw: Box<dyn Read + 'a>) -> Box<dyn Read + 'a> {
        let low = name.to_ascii_lowercase();
        if low.ends_with(".tar.gz") || low.ends_with(".tgz") {
            Box::new(flate2::read::MultiGzDecoder::new(raw))
        } else if low.ends_with(".tar.bz2") || low.ends_with(".tbz2")
            || low.ends_with(".tbz") {
            Box::new(bzip2::read::BzDecoder::new(raw))
        } else if low.ends_with(".tar.xz") || low.ends_with(".txz") {
            Box::new(xz2::read::XzDecoder::new(raw))
        } else {
            raw
        }
    }
}

impl ArchiveFormat for TarFormat {
    fn format_name(&self) -> &'static str { "tar" }

    fn claims_name(&self, name: &str) -> bool { name_ends(name, &TAR_EXTS) }

    fn claims_magic(&self, header: &[u8]) -> bool {
        header.len() > 262 && &header[257..262] == b"ustar"
    }

    fn scan(&self, input: ArchiveInput, chain: &str, ctx: &mut ArchiveCtx)
            -> Result<()> {
        let raw: Box<dyn Read> = match input {
            ArchiveInput::File(p) => Box::new(BufReader::with_capacity(
                1 << 20, File::open(p).context("open tar")?)),
            ArchiveInput::Bytes(b) => Box::new(Cursor::new(b.to_vec())),
        };
        let reader = Self::decompressor(chain, raw);
        let mut archive = tar::Archive::new(reader);
        for entry in archive.entries().context("tar entries")? {
            let mut entry = match entry {
                Ok(e) => e,
                Err(e) => { log::debug!("tar entry error in {chain}: {e}"); continue; }
            };
            if !entry.header().entry_type().is_file() {
                continue;
            }
            let name = entry.path()
                .map(|p| p.to_string_lossy().into_owned())
                .unwrap_or_else(|_| "<invalid-utf8>".into());
            let size = entry.header().size().ok();
            let vchain = format!("{chain}{ARCHIVE_SEP}{name}");
            ctx.scan_member(&vchain, &name, size, &mut entry);
        }
        Ok(())
    }
}

// ===========================================================================
// ZIP
// ===========================================================================
pub struct ZipFormat;

const ZIP_EXTS: [&str; 4] = [".zip", ".jar", ".war", ".apk"];

impl ZipFormat {
    fn scan_seekable<R: Read + Seek>(&self, source: R, chain: &str,
                                     ctx: &mut ArchiveCtx) -> Result<()> {
        let mut zip = zip::ZipArchive::new(source).context("open zip")?;
        for i in 0..zip.len() {
            let mut member = match zip.by_index(i) {
                Ok(m) => m,
                Err(e) => {
                    // encrypted / unsupported member: skip it, keep siblings
                    log::debug!("zip member {i} in {chain}: {e}");
                    continue;
                }
            };
            if member.is_dir() {
                continue;
            }
            let name = member.name().to_string();
            let size = member.size();
            let vchain = format!("{chain}{ARCHIVE_SEP}{name}");
            ctx.scan_member(&vchain, &name, Some(size), &mut member);
        }
        Ok(())
    }
}

impl ArchiveFormat for ZipFormat {
    fn format_name(&self) -> &'static str { "zip" }

    fn claims_name(&self, name: &str) -> bool { name_ends(name, &ZIP_EXTS) }

    fn claims_magic(&self, header: &[u8]) -> bool {
        header.starts_with(b"PK\x03\x04") || header.starts_with(b"PK\x05\x06")
    }

    fn scan(&self, input: ArchiveInput, chain: &str, ctx: &mut ArchiveCtx)
            -> Result<()> {
        match input {
            ArchiveInput::File(p) => {
                let f = File::open(p).context("open zip file")?;
                self.scan_seekable(BufReader::with_capacity(1 << 20, f), chain, ctx)
            }
            ArchiveInput::Bytes(b) => {
                self.scan_seekable(Cursor::new(b), chain, ctx)
            }
        }
    }
}

// ===========================================================================
// Single-stream compressors (.gz / .bz2 / .xz / .lzma)
// ===========================================================================
pub struct SingleStreamFormat;

const SS_EXTS: [&str; 4] = [".gz", ".bz2", ".xz", ".lzma"];

impl ArchiveFormat for SingleStreamFormat {
    fn format_name(&self) -> &'static str { "gzip/bzip2/xz" }

    fn claims_name(&self, name: &str) -> bool { name_ends(name, &SS_EXTS) }

    fn claims_magic(&self, header: &[u8]) -> bool {
        header.starts_with(b"\x1f\x8b")           // gzip
            || header.starts_with(b"BZh")          // bzip2
            || header.starts_with(b"\xfd7zXZ\x00") // xz
    }

    fn scan(&self, input: ArchiveInput, chain: &str, ctx: &mut ArchiveCtx)
            -> Result<()> {
        let raw: Box<dyn Read> = match input {
            ArchiveInput::File(p) => Box::new(BufReader::with_capacity(
                1 << 20, File::open(p).context("open compressed file")?)),
            ArchiveInput::Bytes(b) => Box::new(Cursor::new(b.to_vec())),
        };
        // Pick decoder by extension; fall back to magic sniff via a
        // 4-byte pushback.
        let low = chain.to_ascii_lowercase();
        let mut decoder: Box<dyn Read> = if low.ends_with(".gz") {
            Box::new(flate2::read::MultiGzDecoder::new(raw))
        } else if low.ends_with(".bz2") {
            Box::new(bzip2::read::BzDecoder::new(raw))
        } else {
            Box::new(xz2::read::XzDecoder::new(raw))
        };
        // Inner file: unknown size -> capped/chunked policy applies.
        let inner_name = strip_last_ext(chain);
        let vchain = format!("{chain}{ARCHIVE_SEP}{inner_name}");
        ctx.scan_member(&vchain, &inner_name, None, &mut decoder);
        Ok(())
    }
}

// ===========================================================================
// 7-Zip (feature = "sevenz")
// ===========================================================================
#[cfg(feature = "sevenz")]
mod sevenz {
    use super::*;

    pub struct SevenZFormat;

    impl ArchiveFormat for SevenZFormat {
        fn format_name(&self) -> &'static str { "7z" }

        fn claims_name(&self, name: &str) -> bool {
            name.to_ascii_lowercase().ends_with(".7z")
        }

        fn claims_magic(&self, header: &[u8]) -> bool {
            header.starts_with(b"7z\xbc\xaf\x27\x1c")
        }

        fn scan(&self, input: ArchiveInput, chain: &str, ctx: &mut ArchiveCtx)
                -> Result<()> {
            // sevenz-rust decodes solid blocks; per-member true streaming is
            // not available, so members are surfaced through the entry
            // reader callback ("where practical" per spec).  Global budget
            // caps still apply inside scan_member.
            let scan_entries = |reader: &mut dyn Read, name: &str,
                                size: Option<u64>, ctx: &mut ArchiveCtx| {
                let vchain = format!("{chain}{ARCHIVE_SEP}{name}");
                ctx.scan_member(&vchain, name, size, reader);
            };
            match input {
                ArchiveInput::File(p) => {
                    let mut sz = sevenz_rust::SevenZReader::open(p, "".into())
                        .context("open 7z")?;
                    sz.for_each_entries(|entry, reader| {
                        if !entry.is_directory() {
                            scan_entries(reader, entry.name(),
                                         Some(entry.size()), ctx);
                        }
                        Ok(true)
                    }).context("read 7z")?;
                }
                ArchiveInput::Bytes(b) => {
                    let cursor = Cursor::new(b);
                    let len = b.len() as u64;
                    let mut sz = sevenz_rust::SevenZReader::new(
                        cursor, len, "".into()).context("open nested 7z")?;
                    sz.for_each_entries(|entry, reader| {
                        if !entry.is_directory() {
                            scan_entries(reader, entry.name(),
                                         Some(entry.size()), ctx);
                        }
                        Ok(true)
                    }).context("read nested 7z")?;
                }
            }
            Ok(())
        }
    }
}

// ===========================================================================
// RAR (feature = "rar") — path input only; nested RARs are scanned raw.
// ===========================================================================
#[cfg(feature = "rar")]
mod rar {
    use super::*;

    pub struct RarFormat;

    impl ArchiveFormat for RarFormat {
        fn format_name(&self) -> &'static str { "rar" }

        fn claims_name(&self, name: &str) -> bool {
            name.to_ascii_lowercase().ends_with(".rar")
        }

        fn claims_magic(&self, header: &[u8]) -> bool {
            header.starts_with(b"Rar!\x1a\x07")
        }

        fn scan(&self, input: ArchiveInput, chain: &str, ctx: &mut ArchiveCtx)
                -> Result<()> {
            let ArchiveInput::File(path) = input else {
                anyhow::bail!("nested RAR not supported by backend; \
                               raw bytes were scanned instead");
            };
            let mut archive = unrar::Archive::new(path)
                .open_for_processing().context("open rar")?;
            while let Some(header) = archive.read_header().context("rar header")? {
                let entry = header.entry();
                if !entry.is_file() {
                    archive = header.skip().context("rar skip")?;
                    continue;
                }
                let name = entry.filename.to_string_lossy().into_owned();
                let size = entry.unpacked_size;
                let (data, next) = header.read().context("rar read")?;
                let vchain = format!("{chain}{ARCHIVE_SEP}{name}");
                let mut cursor = Cursor::new(data);
                ctx.scan_member(&vchain, &name, Some(size), &mut cursor);
                archive = next;
            }
            Ok(())
        }
    }
}
