//! Live progress on stderr (own thread; workers only bump atomics).

use crate::stats::Stats;
use crate::utils::{human_bytes, human_eta};
use std::collections::VecDeque;
use std::io::{IsTerminal, Write};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

pub fn run_progress(stats: Arc<Stats>, stop: Arc<AtomicBool>,
                    total_bytes_hint: u64) {
    if !std::io::stderr().is_terminal() {
        // Machine-readable mode (e.g. spawned by the worker): one line per 2s.
        while !stop.load(Ordering::Relaxed) {
            std::thread::sleep(Duration::from_secs(2));
            let s = stats.snapshot();
            eprintln!("PROGRESS files={} bytes={} hits={} errors={}",
                      s.files_scanned, s.bytes_scanned, s.matches, s.errors);
        }
        return;
    }
    // Sliding window => current speed, not lifetime average.
    let mut window: VecDeque<(Instant, u64, u64)> = VecDeque::with_capacity(20);
    let mut err = std::io::stderr();

    while !stop.load(Ordering::Relaxed) {
        std::thread::sleep(Duration::from_millis(500));
        let s = stats.snapshot();
        let now = Instant::now();
        window.push_back((now, s.bytes_scanned, s.files_scanned));
        if window.len() > 20 {
            window.pop_front();
        }
        let (t0, b0, f0) = *window.front().unwrap();
        let dt = now.duration_since(t0).as_secs_f64().max(1e-6);
        let mbps = (s.bytes_scanned - b0) as f64 / dt / (1024.0 * 1024.0);
        let fps = (s.files_scanned - f0) as f64 / dt;

        let eta = if total_bytes_hint > 0 && mbps > 0.0 {
            human_eta((total_bytes_hint.saturating_sub(s.bytes_scanned)) as f64
                      / (mbps * 1024.0 * 1024.0))
        } else {
            "--:--".into()
        };

        let mut line = format!(
            "\r\x1b[Kfiles {} | {:.1} MB/s | {:.0} f/s | {} | hits {} | err {} | ETA {} | {}",
            s.files_scanned, mbps, fps, human_bytes(s.bytes_scanned as f64),
            s.matches, s.errors, eta, s.current_dir);
        line.truncate(200);
        let _ = err.write_all(line.as_bytes());
        let _ = err.flush();
    }
    let _ = err.write_all(b"\n");
}
