//! Lock-free live statistics.
//!
//! Every counter is an `AtomicU64` updated with `Relaxed` ordering — the hot
//! path pays one uncontended atomic add per file, no mutex, no cache-line
//! ping-pong between the progress thread and workers.  (In the Python
//! version this was a mutex; here it is genuinely lock-free.)
//!
//! `current_dir` is the sole string and lives behind a tiny parking-lot-free
//! `std::sync::Mutex` touched once per *directory*, which is noise.

use std::sync::atomic::{AtomicU64, Ordering::Relaxed};
use std::sync::Mutex;

#[derive(Default)]
pub struct Stats {
    pub files_scanned: AtomicU64,
    pub dirs_scanned: AtomicU64,
    pub bytes_scanned: AtomicU64,
    pub matches: AtomicU64,
    pub errors: AtomicU64,
    pub archives_scanned: AtomicU64,
    pub archive_members_scanned: AtomicU64,
    /// microseconds, summed — divide by files for the mean
    pub scan_latency_total_us: AtomicU64,
    pub scan_latency_max_us: AtomicU64,
    pub current_dir: Mutex<String>,
}

impl Stats {
    pub fn add_file(&self, bytes: u64, latency_us: u64, member: bool) {
        self.files_scanned.fetch_add(1, Relaxed);
        self.bytes_scanned.fetch_add(bytes, Relaxed);
        if member {
            self.archive_members_scanned.fetch_add(1, Relaxed);
        }
        self.scan_latency_total_us.fetch_add(latency_us, Relaxed);
        self.scan_latency_max_us.fetch_max(latency_us, Relaxed);
    }

    pub fn add_dir(&self, path: &str) {
        self.dirs_scanned.fetch_add(1, Relaxed);
        if let Ok(mut cur) = self.current_dir.lock() {
            cur.clear();
            cur.push_str(path);
        }
    }

    #[inline]
    pub fn add_error(&self) {
        self.errors.fetch_add(1, Relaxed);
    }

    #[inline]
    pub fn add_matches(&self, n: u64) {
        self.matches.fetch_add(n, Relaxed);
    }

    #[inline]
    pub fn add_archive(&self) {
        self.archives_scanned.fetch_add(1, Relaxed);
    }

    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            files_scanned: self.files_scanned.load(Relaxed),
            dirs_scanned: self.dirs_scanned.load(Relaxed),
            bytes_scanned: self.bytes_scanned.load(Relaxed),
            matches: self.matches.load(Relaxed),
            errors: self.errors.load(Relaxed),
            archives_scanned: self.archives_scanned.load(Relaxed),
            archive_members_scanned: self.archive_members_scanned.load(Relaxed),
            scan_latency_total_us: self.scan_latency_total_us.load(Relaxed),
            scan_latency_max_us: self.scan_latency_max_us.load(Relaxed),
            current_dir: self.current_dir.lock()
                .map(|s| s.clone()).unwrap_or_default(),
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct Snapshot {
    pub files_scanned: u64,
    pub dirs_scanned: u64,
    pub bytes_scanned: u64,
    pub matches: u64,
    pub errors: u64,
    pub archives_scanned: u64,
    pub archive_members_scanned: u64,
    pub scan_latency_total_us: u64,
    pub scan_latency_max_us: u64,
    pub current_dir: String,
}

impl Snapshot {
    pub fn avg_latency_ms(&self) -> f64 {
        if self.files_scanned == 0 {
            0.0
        } else {
            self.scan_latency_total_us as f64 / self.files_scanned as f64 / 1000.0
        }
    }
    pub fn max_latency_ms(&self) -> f64 {
        self.scan_latency_max_us as f64 / 1000.0
    }
}
