//! Hashing — computed **only for matches** (or `--hash-all`).
//!
//! SHA256 and MD5 in a single pass over the same bytes.  For mmapped files
//! the mapping the scanner just used is reused, so a matched large file is
//! read from the page cache exactly once end-to-end (scan + hash).

use md5::Md5;
use sha2::{Digest, Sha256};
use std::io::Read;

pub fn hash_slice(data: &[u8]) -> (String, String) {
    let sha = Sha256::digest(data);
    let md5 = Md5::digest(data);
    (hex(&sha), hex(&md5))
}

pub fn hash_reader<R: Read>(mut r: R, buf: &mut [u8]) -> std::io::Result<(String, String)> {
    let mut sha = Sha256::new();
    let mut md5 = Md5::new();
    loop {
        let n = r.read(buf)?;
        if n == 0 {
            break;
        }
        sha.update(&buf[..n]);
        md5.update(&buf[..n]);
    }
    Ok((hex(&sha.finalize()), hex(&md5.finalize())))
}

#[inline]
fn hex(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        use std::fmt::Write;
        let _ = write!(s, "{b:02x}");
    }
    s
}
