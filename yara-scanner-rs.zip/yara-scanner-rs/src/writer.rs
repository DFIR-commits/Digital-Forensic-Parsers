//! Incremental JSON report writer (dedicated thread).
//!
//! Hits are serialized and flushed as they arrive, so memory never grows
//! with hit count and a crash mid-scan leaves everything written so far on
//! disk.  Workers pay one channel send per hit; serde_json runs on this
//! thread only.

use crate::config::{Config, SCANNER_VERSION, SCHEMA_VERSION};
use crate::models::Hit;
use crate::stats::Snapshot;
use anyhow::Result;
use crossbeam_channel::Receiver;
use serde::Serialize;
use std::fs::File;
use std::io::{BufWriter, Stdout, Write};

pub enum Sink {
    File(BufWriter<File>),
    Stdout(BufWriter<Stdout>),
}

impl Write for Sink {
    fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        match self { Sink::File(w) => w.write(buf), Sink::Stdout(w) => w.write(buf) }
    }
    fn flush(&mut self) -> std::io::Result<()> {
        match self { Sink::File(w) => w.flush(), Sink::Stdout(w) => w.flush() }
    }
}

/// Runs on the writer thread; returns the sink + hit count for finalize.
pub fn write_hits(cfg: &Config, rx: Receiver<Hit>) -> Result<(Sink, u64)> {
    let mut sink = match &cfg.output {
        Some(p) => Sink::File(BufWriter::with_capacity(1 << 20, File::create(p)?)),
        None => Sink::Stdout(BufWriter::new(std::io::stdout())),
    };
    write!(sink, "{{\n  \"schema_version\": \"{SCHEMA_VERSION}\",\n  \"hits\": [")?;

    let mut count = 0u64;
    let mut buf = Vec::with_capacity(4096); // reusable serialization buffer
    while let Ok(hit) = rx.recv() {
        buf.clear();
        if serde_json::to_writer(&mut buf, &hit).is_err() {
            log::warn!("could not serialize hit for {}", hit.file);
            continue;
        }
        sink.write_all(if count == 0 { b"\n    " } else { b",\n    " })?;
        sink.write_all(&buf)?;
        count += 1;
        if count % 128 == 0 {
            sink.flush()?; // bounded durability without per-hit fsync cost
        }
    }
    Ok((sink, count))
}

#[derive(Serialize)]
pub struct ScanInformation {
    pub start_time: String,
    pub end_time: String,
    pub elapsed_seconds: f64,
    pub scanner_version: &'static str,
    pub hostname: String,
    pub threads: usize,
    pub path: String,
    pub rules: String,
    pub files_scanned: u64,
    pub directories_scanned: u64,
    pub bytes_scanned: u64,
    pub archives_scanned: u64,
    pub archive_members_scanned: u64,
    pub matches: u64,
    pub errors: u64,
    pub scan_rate_mb_per_second: f64,
    pub avg_scan_latency_ms: f64,
    pub max_scan_latency_ms: f64,
}

pub fn build_scan_information(cfg: &Config, snap: &Snapshot, start_iso: String,
                              end_iso: String, elapsed: f64) -> ScanInformation {
    let mb = snap.bytes_scanned as f64 / (1024.0 * 1024.0);
    ScanInformation {
        start_time: start_iso,
        end_time: end_iso,
        elapsed_seconds: (elapsed * 1000.0).round() / 1000.0,
        scanner_version: SCANNER_VERSION,
        hostname: hostname::get()
            .map(|h| h.to_string_lossy().into_owned())
            .unwrap_or_default(),
        threads: cfg.threads,
        path: cfg.path.to_string_lossy().into_owned(),
        rules: cfg.rules.iter().map(|p| p.to_string_lossy()).collect::<Vec<_>>().join(", "),
        files_scanned: snap.files_scanned,
        directories_scanned: snap.dirs_scanned,
        bytes_scanned: snap.bytes_scanned,
        archives_scanned: snap.archives_scanned,
        archive_members_scanned: snap.archive_members_scanned,
        matches: snap.matches,
        errors: snap.errors,
        scan_rate_mb_per_second: if elapsed > 0.0 {
            ((mb / elapsed) * 100.0).round() / 100.0 } else { 0.0 },
        avg_scan_latency_ms: (snap.avg_latency_ms() * 1000.0).round() / 1000.0,
        max_scan_latency_ms: (snap.max_latency_ms() * 1000.0).round() / 1000.0,
    }
}

pub fn finalize(mut sink: Sink, info: &ScanInformation) -> Result<()> {
    let body = serde_json::to_string_pretty(info)?
        .replace('\n', "\n  ");
    write!(sink, "\n  ],\n  \"scan_information\": {body}\n}}\n")?;
    sink.flush()?;
    Ok(())
}
