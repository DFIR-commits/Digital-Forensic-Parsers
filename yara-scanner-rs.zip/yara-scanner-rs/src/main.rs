//! Binary entry point: parse CLI, run the scan, exit with a status code.

use clap::Parser;
use yarax_scanner::config::{Cli, Config};

fn main() {
    let cli = Cli::parse();

    env_logger::Builder::new()
        .filter_level(if cli.verbose {
            log::LevelFilter::Debug
        } else if cli.quiet {
            log::LevelFilter::Error
        } else {
            log::LevelFilter::Warn
        })
        .format_timestamp_secs()
        .init();

    let cfg = match Config::from_cli(cli) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::exit(2);
        }
    };

    match yarax_scanner::run(&cfg) {
        Ok(snap) => std::process::exit(if snap.errors == 0 { 0 } else { 1 }),
        Err(e) => {
            eprintln!("fatal: {e:#}");
            std::process::exit(2);
        }
    }
}
