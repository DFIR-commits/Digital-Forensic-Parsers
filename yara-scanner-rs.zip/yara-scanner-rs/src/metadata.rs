//! Hit enrichment — runs **only on matches**, never on the miss path.

use crate::config::SAMPLE_LEN;
use crate::models::Hit;
use crate::utils::{iso_time, shannon_entropy};
use std::fs;
use std::path::Path;

const ARCHIVE_EXTS: [&str; 11] = [".zip", ".gz", ".tgz", ".tar", ".bz2",
                                  ".xz", ".7z", ".rar", ".cab", ".jar", ".war"];

pub fn looks_like_archive(name: &str) -> bool {
    let low = name.to_ascii_lowercase();
    ARCHIVE_EXTS.iter().any(|e| low.ends_with(e))
}

fn base_name(path: &str) -> &str {
    path.rsplit(['/', '\\']).next().unwrap_or(path)
}

/// Enrich a hit for an on-disk file; `sample` is the first bytes of the file
/// (borrowed from the scan buffer/mmap — no extra read).
pub fn enrich_disk(hit: &mut Hit, path: &Path, sample: &[u8]) {
    if let Ok(md) = fs::metadata(path) {
        if let Ok(t) = md.modified() { hit.modified_time = Some(iso_time(t)); }
        if let Ok(t) = md.accessed() { hit.accessed_time = Some(iso_time(t)); }
        if let Ok(t) = md.created()  { hit.created_time  = Some(iso_time(t)); }
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            hit.is_executable = md.permissions().mode() & 0o111 != 0;
        }
    }
    let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
    hit.is_hidden = name.starts_with('.');
    hit.is_archive = looks_like_archive(name);
    enrich_sample(hit, sample);
}

/// Enrich a hit for an archive member from its in-memory bytes.
pub fn enrich_member(hit: &mut Hit, member_name: &str, sample: &[u8]) {
    hit.is_hidden = base_name(member_name).starts_with('.');
    hit.is_archive = looks_like_archive(member_name);
    enrich_sample(hit, sample);
}

fn enrich_sample(hit: &mut Hit, sample: &[u8]) {
    let s = &sample[..sample.len().min(SAMPLE_LEN)];
    hit.entropy = shannon_entropy(s);
    if let Some(kind) = infer::get(s) {
        hit.magic = Some(kind.extension().to_string());
        hit.mime_type = Some(kind.mime_type().to_string());
    }
}
