# Builds yarax-gui.exe and yarax-scanner.exe into .\dist\
#
#   .\build-gui.ps1          release build (slow, several minutes, lots of RAM)
#   .\build-gui.ps1 -Fast    dev build (much quicker to compile; still optimised)
#
# Installs missing prerequisites with winget (Rust, CMake, and a C compiler).
# If winget installed anything, it asks you to re-run in a NEW PowerShell window
# so the new tools are on PATH.
param([switch]$Fast)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Have($cmd) { [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function HaveMsvc {
    $vw = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
    (Test-Path $vw) -and [bool](& $vw -latest -products * `
        -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath)
}

$installed = $false
if (-not (Have winget) -and -not ((Have cargo) -and (Have cmake))) {
    throw "winget not found. Install Rust (https://rustup.rs) and CMake (https://cmake.org/download) manually, then re-run."
}
if (-not (Have cargo)) {
    Write-Host "Installing Rust..." ; winget install -e --id Rustlang.Rustup --accept-source-agreements --accept-package-agreements
    $installed = $true
}
if (-not (Have cmake)) {
    Write-Host "Installing CMake..." ; winget install -e --id Kitware.CMake --accept-source-agreements --accept-package-agreements
    $installed = $true
}
if (-not (HaveMsvc) -and -not (Have gcc)) {
    Write-Host "No C compiler found - installing MinGW (WinLibs)..."
    winget install -e --id BrechtSanders.WinLibs.POSIX.UCRT --accept-source-agreements --accept-package-agreements
    $installed = $true
}
if ($installed) {
    Write-Host "`nPrerequisites installed. Close this window, open a NEW PowerShell, and run .\build-gui.ps1 again."
    exit 0
}

# No MSVC but MinGW present: make sure Rust targets the matching (gnu) toolchain.
if (-not (HaveMsvc) -and (Have gcc) -and -not ((rustc -vV) -match "host: .*-gnu")) {
    Write-Host "Switching Rust to the GNU toolchain (no Visual Studio Build Tools found)..."
    rustup default stable-x86_64-pc-windows-gnu
}

$profileDir = if ($Fast) { "debug" } else { "release" }
$buildArgs = @("build", "--features", "gui") + $(if ($Fast) { @() } else { @("--release") })
Write-Host "cargo $($buildArgs -join ' ')"
cargo @buildArgs
if ($LASTEXITCODE -ne 0) { throw "cargo build failed" }

New-Item -ItemType Directory -Force dist | Out-Null
Copy-Item "target\$profileDir\yarax-gui.exe", "target\$profileDir\yarax-scanner.exe" dist -Force
Write-Host "`nDone. Run:  .\dist\yarax-gui.exe   (keep both .exe files together)"
