rule ascii_marker
{
    meta:
        description = "Matches files containing the ASCII string EVIL_MARKER_1337"
        author = "yara-scanner example"

    strings:
        $marker = "EVIL_MARKER_1337"

    condition:
        $marker
}
