rule suspicious_powershell_download
{
    meta:
        description = "Matches text containing a common PowerShell download-and-execute pattern"
        author = "yara-scanner example"

    strings:
        $download = "IEX(New-Object Net.WebClient).DownloadString" nocase
        $encoded  = "-EncodedCommand" nocase

    condition:
        any of them
}
