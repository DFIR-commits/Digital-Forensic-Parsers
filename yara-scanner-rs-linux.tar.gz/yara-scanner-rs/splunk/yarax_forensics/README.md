# YARA-X Forensics (Splunk app)

One dashboard, **YARA-X Detections**, for reviewing what `yarax-scanner` sent to
Splunk: the detected file, the rule that fired, the recorded reason, the file's
timeline, and the exact rule text that ran. Simple XML only - no JavaScript, no
lookups, no scheduled searches. Tested on Splunk Enterprise 10.4.

## Install

1. Package and install:
   ```sh
   cd yara-scanner-rs/splunk
   tar czf yarax_forensics.tgz yarax_forensics
   ```
   Splunk Web: **Apps > Manage Apps > Install app from file**, upload
   `yarax_forensics.tgz`. (Or copy the folder to `$SPLUNK_HOME/etc/apps/` and
   restart.) Install it on the search head.
2. Point it at your index: **Settings > Advanced search > Search macros >
   `yarax_index`**, set the definition to your index, e.g. `index=yarax_test`
   or `(index=yarax_web OR index=yarax_dc)`. Default: `index=yarax`.
3. Rule text needs scans from a scanner build that sends `yarax:rule`
   events (this repository from now on). Older scans still show in every
   panel; only the rule panel says "No matching rule definition was found"
   for them.

The app ships `props.conf` (`KV_MODE = json` for the four `yarax:*`
sourcetypes, exported system-wide). Without it, fields after the first 10 KB of
an event are not extracted - which cuts off long rule texts.

## Using it

Work top to bottom:

1. **Detections** - one row per detection event, newest first. *Rows:
   Latest per host + file + rule* collapses repeat scans of the same file.
2. **Click a row** - the *Evidence*, *Why it matched* and *File timeline*
   panels open for that detection. Click the SHA-256, Target host or Scan ID
   line in Evidence to filter the whole dashboard to it.
3. **Click the rule name** - the *Rule* panels open with the rule that
   produced this detection: same scan, same namespace, same name. Every line
   of its source is listed in a monospaced table (paged for long rules), with
   its metadata, file, SHA-256s and any other rules of the same name.
   Clicking the metadata table filters the dashboard to that rule.
4. **TA window** - type start and end in UTC (`2026-09-01 00:00:00`). File
   timestamps inside it are highlighted; *Limit to file timestamps in TA
   window* filters on created, modified or any.
5. **Statistics** - every chart and table filters the dashboard when clicked.
6. **Rule repository** - every distinct rule version (name + namespace + exact
   text) loaded by scans in the time range; search by name, namespace or file,
   metadata, or content. Click a row to show its text.

Filters take `*` wildcards. *File path* and *Rule namespace* accept `\` or
`/` and match case-insensitively. Set them back to `*` to clear.

## What the numbers mean

| Shown | Counted as |
|---|---|
| Detection events | every rule match in every scan; rescanning a file adds events |
| Unique detected files | distinct SHA-256; files without a hash (large stream-scanned archive members) count by host + path |
| File locations | distinct host + path |
| Rules that matched | distinct name + namespace (same-named rules from different files stay separate) |

Severity and confidence come only from the rule's own metadata
(`severity`, `confidence`). Nothing is classified by frequency.

## Limitations

- **Base search size.** Panels share one non-transforming base search, which
  Splunk caps at 500,000 events. Narrow the time range or filters beyond that.
- **Matched strings.** Each detection event carries the first 20 string
  matches (`yara_match_strings_truncated` says when more exist) and 128 bytes
  per match. The scanner's JSON report has all of them.
- **No matching condition.** YARA-X reports which strings matched, not which
  part of the condition was true. The dashboard shows the recorded reason and
  matches, and the rule text separately - it does not infer the condition.
- **Rule text availability.** Pre-compiled `.yarc` rules have no source. If
  the rule file changed between compiling and sending, the text is withheld
  rather than possibly wrong (`yara_rule_text_status` says which).
- **Timestamps.** File times are what the evidence file system recorded
  (copying, extraction and timestomping change them). Creation time is empty
  where the OS or file system does not provide it, metadata-change time is
  empty on Windows, and archive members have no file times. Comparison
  against the TA window uses whole seconds.
- **Local time column** uses your Splunk user time-zone preference; all other
  columns are UTC as recorded by the scanner.
