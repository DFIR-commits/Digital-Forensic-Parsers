# YARA-X Forensics (Splunk app)

One dashboard, **YARA-X Detections**, for reviewing what `yarax-scanner` sent to
Splunk: the detected file, the rule that fired, the recorded reason, the file's
timeline, and the exact rule text that ran. Simple XML only - no JavaScript, no
lookups, no scheduled searches. Tested on Splunk Enterprise 10.4.

## Install

**Paste only (no app, no restart):** in Splunk Web, **Dashboards > Create New
Dashboard** (Classic, Simple XML), open **Source**, replace everything with
`default/data/ui/views/yarax_detections.xml` and save. To update, paste the
new file over the old source the same way. Set the **Splunk index** box at the
top to the index your scanner sends to (default `yarax`).

**As an app (optional):** adds `props.conf` so fields past the first 10 KB of
an event are extracted - only long rule texts need that. Installing it usually
asks for a Splunk restart, so do it in a quiet window.
```sh
cd yara-scanner-rs/splunk
tar czf yarax_forensics.tgz yarax_forensics
```
Splunk Web: **Apps > Manage Apps > Install app from file**, upload
`yarax_forensics.tgz` on the search head.

Either way: rule text needs scans from a scanner build that sends
`yarax:rule` events, and every matched string needs a build that sends
`yarax:match_string` events. Older scans still show in every panel, with
the rule panel saying "No matching rule definition was found" and only the
first 20 matched strings.

## Using it

Work top to bottom:

1. **Detected files** - one row per host + file: the rules that matched it,
   path, SHA-256 and file system timestamps. Repeat scans of the same file
   and rule collapse to the latest detection.
2. **Click a row** - the *Evidence* panel (every recorded file field) and
   *Rules that matched this file* (reason, identifiers, matched strings) open.
   Click the SHA-256, Target host or Scan ID line in Evidence to filter the
   whole dashboard to it.
3. **Click a rule** - the *Rule* panels open with the rule that produced
   that detection: same scan, same namespace, same name. Every line of its
   source is listed in a monospaced table (paged for long rules), with its
   metadata, file, SHA-256s and any other rules of the same name. Clicking the
   metadata table filters the dashboard to that rule.
4. **Statistics** - every chart and table filters the dashboard when clicked.
5. **Rule repository** - every distinct rule version (name + namespace + exact
   text) loaded by scans in the time range; search by name, namespace or file,
   metadata, or content. Click a row to show its text.

Filters take `*` wildcards. *File path* and *Rule namespace* accept `\` or
`/` and match case-insensitively. Set them back to `*` to clear.

## What the numbers mean

| Shown | Counted as |
|---|---|
| Detection events | every rule match in every scan; rescanning a file adds events |
| Unique detected files | distinct SHA-256; files without a hash (large stream-scanned archive members) count by host + path |
| File locations | distinct host + path |
| Rules that matched | distinct name + namespace (same-named rules from different files stay separate) |

Severity and confidence come only from the rule's own metadata
(`severity`, `confidence`). Nothing is classified by frequency.

## Limitations

- **Base search size.** Panels share one non-transforming base search, which
  Splunk caps at 500,000 events. Narrow the time range or filters beyond that.
- **Matched strings.** Every string match is sent as its own
  `yarax:match_string` event, up to 1,000 per detection, with 128 bytes per
  match; the matched strings table pages through them 20 at a time. The
  "String matches" column says when a detection reached the 1,000 cap. Scans
  from scanner builds before these events show only the first 20 matches
  stored in the detection itself. The scanner's JSON report has all of them.
- **No matching condition.** YARA-X reports which strings matched, not which
  part of the condition was true. The dashboard shows the recorded reason and
  matches, and the rule text separately - it does not infer the condition.
- **Rule text availability.** Pre-compiled `.yarc` rules have no source. If
  the rule file changed between compiling and sending, the text is withheld
  rather than possibly wrong (`yara_rule_text_status` says which).
- **Timestamps.** File times are what the evidence file system recorded
  (copying, extraction and timestomping change them). Creation time is empty
  where the OS or file system does not provide it, metadata-change time is
  empty on Windows, and archive members have no file times.
