# yarax-scanner (Rust + YARA-X)

Ultra high performance YARA scanning engine for digital forensics and
malware hunting. Native Rust throughout, built on
[YARA-X](https://virustotal.github.io/yara-x/) — VirusTotal's official Rust
rewrite of YARA — so there is **no FFI boundary, no GC, no interpreter**
anywhere in the hot path.

```
walker (1 thread) ──bounded queue──▶ N workers ──channel──▶ streaming JSON writer
                                        │
                                  ArchiveCtx: recursive zip/tar/gz/bz2/xz
                                  (streaming, no temp files, bomb-guarded)
```

## Build

Requires stable Rust (1.75+ recommended): https://rustup.rs

```bash
cargo build --release              # binary at target/release/yarax-scanner
cargo build --release --features sevenz,rar   # + 7z and RAR support
cargo test                         # e2e tests with real YARA-X + archives
```

> **Note:** this project was authored without a compiler available in the
> authoring environment. The YARA-X, zip, and unrar crates evolve; if a
> version bump changed a signature, `cargo build` messages will point at
> the (small) fixes needed — they are localized to `src/engine.rs` and
> `src/archives/formats.rs`.

## Usage

```bash
yarax-scanner /evidence rules.yar --output report.json
yarax-scanner --path /mnt/image --rules rules/ --threads 64 \
    --extensions log,txt,json --exclude '**/node_modules/**' \
    --max-file-size 2G --skip-large-files --output hits.json

# compiled rules load instantly on repeated runs
yr compile rules/ -o rules.yarc          # (yara-x CLI)
yarax-scanner /evidence rules.yarc --output report.json
```

Key options: `--threads` (default: all cores), `--recursive true|false`,
`--follow-links`, `--include/--exclude` (globs, repeatable),
`--extensions`, `--max-file-size 500M`, `--skip-large-files`, `--hash-all`,
`--timeout`, `--external KEY=VALUE`, `--quiet`, `--verbose`.

Archive options: `--scan-archives true|false`, `--max-archive-depth 3`,
`--max-member-size 512M`, `--max-archive-output 8G`,
`--max-compression-ratio 1000`.

## Archive semantics

Hits inside archives use `::` virtual paths and carry provenance fields:

```json
{
  "rule": "Webshell_Generic",
  "file": "/evidence/server_logs.zip::apache/access.log",
  "archive": "/evidence/server_logs.zip",
  "internal_path": "apache/access.log",
  "full_path": "/evidence/server_logs.zip::apache/access.log"
}
```

Nested archives recurse to `--max-archive-depth`
(`backup.zip::logs.tar.gz::app.log`). Everything is streamed — no temp
files, no full extraction. `.gz/.bz2/.xz` are treated as one-member
archives, so `access.log.gz` scans as `access.log.gz::access.log`.

## Why it's fast

| Optimization | Where |
|---|---|
| YARA-X native — matcher LTO-inlined into the binary, match data returned as borrowed slices (zero-copy), no FFI/marshaling | `engine.rs` |
| Rules compiled/deserialized once, shared by `&Rules`; one lightweight `Scanner` per worker → zero lock contention while matching | `engine.rs`, `worker.rs` |
| mmap + `madvise(Sequential)` for >1 MiB files: the kernel streams pages, YARA scans the mapping in place | `worker.rs` |
| ≤1 MiB files: single `read_to_end` into a per-worker reused buffer — zero steady-state allocations on the miss path | `worker.rs` |
| Hash (SHA256+MD5 single pass) **only on match**, reusing the scan buffer/mmap → matched file read exactly once end-to-end | `hashing.rs` |
| Metadata/entropy/magic computed only on hits | `metadata.rs` |
| Lock-free `AtomicU64` stats (relaxed ordering) | `stats.rs` |
| Bounded crossbeam MPMC queue: walker backpressure keeps RSS flat on 20M-file trees | `lib.rs`, `walker.rs` |
| Walker uses `d_type` (free) to skip non-files; one stat per candidate, reused by workers | `walker.rs` |
| Compiled `globset` include/exclude (no per-file regex/fnmatch cost) | `config.rs` |
| Streaming archive members; one reusable member buffer per worker; huge members overlap-window scanned in constant memory | `archives/` |
| zlib-ng backend for gzip (~2× inflate speed) | `Cargo.toml` |
| Streaming JSON writer on its own thread; workers never serialize | `writer.rs` |
| `lto = "fat"`, `codegen-units = 1` release profile | `Cargo.toml` |

## Design notes & trade-offs

- **Huge archive members** (over `--max-member-size` or unknown size) are
  scanned in overlapping 4 MiB windows: constant memory, but matches longer
  than 64 KiB spanning a window boundary can be missed, and such members
  are **not hashed** (hashing would require a second decompression pass).
- **Encrypted zip members** are skipped individually and logged; siblings
  still scan.
- **Corrupt archives** are contained: logged, counted in `errors`, raw
  bytes were already magic-checked.
- At `--max-archive-depth`, a nested archive's raw (compressed) bytes are
  still scanned rather than skipped.
- Nested TAR/single-stream archives buffered from memory incur one extra
  copy (`Cursor<Vec<u8>>`); nested ZIPs use the buffer directly.
- mmap assumes evidence is not truncated mid-scan (standard for read-only
  forensic mounts).
- RAR support (feature `rar`) links the proprietary unrar C++ library and
  only supports on-disk archives; nested RARs are chunk-scanned raw.

## Extending: new archive formats

Implement `ArchiveFormat` (`src/archives/mod.rs`) and add it to
`builtin_formats()` (`src/archives/formats.rs`):

```rust
impl ArchiveFormat for IsoFormat {
    fn format_name(&self) -> &'static str { "iso" }
    fn claims_name(&self, name: &str) -> bool { name.ends_with(".iso") }
    fn claims_magic(&self, h: &[u8]) -> bool { /* CD001 */ }
    fn scan(&self, input: ArchiveInput, chain: &str, ctx: &mut ArchiveCtx)
            -> anyhow::Result<()> {
        // for each member: ctx.scan_member(&vchain, name, size, &mut reader)
        Ok(())
    }
}
```

Depth limits, bomb budgets, virtual paths, hashing and hit emission are all
handled by `scan_member` — a format impl only enumerates members.

## Report schema

Same schema as the Python reference implementation (`schema_version 1.0`):
`hits[]` with rule/namespace/tags/metadata/matched_strings/offsets/
sha256/md5/timestamps/entropy/magic/scan_time_ms + archive provenance, and
`scan_information` with totals, rates and latency stats. The report is
written incrementally — a crash mid-scan leaves all hits so far on disk.

## Desktop GUI (`yarax-gui`)

A point-and-click front end for analysts. It is a thin shell: it launches
`yarax-scanner` as a child process with a structured argument list (no shell
string, so paths with spaces are safe), reads its progress lines, and can kill
it to cancel. The scan engine is unchanged.

```bash
cargo build --release --features gui     # builds yarax-scanner AND yarax-gui
target/release/yarax-gui                  # (yarax-gui.exe on Windows)
```

`yarax-gui` looks for `yarax-scanner` in the **same folder**, so keep the two
executables together. The GUI is opt-in (`--features gui`), so the CLI and the
Docker/worker build carry no GUI dependencies.

Workflow:

1. **Rule sources** - *Add rule folder…* / *Add rule file…* as many times as
   you like (folders are searched recursively). Each entry shows ✔ with its
   rule-file count or ✖ with the reason (missing, empty, unreadable). All valid
   sources are compiled together in one scan; the same file reached via two
   sources is compiled once.
2. **What to scan** - a directory, a mounted drive/volume (drive letters on
   Windows, mount points on Linux, or browse to a mount point), or a single
   file. Optional: scan inside archives, skip files larger than N MB.
3. **Report** - choose a folder and optionally a file name (blank =
   `yarax-report-<date-time>.json`). An existing file is never overwritten
   unless *Overwrite* is ticked. The folder is test-written before the scan.
4. **Start scan** - the window stays responsive; it shows a spinner (the total
   file count is unknown up front, so there is no fake percentage), elapsed
   time, and live files / data / matches / unreadable counts, plus the
   scanner log. **Cancel scan** stops it; the report is then incomplete.
5. When it finishes you get a summary read from the report and a *Show in
   folder* button. Exit code 1 ("some files could not be read") is reported as
   a warning, not a failure; exit code 2 shows the scanner's error in the log.

Access denied on a volume is reported as such; run the GUI as Administrator if
the evidence requires it. The GUI never elevates itself.

### Multiple rule sources on the command line

`--rules` is repeatable (the positional `scanner PATH RULES` form still works
with one source):

```bash
yarax-scanner --path /mnt/image --rules rules/vendor-a --rules "rules/my bundle" \
    --output hits.json
```

With several sources each file gets its own namespace prefixed by the source
position (`src0:`, `src1:`, …), so same-named files or rule names in different
bundles don't collide. A pre-compiled `.yarc` cannot be merged with other
sources - use it alone.

### Machine-readable progress

When stderr is not a terminal and `--quiet` is not set, the scanner prints
`PROGRESS files=N bytes=N hits=N errors=N` every 2 seconds. The GUI and the
forensic-platform worker both consume this.

### Tests

`cargo test` runs the unit tests for the GUI logic (`src/gui_core.rs`:
validation, argument building, progress parsing, report summary) and the e2e
tests, including multiple rule sources, paths with spaces, and an
empty/invalid rule source. The window itself is not covered by automated
tests; smoke-test it by launching it and running a scan on a small folder.

### Try it

`examples/` has two small rules and two sample files. In the GUI add `examplesules` as a rule folder, scan `examples\samples`, and expect exactly one hit (`malicious_sample.txt`).

### Building on a new machine

Run `build-gui.ps1` (see the top of that file). It installs missing prerequisites with winget and puts both executables in `dist\`.

### Checking rules before a big scan

YARA-X is stricter than classic YARA, so rules that compiled with `yara` can
still be rejected. Check them first - this compiles every rule file on its own
and reports **all** failures at once (file, line, column and the compiler's
explanation), instead of the scan stopping at the first bad file:

```bash
yarax-scanner --check-rules --rules path/to/rules      # repeat --rules for several bundles
```

Exit code 0 = everything compiles, 1 = at least one file failed, 2 = bad usage
or an unreadable rule folder. Compiler warnings (for example `slow_pattern`)
are listed too but do not fail the check. In the GUI, use **Check rules** under
the rule sources.

A normal scan aborts on a bad rule file *before* it reads any evidence, and
names the file. To scan anyway with the files that do compile, pass
`--skip-invalid-rules` (GUI: the checkbox under the rule list). It is opt-in
because it reduces detection coverage: each skipped file is printed as a
WARNING with its errors, and again in a summary line, so it is never silent.

## Linux

```bash
tar xzf yara-scanner-rs-linux.tar.gz && cd yara-scanner-rs
./build-linux.sh --gui          # CLI + GUI;  ./build-linux.sh = CLI only
./dist/yarax-gui                # needs a desktop session (X11 or Wayland)
```

`build-linux.sh` installs a C compiler, CMake, pkg-config and Rust (rustup) when
missing, using apt, dnf or pacman (it uses `sudo` unless you are root). `--gui`
also installs GTK3 development files, which the file-picker dialogs need. The
release build is slow and memory-hungry; `--fast` gives a quick dev build.

Command-line scan of mounted evidence (run as root or a user who can read the
mounts - FUSE mounts such as ntfs-3g are often owner-only):

```bash
sudo ./dist/yarax-scanner --path /mnt/evidence --rules /path/to/rules --output report.json
```

If your mount tool leaves the whole raw image inside the mount tree (for example
a `.ewf_fuse/ewf1` file), add `--exclude '**/.ewf_fuse/**'` so it is not scanned
as one giant file. Keep `yarax-gui` and `yarax-scanner` in the same folder.
