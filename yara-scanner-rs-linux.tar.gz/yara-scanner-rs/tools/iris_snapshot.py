#!/usr/bin/env python3
"""Save DFIR-IRIS cases and their IOCs to one JSON file for yarax-scanner.

For when the scanning machine can't reach IRIS: run this on a machine that
can, write the file somewhere both can see, then give its path to
yarax-scanner as the IRIS URL (GUI field or --iris-url). Pick cases and
IOCs there as usual. Rerun to refresh. Standard library only; read-only.

  python3 iris_snapshot.py https://iris.example --insecure --out /Volumes/share/iris-snapshot.json
  (API key: --key, or YARAX_IRIS_API_KEY / IRIS_API_KEY in the environment)
"""
import argparse, datetime, json, os, ssl, sys, urllib.error, urllib.request

FORMAT = "yarax-iris-snapshot/1"  # must match SNAPSHOT_FORMAT in src/iris.rs


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("url", help="IRIS URL, e.g. https://iris.example")
    ap.add_argument("--out", required=True, help="snapshot file to write")
    ap.add_argument("--key", default=os.environ.get("YARAX_IRIS_API_KEY") or os.environ.get("IRIS_API_KEY"))
    ap.add_argument("--insecure", action="store_true", help="don't verify the certificate (IRIS ships a self-signed one)")
    ap.add_argument("--case", type=int, action="append", help="only this case id (repeatable; default: all)")
    a = ap.parse_args()
    if not a.key:
        sys.exit("need --key or YARAX_IRIS_API_KEY")

    base = a.url.strip().rstrip("/")
    ctx = ssl.create_default_context()
    if a.insecure:
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx))

    def get(path):
        req = urllib.request.Request(base + path, headers={"Authorization": f"Bearer {a.key}"})
        try:
            with opener.open(req, timeout=60) as r:
                v = json.load(r)
        except urllib.error.HTTPError as e:
            sys.exit(f"{path}: HTTP {e.code}" + (" (API key rejected or lacks permission)" if e.code in (401, 403) else ""))
        except (urllib.error.URLError, OSError) as e:
            sys.exit(f"cannot reach IRIS at {base}: {e}")
        except ValueError:
            sys.exit(f"{path}: not JSON - is {base} the IRIS URL?")
        if v.get("status") != "success":
            sys.exit(f"{path}: IRIS error: {v.get('message')}")
        return v["data"]

    cases, page = [], 1
    while page:
        d = get(f"/manage/cases/filter?per_page=100&page={page}")
        cases += d["cases"]
        page = d.get("next_page")
    if a.case:
        missing = set(a.case) - {c["case_id"] for c in cases}
        if missing:
            sys.exit(f"case(s) not found or not visible to this key: {sorted(missing)}")
        cases = [c for c in cases if c["case_id"] in a.case]

    iocs = {}
    for c in cases:
        iocs[str(c["case_id"])] = get(f"/case/ioc/list?cid={c['case_id']}")
        print(f"  #{c['case_id']:<5} {len(iocs[str(c['case_id'])].get('ioc', [])):>4} IOCs  {c['name']}")

    snap = {"format": FORMAT, "iris_url": base,
            "fetched_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
            "cases": cases, "iocs": iocs}
    tmp = a.out + ".tmp"  # write then rename: a reader never sees half a file
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(snap, f)
    os.replace(tmp, a.out)
    print(f"{len(cases)} case(s) -> {a.out}")


if __name__ == "__main__":
    main()
