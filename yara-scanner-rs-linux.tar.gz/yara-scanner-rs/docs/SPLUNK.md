# Splunk telemetry

Every scan writes a forensic event stream next to its report, and can send
it to a Splunk HTTP Event Collector (HEC).

```
report.json                     the JSON report (unchanged format, schema 1.1)
report.unreadable.tsv           unreadable items, for the GUI (unchanged)
report.events.ndjson            one JSON event per line - the source of truth for Splunk
report.events.delivery.json     HEC delivery state (only when Splunk is used)
```

## Quick start

GUI: fill in **Evidence host name**, tick **Send results to Splunk** (section 4),
enter the HEC URL, token and index, press **Test connection**, then scan.

CLI:

```sh
export YARAX_SPLUNK_TOKEN=<hec-token>          # Windows: set YARAX_SPLUNK_TOKEN=<hec-token>
yarax-scanner --path /mnt/IOC_SCAN/WEB01 --rules rules/ --output web01.json \
  --target-host WEB01 --splunk-url https://splunk:8088 --splunk-index yarax_test

yarax-scanner --splunk-test --splunk-url https://splunk:8088 --splunk-index yarax_test
yarax-scanner --splunk-send web01.events.ndjson --splunk-url https://splunk:8088 --splunk-index yarax_test
```

| Flag | Meaning |
|---|---|
| `--target-host NAME` | Host the evidence came from. Becomes the Splunk `host`. Omitted = `unknown`. |
| `--splunk-url URL` | HEC base URL (`/services/collector/event` is appended). Needs `--output`. |
| `--splunk-index IDX` | Target index. Omitted = the token's default index. |
| `--splunk-insecure` | Skip TLS certificate verification. Self-signed test servers only. |
| `--splunk-send FILE` | No scan: send / resume sending an existing `.events.ndjson`. |
| `--splunk-test` | No scan: health check + one `connection_test` event. |
| `--max-match-data N` | Matched bytes kept per string (default 128). |

The token is read **only** from `YARAX_SPLUNK_TOKEN`. It is never accepted as an
argument (arguments are visible to every local user), never written to a report,
state file or log, and the GUI keeps it in memory only.

## Delivery

* Events are written to `.events.ndjson` **during** the scan, flushed per line.
  A crash or cancel keeps everything recorded so far. That file is the durable
  spool: Splunk delivery reads it after the scan, and it is never deleted.
* Batches of up to 500 events (~800 KB) are POSTed to `/services/collector/event`
  as concatenated HEC envelopes.
* Each batch is tried up to 4 times with exponential backoff (1 s, 2 s, 4 s) when
  the failure is transient: connection errors, HTTP 429, 5xx, HEC code 9 (busy).
  Token errors (401/403, HEC codes 1-4), a wrong index (code 7) and rejected
  payloads (400) stop immediately - retrying cannot fix them.
* After every accepted batch the resume point is saved to `.events.delivery.json`.
  `--splunk-send` (or **Retry sending** in the GUI) continues from there, so
  events HEC accepted are never sent twice. A new scan with the same report
  name deletes the old state, and state is only reused when its `scan_id`
  matches the spool's.
* A scan that was cancelled or crashed has no summary line. Delivery appends one
  with `scan_status = "interrupted"` (to the file first, then to Splunk), so an
  incomplete scan is never mistaken for a clean one.
* A scan whose rules do not compile still produces events (`rule_compilation_failed`
  + a `failed` summary) and sends them.
* HTTP 200 means HEC accepted the batch. Without indexer acknowledgement enabled
  on the token it does not prove the events were indexed.
* TLS uses the operating system's trust store, so an internal CA installed on the
  scanning machine is trusted. No OpenSSL is needed.

`.events.delivery.json`:

```json
{
  "scan_id": "673e4dc5-5e3e-47ac-aca9-f8161db1e0bb", // state is only reused for this scan's spool
  "delivery_status": "delivered",          // delivered | partial | failed | nothing_to_send
  "events_total": 3, "events_sent": 3,     // events_sent is the resume point
  "delivery_attempt_count": 1,
  "last_http_status": 200,
  "error_type": null, "error_message": null, "retryable": null,
  "index": "yarax_test", "hec_endpoint": "https://splunk:8088/services/collector/event",
  "updated": "2026-10-14T19:40:02.118Z", "synthesized_summary": false
}
```

### HEC payload

Routing metadata is in the envelope; the forensic record is the `event` object:
the NDJSON line with one change - its `host` field moves to the envelope.
Splunk indexes the envelope host, and a second `host` inside the JSON would
make `host` multivalued at search time, doubling every `stats … by host`
(observed on a real Splunk before this was fixed).

```json
{"time": 1791979200.25, "host": "WEB01", "source": "yarax-scanner",
 "sourcetype": "yarax:detection", "index": "yarax_test", "event": { ...event without host... }}
```

| Envelope | Value |
|---|---|
| `time` | `event_created` as Unix epoch seconds, millisecond precision |
| `host` | target host (`--target-host`), else `unknown`. Never a path, hash or the scanner's name. |
| `source` | `yarax-scanner` |
| `sourcetype` | `yarax:detection` (matches), `yarax:unreadable` (items that could not be read or scanned), `yarax:scan` (summary, rule errors, connection tests) |
| `index` | `--splunk-index`; omitted when not set |

### Recommended Splunk configuration

`props.conf` on the search head:

```ini
[yarax:detection]
KV_MODE = json

[yarax:unreadable]
KV_MODE = json

[yarax:scan]
KV_MODE = json
```

Nothing needs to be indexed at ingest: every field is extracted at search time
from the raw JSON, which HEC stores unchanged in `_raw`. Without any props,
Splunk's automatic extraction already works, but it reads only the first 10240
characters of an event (`limits.conf [kv] maxchars`); `KV_MODE = json` extracts
the whole event. As a second line of defence, the variable-size fields
(`yara_rule_meta`, `yara_match_strings`) come last in every event and matched
strings are capped at 20 per event, so the searchable fields are extracted
either way. (Verified on Splunk Enterprise in a container: a 12 KB event was
stored complete; its late fields were extracted only with `KV_MODE = json`.)

**Restrict the token to its index.** A HEC token allowed to write to *any*
index returns HTTP 200 for an index that does not exist, and Splunk then
drops the events. Set the token's *Allowed Indexes* to the target index: a
typo is then rejected (`Incorrect index`, HEC code 7), which the scanner
reports as `hec_incorrect_index` and does not retry. **Test connection** /
`--splunk-test` cannot detect a missing index on an unrestricted token; check
with `index=<name> event_type=connection_test`.

## Event types

| `event_type` | `event_category` / `event_action` | sourcetype | When |
|---|---|---|---|
| `yara_match` | `malware` / `match` | `yarax:detection` | one per rule per file |
| `scan_error` | `file` / `error` | `yarax:unreadable` | an item could not be read or fully scanned |
| `scan_error` | `configuration` / `error` | `yarax:scan` | a rule file was skipped, or rules did not compile |
| `scan_summary` | `file` / `complete` | `yarax:scan` | last event of every scan |

`scan_status` on the summary:

| Value | Meaning | `event_outcome` |
|---|---|---|
| `completed` | everything was scanned | success |
| `completed_with_errors` | finished; some items were unreadable - see `yarax:unreadable` | success |
| `failed` | the scan did not run (`scan_error` says why) | failure |
| `interrupted` | cancelled or crashed; added at delivery time | failure |

A scan with no detections is a `completed` summary with `scan_matches = 0` and no
`yara_match` events. It is never the same as a missing scan.

**A YARA match is a fact about content, not a verdict.** `detection_status =
"match"` records that a rule fired. Severity, confidence, malware family and
threat category are copied from rule metadata when the rule defines them, and are
`null` otherwise - the scanner never invents them.

## Examples

Real output, unedited: `examples/samples` plus a truncated `broken.zip`, copied to
`C:\cases\WEB01\evidence` and scanned with `--target-host WEB01` on Windows. This
is the NDJSON content (in Splunk, `host` is in the envelope instead). On Linux,
`file_metadata_changed_time`, `file_filesystem`, `file_device_path` and a mount
point in `file_volume` are filled in as well.

Detection (`yarax:detection`):

```json
{
  "schema_version": "1.0",
  "event_id": "4d98390f-4024-42bf-b8a5-246ecbbcde65",
  "event_type": "yara_match",
  "event_category": "malware",
  "event_action": "match",
  "event_outcome": "success",
  "event_created": "2026-10-14T19:27:15.549017900Z",
  "event_ingested": null,
  "host": "WEB01",
  "host_name": "WEB01",
  "host_identity_source": "analyst_supplied",
  "host_fqdn": null,
  "host_domain": null,
  "host_id": null,
  "host_os": null,
  "host_os_version": null,
  "host_architecture": null,
  "scanner_host_name": "Tones",
  "scanner_host_id": "1a51fb70-583d-4361-a510-10cc39149b2f",
  "scanner_name": "yarax-scanner",
  "scanner_version": "1.0.0",
  "scanner_engine": "yara-x",
  "scanner_engine_version": "1.19.0",
  "scan_id": "673e4dc5-5e3e-47ac-aca9-f8161db1e0bb",
  "scan_started": "2026-10-14T19:27:15.494256Z",
  "scan_target": "C:\\cases\\WEB01\\evidence",
  "scan_target_type": "directory",
  "file_name": "malicious_sample.txt",
  "file_path": "C:\\cases\\WEB01\\evidence\\malicious_sample.txt",
  "file_path_normalized": "c:/cases/web01/evidence/malicious_sample.txt",
  "file_original_path": null,
  "file_relative_path": "malicious_sample.txt",
  "file_directory": "C:\\cases\\WEB01\\evidence",
  "file_extension": "txt",
  "file_volume": "C:",
  "file_filesystem": null,
  "file_device_path": null,
  "file_access_method": "local_filesystem",
  "file_archive_path": null,
  "file_archive_member_path": null,
  "file_size_bytes": 306,
  "file_type": null,
  "file_mime_type": null,
  "file_attributes": [
    "archive"
  ],
  "file_is_hidden": false,
  "file_is_readonly": false,
  "file_is_executable": false,
  "file_is_archive": false,
  "file_entropy": 4.4524,
  "file_created_time": "2026-10-14T19:27:14.230698500Z",
  "file_birth_time": null,
  "file_modified_time": "2026-10-14T19:27:14.230698500Z",
  "file_modified_time_before_scan": "2026-10-14T19:27:14.230698500Z",
  "file_modified_time_after_scan": "2026-10-14T19:27:14.230698500Z",
  "file_accessed_time": "2026-10-14T19:27:15.543884500Z",
  "file_metadata_changed_time": null,
  "file_changed_during_scan": false,
  "file_timestamp_status": "partial",
  "file_timestamp_source": "windows:GetFileInformationByHandle",
  "file_timestamp_precision": "100ns",
  "file_hash_sha256": "8cea5ae5b48dfc84d9a4bfddeafb3497390fe650d35a32bf4503d2ef4cc33085",
  "file_hash_md5": "ee6a13abb98c6dbb80f61fa9c2f6b1f2",
  "file_hash_sha1": null,
  "file_hash_algorithm": "sha256",
  "file_hash_status": "computed",
  "file_hash_scope": "full_file",
  "file_hash_reason": null,
  "file_hash_calculated_time": "2026-10-14T19:27:15.549017900Z",
  "yara_rule_name": "ascii_marker",
  "yara_rule_namespace": "ascii_marker.yar",
  "yara_rule_source": "ascii_marker.yar",
  "yara_rule_source_path": "C:\\cases\\rules\\ascii_marker.yar",
  "yara_rule_source_kind": "source",
  "yara_rule_hash_sha256": "37016382d4566ecc4151e29502ed42cea961c57fffdff78b3958a2212707775d",
  "yara_rule_tags": [],
  "yara_rule_description": "Matches files containing the ASCII string EVIL_MARKER_1337",
  "yara_rule_author": "yara-scanner example",
  "yara_rule_reference": null,
  "yara_rule_version": null,
  "yara_ruleset_name": "C:\\cases\\rules",
  "yara_ruleset_version": "9efb932c9fcda19d680b3c6e4d3b688a4d3be79d977f047d4dc134279cada4c8",
  "yara_engine_version": "1.19.0",
  "yara_match_count": 1,
  "yara_match_strings_total": 1,
  "yara_match_strings_truncated": false,
  "detection_status": "match",
  "detection_type": "yara_rule_match",
  "detection_name": "ascii_marker.yar:ascii_marker",
  "detection_severity": null,
  "detection_confidence": null,
  "detection_reason": "YARA rule ascii_marker matched 1 string occurrence(s): $marker",
  "detection_tags": [],
  "malware_family": null,
  "threat_category": null,
  "scan_time_ms": 0.374,
  "yara_rule_meta": {
    "description": "Matches files containing the ASCII string EVIL_MARKER_1337",
    "author": "yara-scanner example"
  },
  "yara_match_strings": [
    {
      "identifier": "$marker",
      "offset": 109,
      "length": 16,
      "data": "EVIL_MARKER_1337"
    }
  ]
}
```

Unreadable item (`yarax:unreadable`):

```json
{
  "schema_version": "1.0",
  "event_id": "e4ed368b-4c06-4785-8e04-4f6806b7af20",
  "event_type": "scan_error",
  "event_category": "file",
  "event_action": "error",
  "event_outcome": "failure",
  "event_created": "2026-10-14T19:27:15.549816Z",
  "event_ingested": null,
  "host": "WEB01",
  "host_name": "WEB01",
  "host_identity_source": "analyst_supplied",
  "host_fqdn": null,
  "host_domain": null,
  "host_id": null,
  "host_os": null,
  "host_os_version": null,
  "host_architecture": null,
  "scanner_host_name": "Tones",
  "scanner_host_id": "1a51fb70-583d-4361-a510-10cc39149b2f",
  "scanner_name": "yarax-scanner",
  "scanner_version": "1.0.0",
  "scanner_engine": "yara-x",
  "scanner_engine_version": "1.19.0",
  "scan_id": "673e4dc5-5e3e-47ac-aca9-f8161db1e0bb",
  "scan_started": "2026-10-14T19:27:15.494256Z",
  "scan_target": "C:\\cases\\WEB01\\evidence",
  "scan_target_type": "directory",
  "file_name": "broken.zip",
  "file_path": "C:\\cases\\WEB01\\evidence\\broken.zip",
  "file_path_normalized": "c:/cases/web01/evidence/broken.zip",
  "file_original_path": null,
  "file_relative_path": "broken.zip",
  "file_directory": "C:\\cases\\WEB01\\evidence",
  "file_extension": "zip",
  "file_volume": "C:",
  "file_filesystem": null,
  "file_device_path": null,
  "file_access_method": "local_filesystem",
  "file_archive_path": null,
  "file_archive_member_path": null,
  "error_type": "archive_unreadable",
  "error_code": null,
  "error_message": "open zip: invalid Zip archive: Could not find EOCD",
  "error_stage": "archive",
  "error_timestamp": "2026-10-14T19:27:15.549816Z",
  "retryable": false,
  "detection_status": "not_scanned",
  "scan_coverage_impact": "item not scanned"
}
```

Scan summary (`yarax:scan`):

```json
{
  "schema_version": "1.0",
  "event_id": "6aa62518-be66-4414-8174-6112f29c82e1",
  "event_type": "scan_summary",
  "event_category": "file",
  "event_action": "complete",
  "event_outcome": "success",
  "event_created": "2026-10-14T19:27:15.550529200Z",
  "event_ingested": null,
  "host": "WEB01",
  "host_name": "WEB01",
  "host_identity_source": "analyst_supplied",
  "host_fqdn": null,
  "host_domain": null,
  "host_id": null,
  "host_os": null,
  "host_os_version": null,
  "host_architecture": null,
  "scanner_host_name": "Tones",
  "scanner_host_id": "1a51fb70-583d-4361-a510-10cc39149b2f",
  "scanner_name": "yarax-scanner",
  "scanner_version": "1.0.0",
  "scanner_engine": "yara-x",
  "scanner_engine_version": "1.19.0",
  "scan_id": "673e4dc5-5e3e-47ac-aca9-f8161db1e0bb",
  "scan_started": "2026-10-14T19:27:15.494256Z",
  "scan_target": "C:\\cases\\WEB01\\evidence",
  "scan_target_type": "directory",
  "scan_status": "completed_with_errors",
  "scan_completed": "2026-10-14T19:27:15.550409300Z",
  "scan_duration_ms": 56,
  "scan_mode": "full",
  "scan_files_examined": 2,
  "scan_bytes_examined": 636,
  "scan_files_matched": 1,
  "scan_matches": 1,
  "scan_files_failed": 1,
  "scan_files_skipped": 0,
  "scan_errors_count": 1,
  "scan_error": null,
  "scan_ruleset_name": "C:\\cases\\rules",
  "scan_ruleset_version": "9efb932c9fcda19d680b3c6e4d3b688a4d3be79d977f047d4dc134279cada4c8",
  "scan_rule_files_loaded": 2,
  "scan_rule_files_skipped": 0,
  "scan_configuration_id": "92cd401972c4c2c87c5eb13b30d6621e1622791d7b2e5ff2a7f0f23e7634e11c",
  "scan_exclusions": [],
  "scan_max_file_size_bytes": null,
  "scan_recursion_enabled": true,
  "scan_follow_symlinks": false
}
```

## Field dictionary

Every field below is always present in its event types. **null** means the value
could not be collected or does not apply; fields are never omitted and never
filled with a substitute value. Types: `string`, `int`, `float`, `bool`,
`time` (ISO 8601 UTC string ending in `Z`), `array`, `object`.

### Common (all events)

| Field | Type | Req | Meaning / source |
|---|---|---|---|
| `schema_version` | string | yes | Event schema version, `1.0`. |
| `event_id` | string | yes | Unique id of this event (UUID). Stored in the spool, so a re-send keeps it: `dedup event_id` is always safe. |
| `event_type` | string | yes | `yara_match`, `scan_error`, `scan_summary` (`connection_test` from `--splunk-test`). |
| `event_category` | string | yes | `malware`, `file` or `configuration`. |
| `event_action` | string | yes | `match`, `error`, `complete`. |
| `event_outcome` | string | yes | `success` or `failure`. |
| `event_created` | time | yes | When the fact was observed (match found, error hit, scan finished). Also the HEC `time`. |
| `event_ingested` | null | yes | Always null in the event. Splunk's `_indextime` is the ingestion time. |
| `host` | string | yes | Target host or `unknown`. In the NDJSON file; in Splunk it is the envelope (indexed) `host`, removed from the event body so it is single-valued. |
| `host_name` | string\|null | yes | Target host name as supplied; null when unknown. |
| `host_identity_source` | string | yes | `analyst_supplied` or `unavailable`. |
| `host_fqdn`, `host_domain`, `host_id`, `host_os`, `host_os_version`, `host_architecture` | null | yes | Not collected yet (the scanner does not read the evidence's registry/config). Always null - never the scanner's values. |
| `scanner_host_name` | string\|null | yes | Machine that ran the scan. |
| `scanner_host_id` | string\|null | yes | Its MachineGuid (Windows) or `/etc/machine-id` (Linux). |
| `scanner_name` | string | yes | `yarax-scanner`. |
| `scanner_version` | string | yes | Scanner version. |
| `scanner_engine` | string | yes | `yara-x`. |
| `scanner_engine_version` | string | yes | yara-x version compiled in (read from Cargo.lock at build time). |
| `scan_id` | string | yes | One id per scan run (UUID), also in the report's `scan_information`. |
| `scan_started` | time | yes | Scan start. |
| `scan_target` | string | yes | Absolute path that was scanned. |
| `scan_target_type` | string | yes | `file` or `directory` (mount points are directories). |

### File (`yara_match` and file `scan_error`)

| Field | Type | Req | Meaning / source |
|---|---|---|---|
| `file_name` | string | yes | Base name, as observed. |
| `file_path` | string | yes | Absolute path as observed by the scanner, original case and separators. Archive members: `<archive>::<member>`. This is the path **on the scanning machine** (e.g. a mount point), not on the original system. |
| `file_path_normalized` | string | yes | `file_path` lower-cased with `/` separators, for case-insensitive searching. |
| `file_original_path` | null | yes | Reserved: path on the original system. Null - the scanner only knows the mount path and does not guess drive letters. |
| `file_relative_path` | string\|null | yes | Path relative to `scan_target`. When the target is a mounted volume's root, this is the path inside that volume. |
| `file_directory` | string\|null | yes | Everything before the last separator of `file_path`. |
| `file_extension` | string\|null | yes | Lower-case extension without the dot. |
| `file_volume` | string\|null | yes | Linux: mount point holding the file. Windows: drive (`C:`). |
| `file_filesystem` | string\|null | yes | Linux: filesystem type from `/proc/mounts` (`ntfs3`, `fuseblk`, `ext4`, …). Null on Windows. |
| `file_device_path` | string\|null | yes | Linux: block device of that mount (`/dev/loop3p2`, `/dev/nbd0p1`, `/dev/mapper/…`). |
| `file_access_method` | string | yes | `local_filesystem`, `mounted_image` (loop / nbd / device-mapper device: how ewfmount, qemu-nbd and kpartx present images), `network_share` (UNC path, cifs/nfs/sshfs), `archive_member`. |
| `file_archive_path` | string\|null | yes | The archive on disk, for members. |
| `file_archive_member_path` | string\|null | yes | Path inside the archive chain (`a.tar.gz::b.zip::c.log` → `b.zip::c.log`). |

### Detection-only file facts (`yara_match`)

| Field | Type | Req | Meaning / source |
|---|---|---|---|
| `file_size_bytes` | int | yes | Bytes scanned (members: decompressed size). |
| `file_type` | string\|null | yes | Type from file content (magic), e.g. `exe`, `zip`. Null when unrecognised. |
| `file_mime_type` | string\|null | yes | MIME type from the same content check. |
| `file_attributes` | array | yes | Windows: attribute names (`readonly`, `hidden`, `system`, `archive`, …). Unix: `["mode:0644"]`. |
| `file_is_hidden` | bool | yes | Windows hidden attribute, or a dot-file name. |
| `file_is_readonly` | bool\|null | yes | Read-only per the filesystem. Null for archive members. |
| `file_is_executable` | bool | yes | Executable format by content (PE/ELF/Mach-O), or a Unix execute bit. |
| `file_is_archive` | bool | yes | Archive by name. |
| `file_entropy` | float | yes | Shannon entropy (bits/byte) of the first 1 MiB. |
| `file_created_time` | time\|null | yes | Birth time: Windows creation time, Linux `statx` btime. Null when the OS/filesystem does not expose it. Never filled with mtime or ctime. |
| `file_birth_time` | null | yes | Not exposed separately from `file_created_time` by any supported API. |
| `file_modified_time` | time\|null | yes | Content modification time, read after the scan. |
| `file_modified_time_before_scan` | time\|null | yes | Modification time seen when the file was queued, before it was read. |
| `file_modified_time_after_scan` | time\|null | yes | Same value as `file_modified_time` (explicit pair with the field above). |
| `file_accessed_time` | time\|null | yes | Last access. **Scanning may update it** on filesystems mounted without `noatime`/read-only - mount evidence read-only. |
| `file_metadata_changed_time` | time\|null | yes | POSIX ctime (inode change). Null on Windows (not exposed by the API used). Never a creation time. |
| `file_changed_during_scan` | bool\|null | yes | Size or mtime differs between queueing and the post-scan check. |
| `file_timestamp_status` | string | yes | `collected` (all four), `partial` (some not available - e.g. ctime on Windows, btime on older Linux filesystems), `failed: <reason>`, `unsupported_archive_member`. |
| `file_timestamp_source` | string\|null | yes | `windows:GetFileInformationByHandle`, `linux:statx`, `posix:stat`; null for members. |
| `file_timestamp_precision` | string\|null | yes | API resolution: `100ns` (Windows FILETIME), `1ns` (Linux). The filesystem may be coarser (FAT 2 s, ext3 1 s); values are printed with only the digits they have. |
| `file_hash_sha256` | string\|null | yes | SHA-256 of the complete file / member. Primary file identifier. |
| `file_hash_md5` | string\|null | yes | MD5 of the same bytes (legacy indicator matching). |
| `file_hash_sha1` | null | yes | Not computed. |
| `file_hash_algorithm` | string | yes | Primary algorithm: `sha256`. |
| `file_hash_status` | string | yes | `computed` or `not_computed`. |
| `file_hash_scope` | string | yes | `full_file`, `full_archive_member`, or `none`. Partial hashes are never produced. |
| `file_hash_reason` | string\|null | yes | Why there is no hash (members larger than `--max-member-size` are stream-scanned). |
| `file_hash_calculated_time` | time\|null | yes | When the hash was taken (same pass as the match: the hashed bytes are exactly the scanned bytes). |

### YARA and detection (`yara_match`)

| Field | Type | Req | Meaning / source |
|---|---|---|---|
| `yara_rule_name` | string | yes | Exact rule identifier. |
| `yara_rule_namespace` | string | yes | Namespace: the rule file's path relative to its rule folder (`srcN:` prefix with several sources), or `default`. |
| `yara_rule_source` | string\|null | yes | Rule file name. |
| `yara_rule_source_path` | string\|null | yes | Absolute path of the rule file. |
| `yara_rule_source_kind` | string\|null | yes | `source` (.yar) or `compiled` (.yarc). |
| `yara_rule_hash_sha256` | string\|null | yes | SHA-256 of the exact rule file bytes compiled. |
| `yara_rule_tags` | array | yes | Rule tags. |
| `yara_rule_meta` | object | yes | All rule metadata with native types (int, float, bool, string; bytes escaped). |
| `yara_rule_description` / `_author` / `_reference` / `_version` | any\|null | yes | From meta keys `description`/`desc`, `author`, `reference`/`ref`/`url`, `version` (case-insensitive). |
| `yara_ruleset_name` | string | yes | Rule sources given to the scan. |
| `yara_ruleset_version` | string | yes | SHA-256 over every loaded rule file's hash: identical value = identical ruleset. |
| `yara_engine_version` | string | yes | yara-x version. |
| `yara_match_count` | int | yes | Rules that matched this same file in this scan (one event each). |
| `yara_match_strings` | array | yes | Up to 20 `{identifier, offset, length, data}` (last field of the event); `data` is printable-escaped and cut at `--max-match-data` bytes. |
| `yara_match_strings_total` | int | yes | Total string matches for this rule on this file. |
| `yara_match_strings_truncated` | bool | yes | True when the list was capped. |
| `detection_status` | string | yes | `match` (`not_scanned` on unreadable events). |
| `detection_type` | string | yes | `yara_rule_match`. |
| `detection_name` | string | yes | `<namespace>:<rule>`. |
| `detection_severity` | any\|null | yes | Rule meta `severity`, if defined. |
| `detection_confidence` | any\|null | yes | Rule meta `confidence`, if defined. |
| `detection_reason` | string | yes | Which strings caused the match. |
| `detection_tags` | array | yes | Rule tags. |
| `malware_family` | any\|null | yes | Rule meta `malware_family` / `family`, if defined. |
| `threat_category` | any\|null | yes | Rule meta `threat_category`, if defined. |
| `scan_time_ms` | float | yes | Time spent scanning this file. |

### Errors (`scan_error`)

| Field | Type | Req | Meaning / source |
|---|---|---|---|
| `error_type` | string | yes | `permission_denied`, `file_disappeared`, `scan_timeout`, `directory_unreadable`, `archive_limit`, `read_error`, `rule_file_skipped`, `rule_compilation_failed`. |
| `error_code` | int\|null | yes | OS error number when the message carries one (`13` = EACCES, `5` = Windows access denied). |
| `error_message` | string | yes | The underlying error text. |
| `error_stage` | string | yes | `dir`, `stat`, `open`, `read`, `mmap`, `scan`, `timeout`, `archive`, `member`, `rule_compilation`. |
| `error_timestamp` | time | yes | When it happened. |
| `retryable` | bool | yes | Whether a re-scan could plausibly succeed (timeouts, transient read errors). |
| `scan_coverage_impact` | string | yes | What was not scanned because of it. |
| `yara_rule_source_path` | string | config only | Rule file involved. |

### Summary (`scan_summary`)

| Field | Type | Req | Meaning / source |
|---|---|---|---|
| `scan_status` | string | yes | See the table above. |
| `scan_completed` | time\|null | yes | End time; null when interrupted. |
| `scan_duration_ms` | int\|null | yes | Wall time. |
| `scan_mode` | string | yes | `full` (every selected file is read completely). |
| `scan_files_examined` | int\|null | yes | Files and archive members scanned. |
| `scan_bytes_examined` | int\|null | yes | Bytes scanned. |
| `scan_files_matched` | int | yes | Distinct files with at least one match. |
| `scan_matches` | int | yes | Detection events. |
| `scan_files_failed` | int | yes | Unreadable-item events. |
| `scan_files_skipped` | int\|null | yes | Files left out by the size limit. |
| `scan_errors_count` | int | yes | All errors counted by the scanner. |
| `scan_error` | string\|null | yes | Why a scan failed / was interrupted. |
| `scan_ruleset_name`, `scan_ruleset_version` | string | yes | As `yara_ruleset_*`. |
| `scan_rule_files_loaded`, `scan_rule_files_skipped` | int\|null | yes | Rule files used / left out. |
| `scan_configuration_id` | string\|null | yes | SHA-256 of every coverage-affecting setting: same value = same settings. |
| `scan_exclusions` | array\|null | yes | Coverage limits in effect (`exclude:<glob>`, `include_only:<glob>`, `extensions_only:…`, `skip_larger_than_bytes:…`, `archives_not_opened`, `no_recursion`). |
| `scan_max_file_size_bytes` | int\|null | yes | Size limit, if set. |
| `scan_recursion_enabled`, `scan_follow_symlinks` | bool\|null | yes | Walk settings. |

## Timestamp semantics by platform

| Field | Windows (NTFS / ReFS / FAT) | Linux local (ext4, xfs, btrfs) | Linux mounted NTFS (`ntfs3`, ntfs-3g) |
|---|---|---|---|
| created | Creation time | `statx` btime where the kernel and filesystem provide it, else null | btime from the NTFS creation time where the driver exposes it, else null |
| modified | Last write | mtime | NTFS last write |
| accessed | Last access (NTFS updates lazily, up to 1 h; often disabled) | atime (subject to `relatime`/`noatime`) | atime |
| metadata_changed | null (not exposed) | ctime | the driver's ctime |
| precision | 100 ns (FAT: 2 s modified, 1 day accessed) | 1 ns | 100 ns |

All values are converted to UTC. The scanner never writes to evidence, but
reading a file can update its access time unless the evidence is mounted
read-only (which is how `mount_evidence.py` mounts it).

## SPL examples

```spl
`comment("1. All detections from one target host")`
index=yarax_test sourcetype="yarax:detection" host="WEB01"
| table _time file_path yara_rule_name file_hash_sha256

`comment("2. Everything seen for one SHA-256")`
index=yarax_test sourcetype="yarax:detection" file_hash_sha256="8cea5ae5b48dfc84d9a4bfddeafb3497390fe650d35a32bf4503d2ef4cc33085"
| table _time host file_path yara_rule_name scan_id

`comment("3. Detections under a directory (case-insensitive)")`
index=yarax_test sourcetype="yarax:detection" file_path_normalized="*/inetpub/wwwroot/*"
| table _time host file_path yara_rule_name

`comment("4. One YARA rule")`
index=yarax_test sourcetype="yarax:detection" yara_rule_name="ascii_marker"
| stats count dc(host) as hosts values(host) as host_list by yara_rule_name yara_rule_hash_sha256

`comment("5. A time range (scan time - not file time)")`
index=yarax_test sourcetype="yarax:detection" earliest="10/14/2026:00:00:00" latest="10/15/2026:00:00:00"
| table _time host file_path yara_rule_name

`comment("6. Files matching more than one rule")`
index=yarax_test sourcetype="yarax:detection"
| stats dc(yara_rule_name) as rules values(yara_rule_name) as rule_names by host scan_id file_path
| where rules > 1

`comment("7. Scan errors and incomplete scans")`
index=yarax_test (sourcetype="yarax:unreadable" OR (sourcetype="yarax:scan" event_type="scan_error")
                 OR (sourcetype="yarax:scan" event_type="scan_summary" scan_status!="completed"))
| table _time host scan_id event_type scan_status error_type error_stage file_path error_message

`comment("8. Coverage and match counts per host (latest scan each)")`
index=yarax_test sourcetype="yarax:scan" event_type="scan_summary"
| dedup host sortby -_time
| table host scan_id scan_status scan_files_examined scan_files_failed scan_files_skipped scan_files_matched scan_matches scan_ruleset_version

`comment("9. One rule across several hosts")`
index=yarax_test sourcetype="yarax:detection"
| stats dc(host) as hosts values(host) as host_list count by yara_rule_name
| where hosts > 1

`comment("10. The same file content on several hosts")`
index=yarax_test sourcetype="yarax:detection" file_hash_sha256=*
| stats dc(host) as hosts values(host) as host_list values(file_path) as paths by file_hash_sha256
| where hosts > 1 | sort - hosts

`comment("Pivot: everything from one scan, in order")`
index=yarax_test scan_id="aac7f572-9968-49a0-9480-3216b5338603"
| sort _time | table _time sourcetype event_type file_path yara_rule_name error_type scan_status
```

Re-sends never duplicate accepted batches, but if a spool is sent twice by
hand, `| dedup event_id` removes the copies.

### CIM

Detection events map onto the **Malware** data model (`Malware_Attacks`) with
search-time aliases; the native fields stay as they are:

```ini
[yarax:detection]
FIELDALIAS-cim = host AS dest, file_name AS file_name, file_path AS file_path, \
                 file_hash_sha256 AS file_hash, yara_rule_name AS signature, \
                 scanner_name AS vendor_product
EVAL-action = "allowed"
EVAL-category = coalesce(threat_category, "unknown")
```

`action = allowed` is CIM's value for "detected, not blocked" - the scanner
never quarantines anything.

## Limitations

* **Target host identity** comes only from `--target-host`. FQDN, domain,
  machine id, OS and architecture of the evidence are not read (that needs the
  evidence's SYSTEM/SOFTWARE hives or `/etc`) and are always null.
* **Original-system paths** are not reconstructed: for a mounted image the
  scanner reports the mount path and `file_relative_path`, not `C:\…`.
* **ctime on Windows** and a separate birth time are not collected.
* **Windows attributes on Linux mounts** (hidden/system on NTFS through
  ntfs-3g) are not read; only the POSIX mode is reported.
* **Archive members** have no timestamps; members over `--max-member-size`
  have no hash.
* **Changes during a scan** are detected by size and mtime only; a same-size,
  same-mtime rewrite is not detected.
* **Matches only**: files that did not match produce no event (thousands of
  `no_match` events per host would swamp the index); coverage is in the
  summary. `--hash-all` hashes every file but does not report those hashes.
* **Delivery is after the scan**, not live. Events are on disk as they happen.
* **No indexer acknowledgement** (`useACK`): HTTP 200 means accepted by HEC.
* **Index existence** is not verifiable through HEC: on a token allowed to
  write to any index, events for a mistyped index are accepted and dropped.
  Restrict the token's allowed indexes (see above).
* **Index per host** is not automatic yet: one index per run, chosen by the
  analyst.
