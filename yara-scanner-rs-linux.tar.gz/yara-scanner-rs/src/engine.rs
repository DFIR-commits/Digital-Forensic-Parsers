//! YARA-X engine facade.
//!
//! Performance model:
//! * `yara_x::Rules` is compiled/deserialized **once** and shared by
//!   reference; it is `Sync`.
//! * Each worker owns a `yara_x::Scanner` (cheap to create, holds per-scan
//!   state) borrowing the shared rules — zero cross-thread contention while
//!   matching, and *no FFI boundary at all*: YARA-X is native Rust, so LTO
//!   inlines the matcher into our hot loop and match data is returned as
//!   borrowed slices of the scanned buffer (true zero-copy).
//!
//! Rule loading accepts:
//! * serialized compiled rules (`.yarc`, produced by `yr compile` /
//!   `Rules::serialize`) — detected by attempting deserialization;
//! * a single `.yar` source file;
//! * a directory of sources, each compiled into its own namespace.

use crate::config::{Config, CHUNK_OVERLAP};
use crate::models::{Hit, StringMatchOut};
use crate::utils::escape_bytes;
use anyhow::{Context, Result};
use std::fs;
use std::io::Read;
use std::collections::HashSet;
use std::path::{Path, PathBuf};
use std::time::Duration;

pub struct Engine {
    rules: yara_x::Rules,
    timeout: Duration,
}

/// Owned, thread-local view produced from YARA-X results so hits can cross
/// the channel to the writer (the raw results borrow the scanned buffer).
pub struct OwnedMatch {
    pub rule: String,
    pub namespace: String,
    pub tags: Vec<String>,
    pub metadata: serde_json::Map<String, serde_json::Value>,
    pub strings: Vec<StringMatchOut>,
    pub offsets: Vec<u64>,
}

impl Engine {
    // ------------------------------------------------------------------
    pub fn load(cfg: &Config) -> Result<Self> {
        let rules = Self::load_rules(&cfg.rules, &cfg.externals, cfg.skip_invalid_rules).with_context(|| {
            let shown: Vec<_> = cfg.rules.iter().map(|p| p.display().to_string()).collect();
            format!("loading rules from {}", shown.join(", "))
        })?;
        Ok(Engine { rules, timeout: Duration::from_secs(cfg.timeout_secs) })
    }

    fn load_rules(paths: &[PathBuf], externals: &[(String, String)],
                  skip_invalid: bool) -> Result<yara_x::Rules> {
        // One file: may be pre-compiled (.yarc), which can't be merged with
        // anything else.
        if let [p] = paths {
            if !p.is_dir() {
                return Self::load_file(p, externals);
            }
        }

        // Directories and/or source files, compiled together. One namespace
        // per file so rule-name collisions between packs can't abort
        // compilation; with several sources the namespace is prefixed by the
        // source's position so same-named files in different bundles differ.
        let multi = paths.len() > 1;
        let mut compiler = yara_x::Compiler::new();
        for (k, v) in externals {
            compiler.define_global(k, v.as_str())?;
        }
        let mut seen = HashSet::new();
        let (mut count, mut skipped) = (0usize, 0usize);
        for (i, path) in paths.iter().enumerate() {
            let files = if path.is_dir() { walk_rule_files(path)? } else { vec![path.clone()] };
            anyhow::ensure!(!files.is_empty(), "no rule files found in {}", path.display());
            for entry in files {
                // The same file reachable from two sources is compiled once.
                if !seen.insert(fs::canonicalize(&entry).unwrap_or_else(|_| entry.clone())) {
                    continue;
                }
                if skip_invalid {
                    let c = crate::rulecheck::check_file(&entry, externals);
                    if !c.ok() {
                        eprintln!("WARNING: skipping invalid rule file {}:\n{}",
                                  entry.display(), c.errors.join("\n"));
                        skipped += 1;
                        continue;
                    }
                }
                let src = fs::read(&entry)?;
                let rel = if path.is_dir() { entry.strip_prefix(path).unwrap_or(&entry) } else { &entry };
                let rel = rel.to_string_lossy();
                let ns = if multi { format!("src{i}:{rel}") } else { rel.into_owned() };
                compiler.new_namespace(&ns);
                compiler.add_source(src.as_slice())
                    .with_context(|| format!(
                        "compiling {} (run with --check-rules to list every failing rule file)",
                        entry.display()))?;
                count += 1;
            }
        }
        if skipped > 0 {
            eprintln!("WARNING: scanning WITHOUT {skipped} invalid rule file(s); run --check-rules for details");
            anyhow::ensure!(count > 0, "every rule file was invalid - nothing to scan with");
        }
        log::info!("compiled {count} rule files from {} source(s)", paths.len());
        Ok(compiler.build())
    }

    fn load_file(path: &Path, externals: &[(String, String)]) -> Result<yara_x::Rules> {
        let bytes = fs::read(path)?;
        // Compiled rules first (cheap failure), then source compilation.
        if let Ok(rules) = yara_x::Rules::deserialize(&bytes) {
            log::info!("loaded pre-compiled rules {}", path.display());
            return Ok(rules);
        }
        let mut compiler = yara_x::Compiler::new();
        for (k, v) in externals {
            compiler.define_global(k, v.as_str())?;
        }
        compiler.add_source(bytes.as_slice())
            .with_context(|| format!("compiling {}", path.display()))?;
        log::info!("compiled rules {}", path.display());
        Ok(compiler.build())
    }

    // ------------------------------------------------------------------
    /// One scanner per worker thread; borrows the shared rules.
    pub fn make_scanner(&self) -> yara_x::Scanner<'_> {
        let mut s = yara_x::Scanner::new(&self.rules);
        s.set_timeout(self.timeout);
        s
    }

    // ------------------------------------------------------------------
    /// Scan a buffer and convert results into owned matches.
    /// The conversion allocates **only when there are matches** — the miss
    /// path returns an empty Vec without touching the heap.
    pub fn scan_buf(scanner: &mut yara_x::Scanner, data: &[u8])
                    -> Result<Vec<OwnedMatch>> {
        let results = scanner.scan(data)?;
        Ok(Self::to_owned_matches(&results, data, 0))
    }

    /// Overlapping-window scan for unbounded streams (huge archive members).
    /// Fixed memory (~2×IO_CHUNK); offsets rebased to absolute stream
    /// positions; duplicate rule hits across windows deduplicated.
    /// Matches longer than CHUNK_OVERLAP that straddle a boundary can be
    /// missed — the documented trade for constant memory.
    pub fn scan_chunked<R: Read>(scanner: &mut yara_x::Scanner, mut reader: R,
                                 chunk: usize,
                                 mut budget: impl FnMut(usize) -> Result<()>)
                                 -> Result<(Vec<OwnedMatch>, u64)> {
        let mut window: Vec<u8> = Vec::with_capacity(chunk + CHUNK_OVERLAP);
        let mut buf = vec![0u8; chunk];
        let mut consumed: u64 = 0;
        let mut base: u64 = 0;
        let mut merged: Vec<OwnedMatch> = Vec::new();

        loop {
            let n = read_full(&mut reader, &mut buf)?;
            if n == 0 {
                break;
            }
            budget(n)?;
            consumed += n as u64;
            window.extend_from_slice(&buf[..n]);

            let results = scanner.scan(&window)?;
            for m in Self::to_owned_matches(&results, &window, base) {
                if !merged.iter().any(|e| e.rule == m.rule && e.namespace == m.namespace) {
                    merged.push(m);
                }
            }
            // Keep only the overlap tail; rebase.
            if window.len() > CHUNK_OVERLAP {
                let keep_from = window.len() - CHUNK_OVERLAP;
                base += keep_from as u64;
                window.copy_within(keep_from.., 0);
                window.truncate(CHUNK_OVERLAP);
            }
        }
        Ok((merged, consumed))
    }

    // ------------------------------------------------------------------
    fn to_owned_matches(results: &yara_x::ScanResults, data: &[u8], base: u64)
                        -> Vec<OwnedMatch> {
        let mut out = Vec::new();
        for rule in results.matching_rules() {
            let mut strings = Vec::new();
            let mut offsets = Vec::new();
            for pattern in rule.patterns() {
                let ident = pattern.identifier().to_string();
                for m in pattern.matches() {
                    let r = m.range();
                    let off = base + r.start as u64;
                    strings.push(StringMatchOut {
                        identifier: ident.clone(),
                        offset: off,
                        data: escape_bytes(&data[r.start..r.end.min(data.len())], 128),
                    });
                    offsets.push(off);
                }
            }
            let mut metadata = serde_json::Map::new();
            for (name, value) in rule.metadata() {
                metadata.insert(name.to_string(), meta_to_json(value));
            }
            out.push(OwnedMatch {
                rule: rule.identifier().to_string(),
                namespace: rule.namespace().to_string(),
                tags: rule.tags().map(|t| t.identifier().to_string()).collect(),
                metadata,
                strings,
                offsets,
            });
        }
        out
    }

    /// Turn owned matches into report hits (shared by disk & archive paths).
    pub fn build_hits(matches: Vec<OwnedMatch>, file: &str, relative: &str,
                      size: u64, scan_ms: f64) -> Vec<Hit> {
        matches.into_iter().map(|m| {
            let mut h = Hit::new(m.rule, m.namespace, file.to_string(),
                                 relative.to_string(), size);
            h.tags = m.tags;
            h.metadata = m.metadata;
            h.matched_strings = m.strings;
            h.offsets = m.offsets;
            h.scan_time_ms = scan_ms;
            h
        }).collect()
    }
}

fn meta_to_json(v: yara_x::MetaValue) -> serde_json::Value {
    use serde_json::Value;
    match v {
        yara_x::MetaValue::Integer(i) => Value::from(i),
        yara_x::MetaValue::Float(f) => Value::from(f),
        yara_x::MetaValue::Bool(b) => Value::from(b),
        yara_x::MetaValue::String(s) => Value::from(s),
        yara_x::MetaValue::Bytes(b) => Value::from(escape_bytes(b, 256)),
    }
}

pub fn walk_rule_files(dir: &Path) -> Result<Vec<std::path::PathBuf>> {
    let mut out = Vec::new();
    let mut stack = vec![dir.to_path_buf()];
    while let Some(d) = stack.pop() {
        for entry in fs::read_dir(&d)? {
            let entry = entry?;
            let p = entry.path();
            if p.is_dir() {
                stack.push(p);
            } else if matches!(p.extension().and_then(|e| e.to_str()),
                               Some("yar" | "yara" | "rule" | "rules")) {
                out.push(p);
            }
        }
    }
    out.sort(); // deterministic namespaces
    Ok(out)
}

/// Fill `buf` as far as possible (Read may return short counts on pipes
/// and decompression streams).
fn read_full<R: Read>(r: &mut R, buf: &mut [u8]) -> std::io::Result<usize> {
    let mut total = 0;
    while total < buf.len() {
        match r.read(&mut buf[total..]) {
            Ok(0) => break,
            Ok(n) => total += n,
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
        }
    }
    Ok(total)
}
