//! Small allocation-conscious helpers.

use chrono::{DateTime, SecondsFormat, Utc};
use std::time::SystemTime;

/// Shannon entropy (bits/byte).  Single pass, stack-allocated table; on a
/// 1 MiB sample this vectorizes well under `-C opt-level=3`.
pub fn shannon_entropy(data: &[u8]) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    let mut counts = [0u64; 256];
    for &b in data {
        counts[b as usize] += 1;
    }
    let total = data.len() as f64;
    let mut ent = 0.0;
    for &c in counts.iter() {
        if c != 0 {
            let p = c as f64 / total;
            ent -= p * p.log2();
        }
    }
    (ent * 10_000.0).round() / 10_000.0
}

/// Printable-escape matched bytes for the JSON report, truncated.
pub fn escape_bytes(data: &[u8], limit: usize) -> String {
    let take = data.len().min(limit);
    let mut out = String::with_capacity(take + 16);
    for &b in &data[..take] {
        if (0x20..0x7f).contains(&b) {
            out.push(b as char);
        } else {
            out.push_str(&format!("\\x{b:02x}"));
        }
    }
    if data.len() > limit {
        out.push_str(&format!("... (+{} bytes)", data.len() - limit));
    }
    out
}

/// ISO 8601 UTC with a `Z` suffix. Fractional seconds are printed only as
/// far as the value has them (up to the nanoseconds the OS reports), so no
/// precision is invented or dropped.
pub fn iso_time(t: SystemTime) -> String {
    DateTime::<Utc>::from(t).to_rfc3339_opts(SecondsFormat::AutoSi, true)
}

pub fn now_iso() -> String {
    iso_time(SystemTime::now())
}

pub fn sha256_hex(data: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    Sha256::digest(data).iter().map(|b| format!("{b:02x}")).collect()
}

/// RFC 4122 v4-shaped id from the SHA-256 of `seed` (no RNG dependency).
/// Callers make the seed unique: scan ids mix host, pid and nanosecond
/// time; event ids mix the scan id with a sequence number.
pub fn uuid_from(seed: &str) -> String {
    use sha2::{Digest, Sha256};
    let mut b: [u8; 16] = Sha256::digest(seed.as_bytes())[..16].try_into().unwrap();
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    let h: String = b.iter().map(|x| format!("{x:02x}")).collect();
    format!("{}-{}-{}-{}-{}", &h[..8], &h[8..12], &h[12..16], &h[16..20], &h[20..])
}

pub fn human_bytes(n: f64) -> String {
    const UNITS: [&str; 7] = ["B", "KB", "MB", "GB", "TB", "PB", "EB"];
    let mut v = n;
    for u in UNITS {
        if v.abs() < 1024.0 {
            return format!("{v:.1} {u}");
        }
        v /= 1024.0;
    }
    format!("{v:.1} ZB")
}

pub fn human_eta(secs: f64) -> String {
    if !secs.is_finite() || secs <= 0.0 {
        return "--:--".into();
    }
    let s = secs as u64;
    let (h, m, s) = (s / 3600, (s % 3600) / 60, s % 60);
    if h > 0 { format!("{h}:{m:02}:{s:02}") } else { format!("{m}:{s:02}") }
}

/// `logs.tar.gz -> logs.tar`, `access.log.gz -> access.log`.
/// Splits on `::` (virtual-path chains) as well as path separators, so
/// `outer.zip::logs.gz` yields `logs`.
pub fn strip_last_ext(name: &str) -> String {
    let base = name.rsplit("::").next().unwrap_or(name);
    let base = base.rsplit(['/', '\\']).next().unwrap_or(base);
    match base.rfind('.') {
        Some(i) if i > 0 => base[..i].to_string(),
        _ => base.to_string(),
    }
}
