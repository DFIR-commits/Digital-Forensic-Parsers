//! Splunk HTTP Event Collector delivery.
//!
//! Reads `<report>.events.ndjson` (written during the scan - the durable
//! local spool) and posts it to HEC in batches. Progress is checkpointed in
//! `<report>.events.delivery.json` after every accepted batch, so a failed
//! or interrupted delivery resumes where it stopped and never re-sends what
//! HEC already accepted. Nothing is deleted: the NDJSON file stays as the
//! local record whatever happens to delivery.
//!
//! The token is read from the environment (YARAX_SPLUNK_TOKEN) so it never
//! appears in a command line, a report, or a log line.

use crate::utils::{now_iso, uuid_from};
use serde::{Deserialize, Serialize};
use serde_json::{json, Map, Value};
use std::fs;
use std::path::{Path, PathBuf};
use std::time::Duration;

pub const TOKEN_ENV: &str = "YARAX_SPLUNK_TOKEN";
pub const SOURCE: &str = "yarax-scanner";
pub const ST_DETECTION: &str = "yarax:detection";
pub const ST_UNREADABLE: &str = "yarax:unreadable";
pub const ST_SCAN: &str = "yarax:scan";
pub const ST_RULE: &str = "yarax:rule";

const BATCH_EVENTS: usize = 500;
const BATCH_BYTES: usize = 800 * 1024; // HEC default max_content_length is 800 MB; stay far below

#[derive(Debug, Clone)]
pub struct HecConfig {
    /// e.g. https://splunk.example:8088 (the /services/collector/event path is added)
    pub url: String,
    pub token: String,
    /// None = the token's default index
    pub index: Option<String>,
    /// Skip TLS certificate verification (self-signed test instances only).
    pub insecure: bool,
    pub max_attempts: u32,
    pub backoff: Duration,
}

impl HecConfig {
    pub fn new(url: &str, token: String, index: Option<String>, insecure: bool) -> Self {
        HecConfig { url: url.trim().to_string(), token, index: index.filter(|i| !i.trim().is_empty()),
                    insecure, max_attempts: 4, backoff: Duration::from_secs(1) }
    }

    fn endpoint(&self, path: &str) -> String {
        let base = self.url.trim_end_matches('/');
        let base = base.split("/services/collector").next().unwrap_or(base);
        format!("{base}{path}")
    }

    fn agent(&self) -> ureq::Agent {
        use ureq::tls::{RootCerts, TlsConfig};
        let tls = TlsConfig::builder()
            .root_certs(RootCerts::PlatformVerifier) // OS trust store: corporate CAs work
            .disable_verification(self.insecure)
            .build();
        ureq::Agent::config_builder()
            .http_status_as_error(false)
            .timeout_global(Some(Duration::from_secs(60)))
            .tls_config(tls)
            .build()
            .new_agent()
    }
}

/// Delivery state, written to `<events>.delivery.json`.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Delivery {
    /// scan the spool belongs to; state for another scan is never reused
    #[serde(default)]
    pub scan_id: Option<String>,
    /// delivered | partial | failed | nothing_to_send
    pub delivery_status: String,
    pub events_total: u64,
    /// NDJSON lines HEC has accepted (also the resume point)
    pub events_sent: u64,
    pub delivery_attempt_count: u32,
    pub last_http_status: Option<u16>,
    pub error_type: Option<String>,
    pub error_message: Option<String>,
    pub retryable: Option<bool>,
    pub index: Option<String>,
    pub hec_endpoint: String,
    pub updated: String,
    /// true when delivery had to add an "interrupted" summary
    pub synthesized_summary: bool,
}

pub fn delivery_path(events: &Path) -> PathBuf {
    events.with_extension("delivery.json")
}

pub fn read_delivery(events: &Path) -> Option<Delivery> {
    serde_json::from_str(&fs::read_to_string(delivery_path(events)).ok()?).ok()
}

/// Splunk sourcetype for an event: unreadable files have their own.
pub fn sourcetype(ev: &Value) -> &'static str {
    match (ev["event_type"].as_str(), ev["event_category"].as_str()) {
        (Some("yara_match"), _) => ST_DETECTION,
        (Some("rule_definition"), _) => ST_RULE,
        (Some("scan_error"), Some("file")) => ST_UNREADABLE,
        _ => ST_SCAN,
    }
}

/// HEC envelope: routing metadata outside, forensic event inside `event`.
/// `host` moves from the event body to the envelope: Splunk indexes the
/// envelope host, and a second `host` inside the JSON would make `host`
/// multivalued at search time (doubling every `stats ... by host`).
pub fn envelope(ev: &Value, index: Option<&str>) -> Value {
    let time = ev["event_created"].as_str()
        .and_then(|t| chrono::DateTime::parse_from_rfc3339(t).ok())
        .map(|t| t.timestamp_millis() as f64 / 1000.0);
    let mut body = ev.clone();
    if let Some(o) = body.as_object_mut() { o.remove("host"); }
    let mut env = json!({
        "time": time,
        "host": ev["host"].as_str().unwrap_or("unknown"),
        "source": SOURCE,
        "sourcetype": sourcetype(ev),
        "event": body,
    });
    if let Some(i) = index { env["index"] = json!(i); }
    env
}

/// Send everything in `events` not yet accepted by HEC.
pub fn deliver(events: &Path, hec: &HecConfig) -> Delivery {
    let mut lines: Vec<String> = match fs::read_to_string(events) {
        Ok(t) => t.lines().filter(|l| !l.trim().is_empty()).map(String::from).collect(),
        Err(e) => return finish(events, hec, Delivery::failed(hec, "spool_unreadable", &e.to_string(), false)),
    };
    let mut synthesized = false;
    if let Some(s) = interrupted_summary(&lines) {
        // Scan was cancelled/crashed: record that honestly, locally first.
        if let Ok(mut f) = fs::OpenOptions::new().append(true).open(events) {
            use std::io::Write;
            let _ = writeln!(f, "{s}");
        }
        lines.push(s);
        synthesized = true;
    }
    // Resume only from state that belongs to this spool's scan.
    let scan_id = lines.first().and_then(|l| serde_json::from_str::<Value>(l).ok())
        .and_then(|v| v["scan_id"].as_str().map(String::from));
    let prev = read_delivery(events).filter(|p| p.scan_id.is_some() && p.scan_id == scan_id);
    let mut d = Delivery {
        scan_id,
        delivery_status: "partial".into(),
        events_total: lines.len() as u64,
        events_sent: prev.as_ref().map(|p| p.events_sent.min(lines.len() as u64)).unwrap_or(0),
        delivery_attempt_count: prev.as_ref().map(|p| p.delivery_attempt_count).unwrap_or(0),
        last_http_status: None, error_type: None, error_message: None, retryable: None,
        index: hec.index.clone(), hec_endpoint: hec.endpoint("/services/collector/event"),
        updated: now_iso(), synthesized_summary: synthesized || prev.is_some_and(|p| p.synthesized_summary),
    };
    if lines.is_empty() {
        d.delivery_status = "nothing_to_send".into();
        return finish(events, hec, d);
    }

    let agent = hec.agent();
    let mut i = d.events_sent as usize;
    while i < lines.len() {
        // Build one batch of concatenated envelopes (HEC's batch format).
        let (mut body, mut n) = (String::new(), 0usize);
        while i + n < lines.len() && n < BATCH_EVENTS && body.len() < BATCH_BYTES {
            match serde_json::from_str::<Value>(&lines[i + n]) {
                Ok(ev) => body.push_str(&envelope(&ev, hec.index.as_deref()).to_string()),
                Err(e) => log::warn!("skipping unparseable spool line {}: {e}", i + n + 1),
            }
            body.push('\n');
            n += 1;
        }
        match post_with_retry(&agent, hec, &body, &mut d) {
            Ok(()) => {
                i += n;
                d.events_sent = i as u64;
                d.error_type = None;
                d.error_message = None;
                d.retryable = None;
                save(events, &d); // checkpoint: never re-send an accepted batch
            }
            Err(()) => {
                d.delivery_status = if d.events_sent == 0 { "failed" } else { "partial" }.into();
                return finish(events, hec, d);
            }
        }
    }
    d.delivery_status = "delivered".into();
    finish(events, hec, d)
}

/// One batch, retried with exponential backoff while the failure is
/// transient (network, 429, 5xx). Auth/index/format errors stop at once.
fn post_with_retry(agent: &ureq::Agent, hec: &HecConfig, body: &str, d: &mut Delivery) -> Result<(), ()> {
    let url = hec.endpoint("/services/collector/event");
    for attempt in 0..hec.max_attempts.max(1) {
        if attempt > 0 {
            std::thread::sleep(hec.backoff * 2u32.pow(attempt - 1));
        }
        d.delivery_attempt_count += 1;
        let res = agent.post(&url)
            .header("Authorization", &format!("Splunk {}", hec.token))
            .header("Content-Type", "application/json")
            .send(body);
        match res {
            Ok(mut r) => {
                let code = r.status().as_u16();
                d.last_http_status = Some(code);
                if (200..300).contains(&code) { return Ok(()); }
                let text = r.body_mut().read_to_string().unwrap_or_default();
                let (kind, retry) = classify(code, &text);
                d.error_type = Some(kind.into());
                d.error_message = Some(format!("HTTP {code}: {}", text.chars().take(300).collect::<String>()));
                d.retryable = Some(retry);
                if !retry { return Err(()); }
            }
            Err(e) => {
                d.last_http_status = None;
                d.error_type = Some("connection_failed".into());
                d.error_message = Some(e.to_string());
                d.retryable = Some(true);
            }
        }
    }
    Err(())
}

/// (error_type, retryable) for an HEC HTTP response.
/// HEC codes: 2/3/4 token problems, 7 incorrect index, 9 server busy.
pub fn classify(status: u16, body: &str) -> (&'static str, bool) {
    let code = serde_json::from_str::<Value>(body).ok().and_then(|v| v["code"].as_i64());
    match (status, code) {
        (401 | 403, _) | (_, Some(1..=4)) => ("hec_authentication_failed", false),
        (_, Some(7)) => ("hec_incorrect_index", false),
        (429 | 500..=599, _) | (_, Some(9)) => ("hec_server_unavailable", true),
        (400, _) => ("hec_rejected_payload", false),
        _ => ("hec_unexpected_response", false),
    }
}

/// Health check + one labelled test event (validates URL, TLS, token and index).
pub fn test_connection(hec: &HecConfig) -> Result<String, String> {
    let agent = hec.agent();
    let health = agent.get(&hec.endpoint("/services/collector/health")).call()
        .map_err(|e| format!("cannot reach {}: {e}", hec.url))?;
    if health.status().as_u16() != 200 {
        return Err(format!("HEC health check returned HTTP {}", health.status().as_u16()));
    }
    let ev = json!({
        "schema_version": crate::events::EVENT_SCHEMA_VERSION,
        "event_id": uuid_from(&format!("test|{}", now_iso())),
        "event_type": "connection_test", "event_category": "configuration",
        "event_action": "test", "event_outcome": "success", "event_created": now_iso(),
        "host": "unknown", "scanner_name": SOURCE, "scanner_version": crate::config::SCANNER_VERSION,
        "scanner_host_name": hostname::get().ok().map(|h| h.to_string_lossy().into_owned()),
    });
    let mut d = Delivery::failed(hec, "", "", false);
    let mut one = hec.clone();
    one.max_attempts = 1;
    post_with_retry(&agent, &one, &envelope(&ev, hec.index.as_deref()).to_string(), &mut d)
        // A token allowed to write to any index gets HTTP 200 even for an index
        // that does not exist - Splunk then drops the event. Say so.
        .map(|_| format!("HEC accepted a test event (sourcetype {ST_SCAN}, index {}). HEC does not check \
                          that the index exists: confirm with  index={} event_type=connection_test",
                         hec.index.as_deref().unwrap_or("token default"),
                         hec.index.as_deref().unwrap_or("<default>")))
        .map_err(|_| format!("{}: {}", d.error_type.unwrap_or_default(), d.error_message.unwrap_or_default()))
}

impl Delivery {
    fn failed(hec: &HecConfig, kind: &str, msg: &str, retry: bool) -> Self {
        Delivery {
            scan_id: None,
            delivery_status: "failed".into(), events_total: 0, events_sent: 0, delivery_attempt_count: 0,
            last_http_status: None, error_type: Some(kind.into()).filter(|k: &String| !k.is_empty()),
            error_message: Some(msg.into()).filter(|m: &String| !m.is_empty()), retryable: Some(retry),
            index: hec.index.clone(), hec_endpoint: hec.endpoint("/services/collector/event"),
            updated: now_iso(), synthesized_summary: false,
        }
    }
}

fn save(events: &Path, d: &Delivery) {
    let p = delivery_path(events);
    let tmp = p.with_extension("json.tmp");
    if let Ok(text) = serde_json::to_string_pretty(d) {
        if fs::write(&tmp, text).and_then(|_| fs::rename(&tmp, &p)).is_err() {
            log::warn!("cannot write {}", p.display());
        }
    }
}

fn finish(events: &Path, _hec: &HecConfig, mut d: Delivery) -> Delivery {
    d.updated = now_iso();
    save(events, &d);
    d
}

/// Keys of a real summary event, so a synthesized one has the same shape.
const COMMON_KEYS: &[&str] = &[
    "schema_version", "host", "host_name", "host_identity_source", "host_fqdn", "host_domain",
    "host_id", "host_os", "host_os_version", "host_architecture", "scanner_host_name",
    "scanner_host_id", "scanner_name", "scanner_version", "scanner_engine",
    "scanner_engine_version", "scan_id", "scan_started", "scan_target", "scan_target_type",
];

/// A summary for a spool whose scan never wrote one (cancelled / crashed).
/// None when the last event already is a summary, or nothing is known.
fn interrupted_summary(lines: &[String]) -> Option<String> {
    let events: Vec<Value> = lines.iter().filter_map(|l| serde_json::from_str(l).ok()).collect();
    let first = events.first()?;
    if events.last()?["event_type"] == "scan_summary" { return None; }
    let mut ev: Map<String, Value> = COMMON_KEYS.iter()
        .map(|k| (k.to_string(), first.get(*k).cloned().unwrap_or(Value::Null))).collect();
    let matches: Vec<&Value> = events.iter().filter(|e| e["event_type"] == "yara_match").collect();
    let files: std::collections::HashSet<&str> = matches.iter().filter_map(|e| e["file_path"].as_str()).collect();
    let failed = events.iter().filter(|e| e["event_type"] == "scan_error" && e["event_category"] == "file").count();
    let now = now_iso();
    ev.extend(json!({
        "event_id": uuid_from(&format!("{}|interrupted", first["scan_id"].as_str().unwrap_or(""))),
        "event_type": "scan_summary", "event_category": "file", "event_action": "complete",
        "event_outcome": "failure", "event_created": now, "event_ingested": null,
        "scan_status": "interrupted",
        "scan_error": "scan ended without writing a summary (cancelled or crashed); counts cover only events recorded before it stopped",
        "scan_completed": null, "scan_duration_ms": null, "scan_mode": "full",
        "scan_files_examined": null, "scan_bytes_examined": null,
        "scan_files_matched": files.len(), "scan_matches": matches.len(),
        "scan_files_failed": failed, "scan_files_skipped": null, "scan_errors_count": failed,
        "scan_ruleset_name": matches.first().map(|m| m["yara_ruleset_name"].clone()),
        "scan_ruleset_version": matches.first().map(|m| m["yara_ruleset_version"].clone()),
        "scan_rule_files_loaded": null, "scan_rule_files_skipped": null,
        "scan_configuration_id": null, "scan_exclusions": null, "scan_max_file_size_bytes": null,
        "scan_recursion_enabled": null, "scan_follow_symlinks": null,
    }).as_object().cloned().unwrap_or_default());
    serde_json::to_string(&ev).ok()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{BufRead, BufReader, Read, Write};
    use std::net::TcpListener;
    use std::sync::{Arc, Mutex};

    /// Minimal HEC stand-in: answers each request with the next scripted
    /// (status, body) and records what it received.
    struct MockHec { url: String, requests: Arc<Mutex<Vec<(String, String, String)>>> }

    fn mock(script: Vec<(u16, &'static str)>) -> MockHec {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let url = format!("http://{}", listener.local_addr().unwrap());
        let requests = Arc::new(Mutex::new(Vec::new()));
        let rec = Arc::clone(&requests);
        std::thread::spawn(move || {
            for (status, body) in script {
                let Ok((mut s, _)) = listener.accept() else { return };
                let mut r = BufReader::new(s.try_clone().unwrap());
                let mut first = String::new();
                r.read_line(&mut first).unwrap();
                let (mut len, mut auth) = (0usize, String::new());
                loop {
                    let mut h = String::new();
                    r.read_line(&mut h).unwrap();
                    if h.trim().is_empty() { break; }
                    let low = h.to_ascii_lowercase();
                    if let Some(v) = low.strip_prefix("content-length:") { len = v.trim().parse().unwrap(); }
                    if low.starts_with("authorization:") { auth = h.trim().to_string(); }
                }
                let mut b = vec![0u8; len];
                r.read_exact(&mut b).unwrap();
                rec.lock().unwrap().push((first.trim().to_string(), auth, String::from_utf8(b).unwrap()));
                let _ = write!(s, "HTTP/1.1 {status} X\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}", body.len());
            }
        });
        MockHec { url, requests }
    }

    fn hec(url: &str) -> HecConfig {
        let mut h = HecConfig::new(url, "SECRET-TOKEN".into(), Some("yarax_test".into()), false);
        h.backoff = Duration::from_millis(1);
        h
    }

    fn spool(lines: &[Value]) -> (tempfile::TempDir, PathBuf) {
        let t = tempfile::tempdir().unwrap();
        let p = t.path().join("r.events.ndjson");
        fs::write(&p, lines.iter().map(|l| l.to_string() + "\n").collect::<String>()).unwrap();
        (t, p)
    }

    fn ev(kind: &str, cat: &str) -> Value {
        json!({"event_type": kind, "event_category": cat, "host": "WEB01", "scan_id": "s1",
               "event_created": "2026-10-14T12:00:00.250Z", "file_path": "/ev/a", "event_id": kind})
    }

    #[test]
    fn envelope_separates_routing_from_forensic_data() {
        let e = envelope(&ev("yara_match", "malware"), Some("idx"));
        assert_eq!(e["time"], 1_791_979_200.25); // epoch seconds, ms kept
        assert_eq!((e["host"].as_str(), e["source"].as_str(), e["sourcetype"].as_str(), e["index"].as_str()),
                   (Some("WEB01"), Some(SOURCE), Some(ST_DETECTION), Some("idx")));
        assert_eq!(e["event"]["file_path"], "/ev/a");
        assert!(e["event"].get("host").is_none(), "host only in the envelope (no multivalue host)");
        assert!(envelope(&ev("yara_match", "malware"), None).get("index").is_none());
        assert_eq!(sourcetype(&ev("scan_error", "file")), ST_UNREADABLE);
        assert_eq!(sourcetype(&ev("scan_error", "configuration")), ST_SCAN);
        assert_eq!(sourcetype(&ev("scan_summary", "file")), ST_SCAN);
    }

    #[test]
    fn delivers_in_order_with_token_header() {
        let m = mock(vec![(200, r#"{"text":"Success","code":0}"#)]);
        let (_t, p) = spool(&[ev("yara_match", "malware"), ev("scan_error", "file"), ev("scan_summary", "file")]);
        let d = deliver(&p, &hec(&m.url));
        assert_eq!((d.delivery_status.as_str(), d.events_sent, d.events_total), ("delivered", 3, 3));
        let reqs = m.requests.lock().unwrap();
        assert_eq!(reqs.len(), 1, "one batch");
        assert!(reqs[0].0.starts_with("POST /services/collector/event"));
        let (name, value) = reqs[0].1.split_once(':').unwrap();
        assert!(name.eq_ignore_ascii_case("authorization")); // header names are case-insensitive
        assert_eq!(value.trim(), "Splunk SECRET-TOKEN");
        let sent: Vec<Value> = reqs[0].2.lines().map(|l| serde_json::from_str(l).unwrap()).collect();
        assert_eq!(sent.iter().map(|e| e["sourcetype"].as_str().unwrap()).collect::<Vec<_>>(),
                   [ST_DETECTION, ST_UNREADABLE, ST_SCAN]);
        // token never lands in the state file
        assert!(!fs::read_to_string(delivery_path(&p)).unwrap().contains("SECRET"));
    }

    #[test]
    fn auth_failure_is_not_retried_and_keeps_the_spool() {
        let m = mock(vec![(403, r#"{"text":"Invalid token","code":4}"#), (200, "{}")]);
        let (_t, p) = spool(&[ev("yara_match", "malware"), ev("scan_summary", "file")]);
        let before = fs::read_to_string(&p).unwrap();
        let d = deliver(&p, &hec(&m.url));
        assert_eq!((d.delivery_status.as_str(), d.events_sent, d.delivery_attempt_count), ("failed", 0, 1));
        assert_eq!(d.error_type.as_deref(), Some("hec_authentication_failed"));
        assert_eq!(d.retryable, Some(false));
        assert_eq!(fs::read_to_string(&p).unwrap(), before, "spool untouched");
        assert_eq!(read_delivery(&p).unwrap(), d, "state persisted");
    }

    #[test]
    fn transient_errors_are_retried_then_succeed() {
        let m = mock(vec![(503, r#"{"text":"Server is busy","code":9}"#), (500, ""), (200, "{}")]);
        let (_t, p) = spool(&[ev("scan_summary", "file")]);
        let d = deliver(&p, &hec(&m.url));
        assert_eq!((d.delivery_status.as_str(), d.delivery_attempt_count), ("delivered", 3));
    }

    #[test]
    fn unreachable_server_fails_retryably_and_resumes_later() {
        // nothing listens on this port
        let dead = { let l = TcpListener::bind("127.0.0.1:0").unwrap(); format!("http://{}", l.local_addr().unwrap()) };
        let (_t, p) = spool(&[ev("yara_match", "malware"), ev("scan_summary", "file")]);
        let d = deliver(&p, &hec(&dead));
        assert_eq!((d.delivery_status.as_str(), d.error_type.as_deref(), d.retryable), ("failed", Some("connection_failed"), Some(true)));
        assert_eq!(d.delivery_attempt_count, 4, "bounded retries");

        let m = mock(vec![(200, "{}")]);
        let d = deliver(&p, &hec(&m.url));
        assert_eq!((d.delivery_status.as_str(), d.events_sent), ("delivered", 2));
        // a third run sends nothing new
        let d = deliver(&p, &hec(&m.url));
        assert_eq!(d.events_sent, 2);
        assert_eq!(m.requests.lock().unwrap().len(), 1, "accepted events are never re-sent");
    }

    #[test]
    fn state_from_another_scan_is_never_reused() {
        let m = mock(vec![(200, "{}"), (200, "{}")]);
        let (_t, p) = spool(&[ev("yara_match", "malware"), ev("scan_summary", "file")]);
        assert_eq!(deliver(&p, &hec(&m.url)).events_sent, 2);
        // a new scan (different scan_id) writes a spool with the same name
        let mut a = ev("yara_match", "malware");
        a["scan_id"] = json!("s2");
        let mut b = ev("scan_summary", "file");
        b["scan_id"] = json!("s2");
        fs::write(&p, format!("{a}\n{b}\n")).unwrap();
        let d = deliver(&p, &hec(&m.url));
        assert_eq!((d.events_sent, d.scan_id.as_deref()), (2, Some("s2")));
        assert_eq!(m.requests.lock().unwrap().len(), 2, "the new scan's events were sent");
    }

    #[test]
    fn interrupted_scan_gets_an_honest_summary() {
        let m = mock(vec![(200, "{}")]);
        let (_t, p) = spool(&[ev("yara_match", "malware"), ev("scan_error", "file")]);
        let d = deliver(&p, &hec(&m.url));
        assert!(d.synthesized_summary);
        assert_eq!(d.events_sent, 3);
        let last: Value = serde_json::from_str(fs::read_to_string(&p).unwrap().lines().last().unwrap()).unwrap();
        assert_eq!((last["scan_status"].as_str(), last["event_outcome"].as_str()), (Some("interrupted"), Some("failure")));
        assert_eq!((last["scan_matches"].as_u64(), last["scan_files_failed"].as_u64()), (Some(1), Some(1)));
        assert_eq!(last["host"], "WEB01");
        assert!(interrupted_summary(&fs::read_to_string(&p).unwrap().lines().map(String::from).collect::<Vec<_>>()).is_none(),
                "only added once");
    }

    #[test]
    fn hec_errors_classify() {
        assert_eq!(classify(400, r#"{"text":"Incorrect index","code":7}"#), ("hec_incorrect_index", false));
        assert_eq!(classify(401, ""), ("hec_authentication_failed", false));
        assert_eq!(classify(400, r#"{"text":"Invalid data format","code":6}"#), ("hec_rejected_payload", false));
        assert_eq!(classify(503, ""), ("hec_server_unavailable", true));
    }

    #[test]
    fn endpoint_accepts_base_or_full_url() {
        let h = |u: &str| HecConfig::new(u, String::new(), None, false).endpoint("/services/collector/event");
        assert_eq!(h("https://s:8088"), "https://s:8088/services/collector/event");
        assert_eq!(h("https://s:8088/"), "https://s:8088/services/collector/event");
        assert_eq!(h("https://s:8088/services/collector/event"), "https://s:8088/services/collector/event");
    }
}
