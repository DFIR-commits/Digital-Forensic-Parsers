//! Archive subsystem — plugin-style formats around one scan context.
//!
//! `ArchiveFormat` implementations enumerate members and hand each one to
//! `ArchiveCtx::scan_member`, which centralizes ALL the policy: nested
//! archive recursion (depth-capped), in-memory vs. chunked scanning,
//! bomb budgets, hashing and hit emission.  A new format (ISO, VHDX, E01,
//! docker layer, ...) is one new impl added to `registry()` — the core
//! engine never changes.
//!
//! Everything is streamed: no temp files, no full-archive extraction, one
//! member buffer in flight per worker, reused across members.

use crate::config::{Config, ARCHIVE_SEP, IO_CHUNK, MAGIC_PROBE};
use crate::engine::Engine;
use crate::hashing::hash_slice;
use crate::metadata::enrich_member;
use crate::models::Hit;
use crate::stats::Stats;
use anyhow::{bail, Result};
use crossbeam_channel::Sender;
use std::io::Read;
use std::path::Path;
use std::sync::OnceLock;
use std::time::Instant;

pub mod formats;

// ---------------------------------------------------------------------------
// Plugin trait + registry
// ---------------------------------------------------------------------------

pub enum ArchiveInput<'a> {
    /// Top-level archive on disk (seekable).
    File(&'a Path),
    /// Nested archive buffered in memory.
    Bytes(&'a [u8]),
}

pub trait ArchiveFormat: Send + Sync {
    fn format_name(&self) -> &'static str;
    /// Extension claim; compound extensions (".tar.gz") must be claimed by
    /// the more specific format, which wins by registry order.
    fn claims_name(&self, name: &str) -> bool;
    /// Magic-byte claim for mislabeled files.
    fn claims_magic(&self, header: &[u8]) -> bool;
    /// Enumerate members, calling `ctx.scan_member` for each.
    fn scan(&self, input: ArchiveInput, chain: &str, ctx: &mut ArchiveCtx)
            -> Result<()>;
}

static REGISTRY: OnceLock<Vec<Box<dyn ArchiveFormat>>> = OnceLock::new();

pub fn registry() -> &'static [Box<dyn ArchiveFormat>] {
    REGISTRY.get_or_init(formats::builtin_formats)
}

pub fn find_format(name: &str, header: &[u8]) -> Option<&'static dyn ArchiveFormat> {
    let reg = registry();
    reg.iter().find(|f| f.claims_name(name))
        .or_else(|| if header.is_empty() { None }
                 else { reg.iter().find(|f| f.claims_magic(header)) })
        .map(|b| b.as_ref())
}

pub fn is_archive_name(name: &str) -> bool {
    registry().iter().any(|f| f.claims_name(name))
}

pub fn is_archive_magic(header: &[u8]) -> bool {
    registry().iter().any(|f| f.claims_magic(header))
}

// ---------------------------------------------------------------------------
// Bomb budget
// ---------------------------------------------------------------------------

struct Budget {
    remaining: u64,
    inflated: u64,
    compressed: u64,
    ratio_cap: u64,
}

impl Budget {
    fn new(cfg: &Config, compressed: u64) -> Self {
        Budget {
            remaining: cfg.max_archive_output,
            inflated: 0,
            compressed: compressed.max(1),
            ratio_cap: cfg.max_compression_ratio,
        }
    }

    fn consume(&mut self, n: u64, context: &str) -> Result<()> {
        self.inflated += n;
        if n > self.remaining {
            bail!("archive output cap exceeded at {context:?}");
        }
        self.remaining -= n;
        // Ratio check only once enough data flowed to be meaningful.
        if self.inflated > 64 * 1024 * 1024
            && self.inflated / self.compressed > self.ratio_cap {
            bail!("compression-ratio bomb at {context:?} \
                   ({}/{} bytes)", self.inflated, self.compressed);
        }
        Ok(())
    }
}

/// Result of attempting to buffer a nested archive for recursion.
enum Buffered {
    /// Whole member fit in memory — safe to recurse.
    Complete(Vec<u8>),
    /// Exceeded `max_member_size`; contains everything read so far, which
    /// the caller must still scan (chained with the rest of the reader).
    TooBig(Vec<u8>),
}

// ---------------------------------------------------------------------------
// Scan context
// ---------------------------------------------------------------------------

pub struct ArchiveCtx<'w, 'r> {
    cfg: &'w Config,
    stats: &'w Stats,
    scanner: &'w mut yara_x::Scanner<'r>,
    hit_tx: &'w Sender<Hit>,
    disk_path: String,
    depth: u32,
    budget: Budget,
    /// Reusable member buffer — grows to the largest member seen, then
    /// steady-state zero allocations across thousands of members.
    member_buf: Vec<u8>,
}

/// Top-level entry: scan the on-disk archive at `path`.
/// All errors are contained here — a corrupt archive is logged + counted,
/// never propagated to the worker loop.
pub fn scan_archive_file(cfg: &Config, stats: &Stats,
                         scanner: &mut yara_x::Scanner,
                         hit_tx: &Sender<Hit>, path: &Path, size: u64) {
    let name = path.to_string_lossy().into_owned();
    let header = read_probe(path);
    let Some(format) = find_format(&name, &header) else { return };

    stats.add_archive();
    let mut ctx = ArchiveCtx {
        cfg,
        stats,
        scanner,
        hit_tx,
        disk_path: name.clone(),
        depth: 1,
        budget: Budget::new(cfg, size),
        member_buf: Vec::new(),
    };
    if let Err(e) = format.scan(ArchiveInput::File(path), &name, &mut ctx) {
        log::warn!("archive error in {name}: {e}");
        stats.unreadable("archive", &name, &e);
    }
}

fn read_probe(path: &Path) -> Vec<u8> {
    let mut buf = vec![0u8; MAGIC_PROBE];
    match std::fs::File::open(path).and_then(|mut f| {
        let mut total = 0;
        while total < buf.len() {
            let n = f.read(&mut buf[total..])?;
            if n == 0 { break; }
            total += n;
        }
        Ok(total)
    }) {
        Ok(n) => { buf.truncate(n); buf }
        Err(_) => Vec::new(),
    }
}

impl<'w, 'r> ArchiveCtx<'w, 'r> {
    /// Scan one member.  `vchain` is the virtual path so far including this
    /// member (e.g. `/e/logs.zip::apache/access.log`), `size_hint` is the
    /// declared uncompressed size (None if unknown — streaming formats).
    ///
    /// Policy, in order:
    /// 1. nested archive & depth allows -> buffer (capped) and recurse;
    /// 2. fits `max_member_size`        -> in-memory scan (reused buffer);
    /// 3. otherwise                     -> fixed-memory chunked scan.
    ///
    /// Per-member errors are contained: one bad member never hides its
    /// siblings.
    pub fn scan_member(&mut self, vchain: &str, member_name: &str,
                       size_hint: Option<u64>, reader: &mut dyn Read) {
        if let Err(e) = self.scan_member_inner(vchain, member_name,
                                               size_hint, reader) {
            // Budget violations abort the whole archive by bubbling a
            // distinguishable error; ordinary member errors just log.
            self.stats.unreadable("member", &vchain, &e);
        }
    }

    fn scan_member_inner(&mut self, vchain: &str, member_name: &str,
                         size_hint: Option<u64>, reader: &mut dyn Read)
                         -> Result<()> {
        let t0 = Instant::now();

        // Probe for nested-archive detection (counted against the budget).
        let mut head = vec![0u8; MAGIC_PROBE];
        let n = read_some(reader, &mut head)?;
        head.truncate(n);
        self.budget.consume(n as u64, vchain)?;

        // ---- nested archive? ------------------------------------------
        if self.cfg.scan_archives
            && find_format(member_name, &head).is_some() {
            if self.depth >= self.cfg.max_archive_depth {
                log::debug!("max archive depth at {vchain}; scanning raw");
                // fall through: scan the member's raw bytes instead
            } else {
                match self.buffer_member(&head, reader, vchain)? {
                    Buffered::Complete(buf) => {
                        // recurse into the fully-buffered nested archive
                        self.stats.add_archive();
                        self.depth += 1;
                        let fmt = find_format(member_name, &head).unwrap();
                        let res = fmt.scan(ArchiveInput::Bytes(&buf),
                                           vchain, self);
                        self.depth -= 1;
                        if let Err(e) = res {
                            self.stats.unreadable("archive", &vchain, &e);
                        }
                        return Ok(());
                    }
                    Buffered::TooBig(partial) => {
                        // Too large to recurse: chunk-scan the raw bytes,
                        // chaining the already-buffered prefix so nothing
                        // is lost.
                        log::debug!("nested archive {vchain} exceeds member \
                                     cap; chunk-scanning raw bytes");
                        return self.chunked_scan(vchain, member_name,
                                                 partial, reader, t0);
                    }
                }
            }
        }

        // ---- ordinary member ------------------------------------------
        let fits = size_hint.map_or(false, |s| s <= self.cfg.max_member_size);
        if fits {
            // In-memory scan with the reusable buffer.
            self.member_buf.clear();
            self.member_buf.extend_from_slice(&head);
            drain_into(reader, &mut self.member_buf,
                       &mut self.budget, vchain)?;
            let buf = std::mem::take(&mut self.member_buf);
            let matches = Engine::scan_buf(self.scanner, &buf)?;
            let ms = t0.elapsed().as_secs_f64() * 1000.0;
            self.stats.add_file(buf.len() as u64,
                                t0.elapsed().as_micros() as u64, true);
            if !matches.is_empty() {
                self.emit_hits(matches, vchain, member_name,
                               buf.len() as u64, ms, Some(&buf));
            }
            self.member_buf = buf; // hand the buffer back for reuse
        } else {
            // Unknown or huge size: fixed-memory overlapping-window scan.
            return self.chunked_scan(vchain, member_name, head, reader, t0);
        }
        Ok(())
    }

    /// Fixed-memory overlapping-window scan of `prefix` + remaining reader.
    /// `prefix` bytes were already budget-counted by the caller.
    fn chunked_scan(&mut self, vchain: &str, member_name: &str,
                    prefix: Vec<u8>, reader: &mut dyn Read, t0: Instant)
                    -> Result<()> {
        let prefix_len = prefix.len() as u64;
        let budget = &mut self.budget;
        let vchain_owned = vchain.to_string();
        let chained = prefix.as_slice().chain(&mut *reader);
        let mut streamed: u64 = 0;
        let (matches, consumed) = Engine::scan_chunked(
            self.scanner, chained, IO_CHUNK,
            |n| {
                // Only bytes beyond the (already-counted) prefix hit the budget.
                let new = (streamed + n as u64).saturating_sub(prefix_len)
                    .min(n as u64);
                streamed += n as u64;
                if new > 0 { budget.consume(new, &vchain_owned) } else { Ok(()) }
            })?;
        let ms = t0.elapsed().as_secs_f64() * 1000.0;
        self.stats.add_file(consumed, t0.elapsed().as_micros() as u64, true);
        if !matches.is_empty() {
            // Hashing would need a second full decompression pass over a
            // member too large to buffer — skipped by design.
            self.emit_hits(matches, vchain, member_name, consumed, ms,
                           None);
        }
        Ok(())
    }

    /// Buffer a nested archive up to `max_member_size` for seekable
    /// recursion.  Returns the partial buffer on overflow so the caller can
    /// chain it into a raw chunked scan — no bytes are ever dropped.
    fn buffer_member(&mut self, head: &[u8], reader: &mut dyn Read,
                     vchain: &str) -> Result<Buffered> {
        let cap = self.cfg.max_member_size as usize;
        let mut buf = Vec::with_capacity(head.len().max(64 * 1024));
        buf.extend_from_slice(head);
        let mut chunk = vec![0u8; IO_CHUNK];
        loop {
            let n = read_some(reader, &mut chunk)?;
            if n == 0 {
                return Ok(Buffered::Complete(buf));
            }
            self.budget.consume(n as u64, vchain)?;
            buf.extend_from_slice(&chunk[..n]);
            if buf.len() > cap {
                return Ok(Buffered::TooBig(buf));
            }
        }
    }

    fn emit_hits(&self, matches: Vec<crate::engine::OwnedMatch>, vchain: &str,
                 member_name: &str, size: u64, ms: f64, data: Option<&[u8]>) {
        let internal = vchain
            .split_once(ARCHIVE_SEP)
            .map(|(_, rest)| rest.to_string())
            .unwrap_or_default();
        let hits = Engine::build_hits(matches, vchain, &internal, size, ms);
        let hashes = data.map(hash_slice);
        let n = hits.len() as u64;
        for mut hit in hits {
            hit.archive = Some(self.disk_path.clone());
            hit.internal_path = Some(internal.clone());
            hit.full_path = Some(vchain.to_string());
            if let Some((sha, md5)) = &hashes {
                hit.sha256 = sha.clone();
                hit.md5 = md5.clone();
            }
            enrich_member(&mut hit, member_name,
                          data.map(|d| &d[..d.len().min(4096)]).unwrap_or(&[]));
            let _ = self.hit_tx.send(hit);
        }
        self.stats.add_matches(n);
    }
}

// ---------------------------------------------------------------------------

fn read_some(r: &mut dyn Read, buf: &mut [u8]) -> std::io::Result<usize> {
    let mut total = 0;
    while total < buf.len() {
        match r.read(&mut buf[total..]) {
            Ok(0) => break,
            Ok(n) => total += n,
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(e) => return Err(e),
        }
    }
    Ok(total)
}

fn drain_into(r: &mut dyn Read, out: &mut Vec<u8>, budget: &mut Budget,
              ctx_name: &str) -> Result<u64> {
    let mut chunk = vec![0u8; IO_CHUNK];
    let mut total = 0u64;
    loop {
        let n = read_some(r, &mut chunk)?;
        if n == 0 {
            return Ok(total);
        }
        budget.consume(n as u64, ctx_name)?;
        out.extend_from_slice(&chunk[..n]);
        total += n as u64;
    }
}
