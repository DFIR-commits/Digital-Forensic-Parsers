//! yarax-scanner library root.
//!
//! `run()` wires the pipeline and is callable from tests and the binary:
//!
//! ```text
//! walker (1 thread) ──bounded channel──▶ workers × N ──channel──▶ writer (1 thread)
//!                                            │
//!                                       ArchiveCtx (streaming, recursive)
//! ```

// The event schema is built with large `json!` literals (src/events.rs).
#![recursion_limit = "512"]

pub mod archives;
pub mod config;
pub mod engine;
pub mod events;
pub mod gui_core;
pub mod hashing;
pub mod iris;
pub mod metadata;
pub mod models;
pub mod progress;
pub mod rulecheck;
pub mod splunk;
pub mod stats;
pub mod utils;
pub mod walker;
pub mod worker;
pub mod writer;

use crate::config::Config;
use crate::engine::Engine;
use crate::events::{EventContext, EventLog, SummaryCounts};
use crate::stats::{Snapshot, Stats};
use crate::utils::{human_bytes, now_iso};
use anyhow::Result;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Instant;

pub fn run(cfg: &Config) -> Result<Snapshot> {
    let t0 = Instant::now();
    let mut ctx = EventContext::new(cfg);

    // Compile rules ONCE, before any thread exists.
    let engine = match Engine::load(cfg) {
        Ok(e) => e,
        Err(e) => {
            record_failed_scan(cfg, ctx, &e, t0);
            return Err(e);
        }
    };
    ctx.rules = engine.sources.clone();

    // Event stream next to the report (no report file = no event file).
    let (events, local_ctx) = match cfg.output.as_deref() {
        Some(r) => match EventLog::create(r, ctx) {
            Ok(log) => (Some(Arc::new(log)), None),
            Err(e) => anyhow::bail!("cannot create {}: {e}", events::events_path(r).display()),
        },
        None => (None, Some(ctx)),
    };
    if let Some(ev) = &events {
        ev.rule_definitions(&engine.rule_definitions());
        for (file, msg) in &engine.sources.skipped {
            ev.rule_error(&file.to_string_lossy(), msg, false);
        }
    }

    let mut stats = Stats::with_unreadable_log(cfg.output.as_deref());
    stats.events = events.clone();
    let stats = Arc::new(stats);
    let stop_progress = Arc::new(AtomicBool::new(false));

    // Bounded MPMC work queue: backpressure keeps memory flat.
    let (task_tx, task_rx) = crossbeam_channel::bounded(cfg.queue_depth);
    // Hit channel to the writer; bounded so a hit storm can't balloon RAM.
    let (hit_tx, hit_rx) = crossbeam_channel::bounded(10_000);

    let (sink, hit_count) = std::thread::scope(|s| -> Result<_> {
        // Writer thread: owns the output sink, returns it for finalize.
        let events_ref = events.as_deref();
        let writer_handle = s.spawn(move || writer::write_hits(cfg, hit_rx, events_ref));

        // Worker threads: each owns a Scanner borrowing the shared rules.
        let mut workers = Vec::with_capacity(cfg.threads);
        for _ in 0..cfg.threads {
            let rx = task_rx.clone();
            let tx = hit_tx.clone();
            let engine_ref = &engine;
            let stats_ref = &stats;
            workers.push(s.spawn(move || {
                worker::run_worker(cfg, engine_ref, rx, tx, stats_ref);
            }));
        }
        // Scope's own clones must drop so disconnects propagate.
        drop(task_rx);
        drop(hit_tx);

        // Progress thread.
        {
            let stats = Arc::clone(&stats);
            let stop = Arc::clone(&stop_progress);
            let quiet = cfg.quiet;
            s.spawn(move || {
                if !quiet {
                    progress::run_progress(stats, stop, 0);
                }
            });
        }

        // Walker runs on this thread — it's the producer; when it returns,
        // task_tx drops, the channel disconnects, and workers drain + exit.
        walker::walk(cfg, task_tx, &stats);

        for w in workers {
            let _ = w.join();
        }
        // All hit_tx clones are gone now -> writer sees disconnect.
        stop_progress.store(true, Ordering::Relaxed);
        writer_handle.join().expect("writer thread panicked")
    })?;

    let elapsed = t0.elapsed().as_secs_f64();
    let snap = stats.snapshot();
    let end_iso = now_iso();
    let ctx_ref = events.as_ref().map(|e| &e.ctx).or(local_ctx.as_ref()).expect("one context");
    let info = writer::build_scan_information(cfg, ctx_ref, &snap, end_iso.clone(), elapsed);
    writer::finalize(sink, &info)?;

    if let Some(ev) = &events {
        let unreadable = ev.unreadable.load(std::sync::atomic::Ordering::Relaxed);
        ev.summary(&SummaryCounts {
            status: if snap.errors == 0 { "completed" } else { "completed_with_errors" },
            error: None,
            completed: Some(end_iso),
            duration_ms: Some((elapsed * 1000.0) as u64),
            files_examined: snap.files_scanned,
            bytes_examined: snap.bytes_scanned,
            files_failed: unreadable,
            files_skipped: snap.skipped,
            errors: snap.errors,
            matches: snap.matches,
            recursion: cfg.recursive,
            follow_symlinks: cfg.follow_links,
            max_file_size: (cfg.max_file_size > 0).then_some(cfg.max_file_size),
            exclusions: events::exclusions(cfg),
        });
    }

    if !cfg.quiet {
        eprintln!(
            "scanned {} files ({}) in {:.1}s -> {:.1} MB/s, {} hits ({} written), {} errors",
            snap.files_scanned, human_bytes(snap.bytes_scanned as f64),
            elapsed, info.scan_rate_mb_per_second, snap.matches, hit_count,
            snap.errors);
    }
    if let Some(p) = stats.unreadable_written() {
        eprintln!("unreadable items listed in {}", p.display());
    }
    if let Some(ev) = &events {
        send_to_splunk(cfg, ev.path());
    }
    Ok(snap)
}

/// Rules did not compile: the scan never ran. Record that as events (and
/// send them) so a failed scan is visible, not just absent, in Splunk.
fn record_failed_scan(cfg: &Config, mut ctx: EventContext, err: &anyhow::Error, t0: Instant) {
    let Some(report) = cfg.output.as_deref() else { return };
    ctx.rules = Default::default();
    let Ok(ev) = EventLog::create(report, ctx) else { return };
    let msg = format!("{err:#}");
    ev.rule_error(&ev.ctx.ruleset_name.clone(), &msg, true);
    ev.summary(&SummaryCounts {
        status: "failed",
        error: Some(msg),
        completed: Some(now_iso()),
        duration_ms: Some(t0.elapsed().as_millis() as u64),
        recursion: cfg.recursive,
        follow_symlinks: cfg.follow_links,
        max_file_size: (cfg.max_file_size > 0).then_some(cfg.max_file_size),
        exclusions: events::exclusions(cfg),
        ..Default::default()
    });
    send_to_splunk(cfg, ev.path());
}

/// Deliver the event file if --splunk-url was given. Delivery problems are
/// reported, never fatal: the events stay on disk for --splunk-send.
fn send_to_splunk(cfg: &Config, events_file: &std::path::Path) {
    let Some(hec) = &cfg.splunk else { return };
    let d = splunk::deliver(events_file, hec);
    eprintln!("SPLUNK status={} sent={}/{} attempts={}{}", d.delivery_status, d.events_sent,
              d.events_total, d.delivery_attempt_count,
              d.error_message.map(|m| format!(" error={m}")).unwrap_or_default());
}
