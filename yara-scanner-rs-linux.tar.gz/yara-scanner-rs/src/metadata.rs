//! Hit enrichment — runs **only on matches**, never on the miss path.

use crate::config::SAMPLE_LEN;
use crate::models::Hit;
use crate::utils::{iso_time, shannon_entropy};
use std::fs;
use std::path::Path;
use std::time::SystemTime;

const ARCHIVE_EXTS: [&str; 11] = [".zip", ".gz", ".tgz", ".tar", ".bz2",
                                  ".xz", ".7z", ".rar", ".cab", ".jar", ".war"];

pub fn looks_like_archive(name: &str) -> bool {
    let low = name.to_ascii_lowercase();
    ARCHIVE_EXTS.iter().any(|e| low.ends_with(e))
}

fn base_name(path: &str) -> &str {
    path.rsplit(['/', '\\']).next().unwrap_or(path)
}

/// Enrich a hit for an on-disk file; `sample` is the first bytes of the file
/// (borrowed from the scan buffer/mmap — no extra read). `before` is the
/// (size, mtime) the walker saw before the file was read.
///
/// Timestamp semantics (see docs/SPLUNK.md):
/// * created: birth time (Windows creation time / Linux statx btime). Left
///   empty when the OS or filesystem does not expose it - never filled with
///   mtime or ctime.
/// * metadata_changed: POSIX ctime (inode change). Not exposed by the Rust
///   std API on Windows, so empty there.
pub fn enrich_disk(hit: &mut Hit, path: &Path, sample: &[u8],
                   before: (u64, Option<SystemTime>)) {
    hit.modified_time_before_scan = before.1.map(iso_time);
    match fs::metadata(path) {
        Ok(md) => {
            hit.modified_time = md.modified().ok().map(iso_time);
            hit.accessed_time = md.accessed().ok().map(iso_time);
            hit.created_time = md.created().ok().map(iso_time);
            hit.changed_during_scan = Some(md.len() != before.0
                || (before.1.is_some() && md.modified().ok() != before.1));
            #[cfg(unix)]
            {
                use std::os::unix::fs::MetadataExt;
                let ctime = SystemTime::UNIX_EPOCH
                    + std::time::Duration::new(md.ctime().max(0) as u64, md.ctime_nsec().max(0) as u32);
                hit.metadata_changed_time = Some(iso_time(ctime));
                hit.is_executable = md.mode() & 0o111 != 0;
                hit.file_attributes = vec![format!("mode:{:04o}", md.mode() & 0o7777)];
            }
            #[cfg(windows)]
            {
                use std::os::windows::fs::MetadataExt;
                let a = md.file_attributes();
                hit.file_attributes = windows_attributes(a);
                hit.is_hidden = a & 0x2 != 0;
            }
            hit.is_readonly = Some(md.permissions().readonly());
            // ntfs-3g (FUSE, "fuseblk") has no statx birth time, but keeps
            // the NTFS $STANDARD_INFORMATION times in an xattr.
            #[cfg(target_os = "linux")]
            if hit.created_time.is_none() {
                if let Some(si) = ntfs3g_times(path) {
                    hit.created_time = si.created.map(iso_time);
                    hit.timestamp_source = Some(
                        "linux:statx; created from ntfs-3g system.ntfs_times ($STANDARD_INFORMATION)".into());
                }
            }
            let complete = hit.modified_time.is_some() && hit.accessed_time.is_some()
                && hit.created_time.is_some() && hit.metadata_changed_time.is_some();
            hit.timestamp_status = if complete { "collected" } else { "partial" }.into();
        }
        Err(e) => hit.timestamp_status = format!("failed: {e}"),
    }
    let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
    hit.is_hidden |= name.starts_with('.');
    hit.is_archive = looks_like_archive(name);
    enrich_sample(hit, sample);
}

/// Enrich a hit for an archive member from its in-memory bytes. Members
/// have no filesystem timestamps of their own (archive header times are
/// not read).
pub fn enrich_member(hit: &mut Hit, member_name: &str, sample: &[u8]) {
    hit.is_hidden = base_name(member_name).starts_with('.');
    hit.is_archive = looks_like_archive(member_name);
    hit.timestamp_status = "unsupported_archive_member".into();
    enrich_sample(hit, sample);
}

fn enrich_sample(hit: &mut Hit, sample: &[u8]) {
    let s = &sample[..sample.len().min(SAMPLE_LEN)];
    hit.entropy = shannon_entropy(s);
    if let Some(kind) = infer::get(s) {
        hit.magic = Some(kind.extension().to_string());
        hit.mime_type = Some(kind.mime_type().to_string());
        // PE / ELF / Mach-O etc. by content, not by name or mode bits.
        hit.is_executable |= kind.matcher_type() == infer::MatcherType::App;
    }
}

/// NTFS $STANDARD_INFORMATION times as ntfs-3g exposes them.
#[derive(Debug, PartialEq)]
pub struct NtfsTimes {
    pub created: Option<SystemTime>,
    pub modified: Option<SystemTime>,
    pub accessed: Option<SystemTime>,
    pub mft_changed: Option<SystemTime>,
}

/// `system.ntfs_times`: four little-endian FILETIMEs (100 ns since 1601):
/// creation, modification, access, MFT record change. 0 = not set.
pub fn parse_ntfs_times(b: &[u8]) -> Option<NtfsTimes> {
    const EPOCH_DIFF_100NS: u64 = 116_444_736_000_000_000; // 1601 -> 1970
    let ft = |i: usize| -> Option<SystemTime> {
        let v = u64::from_le_bytes(b.get(i * 8..i * 8 + 8)?.try_into().ok()?);
        if v == 0 { return None; }
        let rel = |d: u64| std::time::Duration::new(d / 10_000_000, (d % 10_000_000) as u32 * 100);
        if v >= EPOCH_DIFF_100NS { SystemTime::UNIX_EPOCH.checked_add(rel(v - EPOCH_DIFF_100NS)) }
        else { SystemTime::UNIX_EPOCH.checked_sub(rel(EPOCH_DIFF_100NS - v)) }
    };
    (b.len() == 32).then(|| NtfsTimes { created: ft(0), modified: ft(1), accessed: ft(2), mft_changed: ft(3) })
}

/// One getxattr; fails (None) on anything that is not an ntfs-3g mount.
#[cfg(target_os = "linux")]
fn ntfs3g_times(path: &Path) -> Option<NtfsTimes> {
    use std::os::unix::ffi::OsStrExt;
    let p = std::ffi::CString::new(path.as_os_str().as_bytes()).ok()?;
    let mut buf = [0u8; 32];
    // SAFETY: valid NUL-terminated strings and a buffer of the length passed.
    let n = unsafe { libc::getxattr(p.as_ptr(), c"system.ntfs_times".as_ptr(),
                                    buf.as_mut_ptr().cast(), buf.len()) };
    if n != 32 { return None; }
    parse_ntfs_times(&buf)
}

#[cfg(windows)]
fn windows_attributes(a: u32) -> Vec<String> {
    const NAMES: [(u32, &str); 12] = [
        (0x1, "readonly"), (0x2, "hidden"), (0x4, "system"), (0x10, "directory"),
        (0x20, "archive"), (0x80, "normal"), (0x100, "temporary"), (0x200, "sparse"),
        (0x400, "reparse_point"), (0x800, "compressed"), (0x1000, "offline"), (0x4000, "encrypted"),
    ];
    NAMES.iter().filter(|(bit, _)| a & bit != 0).map(|(_, n)| n.to_string()).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn change_during_scan_is_detected() {
        let t = tempfile::tempdir().unwrap();
        let f = t.path().join("a.bin");
        fs::write(&f, b"0123456789").unwrap();
        let md = fs::metadata(&f).unwrap();
        let mut h = Hit::new("r".into(), "n".into(), f.to_string_lossy().into(), "a.bin".into(), 10);

        enrich_disk(&mut h, &f, b"0123", (md.len(), md.modified().ok()));
        assert_eq!(h.changed_during_scan, Some(false));
        assert!(h.modified_time_before_scan.is_some());
        assert!(h.timestamp_status == "collected" || h.timestamp_status == "partial");

        // the walker saw a different size: the file changed between walk and scan
        enrich_disk(&mut h, &f, b"0123", (4, md.modified().ok()));
        assert_eq!(h.changed_during_scan, Some(true));

        // file gone after the scan: no timestamps, and that is stated
        fs::remove_file(&f).unwrap();
        let mut gone = Hit::new("r".into(), "n".into(), "x".into(), "x".into(), 1);
        enrich_disk(&mut gone, &f, b"", (1, None));
        assert!(gone.timestamp_status.starts_with("failed"));
        assert!(gone.modified_time.is_none() && gone.created_time.is_none());
    }

    #[test]
    fn ntfs_times_decode() {
        // 2023-11-14T22:13:20.1234567Z as a FILETIME, then 0 (unset), then 1601-01-01
        let ft: u64 = 116_444_736_000_000_000 + 1_700_000_000 * 10_000_000 + 1_234_567;
        let mut b = Vec::new();
        for v in [ft, ft, 0, 1] { b.extend_from_slice(&u64::to_le_bytes(v)); }
        let t = parse_ntfs_times(&b).unwrap();
        assert_eq!(t.created.map(iso_time).as_deref(), Some("2023-11-14T22:13:20.123456700Z"));
        assert_eq!(t.created, t.modified);
        assert_eq!(t.accessed, None, "0 means unset, not 1601");
        assert!(t.mft_changed.unwrap() < SystemTime::UNIX_EPOCH, "pre-1970 survives");
        assert_eq!(parse_ntfs_times(&b[..31]), None);
    }

    #[test]
    fn created_is_never_backfilled_from_ctime_or_mtime() {
        let t = tempfile::tempdir().unwrap();
        let f = t.path().join("b.txt");
        fs::write(&f, b"x").unwrap();
        let md = fs::metadata(&f).unwrap();
        let mut h = Hit::new("r".into(), "n".into(), f.to_string_lossy().into(), "b".into(), 1);
        enrich_disk(&mut h, &f, b"x", (1, md.modified().ok()));
        // created comes only from the OS birth time, or stays None
        assert_eq!(h.created_time, md.created().ok().map(iso_time));
        #[cfg(windows)]
        assert!(h.metadata_changed_time.is_none(), "ctime is not exposed on Windows");
        #[cfg(unix)]
        assert!(h.metadata_changed_time.is_some());
    }
}
