//! Streaming directory enumerator (single producer thread).
//!
//! * Iterative explicit-stack traversal: no recursion limits, no generator
//!   frames, constant memory.
//! * Sends into a **bounded** crossbeam channel — backpressure instead of
//!   buffering paths, so RSS is flat on 20M-file trees.
//! * `DirEntry::file_type()` is free on Linux (comes from `readdir`'s
//!   `d_type`), so non-files are skipped without a `stat`.  One `metadata`
//!   call per candidate file fetches size (needed for routing + limits) —
//!   that stat would be paid later anyway; doing it here means workers
//!   never touch the filesystem before the actual read.
//! * Symlink-loop protection via `(dev, ino)` set, only when following links.

use crate::config::Config;
use crate::models::FileTask;
use crate::stats::Stats;
use crossbeam_channel::Sender;
use std::collections::HashSet;
use std::fs;
use std::path::{Path, PathBuf};

pub fn walk(cfg: &Config, tx: Sender<FileTask>, stats: &Stats) {
    let root = &cfg.path;
    if root.is_file() {
        let size = fs::metadata(root).map(|m| m.len()).unwrap_or(0);
        emit(cfg, &tx, root.clone(), size);
        return; // tx dropped => workers see disconnect
    }

    let mut stack: Vec<PathBuf> = vec![root.clone()];
    #[cfg(unix)]
    let mut seen_dirs: HashSet<(u64, u64)> = HashSet::new();
    #[cfg(not(unix))]
    let mut seen_dirs: HashSet<PathBuf> = HashSet::new();

    while let Some(dir) = stack.pop() {
        stats.add_dir(&dir.to_string_lossy());
        let iter = match fs::read_dir(&dir) {
            Ok(it) => it,
            Err(e) => {
                stats.unreadable("dir", &dir.to_string_lossy(), &e);
                continue;
            }
        };

        for entry in iter {
            let entry = match entry {
                Ok(e) => e,
                Err(e) => { stats.unreadable("dir", &dir.to_string_lossy(), &e); continue; }
            };
            let path = entry.path();
            let ftype = match entry.file_type() {
                Ok(t) => t,
                Err(e) => { stats.unreadable("stat", &entry.path().to_string_lossy(), &e); continue; }
            };

            if ftype.is_dir() || (ftype.is_symlink() && cfg.follow_links
                                  && path.is_dir()) {
                if !cfg.recursive || excluded(cfg, &path) {
                    continue;
                }
                if cfg.follow_links && ftype.is_symlink() {
                    if !mark_dir_seen(&path, &mut seen_dirs) {
                        continue; // loop
                    }
                }
                stack.push(path);
                continue;
            }
            if ftype.is_symlink() && !cfg.follow_links {
                continue;
            }
            if !ftype.is_file() && !(ftype.is_symlink() && cfg.follow_links) {
                continue; // fifo / socket / device
            }

            if excluded(cfg, &path) || !included(cfg, &path) || !ext_ok(cfg, &path) {
                continue;
            }

            let size = match entry.metadata() {
                Ok(m) if m.is_file() => m.len(),
                Ok(_) => match fs::metadata(&path) { // symlink -> target
                    Ok(m) if m.is_file() => m.len(),
                    _ => continue,
                },
                Err(e) => {
                    stats.unreadable("stat", &path.to_string_lossy(), &e);
                    continue;
                }
            };
            emit(cfg, &tx, path, size);
        }
    }
    // tx drops here: channel disconnects, workers drain and exit.
}

#[inline]
fn emit(cfg: &Config, tx: &Sender<FileTask>, path: PathBuf, size: u64) {
    if cfg.max_file_size > 0 && size > cfg.max_file_size && cfg.skip_large_files {
        log::debug!("skip large file {} ({size} bytes)", path.display());
        return;
    }
    // Blocks when the queue is full — that IS the backpressure design.
    let _ = tx.send(FileTask { path, size });
}

#[inline]
fn excluded(cfg: &Config, path: &Path) -> bool {
    cfg.exclude.as_ref().is_some_and(|g| g.is_match(path))
}

#[inline]
fn included(cfg: &Config, path: &Path) -> bool {
    match &cfg.include {
        None => true,
        Some(g) => g.is_match(path),
    }
}

#[inline]
fn ext_ok(cfg: &Config, path: &Path) -> bool {
    if cfg.extensions.is_empty() {
        return true;
    }
    let name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");
    let low = name.to_ascii_lowercase();
    cfg.extensions.iter().any(|e| low.ends_with(e.as_str()))
}

#[cfg(unix)]
fn mark_dir_seen(path: &Path, seen: &mut HashSet<(u64, u64)>) -> bool {
    use std::os::unix::fs::MetadataExt;
    match fs::metadata(path) {
        Ok(m) => seen.insert((m.dev(), m.ino())),
        Err(_) => false,
    }
}

#[cfg(not(unix))]
fn mark_dir_seen(path: &Path, seen: &mut HashSet<PathBuf>) -> bool {
    match fs::canonicalize(path) {
        Ok(c) => seen.insert(c),
        Err(_) => false,
    }
}
