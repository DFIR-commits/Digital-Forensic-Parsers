//! Scan configuration: CLI surface (clap derive) and compile-time tunables.
//!
//! One immutable `Config` is built at startup and shared by `&Config`
//! everywhere — no locks, no globals.

use clap::Parser;
use globset::{Glob, GlobSet, GlobSetBuilder};
use std::path::PathBuf;

// ---------------------------------------------------------------------------
// Tunables
// ---------------------------------------------------------------------------

/// Files at or below this size are read into a reusable per-worker buffer
/// (one `read()` beats mmap setup below ~1 MiB); larger files are mmapped.
pub const SMALL_FILE_THRESHOLD: u64 = 1024 * 1024;

/// Streaming I/O chunk (archive member draining, chunked scans).
pub const IO_CHUNK: usize = 4 * 1024 * 1024;

/// Overlap carried between windows when chunk-scanning unbounded streams so
/// matches spanning a boundary are not lost. Must exceed the longest match
/// your rules can produce.
pub const CHUNK_OVERLAP: usize = 64 * 1024;

/// Bytes sampled for entropy / magic on hits.
pub const SAMPLE_LEN: usize = 1024 * 1024;

/// Header bytes probed for archive magic detection.
pub const MAGIC_PROBE: usize = 512;

pub const SCHEMA_VERSION: &str = "1.0";
pub const SCANNER_VERSION: &str = env!("CARGO_PKG_VERSION");

/// Virtual-path separator: `/evidence/logs.zip::apache/access.log`
pub const ARCHIVE_SEP: &str = "::";

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------

#[derive(Parser, Debug)]
#[command(name = "yarax-scanner", version = SCANNER_VERSION,
          about = "Ultra high performance YARA-X scanner for forensic triage")]
pub struct Cli {
    /// Positional form: <directory_to_scan> <rules>
    #[arg(value_name = "PATH_AND_RULES")]
    pub positional: Vec<String>,

    /// Directory or file to scan
    #[arg(long)]
    pub path: Option<PathBuf>,

    /// Rules: compiled .yarc, a .yar source file, or a directory of rules.
    /// Repeat to scan with several rule bundles at once.
    #[arg(long)]
    pub rules: Vec<PathBuf>,

    /// Write JSON report here (default: stdout)
    #[arg(long, alias = "json")]
    pub output: Option<PathBuf>,

    /// Worker threads (default: logical CPUs)
    #[arg(long, default_value_t = 0)]
    pub threads: usize,

    /// Recurse into subdirectories
    #[arg(long, default_value_t = true, action = clap::ArgAction::Set)]
    pub recursive: bool,

    /// Follow symbolic links (loop-safe)
    #[arg(long)]
    pub follow_links: bool,

    /// Glob whitelist (repeatable)
    #[arg(long)]
    pub include: Vec<String>,

    /// Glob blacklist (repeatable)
    #[arg(long)]
    pub exclude: Vec<String>,

    /// Comma-separated extension filter, e.g. log,txt,json
    #[arg(long, default_value = "")]
    pub extensions: String,

    /// Size cap in bytes, accepts 500M / 2G (0 = unlimited)
    #[arg(long, default_value = "0", value_parser = parse_size)]
    pub max_file_size: u64,

    /// Silently skip files over --max-file-size
    #[arg(long)]
    pub skip_large_files: bool,

    /// Hash every scanned file, not only matches
    #[arg(long)]
    pub hash_all: bool,

    /// Per-file YARA timeout in seconds
    #[arg(long, default_value_t = 60)]
    pub timeout: u64,

    /// YARA global/external variable KEY=VALUE (repeatable)
    #[arg(long = "external", value_name = "KEY=VALUE")]
    pub externals: Vec<String>,

    // ---- archives ----
    /// Recurse into zip/tar/gz/bz2/xz archives
    #[arg(long, default_value_t = true, action = clap::ArgAction::Set)]
    pub scan_archives: bool,

    /// Nested-archive recursion limit
    #[arg(long, default_value_t = 3)]
    pub max_archive_depth: u32,

    /// In-memory cap per archive member (larger members are chunk-scanned)
    #[arg(long, default_value = "512M", value_parser = parse_size)]
    pub max_member_size: u64,

    /// Total inflated bytes allowed per top-level archive
    #[arg(long, default_value = "8G", value_parser = parse_size)]
    pub max_archive_output: u64,

    /// Inflated/compressed ratio bomb guard
    #[arg(long, default_value_t = 1000)]
    pub max_compression_ratio: u64,

    #[arg(long)]
    pub verbose: bool,

    #[arg(long)]
    pub quiet: bool,

    /// Compile every rule file separately, report ALL failures, then exit (no scan)
    #[arg(long)]
    pub check_rules: bool,

    /// Scan with the rule files that compile and list the ones skipped
    /// (default: one bad rule file aborts the scan)
    #[arg(long)]
    pub skip_invalid_rules: bool,
}

fn parse_size(s: &str) -> Result<u64, String> {
    let s = s.trim().to_uppercase();
    let (num, mult) = match s.chars().last() {
        Some('K') => (&s[..s.len() - 1], 1u64 << 10),
        Some('M') => (&s[..s.len() - 1], 1 << 20),
        Some('G') => (&s[..s.len() - 1], 1 << 30),
        Some('T') => (&s[..s.len() - 1], 1 << 40),
        _ => (s.as_str(), 1),
    };
    num.trim()
        .parse::<f64>()
        .map(|v| (v * mult as f64) as u64)
        .map_err(|e| format!("bad size {s:?}: {e}"))
}

// ---------------------------------------------------------------------------
// Resolved runtime configuration
// ---------------------------------------------------------------------------

pub struct Config {
    pub path: PathBuf,
    pub rules: Vec<PathBuf>,
    pub output: Option<PathBuf>,
    pub threads: usize,
    pub queue_depth: usize,
    pub recursive: bool,
    pub follow_links: bool,
    pub include: Option<GlobSet>,
    pub exclude: Option<GlobSet>,
    /// lowercase, dot-prefixed (".log")
    pub extensions: Vec<String>,
    pub max_file_size: u64,
    pub skip_large_files: bool,
    pub hash_all: bool,
    pub timeout_secs: u64,
    pub externals: Vec<(String, String)>,
    pub scan_archives: bool,
    pub max_archive_depth: u32,
    pub max_member_size: u64,
    pub max_archive_output: u64,
    pub max_compression_ratio: u64,
    pub verbose: bool,
    pub quiet: bool,
    pub skip_invalid_rules: bool,
}

impl Config {
    pub fn from_cli(mut cli: Cli) -> anyhow::Result<Self> {
        // Positional compatibility: scanner <dir> <rules>
        if cli.path.is_none() && !cli.positional.is_empty() {
            cli.path = Some(PathBuf::from(cli.positional.remove(0)));
        }
        if cli.rules.is_empty() && !cli.positional.is_empty() {
            cli.rules.push(PathBuf::from(cli.positional.remove(0)));
        }
        let path = cli.path.ok_or_else(|| anyhow::anyhow!(
            "scan path required: yarax-scanner PATH RULES or --path/--rules"))?;
        let rules = cli.rules;
        anyhow::ensure!(!rules.is_empty(), "rules required");

        let threads = if cli.threads == 0 { num_cpus::get() } else { cli.threads };

        let build_globs = |pats: &[String]| -> anyhow::Result<Option<GlobSet>> {
            if pats.is_empty() { return Ok(None); }
            let mut b = GlobSetBuilder::new();
            for p in pats { b.add(Glob::new(p)?); }
            Ok(Some(b.build()?))
        };

        let extensions = cli.extensions
            .split(',')
            .map(|e| e.trim().to_ascii_lowercase())
            .filter(|e| !e.is_empty())
            .map(|e| if e.starts_with('.') { e } else { format!(".{e}") })
            .collect();

        let externals = cli.externals.iter().map(|kv| {
            match kv.split_once('=') {
                Some((k, v)) => Ok((k.to_string(), v.to_string())),
                None => Err(anyhow::anyhow!("--external must be KEY=VALUE, got {kv:?}")),
            }
        }).collect::<anyhow::Result<Vec<_>>>()?;

        Ok(Config {
            path,
            rules,
            output: cli.output,
            threads,
            // Deep enough that workers never starve behind a slow directory,
            // shallow enough that queued tasks stay in cache and memory is flat.
            queue_depth: threads * 8,
            recursive: cli.recursive,
            follow_links: cli.follow_links,
            include: build_globs(&cli.include)?,
            exclude: build_globs(&cli.exclude)?,
            extensions,
            max_file_size: cli.max_file_size,
            skip_large_files: cli.skip_large_files,
            hash_all: cli.hash_all,
            timeout_secs: cli.timeout,
            externals,
            scan_archives: cli.scan_archives,
            max_archive_depth: cli.max_archive_depth,
            max_member_size: cli.max_member_size,
            max_archive_output: cli.max_archive_output,
            max_compression_ratio: cli.max_compression_ratio,
            verbose: cli.verbose,
            quiet: cli.quiet,
            skip_invalid_rules: cli.skip_invalid_rules,
        })
    }
}
