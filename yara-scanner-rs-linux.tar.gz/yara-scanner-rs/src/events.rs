//! Forensic event stream: `<report>.events.ndjson`, one JSON object per line.
//!
//! Written while the scan runs (flushed per line, so a crash or cancel keeps
//! everything emitted so far) and read back by `splunk::deliver`, which makes
//! this file the durable local spool for HEC delivery. Event types:
//!
//! * `rule_definition` - one per compiled rule, first (sourcetype yarax:rule)
//! * `yara_match`  - one per rule per file          (sourcetype yarax:detection)
//! * `scan_error`  - unreadable item or rule error  (yarax:unreadable / yarax:scan)
//! * `scan_summary`- last line of a finished scan   (yarax:scan)
//!
//! Every event carries the same common block. Fields that cannot be
//! collected are present as `null` - never omitted, never guessed. The schema
//! is documented field by field in docs/SPLUNK.md.

use crate::config::{Config, SCANNER_VERSION};
use crate::engine::{RuleDef, RuleSources};
use crate::models::Hit;
use crate::utils::{now_iso, sha256_hex, uuid_from};
use serde_json::{json, Map, Value};
use std::collections::HashSet;
use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Mutex;

pub const EVENT_SCHEMA_VERSION: &str = "1.0";
pub const ENGINE_VERSION: &str = env!("YARAX_ENGINE_VERSION");
/// String matches listed per detection event (the JSON report keeps all).
/// Small enough that a typical event stays under Splunk's 10 KB automatic
/// field-extraction window (limits.conf [kv] maxchars).
pub const MAX_EVENT_STRINGS: usize = 20;

/// `report.json` -> `report.events.ndjson`
pub fn events_path(report: &Path) -> PathBuf {
    report.with_extension("events.ndjson")
}

/// Scan-wide facts shared by every event, gathered once.
pub struct EventContext {
    pub scan_id: String,
    pub scan_started: String,
    /// Analyst-supplied target host name (`--target-host`). None = unknown:
    /// the scanner's own name is never substituted for the target.
    pub target_host: Option<String>,
    pub scanner_host_name: Option<String>,
    pub scanner_host_id: Option<String>,
    pub scan_target: String,
    pub scan_target_type: &'static str,
    pub scan_config_sha256: String,
    pub ruleset_name: String,
    pub rules: RuleSources,
    root: PathBuf,
    mounts: Vec<Mount>,
}

impl EventContext {
    pub fn new(cfg: &Config) -> Self {
        let scanner_host_name = hostname::get().ok().map(|h| h.to_string_lossy().into_owned());
        let started = now_iso();
        let nanos = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_nanos()).unwrap_or(0);
        EventContext {
            scan_id: uuid_from(&format!("{scanner_host_name:?}|{}|{nanos}", std::process::id())),
            scan_started: started,
            target_host: cfg.target_host.clone().filter(|h| !h.trim().is_empty()),
            scanner_host_name,
            scanner_host_id: machine_id(),
            scan_target: cfg.path.to_string_lossy().into_owned(),
            scan_target_type: if cfg.path.is_file() { "file" } else { "directory" },
            scan_config_sha256: config_hash(cfg),
            ruleset_name: cfg.rules.iter().map(|p| p.to_string_lossy()).collect::<Vec<_>>().join(", "),
            rules: RuleSources::default(),
            root: cfg.path.clone(),
            mounts: read_mounts(),
        }
    }

    /// Fields every event carries. `created` is when the fact was observed.
    fn common(&self, event_id: String, event_type: &str, category: &str, action: &str,
              outcome: &str, created: &str) -> Map<String, Value> {
        let host = self.target_host.clone();
        let v = json!({
            "schema_version": EVENT_SCHEMA_VERSION,
            "event_id": event_id,
            "event_type": event_type,
            "event_category": category,
            "event_action": action,
            "event_outcome": outcome,
            "event_created": created,
            "event_ingested": null,
            "host": host.clone().unwrap_or_else(|| "unknown".into()),
            "host_name": host,
            "host_identity_source": if self.target_host.is_some() { "analyst_supplied" } else { "unavailable" },
            "host_fqdn": null,
            "host_domain": null,
            "host_id": null,
            "host_os": null,
            "host_os_version": null,
            "host_architecture": null,
            "scanner_host_name": self.scanner_host_name,
            "scanner_host_id": self.scanner_host_id,
            "scanner_name": "yarax-scanner",
            "scanner_version": SCANNER_VERSION,
            "scanner_engine": "yara-x",
            "scanner_engine_version": ENGINE_VERSION,
            "scan_id": self.scan_id,
            "scan_started": self.scan_started,
            "scan_target": self.scan_target,
            "scan_target_type": self.scan_target_type,
        });
        match v { Value::Object(m) => m, _ => unreachable!() }
    }

    /// File identity / path / timestamp / hash block for an observed path.
    /// `disk` is the on-disk file (the archive itself for members).
    fn file_fields(&self, file_path: &str, disk: &Path, member: Option<&str>) -> Map<String, Value> {
        let name = file_path.rsplit(['/', '\\']).next().unwrap_or(file_path);
        let dir = file_path.len().checked_sub(name.len() + 1).map(|n| &file_path[..n]);
        let ext = name.rfind('.').filter(|&i| i > 0).map(|i| name[i + 1..].to_ascii_lowercase());
        let relative = disk.strip_prefix(&self.root).ok().map(|p| {
            let p = p.to_string_lossy().into_owned();
            match member { Some(m) => format!("{p}{}{m}", crate::config::ARCHIVE_SEP), None => p }
        });
        let mount = self.mount_of(disk);
        let v = json!({
            "file_name": name,
            "file_path": file_path,
            "file_path_normalized": file_path.replace('\\', "/").to_lowercase(),
            "file_original_path": null,
            "file_relative_path": relative,
            "file_directory": dir,
            "file_extension": ext,
            "file_volume": mount.map(|m| m.mount_point.to_string_lossy().into_owned()).or_else(|| windows_volume(disk)),
            "file_filesystem": mount.map(|m| m.fs_type.clone()),
            "file_device_path": mount.map(|m| m.device.clone()),
            "file_access_method": access_method(disk, mount, member.is_some()),
            "file_archive_path": member.map(|_| disk.to_string_lossy().into_owned()),
            "file_archive_member_path": member,
        });
        match v { Value::Object(m) => m, _ => unreachable!() }
    }

    fn mount_of(&self, p: &Path) -> Option<&Mount> {
        self.mounts.iter()
            .filter(|m| p.starts_with(&m.mount_point))
            .max_by_key(|m| m.mount_point.as_os_str().len())
    }
}

/// Event file writer shared by the writer thread (matches) and workers
/// (unreadable items). Both are rare, so one mutex is plenty.
pub struct EventLog {
    pub ctx: EventContext,
    path: PathBuf,
    out: Mutex<Option<BufWriter<File>>>,
    seq: AtomicU64,
    pub matches: AtomicU64,
    pub unreadable: AtomicU64,
    matched_files: Mutex<HashSet<String>>,
}

impl EventLog {
    pub fn create(report: &Path, ctx: EventContext) -> std::io::Result<Self> {
        let path = events_path(report);
        let out = BufWriter::new(File::create(&path)?);
        // A new scan starts a new spool: delivery state from an earlier scan
        // with the same report name must not mark these events as sent.
        let _ = std::fs::remove_file(crate::splunk::delivery_path(&path));
        Ok(EventLog {
            ctx, path, out: Mutex::new(Some(out)), seq: AtomicU64::new(0),
            matches: AtomicU64::new(0), unreadable: AtomicU64::new(0),
            matched_files: Mutex::new(HashSet::new()),
        })
    }

    pub fn path(&self) -> &Path { &self.path }

    fn next_id(&self) -> String {
        uuid_from(&format!("{}|{}", self.ctx.scan_id, self.seq.fetch_add(1, Ordering::Relaxed)))
    }

    fn write(&self, ev: &Map<String, Value>) {
        let line = match serde_json::to_string(ev) {
            Ok(l) => l,
            Err(e) => { log::warn!("event serialization failed: {e}"); return; }
        };
        if let Ok(mut g) = self.out.lock() {
            if let Some(w) = g.as_mut() {
                if writeln!(w, "{line}").and_then(|_| w.flush()).is_err() {
                    log::warn!("cannot write {}", self.path.display());
                    *g = None;
                }
            }
        }
    }

    pub fn hit(&self, hit: &Hit) {
        self.matches.fetch_add(1, Ordering::Relaxed);
        if let Ok(mut s) = self.matched_files.lock() { s.insert(hit.file.clone()); }
        self.write(&match_event(&self.ctx, self.next_id(), hit));
    }

    /// Unreadable file/dir/archive item (`Stats::unreadable` kinds).
    pub fn unreadable(&self, kind: &str, item: &str, reason: &str) {
        self.unreadable.fetch_add(1, Ordering::Relaxed);
        self.write(&unreadable_event(&self.ctx, self.next_id(), kind, item, reason));
    }

    /// The exact ruleset this scan used, one event per rule.
    pub fn rule_definitions(&self, defs: &[RuleDef]) {
        for d in defs {
            self.write(&rule_definition_event(&self.ctx, self.next_id(), d));
        }
    }

    /// Rule file skipped or rule compilation failed.
    pub fn rule_error(&self, rule_file: &str, message: &str, fatal: bool) {
        self.write(&rule_error_event(&self.ctx, self.next_id(), rule_file, message, fatal));
    }

    pub fn summary(&self, s: &SummaryCounts) {
        let files_matched = self.matched_files.lock().map(|f| f.len() as u64).unwrap_or(0);
        self.write(&summary_event(&self.ctx, self.next_id(), s, files_matched));
        if let Ok(mut g) = self.out.lock() { *g = None; } // close
    }
}

/// Aggregates for the summary event, gathered by `run()`.
#[derive(Debug, Default, Clone)]
pub struct SummaryCounts {
    /// completed | completed_with_errors | failed | interrupted
    pub status: &'static str,
    pub error: Option<String>,
    pub completed: Option<String>,
    pub duration_ms: Option<u64>,
    pub files_examined: u64,
    pub bytes_examined: u64,
    pub files_failed: u64,
    pub files_skipped: u64,
    pub errors: u64,
    pub matches: u64,
    pub recursion: bool,
    pub follow_symlinks: bool,
    pub max_file_size: Option<u64>,
    pub exclusions: Vec<String>,
}

// ---------------------------------------------------------------------------
// Event builders (pure; unit-tested below)
// ---------------------------------------------------------------------------

pub fn match_event(ctx: &EventContext, id: String, hit: &Hit) -> Map<String, Value> {
    let mut ev = ctx.common(id, "yara_match", "malware", "match", "success", &hit.detected_time);
    // Disk files: the path itself. Archive members: the archive on disk.
    let disk = hit.archive.as_deref().map(PathBuf::from).unwrap_or_else(|| PathBuf::from(&hit.file));
    ev.extend(ctx.file_fields(&hit.file, &disk, hit.internal_path.as_deref()));

    let member = hit.internal_path.is_some();
    let hashed = !hit.sha256.is_empty();
    let src = ctx.rules.lookup(&hit.namespace);
    let meta = |keys: &[&str]| -> Value {
        keys.iter().find_map(|k| hit.metadata.iter()
            .find(|(mk, _)| mk.eq_ignore_ascii_case(k)).map(|(_, v)| v.clone()))
            .unwrap_or(Value::Null)
    };
    let idents: Vec<&str> = {
        let mut v: Vec<&str> = hit.matched_strings.iter().map(|s| s.identifier.as_str()).collect();
        v.dedup();
        v
    };
    let reason = if hit.matched_strings.is_empty() {
        format!("YARA rule {} condition matched (no string matches recorded)", hit.rule)
    } else {
        format!("YARA rule {} matched {} string occurrence(s): {}", hit.rule,
                hit.matched_strings.len(), idents.join(", "))
    };
    let file_ts = |v: &Option<String>| v.clone().map(Value::from).unwrap_or(Value::Null);

    ev.extend(obj(json!({
        "file_size_bytes": hit.size,
        "file_type": hit.magic,
        "file_mime_type": hit.mime_type,
        "file_attributes": hit.file_attributes,
        "file_is_hidden": hit.is_hidden,
        "file_is_readonly": hit.is_readonly,
        "file_is_executable": hit.is_executable,
        "file_is_archive": hit.is_archive,
        "file_entropy": hit.entropy,

        "file_created_time": file_ts(&hit.created_time),
        "file_birth_time": null,
        "file_modified_time": file_ts(&hit.modified_time),
        "file_modified_time_before_scan": file_ts(&hit.modified_time_before_scan),
        "file_modified_time_after_scan": file_ts(&hit.modified_time),
        "file_accessed_time": file_ts(&hit.accessed_time),
        "file_metadata_changed_time": file_ts(&hit.metadata_changed_time),
        "file_changed_during_scan": hit.changed_during_scan,
        "file_timestamp_status": hit.timestamp_status,
        "file_timestamp_source": if member { Value::Null } else { Value::from(hit.timestamp_source.clone().unwrap_or_else(|| timestamp_source().into())) },
        "file_timestamp_precision": if member { Value::Null } else { Value::from(timestamp_precision()) },

        "file_hash_sha256": if hashed { Value::from(hit.sha256.clone()) } else { Value::Null },
        "file_hash_md5": if hashed { Value::from(hit.md5.clone()) } else { Value::Null },
        "file_hash_sha1": null,
        "file_hash_algorithm": "sha256",
        "file_hash_status": if hashed { "computed" } else { "not_computed" },
        "file_hash_scope": if !hashed { "none" } else if member { "full_archive_member" } else { "full_file" },
        "file_hash_reason": if hashed { Value::Null }
            else { Value::from("member larger than --max-member-size was stream-scanned; hashing would need a second decompression pass") },
        "file_hash_calculated_time": if hashed { Value::from(hit.detected_time.clone()) } else { Value::Null },

        "yara_rule_name": hit.rule,
        "yara_rule_namespace": hit.namespace,
        "yara_rule_source": src.map(|f| f.path.file_name().map(|n| n.to_string_lossy().into_owned())),
        "yara_rule_source_path": src.map(|f| f.path.to_string_lossy().into_owned()),
        "yara_rule_source_kind": src.map(|f| f.kind),
        "yara_rule_hash_sha256": src.map(|f| f.sha256.clone()),
        "yara_rule_tags": hit.tags,
        "yara_rule_description": meta(&["description", "desc"]),
        "yara_rule_author": meta(&["author"]),
        "yara_rule_reference": meta(&["reference", "ref", "url"]),
        "yara_rule_version": meta(&["version", "rule_version"]),
        "yara_ruleset_name": ctx.ruleset_name,
        "yara_ruleset_version": ctx.rules.ruleset_sha256,
        "yara_engine_version": ENGINE_VERSION,
        "yara_match_count": hit.match_count,
        "yara_match_strings_total": hit.matched_strings.len(),
        "yara_match_strings_truncated": hit.matched_strings.len() > MAX_EVENT_STRINGS,

        "detection_status": "match",
        "detection_type": "yara_rule_match",
        "detection_name": format!("{}:{}", hit.namespace, hit.rule),
        "detection_severity": meta(&["severity"]),
        "detection_confidence": meta(&["confidence"]),
        "detection_reason": reason,
        "detection_tags": hit.tags,
        "malware_family": meta(&["malware_family", "family"]),
        "threat_category": meta(&["threat_category"]),
        "scan_time_ms": (hit.scan_time_ms * 1000.0).round() / 1000.0,

        // Variable-size fields last: Splunk's automatic extraction reads only
        // the first 10 KB of an event, so everything searchable comes first.
        // Matched strings are bounded (the JSON report keeps them all).
        "yara_rule_meta": hit.metadata,
        "yara_match_strings": &hit.matched_strings[..hit.matched_strings.len().min(MAX_EVENT_STRINGS)],
    })));
    ev
}

pub fn unreadable_event(ctx: &EventContext, id: String, kind: &str, item: &str, reason: &str)
                        -> Map<String, Value> {
    let now = now_iso();
    let mut ev = ctx.common(id, "scan_error", "file", "error", "failure", &now);
    // Archive members look like `/x/a.zip::m/b.log`.
    let (disk, member) = match item.split_once(crate::config::ARCHIVE_SEP) {
        Some((d, m)) => (PathBuf::from(d), Some(m)),
        None => (PathBuf::from(item), None),
    };
    ev.extend(ctx.file_fields(item, &disk, member));
    let lower = reason.to_ascii_lowercase();
    let (error_type, retryable) = match () {
        _ if kind == "timeout" => ("scan_timeout", true),
        _ if lower.contains("permission denied") || lower.contains("access is denied") => ("permission_denied", false),
        _ if lower.contains("no such file") || lower.contains("cannot find") => ("file_disappeared", false),
        _ if lower.contains("budget") || lower.contains("ratio") || lower.contains("output cap") => ("archive_limit", false),
        _ if kind == "archive" || kind == "member" => ("archive_unreadable", false),
        _ if kind == "dir" => ("directory_unreadable", false),
        _ => ("read_error", true),
    };
    ev.extend(obj(json!({
        "error_type": error_type,
        "error_code": io_error_code(reason),
        "error_message": reason,
        "error_stage": kind,
        "error_timestamp": now,
        "retryable": retryable,
        "detection_status": "not_scanned",
        "scan_coverage_impact": if kind == "dir" { "directory contents not scanned" }
                                else if kind == "timeout" { "file not fully scanned" }
                                else { "item not scanned" },
    })));
    ev
}

pub fn rule_definition_event(ctx: &EventContext, id: String, d: &RuleDef) -> Map<String, Value> {
    let mut ev = ctx.common(id, "rule_definition", "configuration", "load", "success", &ctx.scan_started);
    let meta = |keys: &[&str]| -> Value {
        keys.iter().find_map(|k| d.metadata.iter()
            .find(|(mk, _)| mk.eq_ignore_ascii_case(k)).map(|(_, v)| v.clone()))
            .unwrap_or(Value::Null)
    };
    let f = d.file.as_ref();
    ev.extend(obj(json!({
        "yara_rule_name": d.name,
        "yara_rule_namespace": d.namespace,
        "yara_rule_source": f.map(|f| f.path.file_name().map(|n| n.to_string_lossy().into_owned())),
        "yara_rule_source_path": f.map(|f| f.path.to_string_lossy().into_owned()),
        "yara_rule_source_kind": f.map(|f| f.kind),
        "yara_rule_hash_sha256": f.map(|f| f.sha256.clone()),
        "yara_rule_tags": d.tags,
        "yara_rule_description": meta(&["description", "desc"]),
        "yara_rule_author": meta(&["author"]),
        "yara_rule_reference": meta(&["reference", "ref", "url"]),
        "yara_rule_version": meta(&["version", "rule_version"]),
        "yara_rule_is_private": d.private,
        "yara_rule_is_global": d.global,
        "yara_rule_imports": d.imports,
        "yara_ruleset_name": ctx.ruleset_name,
        "yara_ruleset_version": ctx.rules.ruleset_sha256,
        "yara_rule_text_status": d.text_status,
        "yara_rule_text_length": d.text.as_ref().map(|t| t.len()),
        "yara_rule_text_sha256": d.text.as_ref().map(|t| sha256_hex(t.as_bytes())),
        // Variable-size fields last (see match_event).
        "yara_rule_meta": d.metadata,
        "yara_rule_text": d.text,
    })));
    ev
}

pub fn rule_error_event(ctx: &EventContext, id: String, rule_file: &str, message: &str, fatal: bool)
                        -> Map<String, Value> {
    let now = now_iso();
    let mut ev = ctx.common(id, "scan_error", "configuration", "error", "failure", &now);
    ev.extend(obj(json!({
        "yara_rule_source_path": rule_file,
        "error_type": if fatal { "rule_compilation_failed" } else { "rule_file_skipped" },
        "error_code": null,
        "error_message": message,
        "error_stage": "rule_compilation",
        "error_timestamp": now,
        "retryable": false,
        "scan_coverage_impact": if fatal { "scan did not run" } else { "rules in this file were not used" },
    })));
    ev
}

pub fn summary_event(ctx: &EventContext, id: String, s: &SummaryCounts, files_matched: u64)
                     -> Map<String, Value> {
    let now = now_iso();
    let outcome = match s.status { "completed" | "completed_with_errors" => "success", _ => "failure" };
    let mut ev = ctx.common(id, "scan_summary", "file", "complete", outcome, &now);
    ev.extend(obj(json!({
        "scan_status": s.status,
        "scan_completed": s.completed,
        "scan_duration_ms": s.duration_ms,
        "scan_mode": "full",
        "scan_files_examined": s.files_examined,
        "scan_bytes_examined": s.bytes_examined,
        "scan_files_matched": files_matched,
        "scan_matches": s.matches,
        "scan_files_failed": s.files_failed,
        "scan_files_skipped": s.files_skipped,
        "scan_errors_count": s.errors,
        "scan_error": s.error,
        "scan_ruleset_name": ctx.ruleset_name,
        "scan_ruleset_version": ctx.rules.ruleset_sha256,
        "scan_rule_files_loaded": ctx.rules.by_namespace.len() + ctx.rules.single.iter().count(),
        "scan_rule_files_skipped": ctx.rules.skipped.len(),
        "scan_configuration_id": ctx.scan_config_sha256,
        "scan_exclusions": s.exclusions,
        "scan_max_file_size_bytes": s.max_file_size,
        "scan_recursion_enabled": s.recursion,
        "scan_follow_symlinks": s.follow_symlinks,
    })));
    ev
}

fn obj(v: Value) -> Map<String, Value> {
    match v { Value::Object(m) => m, _ => Map::new() }
}

/// OS error number from a message like "... (os error 13)".
fn io_error_code(reason: &str) -> Value {
    reason.rsplit_once("(os error ").and_then(|(_, r)| r.trim_end_matches(')').parse::<i64>().ok())
        .map(Value::from).unwrap_or(Value::Null)
}

fn timestamp_source() -> &'static str {
    if cfg!(windows) { "windows:GetFileInformationByHandle" }
    else if cfg!(target_os = "linux") { "linux:statx" }
    else { "posix:stat" }
}

fn timestamp_precision() -> &'static str {
    // API resolution; the filesystem may be coarser (FAT 2 s, ext3 1 s).
    if cfg!(windows) { "100ns" } else { "1ns" }
}

/// Hash of the settings that decide scan coverage, so two scans can be
/// compared. External variable values are hashed, never emitted.
fn config_hash(cfg: &Config) -> String {
    let s = format!(
        "path={:?}|rules={:?}|recursive={}|follow={}|include={:?}|exclude={:?}|ext={:?}|max={}|skip_large={}|hash_all={}|timeout={}|externals={:?}|archives={}|depth={}|member={}|output={}|ratio={}|match_data={}",
        cfg.path, cfg.rules, cfg.recursive, cfg.follow_links, cfg.include_patterns, cfg.exclude_patterns,
        cfg.extensions, cfg.max_file_size, cfg.skip_large_files, cfg.hash_all, cfg.timeout_secs,
        cfg.externals, cfg.scan_archives, cfg.max_archive_depth, cfg.max_member_size,
        cfg.max_archive_output, cfg.max_compression_ratio, cfg.max_match_data);
    sha256_hex(s.as_bytes())
}

/// Coverage-limiting settings, as listed in the summary event.
pub fn exclusions(cfg: &Config) -> Vec<String> {
    let mut v: Vec<String> = cfg.exclude_patterns.iter().map(|g| format!("exclude:{g}")).collect();
    v.extend(cfg.include_patterns.iter().map(|g| format!("include_only:{g}")));
    if !cfg.extensions.is_empty() { v.push(format!("extensions_only:{}", cfg.extensions.join(","))); }
    if cfg.skip_large_files && cfg.max_file_size > 0 { v.push(format!("skip_larger_than_bytes:{}", cfg.max_file_size)); }
    if !cfg.scan_archives { v.push("archives_not_opened".into()); }
    if !cfg.recursive { v.push("no_recursion".into()); }
    v
}

// ---------------------------------------------------------------------------
// Host / volume facts
// ---------------------------------------------------------------------------

struct Mount { device: String, mount_point: PathBuf, fs_type: String }

/// Linux /proc/mounts (octal escapes like \040 decoded). Empty elsewhere.
fn read_mounts() -> Vec<Mount> {
    let text = std::fs::read_to_string("/proc/mounts").unwrap_or_default();
    let unescape = |s: &str| -> String {
        let mut out = String::new();
        let mut it = s.chars().peekable();
        while let Some(c) = it.next() {
            if c == '\\' {
                let oct: String = (0..3).filter_map(|_| it.next()).collect();
                match u8::from_str_radix(&oct, 8) { Ok(b) => out.push(b as char), Err(_) => { out.push(c); out.push_str(&oct); } }
            } else { out.push(c); }
        }
        out
    };
    text.lines().filter_map(|l| {
        let mut f = l.split_whitespace();
        Some(Mount { device: unescape(f.next()?), mount_point: PathBuf::from(unescape(f.next()?)), fs_type: f.next()?.to_string() })
    }).collect()
}

fn windows_volume(p: &Path) -> Option<String> {
    match p.components().next()? {
        std::path::Component::Prefix(pre) => Some(pre.as_os_str().to_string_lossy().into_owned()),
        _ => None,
    }
}

/// How the scanner reached the file. Mounted evidence is recognised by its
/// block device (loop / nbd / device-mapper), which is how ewfmount, qemu-nbd
/// and kpartx present images.
fn access_method(disk: &Path, mount: Option<&Mount>, member: bool) -> &'static str {
    if member { return "archive_member"; }
    if disk.to_string_lossy().starts_with(r"\\") { return "network_share"; }
    match mount {
        Some(m) if ["cifs", "smb3", "smbfs", "nfs", "nfs4", "fuse.sshfs", "9p"].contains(&m.fs_type.as_str()) => "network_share",
        Some(m) if ["/dev/loop", "/dev/nbd", "/dev/mapper/", "/dev/dm-"].iter().any(|d| m.device.starts_with(d)) => "mounted_image",
        _ => "local_filesystem",
    }
}

/// Stable machine id of the scanning system, where the OS has one.
fn machine_id() -> Option<String> {
    #[cfg(target_os = "linux")]
    { std::fs::read_to_string("/etc/machine-id").ok().map(|s| s.trim().to_string()).filter(|s| !s.is_empty()) }
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        let out = std::process::Command::new("reg")
            .args(["query", r"HKLM\SOFTWARE\Microsoft\Cryptography", "/v", "MachineGuid"])
            .creation_flags(0x0800_0000).output().ok()?;
        String::from_utf8_lossy(&out.stdout).lines()
            .find(|l| l.contains("MachineGuid"))
            .and_then(|l| l.split_whitespace().last()).map(String::from)
    }
    #[cfg(not(any(target_os = "linux", windows)))]
    { None }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::models::StringMatchOut;

    fn ctx(target_host: Option<&str>) -> EventContext {
        let cli = <crate::config::Cli as clap::Parser>::try_parse_from(
            ["yarax-scanner", "/ev", "/r.yar"]).unwrap();
        let mut cfg = Config::from_cli(cli).unwrap();
        cfg.target_host = target_host.map(String::from);
        EventContext::new(&cfg)
    }

    fn hit(file: &str, rule: &str) -> Hit {
        let mut h = Hit::new(rule.into(), "default".into(), file.into(), "rel".into(), 42);
        h.sha256 = "a".repeat(64);
        h.md5 = "b".repeat(32);
        h.matched_strings = vec![StringMatchOut { identifier: "$m".into(), offset: 7, length: 5, data: "EVIL!".into() }];
        h.metadata.insert("Severity".into(), json!("high"));
        h.metadata.insert("score".into(), json!(80));
        h
    }

    /// Every field a detection event must always carry (value may be null).
    const MATCH_FIELDS: &[&str] = &[
        "schema_version", "event_id", "event_type", "event_category", "event_action", "event_outcome",
        "event_created", "event_ingested", "host", "host_name", "host_fqdn", "host_domain", "host_id",
        "host_os", "host_os_version", "host_architecture", "scanner_host_name", "scanner_host_id",
        "scanner_name", "scanner_version", "scanner_engine", "scanner_engine_version", "scan_id",
        "scan_started", "file_name", "file_path", "file_path_normalized", "file_directory",
        "file_extension", "file_size_bytes", "file_type", "file_mime_type", "file_attributes",
        "file_is_hidden", "file_is_readonly", "file_is_executable", "file_volume", "file_filesystem",
        "file_device_path", "file_original_path", "file_access_method", "file_created_time",
        "file_modified_time", "file_accessed_time", "file_metadata_changed_time", "file_birth_time",
        "file_timestamp_source", "file_timestamp_precision", "file_timestamp_status",
        "file_hash_sha256", "file_hash_sha1", "file_hash_md5", "file_hash_status",
        "file_hash_algorithm", "file_hash_scope", "file_hash_calculated_time", "yara_rule_name",
        "yara_rule_namespace", "yara_rule_source", "yara_rule_source_path", "yara_rule_tags",
        "yara_rule_meta", "yara_rule_description", "yara_rule_author", "yara_rule_reference",
        "yara_rule_version", "yara_rule_hash_sha256", "yara_ruleset_name", "yara_ruleset_version",
        "yara_engine_version", "yara_match_count", "yara_match_strings", "detection_status",
        "detection_type", "detection_name", "detection_severity", "detection_confidence",
        "detection_reason", "detection_tags", "malware_family", "threat_category",
    ];

    #[test]
    fn match_event_carries_the_full_schema() {
        let ev = match_event(&ctx(Some("WEB01")), "id-1".into(), &hit("/ev/a.log", "R1"));
        for f in MATCH_FIELDS {
            assert!(ev.contains_key(*f), "missing field {f}");
        }
        assert_eq!(ev["event_type"], "yara_match");
        assert_eq!(ev["file_size_bytes"], 42); // integer, not string
        assert_eq!(ev["yara_match_strings"][0]["length"], 5);
        assert_eq!(ev["detection_severity"], "high"); // case-insensitive meta key
        assert_eq!(ev["detection_confidence"], Value::Null); // never invented
        assert_eq!(ev["malware_family"], Value::Null);
        assert_eq!(ev["yara_rule_meta"]["score"], 80); // meta types preserved
        assert_eq!(ev["file_hash_status"], "computed");
        assert_eq!(ev["file_hash_scope"], "full_file");
        assert_eq!((ev["yara_match_strings_total"].as_u64(), ev["yara_match_strings_truncated"].as_bool()),
                   (Some(1), Some(false)));
    }

    #[test]
    fn huge_match_lists_are_bounded() {
        let mut h = hit("/ev/big.log", "R");
        h.matched_strings = (0..5000).map(|i| StringMatchOut {
            identifier: "$a".into(), offset: i, length: 128, data: "x".repeat(128) }).collect();
        let ev = match_event(&ctx(None), "x".into(), &h);
        assert_eq!(ev["yara_match_strings"].as_array().unwrap().len(), MAX_EVENT_STRINGS);
        assert_eq!((ev["yara_match_strings_total"].as_u64(), ev["yara_match_strings_truncated"].as_bool()),
                   (Some(5000), Some(true)));
        assert!(serde_json::to_string(&ev).unwrap().len() < 64 * 1024, "event stays a sane size");
    }

    #[test]
    fn target_host_is_never_the_scanner() {
        let known = match_event(&ctx(Some("WEB01")), "x".into(), &hit("/ev/a", "R"));
        assert_eq!((known["host"].as_str(), known["host_identity_source"].as_str()),
                   (Some("WEB01"), Some("analyst_supplied")));
        let unknown = match_event(&ctx(None), "x".into(), &hit("/ev/a", "R"));
        assert_eq!(unknown["host"], "unknown");
        assert_eq!(unknown["host_name"], Value::Null);
        assert_eq!(unknown["host_identity_source"], "unavailable");
        assert_ne!(unknown["host"], unknown["scanner_host_name"]);
        // blank input counts as unknown too
        assert_eq!(match_event(&ctx(Some("  ")), "x".into(), &hit("/ev/a", "R"))["host"], "unknown");
    }

    #[test]
    fn unusual_paths_are_preserved_exactly() {
        let p = "/ev/Dossier Ünïcode/naïve file (1) 'q'.TXT";
        let ev = match_event(&ctx(None), "x".into(), &hit(p, "R"));
        assert_eq!(ev["file_path"], p); // original casing and characters kept
        assert_eq!(ev["file_name"], "naïve file (1) 'q'.TXT");
        assert_eq!(ev["file_directory"], "/ev/Dossier Ünïcode");
        assert_eq!(ev["file_extension"], "txt");
        assert_eq!(ev["file_path_normalized"], "/ev/dossier ünïcode/naïve file (1) 'q'.txt");
        let win = match_event(&ctx(None), "x".into(), &hit(r"C:\Ev\A B\x.dll", "R"));
        assert_eq!(win["file_path"], r"C:\Ev\A B\x.dll");
        assert_eq!(win["file_path_normalized"], "c:/ev/a b/x.dll");
    }

    #[test]
    fn missing_timestamps_and_hashes_are_explicit() {
        let mut h = hit("/ev/a.zip::m.bin", "R");
        h.sha256.clear();
        h.md5.clear();
        h.archive = Some("/ev/a.zip".into());
        h.internal_path = Some("m.bin".into());
        h.timestamp_status = "unsupported_archive_member".into();
        let ev = match_event(&ctx(None), "x".into(), &h);
        for f in ["file_created_time", "file_modified_time", "file_accessed_time",
                  "file_metadata_changed_time", "file_hash_sha256", "file_hash_md5"] {
            assert_eq!(ev[f], Value::Null, "{f} must be null, not omitted or guessed");
        }
        assert_eq!(ev["file_timestamp_status"], "unsupported_archive_member");
        assert_eq!(ev["file_hash_status"], "not_computed");
        assert_eq!(ev["file_hash_scope"], "none");
        assert_eq!(ev["file_access_method"], "archive_member");
        assert_eq!(ev["file_archive_member_path"], "m.bin");
        // a missing hash never suppresses the match itself
        assert_eq!(ev["detection_status"], "match");
    }

    #[test]
    fn timestamps_are_utc_z() {
        // 100 ns steps: representable on Windows (FILETIME) and Linux alike
        let t = std::time::UNIX_EPOCH + std::time::Duration::new(1_700_000_000, 123_456_700);
        assert_eq!(crate::utils::iso_time(t), "2023-11-14T22:13:20.123456700Z");
        let t = std::time::UNIX_EPOCH + std::time::Duration::from_secs(1_700_000_000);
        assert_eq!(crate::utils::iso_time(t), "2023-11-14T22:13:20Z"); // no invented fraction
        let ev = match_event(&ctx(None), "x".into(), &hit("/ev/a", "R"));
        assert!(ev["event_created"].as_str().unwrap().ends_with('Z'));
        assert!(ev["scan_started"].as_str().unwrap().ends_with('Z'));
    }

    #[test]
    fn several_rules_on_one_file_stay_separate() {
        let t = tempfile::tempdir().unwrap();
        let report = t.path().join("r.json");
        let log = EventLog::create(&report, ctx(Some("H"))).unwrap();
        let mut a = hit("/ev/same.bin", "RuleA");
        let mut b = hit("/ev/same.bin", "RuleB");
        a.match_count = 2;
        b.match_count = 2;
        log.hit(&a);
        log.hit(&b);
        log.unreadable("open", "/ev/locked.bin", "Permission denied (os error 13)");
        log.summary(&SummaryCounts { status: "completed_with_errors", matches: 2, errors: 1, ..Default::default() });

        let lines: Vec<Value> = std::fs::read_to_string(events_path(&report)).unwrap()
            .lines().map(|l| serde_json::from_str(l).unwrap()).collect();
        assert_eq!(lines.len(), 4);
        assert_eq!(lines[0]["yara_rule_name"], "RuleA");
        assert_eq!(lines[1]["yara_rule_name"], "RuleB");
        assert_eq!(lines[1]["yara_match_count"], 2);
        let ids: HashSet<&str> = lines.iter().map(|l| l["event_id"].as_str().unwrap()).collect();
        assert_eq!(ids.len(), 4, "event ids must be unique");
        let scan_ids: HashSet<&str> = lines.iter().map(|l| l["scan_id"].as_str().unwrap()).collect();
        assert_eq!(scan_ids.len(), 1, "one scan id per scan");

        let err = &lines[2];
        assert_eq!((err["event_type"].as_str(), err["error_type"].as_str(), err["error_code"].as_i64()),
                   (Some("scan_error"), Some("permission_denied"), Some(13)));
        assert_eq!(err["retryable"], false);
        let sum = &lines[3];
        assert_eq!(sum["event_type"], "scan_summary");
        assert_eq!(sum["scan_files_matched"], 1, "two rules on one file = one matched file");
        assert_eq!(sum["scan_matches"], 2);
        assert_eq!(sum["event_outcome"], "success");
    }

    #[test]
    fn summary_outcomes_distinguish_failure_from_no_matches() {
        let c = ctx(None);
        let clean = summary_event(&c, "x".into(), &SummaryCounts { status: "completed", ..Default::default() }, 0);
        assert_eq!((clean["scan_status"].as_str(), clean["event_outcome"].as_str(), clean["scan_files_matched"].as_u64()),
                   (Some("completed"), Some("success"), Some(0)));
        let failed = summary_event(&c, "x".into(), &SummaryCounts { status: "failed", error: Some("bad rule".into()), ..Default::default() }, 0);
        assert_eq!((failed["scan_status"].as_str(), failed["event_outcome"].as_str(), failed["scan_error"].as_str()),
                   (Some("failed"), Some("failure"), Some("bad rule")));
    }

    #[test]
    fn unreadable_kinds_classify() {
        let c = ctx(None);
        let t = unreadable_event(&c, "x".into(), "timeout", "/ev/big.log", "timeout");
        assert_eq!((t["error_type"].as_str(), t["retryable"].as_bool()), (Some("scan_timeout"), Some(true)));
        let m = unreadable_event(&c, "x".into(), "member", "/ev/a.zip::x/y.log", "corrupt deflate stream");
        assert_eq!(m["file_archive_path"], "/ev/a.zip");
        assert_eq!(m["file_archive_member_path"], "x/y.log");
        assert_eq!((m["error_type"].as_str(), m["retryable"].as_bool()), (Some("archive_unreadable"), Some(false)));
        let gone = unreadable_event(&c, "x".into(), "open", "/ev/tmp.bin", "No such file or directory (os error 2)");
        assert_eq!(gone["error_type"], "file_disappeared");
    }

    #[test]
    fn uuids_are_well_formed_and_distinct() {
        let a = uuid_from("a");
        assert_eq!(a.len(), 36);
        assert_eq!(&a[14..15], "4");
        assert_ne!(a, uuid_from("b"));
    }
}
