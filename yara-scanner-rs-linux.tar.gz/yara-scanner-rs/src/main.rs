//! Binary entry point: parse CLI, run the scan, exit with a status code.

use clap::Parser;
use yarax_scanner::config::{Cli, Config};

fn main() {
    let cli = Cli::parse();

    env_logger::Builder::new()
        .filter_level(if cli.verbose {
            log::LevelFilter::Debug
        } else if cli.quiet {
            log::LevelFilter::Error
        } else {
            log::LevelFilter::Warn
        })
        .format_timestamp_secs()
        .init();

    if cli.check_rules {
        std::process::exit(check_rules(&cli));
    }

    let cfg = match Config::from_cli(cli) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::exit(2);
        }
    };

    match yarax_scanner::run(&cfg) {
        Ok(snap) => std::process::exit(if snap.errors == 0 { 0 } else { 1 }),
        Err(e) => {
            eprintln!("fatal: {e:#}");
            std::process::exit(2);
        }
    }
}

/// `--check-rules`: compile each rule file on its own, print every failure.
/// Exit 0 = all compile, 1 = some failed, 2 = bad usage / unreadable source.
fn check_rules(cli: &Cli) -> i32 {
    let mut rules = cli.rules.clone();
    rules.extend(cli.positional.iter().map(std::path::PathBuf::from));
    if rules.is_empty() {
        eprintln!("error: --check-rules needs rules: yarax-scanner --check-rules --rules <dir-or-file>");
        return 2;
    }
    let externals: Vec<(String, String)> = cli.externals.iter()
        .filter_map(|kv| kv.split_once('=').map(|(k, v)| (k.to_string(), v.to_string())))
        .collect();
    match yarax_scanner::rulecheck::check_all(&rules, &externals) {
        Ok(checks) => if yarax_scanner::rulecheck::print_report(&checks) { 0 } else { 1 },
        Err(e) => { eprintln!("fatal: {e:#}"); 2 }
    }
}
