//! Binary entry point: parse CLI, run the scan, exit with a status code.

use clap::Parser;
use yarax_scanner::config::{Cli, Config};

fn main() {
    let cli = Cli::parse();

    env_logger::Builder::new()
        .filter_level(if cli.verbose {
            log::LevelFilter::Debug
        } else if cli.quiet {
            log::LevelFilter::Error
        } else {
            log::LevelFilter::Warn
        })
        .format_timestamp_secs()
        .init();

    if cli.check_rules {
        std::process::exit(check_rules(&cli));
    }
    if cli.splunk_test || cli.splunk_send.is_some() {
        std::process::exit(splunk_only(&cli));
    }
    if cli.iris_list || cli.iris_export.is_some() {
        std::process::exit(iris_only(&cli));
    }

    let cfg = match Config::from_cli(cli) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::exit(2);
        }
    };

    match yarax_scanner::run(&cfg) {
        Ok(snap) => std::process::exit(if snap.errors == 0 { 0 } else { 1 }),
        Err(e) => {
            eprintln!("fatal: {e:#}");
            std::process::exit(2);
        }
    }
}

/// `--splunk-test` / `--splunk-send FILE`: no scan. Exit 0 = OK / all
/// delivered, 1 = HEC refused or partial delivery, 2 = bad usage.
fn splunk_only(cli: &Cli) -> i32 {
    use yarax_scanner::splunk;
    let hec = match cli.hec() {
        Ok(Some(h)) => h,
        Ok(None) => { eprintln!("error: --splunk-url is required"); return 2; }
        Err(e) => { eprintln!("error: {e}"); return 2; }
    };
    if cli.splunk_test {
        return match splunk::test_connection(&hec) {
            Ok(msg) => { eprintln!("SPLUNK test=ok {msg}"); 0 }
            Err(e) => { eprintln!("SPLUNK test=failed {e}"); 1 }
        };
    }
    let file = cli.splunk_send.as_deref().unwrap();
    let d = splunk::deliver(file, &hec);
    eprintln!("SPLUNK status={} sent={}/{} attempts={}{}", d.delivery_status, d.events_sent,
              d.events_total, d.delivery_attempt_count,
              d.error_message.map(|m| format!(" error={m}")).unwrap_or_default());
    if d.delivery_status == "delivered" || d.delivery_status == "nothing_to_send" { 0 } else { 1 }
}

/// `--check-rules`: compile each rule file on its own, print every failure.
/// Exit 0 = all compile, 1 = some failed, 2 = bad usage / unreadable source.
fn check_rules(cli: &Cli) -> i32 {
    let mut rules = cli.rules.clone();
    rules.extend(cli.positional.iter().map(std::path::PathBuf::from));
    if rules.is_empty() {
        eprintln!("error: --check-rules needs rules: yarax-scanner --check-rules --rules <dir-or-file>");
        return 2;
    }
    let externals: Vec<(String, String)> = cli.externals.iter()
        .filter_map(|kv| kv.split_once('=').map(|(k, v)| (k.to_string(), v.to_string())))
        .collect();
    match yarax_scanner::rulecheck::check_all(&rules, &externals) {
        Ok(checks) => if yarax_scanner::rulecheck::print_report(&checks) { 0 } else { 1 },
        Err(e) => { eprintln!("fatal: {e:#}"); 2 }
    }
}

/// `--iris-list` / `--iris-export DIR`: talk to DFIR-IRIS, no scan.
/// Exit 0 = done, 1 = IRIS error or nothing written, 2 = bad usage.
fn iris_only(cli: &Cli) -> i32 {
    use yarax_scanner::iris;
    let mut s = iris::load_settings();
    if let Some(u) = &cli.iris_url { s.url = u.clone(); }
    s.insecure |= cli.iris_insecure;
    let client = match iris::Client::new(&s) {
        Ok(c) => c,
        Err(e) => { eprintln!("error: {e} (--iris-url, {})", iris::KEY_ENV); return 2; }
    };
    let cases = match client.cases() {
        Ok(c) => c,
        Err(e) => { eprintln!("IRIS error: {e:#}"); return 1; }
    };
    if let Some(t) = client.snapshot_time() { eprintln!("IRIS snapshot of {} taken {t}", client.iris_url()); }
    if cli.iris_case.is_empty() {
        if cli.iris_export.is_some() { eprintln!("error: --iris-export needs --iris-case ID"); return 2; }
        println!("{:>6}  {:<10}  CASE", "ID", "STATE");
        for c in &cases { println!("{:>6}  {:<10}  {}", c.id, c.state, c.name); }
        return 0;
    }
    let mut rc = 0;
    for id in &cli.iris_case {
        let Some(case) = cases.iter().find(|c| c.id == *id) else {
            eprintln!("IRIS case {id}: not found (or this API key can't see it)"); rc = 1; continue;
        };
        let iocs: Vec<_> = match client.iocs(*id) {
            Ok(v) => v.into_iter().filter(|i| cli.iris_ioc.is_empty() || cli.iris_ioc.contains(&i.id)).collect(),
            Err(e) => { eprintln!("IRIS case {id}: {e:#}"); rc = 1; continue; }
        };
        let Some(dir) = &cli.iris_export else {
            println!("Case {} - {} ({} IOCs)", case.id, case.name, iocs.len());
            for i in &iocs {
                let how = match iris::patterns(i) {
                    Ok(p) => p.iter().map(|p| p.describe()).collect::<Vec<_>>().join(", "),
                    Err(e) => format!("SKIPPED: {e}"),
                };
                println!("  {:>6}  {:<16} {:<40} tlp:{:<6} {}", i.id, i.kind, i.value, i.tlp, how);
            }
            continue;
        };
        let b = iris::build_bundle(case, &iocs, client.iris_url());
        for (i, why) in &b.skipped { eprintln!("IRIS case {id}: IOC {} ({} {}) skipped: {why}", i.id, i.kind, i.value); }
        match iris::write_bundle(dir, &b) {
            Ok(p) => println!("IRIS case {id}: {} rule(s) -> {}", b.rules, p.display()),
            Err(e) => { eprintln!("IRIS case {id}: {e:#}"); rc = 1; }
        }
    }
    rc
}
