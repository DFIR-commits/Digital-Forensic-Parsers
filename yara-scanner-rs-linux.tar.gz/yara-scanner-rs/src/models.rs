//! Pipeline data models.
//!
//! `FileTask` is deliberately tiny (one `PathBuf` + a `u64`): millions of
//! them flow through the bounded channel and small tasks stay cache-hot.
//! `Hit` derives `Serialize` so the writer thread emits it with zero
//! intermediate representation.

use serde::Serialize;
use std::path::PathBuf;
use std::time::SystemTime;

/// One unit of work.  `size` and `mtime` arrive from the walker's metadata
/// call so workers never re-stat a file; on a hit they are the "before
/// scan" values compared against a fresh stat.
#[derive(Debug)]
pub struct FileTask {
    pub path: PathBuf,
    pub size: u64,
    pub mtime: Option<SystemTime>,
}

#[derive(Debug, Serialize)]
pub struct StringMatchOut {
    pub identifier: String,
    pub offset: u64,
    /// length of the match in bytes (`data` may be truncated)
    pub length: u64,
    /// matched bytes, printable-escaped and truncated to --max-match-data
    pub data: String,
}

#[derive(Debug, Serialize)]
pub struct Hit {
    pub rule: String,
    pub namespace: String,
    pub file: String,
    pub relative_path: String,
    pub size: u64,
    pub sha256: String,
    pub md5: String,
    pub offsets: Vec<u64>,
    pub matched_strings: Vec<StringMatchOut>,
    pub tags: Vec<String>,
    pub metadata: serde_json::Map<String, serde_json::Value>,

    #[serde(skip_serializing_if = "Option::is_none")]
    pub archive: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub internal_path: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub full_path: Option<String>,

    #[serde(skip_serializing_if = "Option::is_none")]
    pub modified_time: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub created_time: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub accessed_time: Option<String>,
    /// POSIX ctime (inode metadata change), never a creation time.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub metadata_changed_time: Option<String>,
    /// mtime the walker saw before the file was read.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub modified_time_before_scan: Option<String>,
    /// Size or mtime differs between the walk and the post-scan stat.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub changed_during_scan: Option<bool>,
    /// Windows attribute names, or the POSIX mode as "mode:0644".
    pub file_attributes: Vec<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub is_readonly: Option<bool>,
    /// Where the timestamps came from when it is not the platform default
    /// (e.g. creation time read from ntfs-3g); None = the stat API only.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub timestamp_source: Option<String>,
    /// Which stat succeeded: "collected", or why timestamps are missing.
    pub timestamp_status: String,

    pub is_executable: bool,
    pub is_archive: bool,
    pub is_hidden: bool,
    pub entropy: f64,

    #[serde(skip_serializing_if = "Option::is_none")]
    pub magic: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub mime_type: Option<String>,

    pub scan_time_ms: f64,
    /// When the match was found (UTC).
    pub detected_time: String,
    /// Rules that matched this same file in this scan (this hit included).
    pub match_count: usize,
}

impl Hit {
    /// Skeleton hit with rule/match data; enrichment fills the rest.
    pub fn new(rule: String, namespace: String, file: String,
               relative_path: String, size: u64) -> Self {
        Hit {
            rule,
            namespace,
            file,
            relative_path,
            size,
            sha256: String::new(),
            md5: String::new(),
            offsets: Vec::new(),
            matched_strings: Vec::new(),
            tags: Vec::new(),
            metadata: serde_json::Map::new(),
            archive: None,
            internal_path: None,
            full_path: None,
            modified_time: None,
            created_time: None,
            accessed_time: None,
            metadata_changed_time: None,
            modified_time_before_scan: None,
            changed_during_scan: None,
            file_attributes: Vec::new(),
            is_readonly: None,
            timestamp_source: None,
            timestamp_status: "not_collected".into(),
            is_executable: false,
            is_archive: false,
            is_hidden: false,
            entropy: 0.0,
            magic: None,
            mime_type: None,
            scan_time_ms: 0.0,
            detected_time: crate::utils::now_iso(),
            match_count: 1,
        }
    }
}
