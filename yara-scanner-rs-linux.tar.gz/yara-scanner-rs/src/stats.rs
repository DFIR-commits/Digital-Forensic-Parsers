//! Lock-free live statistics.
//!
//! Every counter is an `AtomicU64` updated with `Relaxed` ordering — the hot
//! path pays one uncontended atomic add per file, no mutex, no cache-line
//! ping-pong between the progress thread and workers.  (In the Python
//! version this was a mutex; here it is genuinely lock-free.)
//!
//! `current_dir` is the sole string and lives behind a tiny parking-lot-free
//! `std::sync::Mutex` touched once per *directory*, which is noise.

use std::fs::File;
use std::io::{BufWriter, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering::Relaxed};
use std::sync::Mutex;

/// `report.json` -> `report.unreadable.tsv`: one line per item that could
/// not be read or scanned (`kind<TAB>path<TAB>reason`).
pub fn unreadable_path(report: &Path) -> PathBuf {
    report.with_extension("unreadable.tsv")
}

/// Sidecar list of unreadable items. Created lazily on the first entry and
/// flushed per line, so a cancelled/crashed scan still leaves a usable list.
#[derive(Default)]
struct UnreadableLog {
    path: Option<PathBuf>,
    out: Option<BufWriter<File>>,
    broken: bool,
}

impl UnreadableLog {
    fn write(&mut self, kind: &str, item: &str, reason: &str) {
        if self.broken { return; }
        let Some(path) = &self.path else { return };
        if self.out.is_none() {
            match File::create(path) {
                Ok(f) => {
                    let mut w = BufWriter::new(f);
                    let _ = writeln!(w, "kind\tpath\treason");
                    self.out = Some(w);
                }
                Err(e) => {
                    log::warn!("cannot create {}: {e}", path.display());
                    self.broken = true;
                    return;
                }
            }
        }
        let clean = |s: &str| s.replace(['\t', '\n', '\r'], " ");
        let w = self.out.as_mut().unwrap();
        if writeln!(w, "{kind}\t{}\t{}", clean(item), clean(reason)).and_then(|_| w.flush()).is_err() {
            self.broken = true;
        }
    }
}

#[derive(Default)]
pub struct Stats {
    pub files_scanned: AtomicU64,
    pub dirs_scanned: AtomicU64,
    pub bytes_scanned: AtomicU64,
    pub matches: AtomicU64,
    pub errors: AtomicU64,
    pub archives_scanned: AtomicU64,
    pub archive_members_scanned: AtomicU64,
    /// microseconds, summed — divide by files for the mean
    pub scan_latency_total_us: AtomicU64,
    pub scan_latency_max_us: AtomicU64,
    pub current_dir: Mutex<String>,
    unreadable: Mutex<UnreadableLog>,
}

impl Stats {
    /// Stats that also record unreadable items next to the report. Removes
    /// a stale list from an earlier run with the same report name.
    pub fn with_unreadable_log(report: Option<&Path>) -> Self {
        let s = Stats::default();
        if let Some(r) = report {
            let p = unreadable_path(r);
            let _ = std::fs::remove_file(&p);
            s.unreadable.lock().unwrap().path = Some(p);
        }
        s
    }

    /// Count an item that could not be read or scanned, and record why.
    /// `kind`: dir | stat | open | read | mmap | scan | timeout | archive | member
    pub fn unreadable(&self, kind: &str, item: &str, reason: &dyn std::fmt::Display) {
        self.add_error();
        let reason = reason.to_string();
        // YARA-X reports per-file timeouts as a scan error; make them visible.
        let kind = if kind == "scan" && reason.to_ascii_lowercase().contains("timeout") { "timeout" } else { kind };
        log::debug!("{kind} {item}: {reason}");
        if let Ok(mut u) = self.unreadable.lock() {
            u.write(kind, item, &reason);
        }
    }

    /// Path of the unreadable list, if one was written.
    pub fn unreadable_written(&self) -> Option<PathBuf> {
        let u = self.unreadable.lock().ok()?;
        u.out.as_ref().and(u.path.clone())
    }
    pub fn add_file(&self, bytes: u64, latency_us: u64, member: bool) {
        self.files_scanned.fetch_add(1, Relaxed);
        self.bytes_scanned.fetch_add(bytes, Relaxed);
        if member {
            self.archive_members_scanned.fetch_add(1, Relaxed);
        }
        self.scan_latency_total_us.fetch_add(latency_us, Relaxed);
        self.scan_latency_max_us.fetch_max(latency_us, Relaxed);
    }

    pub fn add_dir(&self, path: &str) {
        self.dirs_scanned.fetch_add(1, Relaxed);
        if let Ok(mut cur) = self.current_dir.lock() {
            cur.clear();
            cur.push_str(path);
        }
    }

    #[inline]
    pub fn add_error(&self) {
        self.errors.fetch_add(1, Relaxed);
    }

    #[inline]
    pub fn add_matches(&self, n: u64) {
        self.matches.fetch_add(n, Relaxed);
    }

    #[inline]
    pub fn add_archive(&self) {
        self.archives_scanned.fetch_add(1, Relaxed);
    }

    pub fn snapshot(&self) -> Snapshot {
        Snapshot {
            files_scanned: self.files_scanned.load(Relaxed),
            dirs_scanned: self.dirs_scanned.load(Relaxed),
            bytes_scanned: self.bytes_scanned.load(Relaxed),
            matches: self.matches.load(Relaxed),
            errors: self.errors.load(Relaxed),
            archives_scanned: self.archives_scanned.load(Relaxed),
            archive_members_scanned: self.archive_members_scanned.load(Relaxed),
            scan_latency_total_us: self.scan_latency_total_us.load(Relaxed),
            scan_latency_max_us: self.scan_latency_max_us.load(Relaxed),
            current_dir: self.current_dir.lock()
                .map(|s| s.clone()).unwrap_or_default(),
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct Snapshot {
    pub files_scanned: u64,
    pub dirs_scanned: u64,
    pub bytes_scanned: u64,
    pub matches: u64,
    pub errors: u64,
    pub archives_scanned: u64,
    pub archive_members_scanned: u64,
    pub scan_latency_total_us: u64,
    pub scan_latency_max_us: u64,
    pub current_dir: String,
}

impl Snapshot {
    pub fn avg_latency_ms(&self) -> f64 {
        if self.files_scanned == 0 {
            0.0
        } else {
            self.scan_latency_total_us as f64 / self.files_scanned as f64 / 1000.0
        }
    }
    pub fn max_latency_ms(&self) -> f64 {
        self.scan_latency_max_us as f64 / 1000.0
    }
}
