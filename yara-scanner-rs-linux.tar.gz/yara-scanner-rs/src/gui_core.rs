//! GUI-facing logic with no GUI dependencies: validation, argument
//! building, progress-line parsing and report summarising. The GUI binary
//! (`src/bin/gui.rs`) is a thin shell over this module, and everything here
//! is unit-tested without a display.
//!
//! The GUI never links the scan engine: it launches the `yarax-scanner`
//! executable with a structured argument list (no shell, so spaces and odd
//! characters in paths are safe) and reads its `PROGRESS` lines.

use crate::engine::walk_rule_files;
use std::ffi::OsString;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct Progress {
    pub files: u64,
    pub bytes: u64,
    pub hits: u64,
    pub errors: u64,
}

/// Parse `PROGRESS files=N bytes=N hits=N errors=N` (see progress.rs).
pub fn parse_progress(line: &str) -> Option<Progress> {
    let rest = line.strip_prefix("PROGRESS ")?;
    let mut p = Progress::default();
    for kv in rest.split_whitespace() {
        let (k, v) = kv.split_once('=')?;
        let v: u64 = v.parse().ok()?;
        match k {
            "files" => p.files = v,
            "bytes" => p.bytes = v,
            "hits" => p.hits = v,
            "errors" => p.errors = v,
            _ => {}
        }
    }
    Some(p)
}

/// Check a rule source. Returns how many rule files it contains.
pub fn validate_rule_source(path: &Path) -> Result<usize, String> {
    if !path.exists() {
        return Err("does not exist".into());
    }
    if path.is_dir() {
        let files = walk_rule_files(path)
            .map_err(|e| format!("cannot read directory: {e}"))?;
        if files.is_empty() {
            return Err("no .yar / .yara / .rule / .rules files found".into());
        }
        Ok(files.len())
    } else {
        fs::File::open(path).map_err(|e| format!("cannot open: {e}"))?;
        Ok(1)
    }
}

/// Check a scan target (file, directory or mount point) is readable.
pub fn validate_target(path: &Path) -> Result<(), String> {
    if !path.exists() {
        return Err("does not exist".into());
    }
    let r = if path.is_dir() {
        fs::read_dir(path).map(|_| ())
    } else {
        fs::File::open(path).map(|_| ())
    };
    r.map_err(|e| match e.kind() {
        std::io::ErrorKind::PermissionDenied =>
            "access denied - try running as Administrator, or pick a mounted copy".to_string(),
        _ => format!("cannot read: {e}"),
    })
}

/// Resolve and check the report destination. `output` may be a directory
/// (a timestamped file name is chosen inside it) or a file path. Fails if
/// the folder is missing/unwritable, or the file exists and `overwrite`
/// is false.
pub fn resolve_output(output: &Path, overwrite: bool) -> Result<PathBuf, String> {
    let file = if output.is_dir() {
        output.join(format!("yarax-report-{}.json",
                            chrono::Local::now().format("%Y%m%d-%H%M%S")))
    } else {
        output.to_path_buf()
    };
    let parent = match file.parent() {
        Some(p) if !p.as_os_str().is_empty() => p.to_path_buf(),
        _ => PathBuf::from("."),
    };
    if !parent.is_dir() {
        return Err(format!("folder {} does not exist", parent.display()));
    }
    if file.exists() && !overwrite {
        return Err(format!("{} already exists (tick \"Overwrite\" to replace it)", file.display()));
    }
    // Probe writability with a throwaway file: metadata permission bits lie
    // on Windows and network shares.
    let probe = parent.join(format!(".yarax-write-test-{}", std::process::id()));
    fs::File::create(&probe)
        .and_then(|_| fs::remove_file(&probe))
        .map_err(|e| format!("cannot write to {}: {e}", parent.display()))?;
    Ok(file)
}

#[derive(Debug, Clone, Default)]
pub struct ScanOptions {
    pub scan_archives: bool,
    /// Skip files larger than this many MB (None = scan everything).
    pub skip_larger_than_mb: Option<u64>,
    /// Scan with the rule files that compile instead of aborting on a bad one.
    pub skip_invalid_rules: bool,
}

/// Structured argument list for `yarax-scanner` (never a shell string).
pub fn build_args(rules: &[PathBuf], target: &Path, output: &Path, opts: &ScanOptions)
                  -> Vec<OsString> {
    let mut a: Vec<OsString> = vec!["--path".into(), target.into()];
    for r in rules {
        a.push("--rules".into());
        a.push(r.into());
    }
    a.push("--output".into());
    a.push(output.into());
    if opts.skip_invalid_rules {
        a.push("--skip-invalid-rules".into());
    }
    if !opts.scan_archives {
        a.extend(["--scan-archives".into(), "false".into()]);
    }
    if let Some(mb) = opts.skip_larger_than_mb {
        a.extend(["--max-file-size".into(), format!("{mb}M").into(), "--skip-large-files".into()]);
    }
    a
}

/// Arguments for a rule pre-flight: `yarax-scanner --check-rules --rules ...`.
pub fn build_check_args(rules: &[PathBuf]) -> Vec<OsString> {
    let mut a: Vec<OsString> = vec!["--check-rules".into()];
    for r in rules {
        a.push("--rules".into());
        a.push(r.into());
    }
    a
}

/// `yarax-scanner[.exe]` next to the running GUI executable.
pub fn scanner_exe() -> Result<PathBuf, String> {
    let me = std::env::current_exe().map_err(|e| e.to_string())?;
    let exe = me.with_file_name(format!("yarax-scanner{}", std::env::consts::EXE_SUFFIX));
    if exe.is_file() {
        Ok(exe)
    } else {
        Err(format!("scanner executable not found at {} - build it with `cargo build --release`", exe.display()))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Summary {
    pub files_scanned: u64,
    pub matches: u64,
    pub errors: u64,
    pub elapsed_seconds: f64,
}

/// Read `scan_information` from a finished report.
pub fn read_summary(report: &Path) -> Result<Summary, String> {
    let text = fs::read_to_string(report).map_err(|e| e.to_string())?;
    let v: serde_json::Value = serde_json::from_str(&text)
        .map_err(|e| format!("report is incomplete or invalid: {e}"))?;
    let i = v.get("scan_information").ok_or("report has no scan_information")?;
    let n = |k: &str| i.get(k).and_then(|x| x.as_u64()).unwrap_or(0);
    Ok(Summary {
        files_scanned: n("files_scanned"),
        matches: n("matches"),
        errors: n("errors"),
        elapsed_seconds: i.get("elapsed_seconds").and_then(|x| x.as_f64()).unwrap_or(0.0),
    })
}

#[derive(Debug, Clone, PartialEq)]
pub struct Unreadable {
    pub kind: String,
    pub path: String,
    pub reason: String,
}

/// Load the `<report>.unreadable.tsv` list written next to a report.
/// `Ok(None)` when the scan wrote no list (nothing was unreadable).
pub fn read_unreadable(report: &Path) -> Result<Option<Vec<Unreadable>>, String> {
    let p = crate::stats::unreadable_path(report);
    if !p.exists() {
        return Ok(None);
    }
    let text = fs::read_to_string(&p).map_err(|e| format!("cannot read {}: {e}", p.display()))?;
    Ok(Some(text.lines().skip(1).filter_map(|l| {
        let mut it = l.splitn(3, '\t');
        Some(Unreadable { kind: it.next()?.into(), path: it.next()?.into(), reason: it.next().unwrap_or("").into() })
    }).collect()))
}

/// `[(kind, count)]`, most frequent first.
pub fn count_by_kind(items: &[Unreadable]) -> Vec<(String, usize)> {
    let mut m = std::collections::BTreeMap::new();
    for i in items { *m.entry(i.kind.clone()).or_insert(0usize) += 1; }
    let mut v: Vec<_> = m.into_iter().collect();
    v.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.cmp(&b.0)));
    v
}

/// Mounted drives / volumes to offer as scan targets.
pub fn list_volumes() -> Vec<PathBuf> {
    #[cfg(windows)]
    {
        ('A'..='Z').map(|c| PathBuf::from(format!("{c}:\\"))).filter(|p| p.exists()).collect()
    }
    #[cfg(not(windows))]
    {
        const SKIP: [&str; 5] = ["/proc", "/sys", "/dev", "/run", "/snap"];
        let mounts = fs::read_to_string("/proc/mounts").unwrap_or_default();
        let mut v: Vec<PathBuf> = mounts.lines()
            .filter_map(|l| l.split_whitespace().nth(1))
            .filter(|m| !SKIP.iter().any(|s| m.starts_with(s)))
            .map(PathBuf::from)
            .collect();
        v.sort();
        v.dedup();
        v
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn progress_line_parses() {
        let p = parse_progress("PROGRESS files=12 bytes=3400 hits=2 errors=1").unwrap();
        assert_eq!(p, Progress { files: 12, bytes: 3400, hits: 2, errors: 1 });
        assert!(parse_progress("scanned 7 files").is_none());
        assert!(parse_progress("PROGRESS files=abc").is_none());
    }

    #[test]
    fn rule_sources_validate() {
        let t = tempfile::tempdir().unwrap();
        let good = t.path().join("my rules"); // space in name on purpose
        fs::create_dir_all(good.join("nested")).unwrap();
        fs::write(good.join("nested/a.yar"), "rule a { condition: true }").unwrap();
        let empty = t.path().join("empty");
        fs::create_dir(&empty).unwrap();
        assert_eq!(validate_rule_source(&good), Ok(1));
        assert!(validate_rule_source(&empty).unwrap_err().contains("no .yar"));
        assert!(validate_rule_source(&t.path().join("missing")).unwrap_err().contains("does not exist"));
    }

    #[test]
    fn target_and_output_validate() {
        let t = tempfile::tempdir().unwrap();
        assert!(validate_target(t.path()).is_ok());
        assert!(validate_target(&t.path().join("nope")).is_err());

        // directory -> timestamped file inside
        let out = resolve_output(t.path(), false).unwrap();
        assert_eq!(out.parent().unwrap(), t.path());
        // existing file: refuse unless overwrite
        let f = t.path().join("r.json");
        fs::write(&f, "{}").unwrap();
        assert!(resolve_output(&f, false).unwrap_err().contains("already exists"));
        assert!(resolve_output(&f, true).is_ok());
        // missing folder
        assert!(resolve_output(&t.path().join("no/such/r.json"), false).is_err());
    }

    #[test]
    fn args_are_structured() {
        let a = build_args(
            &[PathBuf::from("/r 1"), PathBuf::from("/r2")],
            Path::new("/ev idence"), Path::new("/o/out.json"),
            &ScanOptions { scan_archives: false, skip_larger_than_mb: Some(500), skip_invalid_rules: true });
        let s: Vec<String> = a.iter().map(|x| x.to_string_lossy().into_owned()).collect();
        assert_eq!(s, ["--path", "/ev idence", "--rules", "/r 1", "--rules", "/r2",
                       "--output", "/o/out.json", "--skip-invalid-rules", "--scan-archives", "false",
                       "--max-file-size", "500M", "--skip-large-files"]);
    }

    #[test]
    fn unreadable_list_round_trips() {
        let t = tempfile::tempdir().unwrap();
        let report = t.path().join("r.json");
        assert_eq!(read_unreadable(&report), Ok(None));
        let s = crate::stats::Stats::with_unreadable_log(Some(&report));
        s.unreadable("open", "/ev/a b.txt", &"Permission denied");
        s.unreadable("scan", "/ev/big.bin", &"timeout");
        s.unreadable("open", "/ev/c.txt", &"Permission\tdenied");
        let items = read_unreadable(&report).unwrap().unwrap();
        assert_eq!(items.len(), 3);
        assert_eq!(items[0], Unreadable { kind: "open".into(), path: "/ev/a b.txt".into(), reason: "Permission denied".into() });
        assert_eq!(items[1].kind, "timeout"); // scan timeouts get their own kind
        assert_eq!(items[2].reason, "Permission denied"); // tabs in reasons cannot break columns
        assert_eq!(count_by_kind(&items), vec![("open".to_string(), 2), ("timeout".to_string(), 1)]);
        assert_eq!(s.errors.load(std::sync::atomic::Ordering::Relaxed), 3);
        // a new run with the same report name starts clean
        let _s2 = crate::stats::Stats::with_unreadable_log(Some(&report));
        assert_eq!(read_unreadable(&report), Ok(None));
    }

    #[test]
    fn summary_reads_report() {
        let t = tempfile::tempdir().unwrap();
        let f = t.path().join("r.json");
        fs::write(&f, r#"{"hits":[],"scan_information":{"files_scanned":5,"matches":1,"errors":0,"elapsed_seconds":2.5}}"#).unwrap();
        assert_eq!(read_summary(&f).unwrap(),
                   Summary { files_scanned: 5, matches: 1, errors: 0, elapsed_seconds: 2.5 });
        fs::write(&f, r#"{"hits":["#).unwrap(); // cancelled mid-write
        assert!(read_summary(&f).unwrap_err().contains("incomplete"));
    }
}
