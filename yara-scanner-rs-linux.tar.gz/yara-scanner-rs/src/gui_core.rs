//! GUI-facing logic with no GUI dependencies: validation, argument
//! building, progress-line parsing and report summarising. The GUI binary
//! (`src/bin/gui.rs`) is a thin shell over this module, and everything here
//! is unit-tested without a display.
//!
//! The GUI never links the scan engine: it launches the `yarax-scanner`
//! executable with a structured argument list (no shell, so spaces and odd
//! characters in paths are safe) and reads its `PROGRESS` lines.

use crate::engine::walk_rule_files;
use std::ffi::OsString;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub struct Progress {
    pub files: u64,
    pub bytes: u64,
    pub hits: u64,
    pub errors: u64,
}

/// Parse `PROGRESS files=N bytes=N hits=N errors=N` (see progress.rs).
pub fn parse_progress(line: &str) -> Option<Progress> {
    let rest = line.strip_prefix("PROGRESS ")?;
    let mut p = Progress::default();
    for kv in rest.split_whitespace() {
        let (k, v) = kv.split_once('=')?;
        let v: u64 = v.parse().ok()?;
        match k {
            "files" => p.files = v,
            "bytes" => p.bytes = v,
            "hits" => p.hits = v,
            "errors" => p.errors = v,
            _ => {}
        }
    }
    Some(p)
}

/// Check a rule source. Returns how many rule files it contains.
pub fn validate_rule_source(path: &Path) -> Result<usize, String> {
    if !path.exists() {
        return Err("does not exist".into());
    }
    if path.is_dir() {
        let files = walk_rule_files(path)
            .map_err(|e| format!("cannot read directory: {e}"))?;
        if files.is_empty() {
            return Err("no .yar / .yara / .rule / .rules files found".into());
        }
        Ok(files.len())
    } else {
        fs::File::open(path).map_err(|e| format!("cannot open: {e}"))?;
        Ok(1)
    }
}

/// Check a scan target (file, directory or mount point) is readable.
pub fn validate_target(path: &Path) -> Result<(), String> {
    if !path.exists() {
        return Err("does not exist".into());
    }
    let r = if path.is_dir() {
        fs::read_dir(path).map(|_| ())
    } else {
        fs::File::open(path).map(|_| ())
    };
    r.map_err(|e| match e.kind() {
        std::io::ErrorKind::PermissionDenied =>
            "access denied - try running as Administrator, or pick a mounted copy".to_string(),
        _ => format!("cannot read: {e}"),
    })
}

/// Resolve and check the report destination. `output` may be a directory
/// (a timestamped file name is chosen inside it) or a file path. Fails if
/// the folder is missing/unwritable, or the file exists and `overwrite`
/// is false.
pub fn resolve_output(output: &Path, overwrite: bool) -> Result<PathBuf, String> {
    let file = if output.is_dir() {
        output.join(format!("yarax-report-{}.json",
                            chrono::Local::now().format("%Y%m%d-%H%M%S")))
    } else {
        output.to_path_buf()
    };
    let parent = match file.parent() {
        Some(p) if !p.as_os_str().is_empty() => p.to_path_buf(),
        _ => PathBuf::from("."),
    };
    if !parent.is_dir() {
        return Err(format!("folder {} does not exist", parent.display()));
    }
    if file.exists() && !overwrite {
        return Err(format!("{} already exists (tick \"Overwrite\" to replace it)", file.display()));
    }
    // Probe writability with a throwaway file: metadata permission bits lie
    // on Windows and network shares.
    let probe = parent.join(format!(".yarax-write-test-{}", std::process::id()));
    fs::File::create(&probe)
        .and_then(|_| fs::remove_file(&probe))
        .map_err(|e| format!("cannot write to {}: {e}", parent.display()))?;
    Ok(file)
}

/// Every scan option the GUI can set. `Default` mirrors the CLI defaults
/// (src/config.rs), and `build_args` only emits flags that differ from
/// them, so the generated command stays short and readable.
#[derive(Debug, Clone, PartialEq)]
pub struct ScanOptions {
    pub scan_archives: bool,
    /// Skip files larger than this many MB (None = scan everything).
    pub skip_larger_than_mb: Option<u64>,
    /// Scan with the rule files that compile instead of aborting on a bad one.
    pub skip_invalid_rules: bool,
    /// Per-file YARA timeout in seconds.
    pub timeout_secs: u64,
    /// Scan threads; 0 = one per CPU core.
    pub threads: usize,
    pub recursive: bool,
    pub follow_links: bool,
    /// Hash every scanned file, not only matches.
    pub hash_all: bool,
    /// Comma-separated extensions, e.g. "log,txt" ("" = all files).
    pub extensions: String,
    /// Glob patterns (one per entry).
    pub include: Vec<String>,
    pub exclude: Vec<String>,
    /// YARA external variables, KEY=VALUE.
    pub externals: Vec<String>,
    pub max_archive_depth: u32,
    pub max_member_mb: u64,
    pub max_archive_output_mb: u64,
    pub max_compression_ratio: u64,
}

impl Default for ScanOptions {
    fn default() -> Self {
        ScanOptions {
            scan_archives: true,
            skip_larger_than_mb: None,
            skip_invalid_rules: false,
            timeout_secs: 60,
            threads: 0,
            recursive: true,
            follow_links: false,
            hash_all: false,
            extensions: String::new(),
            include: vec![],
            exclude: vec![],
            externals: vec![],
            max_archive_depth: 3,
            max_member_mb: 512,
            max_archive_output_mb: 8 * 1024,
            max_compression_ratio: 1000,
        }
    }
}

/// Non-empty, trimmed lines of a multi-line text box.
pub fn split_lines(s: &str) -> Vec<String> {
    s.lines().map(str::trim).filter(|l| !l.is_empty()).map(String::from).collect()
}

/// Catch mistakes before launching the scanner (which would reject them
/// with a less friendly message).
pub fn validate_options(o: &ScanOptions) -> Result<(), String> {
    if o.timeout_secs == 0 {
        return Err("Timeout must be at least 1 second.".into());
    }
    for g in o.include.iter().chain(&o.exclude) {
        globset::Glob::new(g).map_err(|e| format!("Bad pattern \"{g}\": {e}"))?;
    }
    for kv in &o.externals {
        match kv.split_once('=') {
            Some((k, _)) if !k.trim().is_empty() => {}
            _ => return Err(format!("External variable \"{kv}\" must look like KEY=VALUE.")),
        }
    }
    Ok(())
}

/// Structured argument list for `yarax-scanner` (never a shell string).
pub fn build_args(rules: &[PathBuf], target: &Path, output: &Path, opts: &ScanOptions)
                  -> Vec<OsString> {
    let mut a: Vec<OsString> = vec!["--path".into(), target.into()];
    for r in rules {
        a.push("--rules".into());
        a.push(r.into());
    }
    a.push("--output".into());
    a.push(output.into());
    if opts.skip_invalid_rules {
        a.push("--skip-invalid-rules".into());
    }
    if !opts.scan_archives {
        a.extend(["--scan-archives".into(), "false".into()]);
    }
    if let Some(mb) = opts.skip_larger_than_mb {
        a.extend(["--max-file-size".into(), format!("{mb}M").into(), "--skip-large-files".into()]);
    }
    let d = ScanOptions::default();
    let mut flag = |name: &str, val: String| { a.push(name.into()); a.push(val.into()); };
    if opts.timeout_secs != d.timeout_secs { flag("--timeout", opts.timeout_secs.to_string()); }
    if opts.threads != d.threads { flag("--threads", opts.threads.to_string()); }
    if !opts.recursive { flag("--recursive", "false".into()); }
    if !opts.extensions.trim().is_empty() { flag("--extensions", opts.extensions.trim().into()); }
    for g in &opts.include { flag("--include", g.clone()); }
    for g in &opts.exclude { flag("--exclude", g.clone()); }
    for kv in &opts.externals { flag("--external", kv.clone()); }
    if opts.max_archive_depth != d.max_archive_depth { flag("--max-archive-depth", opts.max_archive_depth.to_string()); }
    if opts.max_member_mb != d.max_member_mb { flag("--max-member-size", format!("{}M", opts.max_member_mb)); }
    if opts.max_archive_output_mb != d.max_archive_output_mb { flag("--max-archive-output", format!("{}M", opts.max_archive_output_mb)); }
    if opts.max_compression_ratio != d.max_compression_ratio { flag("--max-compression-ratio", opts.max_compression_ratio.to_string()); }
    if opts.follow_links { a.push("--follow-links".into()); }
    if opts.hash_all { a.push("--hash-all".into()); }
    a
}

/// Arguments for a rule pre-flight: `yarax-scanner --check-rules --rules ...`.
/// External variables are passed too: rules that use them don't compile
/// without them.
pub fn build_check_args(rules: &[PathBuf], externals: &[String]) -> Vec<OsString> {
    let mut a: Vec<OsString> = vec!["--check-rules".into()];
    for r in rules {
        a.push("--rules".into());
        a.push(r.into());
    }
    for kv in externals {
        a.push("--external".into());
        a.push(kv.into());
    }
    a
}

/// Shell-style rendering of a command for display / copy-paste. Arguments
/// with spaces or quotes are single-quoted. Display only - the scanner is
/// always launched with the structured argument list, never through a shell.
pub fn command_line(exe: &str, args: &[OsString]) -> String {
    let mut s = exe.to_string();
    for a in args {
        let a = a.to_string_lossy();
        s.push(' ');
        if a.is_empty() || a.contains(|c: char| c.is_whitespace() || "'\"$`\\*?;&|<>()".contains(c)) {
            s.push('\'');
            s.push_str(&a.replace('\'', "'\\''"));
            s.push('\'');
        } else {
            s.push_str(&a);
        }
    }
    s
}

/// `yarax-scanner[.exe]` next to the running GUI executable.
pub fn scanner_exe() -> Result<PathBuf, String> {
    let me = std::env::current_exe().map_err(|e| e.to_string())?;
    let exe = me.with_file_name(format!("yarax-scanner{}", std::env::consts::EXE_SUFFIX));
    if exe.is_file() {
        Ok(exe)
    } else {
        Err(format!("scanner executable not found at {} - build it with `cargo build --release`", exe.display()))
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Summary {
    pub files_scanned: u64,
    pub matches: u64,
    pub errors: u64,
    pub elapsed_seconds: f64,
}

/// Read `scan_information` from a finished report.
pub fn read_summary(report: &Path) -> Result<Summary, String> {
    let text = fs::read_to_string(report).map_err(|e| e.to_string())?;
    let v: serde_json::Value = serde_json::from_str(&text)
        .map_err(|e| format!("report is incomplete or invalid: {e}"))?;
    let i = v.get("scan_information").ok_or("report has no scan_information")?;
    let n = |k: &str| i.get(k).and_then(|x| x.as_u64()).unwrap_or(0);
    Ok(Summary {
        files_scanned: n("files_scanned"),
        matches: n("matches"),
        errors: n("errors"),
        elapsed_seconds: i.get("elapsed_seconds").and_then(|x| x.as_f64()).unwrap_or(0.0),
    })
}

#[derive(Debug, Clone, PartialEq)]
pub struct Unreadable {
    pub kind: String,
    pub path: String,
    pub reason: String,
}

/// Load the `<report>.unreadable.tsv` list written next to a report.
/// `Ok(None)` when the scan wrote no list (nothing was unreadable).
pub fn read_unreadable(report: &Path) -> Result<Option<Vec<Unreadable>>, String> {
    let p = crate::stats::unreadable_path(report);
    if !p.exists() {
        return Ok(None);
    }
    let text = fs::read_to_string(&p).map_err(|e| format!("cannot read {}: {e}", p.display()))?;
    Ok(Some(text.lines().skip(1).filter_map(|l| {
        let mut it = l.splitn(3, '\t');
        Some(Unreadable { kind: it.next()?.into(), path: it.next()?.into(), reason: it.next().unwrap_or("").into() })
    }).collect()))
}

/// `[(kind, count)]`, most frequent first.
pub fn count_by_kind(items: &[Unreadable]) -> Vec<(String, usize)> {
    let mut m = std::collections::BTreeMap::new();
    for i in items { *m.entry(i.kind.clone()).or_insert(0usize) += 1; }
    let mut v: Vec<_> = m.into_iter().collect();
    v.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.cmp(&b.0)));
    v
}

/// Mounted drives / volumes to offer as scan targets.
pub fn list_volumes() -> Vec<PathBuf> {
    #[cfg(windows)]
    {
        ('A'..='Z').map(|c| PathBuf::from(format!("{c}:\\"))).filter(|p| p.exists()).collect()
    }
    #[cfg(not(windows))]
    {
        const SKIP: [&str; 5] = ["/proc", "/sys", "/dev", "/run", "/snap"];
        let mounts = fs::read_to_string("/proc/mounts").unwrap_or_default();
        let mut v: Vec<PathBuf> = mounts.lines()
            .filter_map(|l| l.split_whitespace().nth(1))
            .filter(|m| !SKIP.iter().any(|s| m.starts_with(s)))
            .map(PathBuf::from)
            .collect();
        v.sort();
        v.dedup();
        v
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn progress_line_parses() {
        let p = parse_progress("PROGRESS files=12 bytes=3400 hits=2 errors=1").unwrap();
        assert_eq!(p, Progress { files: 12, bytes: 3400, hits: 2, errors: 1 });
        assert!(parse_progress("scanned 7 files").is_none());
        assert!(parse_progress("PROGRESS files=abc").is_none());
    }

    #[test]
    fn rule_sources_validate() {
        let t = tempfile::tempdir().unwrap();
        let good = t.path().join("my rules"); // space in name on purpose
        fs::create_dir_all(good.join("nested")).unwrap();
        fs::write(good.join("nested/a.yar"), "rule a { condition: true }").unwrap();
        let empty = t.path().join("empty");
        fs::create_dir(&empty).unwrap();
        assert_eq!(validate_rule_source(&good), Ok(1));
        assert!(validate_rule_source(&empty).unwrap_err().contains("no .yar"));
        assert!(validate_rule_source(&t.path().join("missing")).unwrap_err().contains("does not exist"));
    }

    #[test]
    fn target_and_output_validate() {
        let t = tempfile::tempdir().unwrap();
        assert!(validate_target(t.path()).is_ok());
        assert!(validate_target(&t.path().join("nope")).is_err());

        // directory -> timestamped file inside
        let out = resolve_output(t.path(), false).unwrap();
        assert_eq!(out.parent().unwrap(), t.path());
        // existing file: refuse unless overwrite
        let f = t.path().join("r.json");
        fs::write(&f, "{}").unwrap();
        assert!(resolve_output(&f, false).unwrap_err().contains("already exists"));
        assert!(resolve_output(&f, true).is_ok());
        // missing folder
        assert!(resolve_output(&t.path().join("no/such/r.json"), false).is_err());
    }

    #[test]
    fn args_are_structured() {
        let a = build_args(
            &[PathBuf::from("/r 1"), PathBuf::from("/r2")],
            Path::new("/ev idence"), Path::new("/o/out.json"),
            &ScanOptions { scan_archives: false, skip_larger_than_mb: Some(500), skip_invalid_rules: true,
                           ..Default::default() });
        let s: Vec<String> = a.iter().map(|x| x.to_string_lossy().into_owned()).collect();
        assert_eq!(s, ["--path", "/ev idence", "--rules", "/r 1", "--rules", "/r2",
                       "--output", "/o/out.json", "--skip-invalid-rules", "--scan-archives", "false",
                       "--max-file-size", "500M", "--skip-large-files"]);
    }

    #[test]
    fn unreadable_list_round_trips() {
        let t = tempfile::tempdir().unwrap();
        let report = t.path().join("r.json");
        assert_eq!(read_unreadable(&report), Ok(None));
        let s = crate::stats::Stats::with_unreadable_log(Some(&report));
        s.unreadable("open", "/ev/a b.txt", &"Permission denied");
        s.unreadable("scan", "/ev/big.bin", &"timeout");
        s.unreadable("open", "/ev/c.txt", &"Permission\tdenied");
        let items = read_unreadable(&report).unwrap().unwrap();
        assert_eq!(items.len(), 3);
        assert_eq!(items[0], Unreadable { kind: "open".into(), path: "/ev/a b.txt".into(), reason: "Permission denied".into() });
        assert_eq!(items[1].kind, "timeout"); // scan timeouts get their own kind
        assert_eq!(items[2].reason, "Permission denied"); // tabs in reasons cannot break columns
        assert_eq!(count_by_kind(&items), vec![("open".to_string(), 2), ("timeout".to_string(), 1)]);
        assert_eq!(s.errors.load(std::sync::atomic::Ordering::Relaxed), 3);
        // a new run with the same report name starts clean
        let _s2 = crate::stats::Stats::with_unreadable_log(Some(&report));
        assert_eq!(read_unreadable(&report), Ok(None));
    }

    #[test]
    fn every_gui_option_is_understood_by_the_cli() {
        use clap::Parser;
        let o = ScanOptions {
            scan_archives: false, skip_larger_than_mb: Some(500), skip_invalid_rules: true,
            timeout_secs: 300, threads: 16, recursive: false, follow_links: true, hash_all: true,
            extensions: "log, txt".into(), include: vec!["**/*.log".into()],
            exclude: vec!["**/.ewf_fuse/**".into()], externals: vec!["env=prod".into()],
            max_archive_depth: 5, max_member_mb: 256, max_archive_output_mb: 1024,
            max_compression_ratio: 500,
        };
        let mut argv: Vec<OsString> = vec!["yarax-scanner".into()];
        argv.extend(build_args(&[PathBuf::from("/r")], Path::new("/t"), Path::new("/o.json"), &o));
        let c = crate::config::Config::from_cli(crate::config::Cli::try_parse_from(argv).unwrap()).unwrap();
        assert_eq!((c.timeout_secs, c.threads, c.recursive, c.follow_links, c.hash_all),
                   (300, 16, false, true, true));
        assert_eq!(c.extensions, [".log", ".txt"]);
        assert!(c.include.is_some() && c.exclude.is_some());
        assert_eq!(c.externals, [("env".to_string(), "prod".to_string())]);
        assert_eq!((c.max_archive_depth, c.max_member_size, c.max_archive_output, c.max_compression_ratio),
                   (5, 256 << 20, 1024 << 20, 500));
        assert_eq!((c.max_file_size, c.skip_large_files, c.scan_archives, c.skip_invalid_rules),
                   (500 << 20, true, false, true));
    }

    #[test]
    fn defaults_add_no_extra_flags() {
        let a = build_args(&[PathBuf::from("/r")], Path::new("/t"), Path::new("/o.json"), &ScanOptions::default());
        let s: Vec<String> = a.iter().map(|x| x.to_string_lossy().into_owned()).collect();
        assert_eq!(s, ["--path", "/t", "--rules", "/r", "--output", "/o.json"]);
    }

    #[test]
    fn options_validate() {
        assert!(validate_options(&ScanOptions::default()).is_ok());
        let bad_glob = ScanOptions { exclude: vec!["**/{a".into()], ..Default::default() };
        assert!(validate_options(&bad_glob).unwrap_err().contains("Bad pattern"));
        let bad_ext = ScanOptions { externals: vec!["noequals".into()], ..Default::default() };
        assert!(validate_options(&bad_ext).unwrap_err().contains("KEY=VALUE"));
        let zero = ScanOptions { timeout_secs: 0, ..Default::default() };
        assert!(validate_options(&zero).is_err());
        assert_eq!(split_lines("  a \n\n b\n"), ["a", "b"]);
    }

    #[test]
    fn command_line_is_copy_pasteable() {
        let args: Vec<OsString> = ["--path", "/ev idence", "--exclude", "**/x", "--external", "k=it's"]
            .iter().map(OsString::from).collect();
        assert_eq!(command_line("yarax-scanner", &args),
                   "yarax-scanner --path '/ev idence' --exclude '**/x' --external 'k=it'\\''s'");
    }

    #[test]
    fn summary_reads_report() {
        let t = tempfile::tempdir().unwrap();
        let f = t.path().join("r.json");
        fs::write(&f, r#"{"hits":[],"scan_information":{"files_scanned":5,"matches":1,"errors":0,"elapsed_seconds":2.5}}"#).unwrap();
        assert_eq!(read_summary(&f).unwrap(),
                   Summary { files_scanned: 5, matches: 1, errors: 0, elapsed_seconds: 2.5 });
        fs::write(&f, r#"{"hits":["#).unwrap(); // cancelled mid-write
        assert!(read_summary(&f).unwrap_err().contains("incomplete"));
    }
}
