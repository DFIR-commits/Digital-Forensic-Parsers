//! Pre-flight rule validation: compile every rule file on its own with
//! YARA-X and report ALL failures (and compiler warnings) at once, instead
//! of the scan stopping at the first bad file.
//!
//! Each file gets a fresh `Compiler`, exactly as the scan gives each file
//! its own namespace, so "passes here" means "compiles in the scan" (same
//! externals included).

use crate::engine::walk_rule_files;
use anyhow::{bail, Result};
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Debug)]
pub struct FileCheck {
    pub path: PathBuf,
    pub warnings: Vec<String>,
    /// All compile errors in this file, rendered with file/line context.
    pub errors: Vec<String>,
}

impl FileCheck {
    pub fn ok(&self) -> bool { self.errors.is_empty() }
}

/// Expand rule sources: directories are searched recursively, files are
/// taken as given. Missing or empty sources are an error.
pub fn collect_rule_files(paths: &[PathBuf]) -> Result<Vec<PathBuf>> {
    let mut out = Vec::new();
    for p in paths {
        if !p.exists() {
            bail!("rule source {} does not exist", p.display());
        }
        if p.is_dir() {
            let files = walk_rule_files(p)?;
            if files.is_empty() {
                bail!("no rule files found in {}", p.display());
            }
            out.extend(files);
        } else {
            out.push(p.clone());
        }
    }
    Ok(out)
}

/// Compile one file in isolation.
pub fn check_file(path: &Path, externals: &[(String, String)]) -> FileCheck {
    let mut res = FileCheck { path: path.to_path_buf(), warnings: vec![], errors: vec![] };
    let bytes = match fs::read(path) {
        Ok(b) => b,
        Err(e) => { res.errors.push(format!("cannot read file: {e}")); return res; }
    };
    let mut compiler = yara_x::Compiler::new();
    for (k, v) in externals {
        if let Err(e) = compiler.define_global(k, v.as_str()) {
            res.errors.push(format!("bad --external {k}: {e}"));
            return res;
        }
    }
    let src = yara_x::SourceCode::from(bytes.as_slice())
        .with_origin(path.display().to_string());
    if let Err(first) = compiler.add_source(src) {
        // errors() has every error in the file; the Err is only the first.
        res.errors = compiler.errors().iter().map(|e| e.to_string()).collect();
        if res.errors.is_empty() {
            res.errors.push(first.to_string());
        }
    }
    res.warnings = compiler.warnings().iter().map(|w| w.to_string()).collect();
    res
}

pub fn check_all(paths: &[PathBuf], externals: &[(String, String)]) -> Result<Vec<FileCheck>> {
    Ok(collect_rule_files(paths)?.iter().map(|f| check_file(f, externals)).collect())
}

/// Human-readable report on stdout; returns true when every file compiled.
pub fn print_report(checks: &[FileCheck]) -> bool {
    let (mut bad, mut warned) = (0usize, 0usize);
    for c in checks {
        if c.ok() {
            println!("OK    {}{}", c.path.display(),
                     if c.warnings.is_empty() { String::new() }
                     else { format!("  ({} warning(s))", c.warnings.len()) });
        } else {
            bad += 1;
            println!("FAIL  {}", c.path.display());
            for e in &c.errors { println!("{}", indent(e)); }
        }
        if !c.warnings.is_empty() {
            warned += 1;
            for w in &c.warnings { println!("{}", indent(&format!("warning: {w}"))); }
        }
    }
    println!("\n{} rule file(s) checked: {} ok, {} FAILED, {} with warnings",
             checks.len(), checks.len() - bad, bad, warned);
    bad == 0
}

fn indent(s: &str) -> String {
    s.trim_end().lines().map(|l| format!("        {l}")).collect::<Vec<_>>().join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reports_every_bad_file_not_just_the_first() {
        let t = tempfile::tempdir().unwrap();
        fs::write(t.path().join("good.yar"), "rule ok { condition: true }").unwrap();
        fs::write(t.path().join("bad1.yar"), "rule a { condition: nope }").unwrap();
        fs::write(t.path().join("bad2.yar"), "rule b { strings: $a = \"x\" condition: true }").unwrap(); // unused string
        let checks = check_all(&[t.path().to_path_buf()], &[]).unwrap();
        assert_eq!(checks.len(), 3);
        let failed: Vec<_> = checks.iter().filter(|c| !c.ok())
            .map(|c| c.path.file_name().unwrap().to_string_lossy().into_owned()).collect();
        assert_eq!(failed, ["bad1.yar", "bad2.yar"]);
        assert!(checks.iter().find(|c| c.path.ends_with("bad1.yar")).unwrap()
            .errors[0].contains("bad1.yar"), "error should name the file");
    }

    #[test]
    fn empty_or_missing_source_is_an_error() {
        let t = tempfile::tempdir().unwrap();
        assert!(check_all(&[t.path().to_path_buf()], &[]).is_err());
        assert!(check_all(&[t.path().join("nope")], &[]).is_err());
    }
}
