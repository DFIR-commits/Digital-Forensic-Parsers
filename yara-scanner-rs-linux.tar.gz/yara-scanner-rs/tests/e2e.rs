//! End-to-end integration tests — run with `cargo test`.
//!
//! These use the REAL YARA-X engine (it's a native crate, no system deps),
//! build a fixture tree containing plain files, a zip, a tar.gz, a nested
//! zip-in-tar.gz, a .log.gz, and a corrupt archive, then verify the full
//! pipeline: hits, `::` virtual paths, hashes, bomb guards and error
//! resilience.

use clap::Parser;
use std::fs::{self, File};
use std::io::Write;
use std::path::{Path, PathBuf};

use yarax_scanner::config::{Cli, Config};
use yarax_scanner::run;

const RULE: &str = r#"
rule Suspicious_Marker : test {
    meta:
        author = "e2e"
    strings:
        $m = "EVIL_MARKER_123"
    condition:
        $m
}
"#;

fn write_zip(path: &Path, members: &[(&str, &[u8])]) {
    let f = File::create(path).unwrap();
    let mut zip = zip::ZipWriter::new(f);
    let opts = zip::write::SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated);
    for (name, data) in members {
        zip.start_file(*name, opts).unwrap();
        zip.write_all(data).unwrap();
    }
    zip.finish().unwrap();
}

fn write_targz(path: &Path, members: &[(&str, &[u8])]) {
    let f = File::create(path).unwrap();
    let gz = flate2::write::GzEncoder::new(f, flate2::Compression::default());
    let mut tar = tar::Builder::new(gz);
    for (name, data) in members {
        let mut header = tar::Header::new_gnu();
        header.set_size(data.len() as u64);
        header.set_mode(0o644);
        header.set_cksum();
        tar.append_data(&mut header, name, *data).unwrap();
    }
    tar.into_inner().unwrap().finish().unwrap();
}

struct Fixture {
    _tmp: tempfile::TempDir,
    root: PathBuf,
    rules: PathBuf,
    output: PathBuf,
}

fn fixture() -> Fixture {
    let tmp = tempfile::TempDir::with_prefix("yarax-e2e").unwrap();
    let root = tmp.path().join("evidence");
    fs::create_dir_all(root.join("deep/deeper")).unwrap();

    fs::write(root.join("clean.log"), "nothing to see\n".repeat(200)).unwrap();
    fs::write(root.join("deep/bad.log"), "prefix EVIL_MARKER_123 suffix\n").unwrap();

    write_zip(&root.join("logs.zip"), &[
        ("apache/access.log", b"GET / 200\nEVIL_MARKER_123 hit\n"),
        ("apache/error.log", b"clean\n"),
    ]);

    // nested: zip inside tar.gz
    let mut inner = Vec::new();
    {
        let mut zw = zip::ZipWriter::new(std::io::Cursor::new(&mut inner));
        let opts = zip::write::SimpleFileOptions::default();
        zw.start_file("nginx/access.log", opts).unwrap();
        zw.write_all(b"EVIL_MARKER_123 nested\n").unwrap();
        zw.finish().unwrap();
    }
    write_targz(&root.join("deep/server.tar.gz"), &[("nginx.zip", &inner)]);

    // single-stream gz
    {
        let f = File::create(root.join("deep/deeper/auth.log.gz")).unwrap();
        let mut gz = flate2::write::GzEncoder::new(f, flate2::Compression::default());
        gz.write_all(b"login ok\nEVIL_MARKER_123 in gz\n").unwrap();
        gz.finish().unwrap();
    }

    // corrupt archive: must be skipped without crashing
    fs::write(root.join("corrupt.zip"), b"PK\x03\x04 not really a zip").unwrap();

    let rules = tmp.path().join("test.yar");
    fs::write(&rules, RULE).unwrap();
    let output = tmp.path().join("report.json");
    Fixture { root, rules, output, _tmp: tmp }
}

fn config(fx: &Fixture) -> Config {
    let cli = Cli::try_parse_from([
        "yarax-scanner",
        fx.root.to_str().unwrap(),
        fx.rules.to_str().unwrap(),
        "--output", fx.output.to_str().unwrap(),
        "--threads", "4",
        "--quiet",
    ]).unwrap();
    Config::from_cli(cli).unwrap()
}

#[test]
fn full_pipeline_with_archives() {
    let fx = fixture();
    let snap = run(&config(&fx)).unwrap();

    let doc: serde_json::Value =
        serde_json::from_str(&fs::read_to_string(&fx.output).unwrap()).unwrap();
    let hits = doc["hits"].as_array().unwrap();
    let files: Vec<&str> = hits.iter()
        .map(|h| h["file"].as_str().unwrap()).collect();

    // plain file hit
    assert!(files.iter().any(|f| f.replace('\\', "/").ends_with("deep/bad.log")));
    // zip member hit with :: path + archive fields
    let zip_hit = hits.iter()
        .find(|h| h["file"].as_str().unwrap().contains("logs.zip::"))
        .expect("zip member hit");
    assert_eq!(zip_hit["internal_path"], "apache/access.log");
    assert!(zip_hit["archive"].as_str().unwrap().ends_with("logs.zip"));
    assert_eq!(zip_hit["sha256"].as_str().unwrap().len(), 64);
    // nested chain
    assert!(files.iter().any(
        |f| f.ends_with("server.tar.gz::nginx.zip::nginx/access.log")));
    // gz single stream
    assert!(files.iter().any(|f| f.contains("auth.log.gz::auth.log")));

    assert_eq!(hits.len(), 4, "expected exactly 4 hits, got: {files:?}");
    assert_eq!(snap.matches, 4);
    // corrupt.zip must have produced an error, not a crash
    assert!(snap.errors >= 1);
    // matched strings recorded with offsets
    assert!(zip_hit["matched_strings"].as_array().unwrap().len() >= 1);
    assert!(doc["scan_information"]["scan_rate_mb_per_second"].is_number());
}

#[test]
fn bomb_guard_output_cap() {
    let fx = fixture();
    // Highly compressible bomb-ish zip: 64 MiB of zeros.
    write_zip(&fx.root.join("bomb.zip"),
              &[("zeros.bin", vec![0u8; 64 << 20].as_slice())]);
    let mut cfg = config(&fx);
    cfg.max_archive_output = 1 << 20; // 1 MiB cap
    let snap = run(&cfg).unwrap();
    // The bomb tripped the guard (error counted), scan completed anyway.
    assert!(snap.errors >= 1);
    assert!(snap.files_scanned >= 4);
}

#[test]
fn extension_filter_and_exclude() {
    let fx = fixture();
    let cli = Cli::try_parse_from([
        "yarax-scanner",
        fx.root.to_str().unwrap(),
        fx.rules.to_str().unwrap(),
        "--output", fx.output.to_str().unwrap(),
        "--extensions", "log",
        "--scan-archives", "false",
        "--quiet",
    ]).unwrap();
    let cfg = Config::from_cli(cli).unwrap();
    let snap = run(&cfg).unwrap();
    // only *.log files scanned: clean.log + deep/bad.log
    assert_eq!(snap.files_scanned, 2);
    assert_eq!(snap.matches, 1);
}

#[test]
fn multiple_rule_sources_scan_together() {
    let fx = fixture();
    // Two bundles in directories with spaces; same file name in both to
    // prove namespaces keep them apart; plus a second single-file source.
    let a = fx.root.parent().unwrap().join("bundle a");
    let b = fx.root.parent().unwrap().join("bundle b");
    fs::create_dir_all(&a).unwrap();
    fs::create_dir_all(&b).unwrap();
    fs::write(a.join("same.yar"), RULE).unwrap();
    fs::write(b.join("same.yar"), "rule Second_Rule { strings: $m = \"EVIL_MARKER_123\" condition: $m }").unwrap();

    let cli = Cli::try_parse_from([
        "yarax-scanner",
        "--path", fx.root.to_str().unwrap(),
        "--rules", a.to_str().unwrap(),
        "--rules", b.to_str().unwrap(),
        "--rules", fx.rules.to_str().unwrap(), // duplicate of RULE content, different file
        "--output", fx.output.to_str().unwrap(),
        "--threads", "2", "--quiet",
    ]).unwrap();
    run(&Config::from_cli(cli).unwrap()).unwrap();

    let doc: serde_json::Value =
        serde_json::from_str(&fs::read_to_string(&fx.output).unwrap()).unwrap();
    let rules: std::collections::HashSet<&str> = doc["hits"].as_array().unwrap().iter()
        .map(|h| h["rule"].as_str().unwrap()).collect();
    assert!(rules.contains("Suspicious_Marker") && rules.contains("Second_Rule"), "{rules:?}");
}

#[test]
fn invalid_rule_source_is_a_clear_error() {
    let fx = fixture();
    let empty = fx.root.parent().unwrap().join("empty rules");
    fs::create_dir_all(&empty).unwrap();
    let cli = Cli::try_parse_from([
        "yarax-scanner",
        "--path", fx.root.to_str().unwrap(),
        "--rules", fx.rules.to_str().unwrap(),
        "--rules", empty.to_str().unwrap(),
        "--output", fx.output.to_str().unwrap(), "--quiet",
    ]).unwrap();
    let err = run(&Config::from_cli(cli).unwrap()).unwrap_err();
    assert!(format!("{err:#}").contains("no rule files found"), "{err:#}");
}

#[test]
fn skip_invalid_rules_scans_with_the_good_files() {
    let fx = fixture();
    let rules = fx.root.parent().unwrap().join("mixed rules");
    fs::create_dir_all(&rules).unwrap();
    fs::write(rules.join("good.yar"), RULE).unwrap();
    fs::write(rules.join("bad.yar"), "rule broken { condition: no_such_thing }").unwrap();

    let args = |skip: bool| {
        let mut v = vec!["yarax-scanner", "--path", fx.root.to_str().unwrap(),
                         "--rules", rules.to_str().unwrap(),
                         "--output", fx.output.to_str().unwrap(), "--quiet"];
        if skip { v.push("--skip-invalid-rules"); }
        Config::from_cli(Cli::try_parse_from(v).unwrap()).unwrap()
    };
    // default: a bad rule file aborts, and the message points at the file
    let err = run(&args(false)).unwrap_err();
    assert!(format!("{err:#}").contains("bad.yar"), "{err:#}");
    // opt-in: scan with the file that compiles
    run(&args(true)).unwrap();
    let doc: serde_json::Value =
        serde_json::from_str(&fs::read_to_string(&fx.output).unwrap()).unwrap();
    assert!(doc["hits"].as_array().unwrap().iter().any(|h| h["rule"] == "Suspicious_Marker"));
}

// ---------------------------------------------------------------------------
// Forensic event stream (<report>.events.ndjson)
// ---------------------------------------------------------------------------

fn read_events(report: &Path) -> Vec<serde_json::Value> {
    let p = yarax_scanner::events::events_path(report);
    fs::read_to_string(&p).unwrap().lines()
        .map(|l| serde_json::from_str(l).expect("every line is one JSON object")).collect()
}

#[test]
fn event_stream_matches_the_scan() {
    let fx = fixture();
    // unusual name: spaces, unicode, quotes
    let odd = fx.root.join("Dossier Ünïcode").join("naïve 'file' (1).log");
    fs::create_dir_all(odd.parent().unwrap()).unwrap();
    fs::write(&odd, "EVIL_MARKER_123").unwrap();

    let cli = Cli::try_parse_from([
        "yarax-scanner", fx.root.to_str().unwrap(), fx.rules.to_str().unwrap(),
        "--output", fx.output.to_str().unwrap(), "--quiet", "--target-host", "WEB01",
    ]).unwrap();
    let snap = run(&Config::from_cli(cli).unwrap()).unwrap();
    let ev = read_events(&fx.output);

    let of = |t: &str| ev.iter().filter(|e| e["event_type"] == t).collect::<Vec<_>>();
    let (matches, errors, summaries) = (of("yara_match"), of("scan_error"), of("scan_summary"));
    assert_eq!(matches.len() as u64, snap.matches);
    assert_eq!(matches.len(), 5);
    assert_eq!(errors.len() as u64, snap.errors, "every unreadable item is an event");
    assert!(errors.iter().any(|e| e["file_path"].as_str().unwrap().ends_with("corrupt.zip")));
    assert_eq!(summaries.len(), 1);
    assert_eq!(ev.last().unwrap()["event_type"], "scan_summary", "summary is the last line");

    let s = summaries[0];
    assert_eq!(s["scan_status"], "completed_with_errors");
    assert_eq!(s["scan_files_examined"].as_u64(), Some(snap.files_scanned));
    assert_eq!(s["scan_matches"].as_u64(), Some(5));
    assert_eq!(s["scan_files_matched"].as_u64(), Some(5));
    assert_eq!(s["scan_errors_count"].as_u64(), Some(snap.errors));

    // one scan, unique events, target host as given
    let ids: std::collections::HashSet<_> = ev.iter().map(|e| e["event_id"].as_str().unwrap()).collect();
    assert_eq!(ids.len(), ev.len());
    assert!(ev.iter().all(|e| e["scan_id"] == ev[0]["scan_id"] && e["host"] == "WEB01"));

    // exact path, real hash and real timestamps for an on-disk hit
    let hit = matches.iter().find(|m| m["file_name"] == "naïve 'file' (1).log").expect("unicode hit");
    assert_eq!(hit["file_path"].as_str().unwrap(), odd.to_str().unwrap());
    assert_eq!(hit["file_hash_sha256"].as_str().unwrap().len(), 64);
    assert_eq!(hit["file_hash_scope"], "full_file");
    assert_eq!(hit["file_size_bytes"], 15);
    assert!(hit["file_modified_time"].as_str().unwrap().ends_with('Z'));
    assert_eq!(hit["file_changed_during_scan"], false);
    assert_eq!(hit["yara_rule_name"], "Suspicious_Marker");
    assert_eq!(hit["yara_rule_author"], "e2e");
    assert_eq!(hit["yara_rule_source_path"].as_str().unwrap(), fx.rules.to_str().unwrap());
    assert_eq!(hit["yara_rule_hash_sha256"].as_str().unwrap(), yarax_scanner::utils::sha256_hex(RULE.as_bytes()));
    assert_eq!(hit["yara_engine_version"].as_str().unwrap().split('.').count(), 3);

    // archive member: virtual path kept, archive identified
    let zip = matches.iter().find(|m| m["file_archive_member_path"] == "apache/access.log").unwrap();
    assert!(zip["file_archive_path"].as_str().unwrap().ends_with("logs.zip"));
    assert_eq!(zip["file_access_method"], "archive_member");
    assert_eq!(zip["file_timestamp_status"], "unsupported_archive_member");

    // the report carries the same scan id
    let doc: serde_json::Value = serde_json::from_str(&fs::read_to_string(&fx.output).unwrap()).unwrap();
    assert_eq!(doc["scan_information"]["scan_id"], ev[0]["scan_id"]);
    assert_eq!(doc["scan_information"]["target_host"], "WEB01");
}

#[test]
fn rescan_resets_delivery_state() {
    let fx = fixture();
    let cfg = config(&fx);
    run(&cfg).unwrap();
    let events = yarax_scanner::events::events_path(&fx.output);
    let state = yarax_scanner::splunk::delivery_path(&events);
    fs::write(&state, r#"{"delivery_status":"delivered","events_total":9,"events_sent":9}"#).unwrap();
    run(&cfg).unwrap(); // same report name
    assert!(!state.exists(), "a new scan must not inherit the old scan's delivery state");
}

#[test]
fn failed_scan_is_recorded_not_silent() {
    let fx = fixture();
    let bad = fx.root.parent().unwrap().join("bad.yar");
    fs::write(&bad, "rule broken { condition: no_such_thing }").unwrap();
    let cli = Cli::try_parse_from([
        "yarax-scanner", fx.root.to_str().unwrap(), bad.to_str().unwrap(),
        "--output", fx.output.to_str().unwrap(), "--quiet",
    ]).unwrap();
    assert!(run(&Config::from_cli(cli).unwrap()).is_err());
    let ev = read_events(&fx.output);
    assert_eq!(ev.len(), 2);
    assert_eq!(ev[0]["error_type"], "rule_compilation_failed");
    assert_eq!(ev[0]["event_category"], "configuration");
    assert_eq!((ev[1]["scan_status"].as_str(), ev[1]["event_outcome"].as_str()), (Some("failed"), Some("failure")));
    assert_eq!(ev[1]["host"], "unknown", "no --target-host: unknown, not the scanner's name");
}

#[test]
fn skipped_rule_files_are_events() {
    let fx = fixture();
    let rules = fx.root.parent().unwrap().join("mixed");
    fs::create_dir_all(&rules).unwrap();
    fs::write(rules.join("good.yar"), RULE).unwrap();
    fs::write(rules.join("bad.yar"), "rule broken { condition: nope }").unwrap();
    let cli = Cli::try_parse_from([
        "yarax-scanner", fx.root.to_str().unwrap(), rules.to_str().unwrap(),
        "--output", fx.output.to_str().unwrap(), "--quiet", "--skip-invalid-rules",
    ]).unwrap();
    run(&Config::from_cli(cli).unwrap()).unwrap();
    let ev = read_events(&fx.output);
    let skipped: Vec<_> = ev.iter().filter(|e| e["error_type"] == "rule_file_skipped").collect();
    assert_eq!(skipped.len(), 1);
    assert!(skipped[0]["yara_rule_source_path"].as_str().unwrap().ends_with("bad.yar"));
    assert_eq!(ev.last().unwrap()["scan_rule_files_skipped"], 1);
}

#[test]
fn splunk_needs_token_and_report() {
    let fx = fixture();
    std::env::remove_var(yarax_scanner::splunk::TOKEN_ENV);
    let cli = Cli::try_parse_from([
        "yarax-scanner", fx.root.to_str().unwrap(), fx.rules.to_str().unwrap(),
        "--output", fx.output.to_str().unwrap(), "--splunk-url", "https://127.0.0.1:1",
    ]).unwrap();
    let err = Config::from_cli(cli).err().expect("token required");
    assert!(err.to_string().contains("YARAX_SPLUNK_TOKEN"), "{err}");
}
