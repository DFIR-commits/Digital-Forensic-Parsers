#!/usr/bin/env bash
# Builds yarax-scanner (command line) into ./dist
#
#   ./build-linux.sh          release build of the CLI scanner (slow, lots of RAM)
#   ./build-linux.sh --gui    also build yarax-gui (needs a desktop session to run)
#   ./build-linux.sh --fast   dev build: compiles much faster, binaries are huge
#
# Installs missing prerequisites (C compiler, cmake, pkg-config, and Rust via
# rustup). Uses sudo for system packages when not run as root.
set -euo pipefail
cd "$(dirname "$0")"

GUI=0; FAST=0
for a in "$@"; do
  case "$a" in
    --gui) GUI=1 ;;
    --fast) FAST=1 ;;
    *) echo "unknown option: $a (use --gui and/or --fast)"; exit 2 ;;
  esac
done

have() { command -v "$1" >/dev/null 2>&1; }
SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
[ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"

install_pkgs() {  # apt-names... | dnf-names... | pacman-names  (see calls below)
  if have apt-get; then $SUDO apt-get update && $SUDO apt-get install -y $1
  elif have dnf; then $SUDO dnf install -y $2
  elif have pacman; then $SUDO pacman -S --needed --noconfirm $3
  else echo "No supported package manager. Install manually: $1"; exit 1; fi
}

if ! have cc || ! have cmake || ! have pkg-config || ! have curl; then
  echo "Installing build tools..."
  install_pkgs "build-essential cmake pkg-config curl ca-certificates" \
               "gcc gcc-c++ make cmake pkgconf-pkg-config curl" \
               "base-devel cmake pkgconf curl"
fi
if [ "$GUI" = 1 ]; then
  # file-dialog backend (rfd -> GTK3); windowing libraries are loaded at run time
  install_pkgs "libgtk-3-dev" "gtk3-devel" "gtk3"
fi
if ! have cargo; then
  echo "Installing Rust (rustup)..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
  . "$HOME/.cargo/env"
fi

PROFILE=release; ARGS=(--release)
[ "$FAST" = 1 ] && { PROFILE=debug; ARGS=(); }
[ "$GUI" = 1 ] && ARGS+=(--features gui)

echo "cargo build ${ARGS[*]:-}"
cargo build "${ARGS[@]}"

mkdir -p dist
cp "target/$PROFILE/yarax-scanner" dist/
if [ "$GUI" = 1 ]; then
  cp "target/$PROFILE/yarax-gui" yarax-scanner.png dist/
  # menu entry + taskbar icon (Wayland docks match it by app_id = file name). yarax-gui
  # rewrites the same two files at start-up, so a moved folder fixes itself on next launch.
  APPS="$HOME/.local/share/applications"; ICONS="$HOME/.local/share/icons/hicolor/256x256/apps"
  mkdir -p "$APPS" "$ICONS"
  cp yarax-scanner.png "$ICONS/yarax-gui.png"
  cat > "$APPS/yarax-gui.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=YARA-X Scanner
Exec="$PWD/dist/yarax-gui"
Icon=yarax-gui
StartupWMClass=yarax-gui
Categories=Utility;Security;
EOF
fi
echo
echo "Done. Scan:  ./dist/yarax-scanner --path /mnt/evidence --rules /path/to/rules --output report.json"
echo "Rule check:  ./dist/yarax-scanner --check-rules --rules /path/to/rules"
