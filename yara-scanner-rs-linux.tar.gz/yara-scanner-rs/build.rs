//! Records the yara-x version actually locked in Cargo.lock as
//! YARAX_ENGINE_VERSION, so reports name the real engine version.

fn main() {
    println!("cargo:rerun-if-changed=Cargo.lock");
    let lock = std::fs::read_to_string("Cargo.lock").unwrap_or_default();
    let version = lock
        .split("[[package]]")
        .find(|p| p.contains("\nname = \"yara-x\"\n"))
        .and_then(|p| p.lines().find_map(|l| l.strip_prefix("version = \"")))
        .map(|v| v.trim_end_matches('"').to_string())
        .unwrap_or_else(|| "unknown".into());
    println!("cargo:rustc-env=YARAX_ENGINE_VERSION={version}");
}
