#!/usr/bin/env python3
"""Save DFIR-IRIS cases and their IOCs to one JSON file for yarax-scanner.

For when the scanning machine can't reach IRIS: run this on a machine that
can, write the file somewhere both can see, then give its path to
yarax-scanner as the IRIS URL (GUI field or --iris-url). Pick cases and
IOCs there as usual. Rerun to refresh. Standard library only; read-only.

  python3 tools/iris_snapshot.py --insecure --out /mnt/share/iris-snapshot.json

The IRIS URL is IRIS_URL below. The API key is asked for when it runs
(typing is not shown) and is sent only in the Authorization header.
"""
import argparse, datetime, getpass, json, os, ssl, sys, urllib.error, urllib.request

# The DFIR-IRIS server to read from. Replace the placeholder with your IRIS URL,
# e.g. "https://iris.your-domain:8443" (no trailing path).
IRIS_URL = "https://REPLACE-WITH-IRIS-URL.invalid"

FORMAT = "yarax-iris-snapshot/1"  # must match SNAPSHOT_FORMAT in src/iris.rs


class NoRedirect(urllib.request.HTTPRedirectHandler):
    # urllib would resend the Authorization header to wherever a redirect points
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def snapshot(url, key, out, insecure=False, case_ids=None):
    """Fetch the cases (all, or case_ids) and their IOCs from url; write out."""
    base = url.strip().rstrip("/")
    ctx = ssl.create_default_context()
    if insecure:
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), NoRedirect)

    def get(path):
        req = urllib.request.Request(base + path, headers={"Authorization": f"Bearer {key}"})
        try:
            with opener.open(req, timeout=60) as r:
                v = json.load(r)
        except urllib.error.HTTPError as e:
            why = {401: " (API key rejected)", 403: " (API key lacks permission)"}.get(e.code, "")
            if 300 <= e.code < 400:
                why = f" (redirect to {e.headers.get('Location')} not followed - check IRIS_URL)"
            sys.exit(f"{path}: HTTP {e.code}{why}")
        except (urllib.error.URLError, OSError) as e:
            sys.exit(f"cannot reach IRIS at {base}: {e}")
        except ValueError:
            sys.exit(f"{path}: not JSON - is {base} the IRIS URL?")
        if v.get("status") != "success":
            sys.exit(f"{path}: IRIS error: {v.get('message')}")
        return v["data"]

    cases, page = [], 1
    while page:
        d = get(f"/manage/cases/filter?per_page=100&page={page}")
        cases += d["cases"]
        page = d.get("next_page")
    if case_ids:
        missing = set(case_ids) - {c["case_id"] for c in cases}
        if missing:
            sys.exit(f"case(s) not found or not visible to this key: {sorted(missing)}")
        cases = [c for c in cases if c["case_id"] in case_ids]

    iocs = {}
    for c in cases:
        iocs[str(c["case_id"])] = get(f"/case/ioc/list?cid={c['case_id']}")
        print(f"  #{c['case_id']:<5} {len(iocs[str(c['case_id'])].get('ioc', [])):>4} IOCs  {c['name']}")

    snap = {"format": FORMAT, "iris_url": base,
            "fetched_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
            "cases": cases, "iocs": iocs}
    tmp = out + ".tmp"  # write then rename: a reader never sees half a file
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(snap, f)
    os.replace(tmp, out)
    print(f"{len(cases)} case(s) -> {out}")


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", required=True, help="snapshot file to write")
    ap.add_argument("--insecure", action="store_true", help="don't verify the certificate (IRIS ships a self-signed one)")
    ap.add_argument("--case", type=int, action="append", help="only this case id (repeatable; default: all)")
    a = ap.parse_args()
    if "REPLACE-WITH-IRIS-URL" in IRIS_URL:
        sys.exit(f"IRIS_URL is not set: edit IRIS_URL near the top of {os.path.abspath(__file__)}")

    print(f"IRIS: {IRIS_URL}")
    try:
        key = getpass.getpass("DFIR-IRIS API key (IRIS: user menu > My settings; typing is not shown): ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit("no API key entered")
    if not key:
        sys.exit("no API key entered")
    snapshot(IRIS_URL, key, a.out, a.insecure, a.case)


if __name__ == "__main__":
    main()
