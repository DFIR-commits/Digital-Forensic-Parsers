# Testing

What was tested for 1.0.0, how, and the results. Everything below was run on
2026-11-03 against the code in this release.

## Test suites

| Suite | What it covers | Result |
|---|---|---|
| `cargo test --locked` (unit) | Splunk event schema (12) and HEC delivery/resume (9), GUI logic (12: validation, argument building, progress parsing, report summary), IRIS IOC-to-rule conversion (7), file metadata (3), rule check (2), engine (1) | 46 passed |
| `cargo test --locked` (end-to-end) | real YARA-X scans: archives, several rule sources, paths with spaces, empty/invalid rule sources | 11 passed |
| `tests/integration_cli.sh` | the built binary, end to end (below) | 52 passed, 0 failed |

`tests/integration_cli.sh` checks:

- hits on plain files, a folder with spaces, a nested zip, a tar.gz and a
  single .gz; clean files not matched; the reported SHA-256 is the file's real
  hash; the event stream ends with the scan summary
- the positional `PATH RULES` form
- the evidence is unchanged after a scan (content hashes, mtimes, sizes)
- bad usage exits 2 and writes no report: missing scan path, missing rules,
  an extra positional argument, Splunk without a token, a bad `--external`
- `--check-rules` (exit 0 / exit 1 and names the broken file), a broken rule
  file aborts the scan (exit 2) with a `failed` summary event,
  `--skip-invalid-rules`
- a report saved inside the scanned folder is not scanned and not counted
- unreadable items (run as an unprivileged user): exit 1, a locked folder
  (`dir`), an unreadable file (`open`), an encrypted zip member (`member`)
  while the unencrypted member of the same zip still matches
- a scan killed with SIGKILL leaves a spool whose every line is valid JSON
- live Splunk HEC (optional): connection test, all events delivered, the token
  never written to disk, a wrong token exits 1
- live DFIR-IRIS (optional, read-only): list cases, list a case's IOCs, export
  rules, the exported rules compile, a wrong key exits 1, a snapshot file gives
  the same result as the live API

Run with live services: Splunk Enterprise in Docker (HEC over HTTP, index
`yarax`), DFIR-IRIS v2.4.27 in Docker (self-signed certificate). Splunk: 13 of
13 events delivered. IRIS: a case with 11 IOCs gave 8 rules; the 3 left out
were a community-id, a 2-character mutex and a YARA-rule IOC, each with its
reason.

## Clean install

`tests/clean_install_test.sh` in a fresh container, as a normal user with sudo:
`./build-linux.sh --gui` from nothing, the menu entry and icon exist, no
unresolved GUI libraries (`ldd`), `cargo test`, the integration script, a
second build over the first, `--uninstall` and a check that it left nothing
behind. Docker on WSL2 (kernel 6.6), 2 CPUs, 6 GB RAM.

| Distribution | Build | Tests | Rebuild | Uninstall |
|---|---|---|---|---|
| Ubuntu 24.04.5 | ok, 9.5 min, self-test ok | 46 + 11 passed; integration 40 passed | ok | clean |
| Ubuntu 22.04.5 | ok, 9.6 min, self-test ok | 46 + 11 passed; integration 40 passed | ok | clean |
| Debian 12 | ok, 9.7 min, self-test ok | 46 + 11 passed; integration 40 passed | ok | clean |

All three: Rust 1.99.1 installed by the script, menu entry and icon present,
0 unresolved GUI libraries. The integration count is 40 here because the
optional live Splunk and IRIS checks are skipped inside these containers.

## On a SIFT workstation

SANS SIFT on Ubuntu 24.04.4, GNOME 46 on Wayland, in a VMware VM.

- **GUI walkthrough.** Every step in the README was done in the GUI and
  screenshotted: rules and rule check, IRIS cases and IOCs (from a snapshot
  file), creating the case rule file, a target with host-from-path, advanced
  options and the command-line preview, the Splunk connection test, a scan of
  two staged hosts (9 files, 8 matches, 1 unreadable file, 28 of 28 events
  delivered to Splunk), and closing the window during a scan: *Keep scanning*
  keeps it running; *Stop the scan and close* ends both the GUI and the
  scanner, and the stopped scan's spool is valid line by line.
- **Damaged disk.** A small ext4 image behind a device-mapper target with
  unreadable regions inside two files (8 MB and under 1 MiB), mounted
  read-only. Before the fix, the scan died with SIGBUS (exit 135, empty
  report). After it, three cold-cache runs each exited 1 with both files listed
  as `read` errors, the readable file next to them matched, and the report was
  complete.
- **Speed of the read-through** (the fix above). A 1 GB file: 2.25 s cold,
  0.55 s warm, of which the extra read is 0.24 s warm (1.64 s cold).

## Not tested

- Windows and macOS (`build-gui.ps1` is kept but untested for this release).
- Fedora/RHEL (dnf) and Arch (pacman) paths of `build-linux.sh`.
- The `sevenz` and `rar` features.
- A real failing disk (the damaged-disk test uses device-mapper error targets),
  and evidence over network shares.
- Very large evidence sets for memory and throughput beyond the numbers above.
