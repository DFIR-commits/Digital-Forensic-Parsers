# Changelog

## 1.0.0 - 2026-11-03

First release as a standalone repository (Linux).

Fixed

- A damaged disk no longer ends the whole scan. Files over 1 MiB were scanned
  only through a memory map, and an I/O error on a mapped page killed the
  process (SIGBUS, empty report). Each such file is now read through first;
  a bad sector becomes a `read` entry in the unreadable list.
- A mistyped scan path is now bad usage (exit 2, no report) instead of a
  "completed with errors" scan of 0 files.
- Extra positional arguments are rejected instead of silently ignored.
- The scanner no longer scans its own report, event and delivery files when
  they are saved inside the scan target.
- Encrypted zip members are listed in the unreadable list (`member`) instead of
  being skipped with only a debug log line.
- Closing the GUI during a scan asks first instead of leaving the scan
  running unseen.

Added

- `build-linux.sh`: `--uninstall`, `--help`, `--locked` builds, a post-build
  self-test, a low-memory warning, and XDG data-folder support.
- `tests/integration_cli.sh`: end-to-end test of the built binary, with
  optional live Splunk HEC and DFIR-IRIS checks.
- `tests/clean_install_test.sh`: clean install, test, rebuild and uninstall in
  a fresh container.
- README rewritten for analysts, with real screenshots; `docs/TESTING.md`.

Changed

- `Cargo.toml`: no licence claim; `publish = false`.
