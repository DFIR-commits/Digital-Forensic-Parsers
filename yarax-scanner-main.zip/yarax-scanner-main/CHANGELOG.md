# Changelog

## Unreleased

Fixed
- `./build-linux.sh` gave "Permission denied" on a fresh clone: the scripts were committed
  without the execute bit. `build-linux.sh`, the two test scripts and `tools/iris_snapshot.py`
  are now executable. The README says what to do when a copy has lost the permissions.

Changed
- `tools/iris_snapshot.py`: the IRIS URL is set in the script (`IRIS_URL`, a placeholder until
  you edit it) instead of being a command-line argument, and the API key is asked for at run
  time without echoing. `--key` and the `YARAX_IRIS_API_KEY` / `IRIS_API_KEY` environment
  variables are no longer read by it. It no longer follows HTTP redirects, which would have sent
  the key on to the redirect target.
- README: a step-by-step section for snapshots (no connection to IRIS from the scanning machine).

## 1.0.0 - 2026-11-03

First release as a standalone repository (Linux).

Fixed

- A damaged disk no longer ends the whole scan. Files over 1 MiB were scanned
  only through a memory map, and an I/O error on a mapped page killed the
  process (SIGBUS, empty report). Each such file is now read through first;
  a bad sector becomes a `read` entry in the unreadable list.
- A mistyped scan path is now bad usage (exit 2, no report) instead of a
  "completed with errors" scan of 0 files.
- Extra positional arguments are rejected instead of silently ignored.
- The scanner no longer scans its own report, event and delivery files when
  they are saved inside the scan target.
- Encrypted zip members are listed in the unreadable list (`member`) instead of
  being skipped with only a debug log line.
- Closing the GUI during a scan asks first instead of leaving the scan
  running unseen.

Added

- `build-linux.sh`: `--uninstall`, `--help`, `--locked` builds, a post-build
  self-test, a low-memory warning, and XDG data-folder support.
- `tests/integration_cli.sh`: end-to-end test of the built binary, with
  optional live Splunk HEC and DFIR-IRIS checks.
- `tests/clean_install_test.sh`: clean install, test, rebuild and uninstall in
  a fresh container.
- README rewritten for analysts, with real screenshots; `docs/TESTING.md`.

Changed

- `Cargo.toml`: no licence claim; `publish = false`.
