//! Worker — the hot path.
//!
//! Miss path per file (~99.99% of files on a real hunt):
//!
//! ```text
//! channel.recv -> [<=1MiB: read into reused buf + scan]
//!                 [>1MiB : mmap + scan &[u8] (zero copy)]
//!              -> two relaxed atomic adds -> done
//! ```
//!
//! * no stat (size arrived with the task),
//! * no heap allocation (task's PathBuf aside — freed immediately),
//! * no hashing / metadata / string formatting,
//! * YARA-X runs natively in-thread: no GIL, no FFI, LTO-inlined.
//!
//! Only a match triggers the slow path: single-pass SHA256+MD5 over the
//! same buffer/mmap (page cache hit — the file is read once total),
//! timestamps, entropy, magic, JSON emission via channel.

use crate::archives;
use crate::config::{Config, SMALL_FILE_THRESHOLD};
use crate::engine::Engine;
use crate::hashing::{hash_reader, hash_slice};
use crate::metadata::enrich_disk;
use crate::models::{FileTask, Hit};
use crate::stats::Stats;
use crossbeam_channel::{Receiver, Sender};
use memmap2::Mmap;
use std::fs::File;
use std::io::Read;
use std::time::Instant;

pub fn run_worker(cfg: &Config, engine: &Engine, rx: Receiver<FileTask>,
                  hit_tx: Sender<Hit>, stats: &Stats) {
    let mut scanner = engine.make_scanner();
    // Per-worker reusable buffers: zero steady-state allocations.
    let mut small_buf: Vec<u8> = Vec::with_capacity(SMALL_FILE_THRESHOLD as usize + 1);
    let mut hash_buf = vec![0u8; crate::config::IO_CHUNK];

    // Channel disconnect (walker done + queue drained) ends the loop.
    while let Ok(task) = rx.recv() {
        process(cfg, &mut scanner, &hit_tx, stats, &task,
                &mut small_buf, &mut hash_buf);
    }
}

fn process(cfg: &Config, scanner: &mut yara_x::Scanner, hit_tx: &Sender<Hit>,
           stats: &Stats, task: &FileTask,
           small_buf: &mut Vec<u8>, hash_buf: &mut [u8]) {
    let path = &task.path;
    let name = path.to_string_lossy();
    let t0 = Instant::now();

    // ---- archive dispatch by extension (one string test) ---------------
    if cfg.scan_archives && archives::is_archive_name(&name) {
        archives::scan_archive_file(cfg, stats, scanner, hit_tx, path, task.size);
        return;
    }

    // ---- small file: one read serves scan + magic-rescue + hashing -----
    if task.size <= SMALL_FILE_THRESHOLD {
        small_buf.clear();
        let mut f = match File::open(path) {
            Ok(f) => f,
            Err(e) => { stats.unreadable("open", &name, &e); return; }
        };
        if let Err(e) = f.read_to_end(small_buf) {
            stats.unreadable("read", &name, &e);
            return;
        }
        drop(f);

        // Magic rescue: 'notazip.dat' that is really an archive.
        if cfg.scan_archives && archives::is_archive_magic(small_buf) {
            archives::scan_archive_file(cfg, stats, scanner, hit_tx,
                                        path, small_buf.len() as u64);
            return;
        }

        let matches = match Engine::scan_buf(scanner, small_buf, cfg.max_match_data) {
            Ok(m) => m,
            Err(e) => { stats.unreadable("scan", &name, &e); return; }
        };
        let elapsed = t0.elapsed();
        stats.add_file(small_buf.len() as u64, elapsed.as_micros() as u64, false);
        if !matches.is_empty() {
            let (sha, md5) = hash_slice(small_buf);
            emit_disk_hits(cfg, hit_tx, stats, matches, task,
                           small_buf.len() as u64,
                           elapsed.as_secs_f64() * 1000.0,
                           sha, md5, small_buf);
        } else if cfg.hash_all {
            let _ = hash_slice(small_buf);
        }
        return;
    }

    // ---- large file: mmap zero-copy scan --------------------------------
    let file = match File::open(path) {
        Ok(f) => f,
        Err(e) => { stats.unreadable("open", &name, &e); return; }
    };
    // Read the whole file once before mapping it. An I/O error on a mapped page
    // is SIGBUS, which kills the process: one damaged file (a bad sector, a
    // corrupt E01 chunk behind a FUSE mount) would end the whole scan. A read()
    // error is just this file's error. The read also fills the page cache the
    // scan then maps.
    // ponytail: files larger than free RAM are read from disk twice; a device that
    // starts failing between this read and the scan can still SIGBUS.
    if let Err(e) = read_through(&file, hash_buf) {
        stats.unreadable("read", &name, &e);
        return;
    }
    // SAFETY: standard mmap caveat — if another process truncates the file
    // mid-scan a fault is possible; on forensic images/evidence mounts the
    // data is read-only, which is the deployment model.
    let mmap = match unsafe { Mmap::map(&file) } {
        Ok(m) => m,
        Err(e) => { stats.unreadable("mmap", &name, &e); return; }
    };
    #[cfg(unix)]
    let _ = mmap.advise(memmap2::Advice::Sequential); // kernel read-ahead

    let matches = match Engine::scan_buf(scanner, &mmap, cfg.max_match_data) {
        Ok(m) => m,
        Err(e) => { stats.unreadable("scan", &name, &e); return; }
    };
    let elapsed = t0.elapsed();
    stats.add_file(mmap.len() as u64, elapsed.as_micros() as u64, false);
    if !matches.is_empty() {
        // Hash straight from the mapping: pages are already hot.
        let (sha, md5) = hash_slice(&mmap);
        let sample_len = mmap.len().min(4096);
        emit_disk_hits(cfg, hit_tx, stats, matches, task, mmap.len() as u64,
                       elapsed.as_secs_f64() * 1000.0, sha, md5,
                       &mmap[..sample_len]);
    } else if cfg.hash_all {
        let _ = hash_reader(&mmap[..], hash_buf);
    }
}

/// Read `file` to the end, discarding the data: surfaces I/O errors as errors.
fn read_through(mut file: &File, buf: &mut [u8]) -> std::io::Result<()> {
    loop {
        match file.read(buf) {
            Ok(0) => return Ok(()),
            Ok(_) => {}
            Err(e) if e.kind() == std::io::ErrorKind::Interrupted => {}
            Err(e) => return Err(e),
        }
    }
}

#[allow(clippy::too_many_arguments)]
fn emit_disk_hits(cfg: &Config, hit_tx: &Sender<Hit>, stats: &Stats,
                  matches: Vec<crate::engine::OwnedMatch>, task: &FileTask,
                  size: u64, ms: f64, sha: String, md5: String,
                  sample: &[u8]) {
    let path = &task.path;
    let file = path.to_string_lossy();
    let relative = path.strip_prefix(&cfg.path)
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or_else(|_| file.clone().into_owned());
    let hits = Engine::build_hits(matches, &file, &relative, size, ms);
    let n = hits.len() as u64;
    for mut hit in hits {
        hit.sha256 = sha.clone();
        hit.md5 = md5.clone();
        enrich_disk(&mut hit, path, sample, (task.size, task.mtime));
        let _ = hit_tx.send(hit);
    }
    stats.add_matches(n);
}
