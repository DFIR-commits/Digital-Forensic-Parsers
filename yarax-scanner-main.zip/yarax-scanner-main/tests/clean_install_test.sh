#!/usr/bin/env bash
# Clean-install validation in a throwaway container (Ubuntu / Debian):
#
#   docker run --rm -v "$PWD:/src:ro" ubuntu:24.04 bash /src/tests/clean_install_test.sh
#
# Creates a normal user with sudo, runs ./build-linux.sh --gui as that user
# from nothing (packages, rustup, the release build, the menu entry, the
# self-test), runs tests/integration_cli.sh against the build, rebuilds, and
# uninstalls. Never run it on a machine you care about: it installs packages.
set -uo pipefail
. /etc/os-release; echo "== $PRETTY_NAME / kernel $(uname -r)"
export DEBIAN_FRONTEND=noninteractive
apt-get -qq update >/dev/null && apt-get -qq install -y sudo python3 zip util-linux >/dev/null 2>&1
useradd -m -s /bin/bash analyst && echo 'analyst ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/analyst
cp -r /src /home/analyst/yarax-scanner && rm -rf /home/analyst/yarax-scanner/dist /home/analyst/yarax-scanner/target
chown -R analyst: /home/analyst/yarax-scanner
as() { sudo -iu analyst bash -c "cd ~/yarax-scanner && $*"; }

echo "######## build-linux.sh --gui (clean)"
s=$(date +%s); as ./build-linux.sh --gui > /tmp/build.log 2>&1; rc=$?
echo "build rc=$rc in $(( $(date +%s) - s ))s; $(grep -m1 '^cargo ' /tmp/build.log)"; grep -E '^\s+(ok|FAIL)' /tmp/build.log
[ $rc = 0 ] || { tail -30 /tmp/build.log; exit 1; }
as 'test -x dist/yarax-gui && test -f ~/.local/share/applications/yarax-gui.desktop && test -f ~/.local/share/icons/hicolor/256x256/apps/yarax-gui.png' \
  && echo "menu entry and icon present" || echo "FAIL menu entry/icon missing"
as 'ldd dist/yarax-gui | grep -c "not found"' | sed 's/^/unresolved GUI libraries: /'

echo "######## unit + e2e tests (cargo test --locked)"
as 'source ~/.cargo/env && cargo test --locked --release 2>&1 | grep -E "^test result|FAILED|panicked"'

echo "######## integration (as analyst)"
as 'bash tests/integration_cli.sh dist/yarax-scanner' | grep -E '^(FAIL|passed)'

echo "######## rebuild (already installed)"
as ./build-linux.sh --gui > /tmp/rebuild.log 2>&1; echo "rebuild rc=$?"; grep -E '^\s+(ok|FAIL)' /tmp/rebuild.log

echo "######## uninstall"
as ./build-linux.sh --uninstall | tail -2
as 'test ! -e dist && test ! -e ~/.local/share/applications/yarax-gui.desktop && test ! -e ~/.local/share/icons/hicolor/256x256/apps/yarax-gui.png' \
  && echo "uninstall clean" || echo "FAIL uninstall left files"
