# YARA-X Scanner

Fast YARA scanning of mounted evidence, for forensic triage on Linux.
It is a command-line scanner (`yarax-scanner`) plus a desktop front end
(`yarax-gui`), built on [YARA-X](https://virustotal.github.io/yara-x/),
VirusTotal's Rust rewrite of YARA.

- Scans folders, mounted images and single files, including **inside zip, tar,
  gz, bz2 and xz archives**, streamed with no temporary files.
- Writes a JSON report, a list of everything it could **not** read, and a
  Splunk-ready event stream. It can send the events to Splunk HEC itself.
- Turns **DFIR-IRIS case IOCs** into YARA rules, one rule file per case.
- Checks rule files before a long scan and reports every compile error at once.

![The finished scan in the GUI](docs/screenshots/07-scan-finished.png)

## Quick start

```bash
git clone <repository-url> yarax-scanner && cd yarax-scanner
./build-linux.sh --gui        # installs what is missing, builds, adds a menu entry
```

Then open **YARA-X Scanner** from the applications menu (or `./dist/yarax-gui`).
From the command line:

```bash
./dist/yarax-scanner --check-rules --rules /path/to/rules
sudo ./dist/yarax-scanner --path /mnt/evidence --rules /path/to/rules --output ~/cases/report.json
```

Exit codes: `0` = finished, `1` = finished but some items could not be read (or
Splunk/IRIS delivery failed), `2` = bad usage or a fatal error (nothing scanned).

## Contents

- [Install](#install)
- [Walkthrough (GUI)](#walkthrough-gui)
- [Command line](#command-line)
- [Output files](#output-files)
- [Rules from DFIR-IRIS case IOCs](#rules-from-dfir-iris-case-iocs)
- [Splunk](#splunk)
- [Forensic and security notes](#forensic-and-security-notes)
- [Troubleshooting](#troubleshooting)
- [Uninstall](#uninstall)
- [How it works](#how-it-works)
- [Testing](#testing)

## Install

Linux only. Tested on Ubuntu 22.04 and 24.04, Debian 12, and the SANS SIFT
workstation (Ubuntu 24.04, GNOME on Wayland). See
[docs/TESTING.md](docs/TESTING.md).

```bash
./build-linux.sh             # command-line scanner only
./build-linux.sh --gui       # scanner + GUI + applications-menu entry and icon
./build-linux.sh --fast      # quick debug build, for trying changes
./build-linux.sh --help
```

No `chmod` is needed: the scripts are stored in the repository as executable,
and `git clone` (or unpacking a `.tar.gz` of the repository) keeps that. If you
copied the folder some other way, for example through a Windows machine or a
`.zip`, and see `Permission denied`, run the script through bash instead:

```bash
bash build-linux.sh --gui     # works whatever the file's permissions are
chmod +x build-linux.sh       # or make it executable again, then ./build-linux.sh --gui
```

Don't use `sudo` or `sh` to run it: `sudo ./build-linux.sh` makes the menu entry
for root instead of you, and `sh build-linux.sh` fails with
`Illegal option -o pipefail` (on Ubuntu and Debian, `sh` is not bash).

What the script does:

1. Installs a C compiler, CMake, pkg-config and curl if any are missing (apt,
   dnf or pacman; it uses `sudo` unless you are root). With `--gui` it also
   installs the GTK3 development files, which the file dialogs need.
2. Installs Rust with rustup into your home folder if `cargo` is missing.
3. Builds with `cargo build --release --locked`, so you get exactly the
   dependency versions in `Cargo.lock`.
4. Copies the programs to `./dist`. With `--gui` it also writes
   `~/.local/share/applications/yarax-gui.desktop` and the icon.
5. Checks the build: it scans `examples/samples` with `examples/rules` and
   expects exactly one hit, on `malicious_sample.txt`.

Run it as the user who will use the GUI, not with `sudo`: the menu entry is
made for the user who runs the script.

Requirements:

- About **3 GB of RAM plus swap** for the release build. The script warns
  when there is less. A clean build took about 10 minutes on 2 CPU cores in testing.
- Internet access for the first build, to download Rust and the crates. To
  build offline, run `cargo vendor` on a connected machine and copy the
  folder with it.
- A desktop session (X11 or Wayland) for the GUI. The scanner itself needs
  none.

Keep `yarax-gui` and `yarax-scanner` in the same folder: the GUI runs the
scanner that sits next to it.

Optional formats: `cargo build --release --features sevenz,rar` adds 7z and
RAR. RAR links the proprietary unrar library. These features are not part of
the tested build.

## Walkthrough (GUI)

This walkthrough scans two staged evidence folders (`WEB01` and `DC01`) with
the example rules plus rules made from an IRIS case. Every screenshot is from a
real run on a SIFT workstation.

### 1. Add rules and check them

![Start screen](docs/screenshots/01-start.png)

Press **Add rule folder…** (folders are searched recursively) or **Add rule
file…**. Add as many as you need; all of them are compiled together. Each entry
shows a ✔ and its file count, or ✖ and the reason (missing, empty, unreadable).

Press **Check rules** before a big scan. YARA-X is stricter than classic YARA,
so rules that worked with `yara` can fail here. The check lists every failing
file with line, column and the compiler's message.

![Rules checked](docs/screenshots/02-rules-checked.png)

If some files will not compile, either fix them or tick **If a rule file fails
to compile, skip it**. Skipped files are named in the log; nothing is skipped
silently.

### 2. Optional: add rules from an IRIS case

Open **Add rules from DFIR-IRIS case IOCs**. Enter the IRIS URL and your API
key (IRIS: user menu > *My settings*). IRIS ships with a self-signed
certificate, so tick **Don't verify the server certificate** unless your IRIS
has a trusted one. Press **Load cases** and tick a case.

![IRIS case IOCs](docs/screenshots/03-iris-iocs.png)

(These screenshots load a [snapshot file](#rules-from-dfir-iris-case-iocs)
instead of a live IRIS, so the URL field shows a file path and no API key is
needed.)

The table shows each IOC and how it will be searched for. IOCs that cannot
become a file-content rule are marked **left out**; hover for the reason (here,
a network community-id, and a mutex value too short to search for safely).
Untick anything you don't want, then press **Create rule files**. The rule file
is written and added to the rule list.

![IRIS rule file created](docs/screenshots/04-iris-rules-created.png)

**Save settings** stores the URL and key in `~/.config/yarax-scanner/iris.json`,
readable by your user only. Without it, the key is kept only while the window
is open.

### 3. Choose what to scan

Choose **Directory**, **Mounted drive / volume** or **Single file**, then
browse to it.

If you know which computer the evidence came from, type it in **Evidence host
name**; it becomes the `host` in Splunk. If one folder holds several hosts laid
out as `<folder>/<host>/<image>/<partition>/…`, tick **Host = folder name
under** and pick that folder instead. Each file then gets the host from its own
path, so one scan can cover many hosts.

**Advanced options** has the remaining command-line options: threads, symbolic
links, extension filter, include and exclude patterns, hash every file, archive
limits and YARA external variables. At the bottom it shows the **command-line
equivalent** of everything you have set, ready to paste into a script.

![Target and advanced options](docs/screenshots/05-target-and-options.png)

**Per-file timeout** (default 60 s): a file that runs out of time is not fully
scanned and is listed as `timeout`. Big logs with regex-heavy rules may need
300 s or more.

### 4. Choose where to save the report

Press **Choose folder…**. Leave the file name blank for
`yarax-report-<date-time>.json`. An existing report is never overwritten unless
you tick **Overwrite**. The folder is test-written before the scan starts.

Save reports **outside the evidence** (for example in your case folder). If
you do save inside the scanned folder, the scanner skips its own report files.

### 5. Optional: send results to Splunk

Tick **Send detections…**, enter the HEC URL, token and index, and press **Test
connection**. It sends one event labelled `event_type=connection_test`.

![Splunk connection test](docs/screenshots/06-splunk-test.png)

HEC accepts events for an index that does not exist and drops them later, so
search for the test event once (`index=yarax event_type=connection_test`) before
relying on it.

### 6. Scan

Press **Start scan**. The window shows elapsed time and live counts of files,
data, matches and unreadable items. It shows no percentage, because the total is
not known until the scan finishes.

When the scan finishes, the window shows a summary, the Splunk delivery
result, the report path with **Show in folder**, and the list of unreadable
items. The screenshot at the top of this page is this demo: 9 files scanned,
8 matches across the two hosts, and one file that could not be opened.

Closing the window during a scan asks first:

![Close while scanning](docs/screenshots/08-close-while-scanning.png)

**Cancel scan** or **Stop the scan and close** kills the scanner. The `.json`
report of a stopped scan is incomplete and is not valid JSON. Everything found
up to that point is in the `.events.ndjson` and `.unreadable.tsv` files next
to it.

## Command line

```bash
yarax-scanner --path /mnt/evidence --rules rules/ --output report.json
yarax-scanner /mnt/evidence rules/ --output report.json          # same, positional form

# several rule sources, filters, a size limit
yarax-scanner --path /mnt/image --rules rules/vendor-a --rules "rules/my bundle" \
    --extensions log,txt,ps1 --exclude '**/node_modules/**' \
    --max-file-size 2G --skip-large-files --output hits.json

# pre-compiled rules load faster on repeated runs (yr is the YARA-X CLI)
yr compile rules/ -o rules.yarc
yarax-scanner --path /mnt/evidence --rules rules.yarc --output report.json
```

| Option | Meaning |
|---|---|
| `--path P`, `--rules R` | What to scan, and a rule file or folder. Repeat `--rules` for several. |
| `--output FILE` | The JSON report. Without it, the report goes to stdout. |
| `--check-rules` | Only compile the rules and report every failure. Exit 1 if any file fails. |
| `--skip-invalid-rules` | Scan with the rule files that compile; name the ones skipped. |
| `--threads N` | Worker threads (default: one per CPU). More helps on slow network/FUSE mounts. |
| `--recursive true\|false`, `--follow-links` | Subfolders (default on); follow symbolic links (default off). |
| `--extensions a,b`, `--include GLOB`, `--exclude GLOB` | Filters. `--include`/`--exclude` repeat. |
| `--max-file-size 500M`, `--skip-large-files` | Size limit; skipped files are not listed as unreadable. |
| `--timeout SECS` | Per-file scan timeout (default 60). |
| `--hash-all` | Hash every file, not just matches (slower). |
| `--external KEY=VALUE` | YARA external variable. Repeatable. |
| `--scan-archives true\|false` | Look inside archives (default on). |
| `--max-archive-depth 3`, `--max-member-size 512M`, `--max-archive-output 8G`, `--max-compression-ratio 1000` | Archive-bomb limits. |
| `--target-host NAME`, `--host-from-path DIR` | Evidence host for Splunk; see [docs/SPLUNK.md](docs/SPLUNK.md). |
| `--quiet`, `--verbose` | Less or more logging. |

The Splunk and IRIS options are below. `yarax-scanner --help` lists everything.

With several rule sources, each file gets a namespace prefixed with its source
position (`src0:`, `src1:`, …), so files or rules with the same name in
different bundles don't collide. A pre-compiled `.yarc` must be used alone.

When stderr is not a terminal and `--quiet` is not set, the scanner prints
`PROGRESS files=N bytes=N hits=N errors=N` every 2 seconds. The GUI reads these
lines.

## Output files

For `--output report.json` (all are written next to it):

| File | What it is |
|---|---|
| `report.json` | The report: `hits[]` and `scan_information` (totals, rates, `scan_id`, `ruleset_sha256`, …). Complete and valid only when the scan finishes. |
| `report.unreadable.tsv` | Every item that could not be read or fully scanned: `kind`, `path`, `reason`. Written as the scan runs. Only created when something was unreadable. |
| `report.events.ndjson` | One JSON event per rule, detection, unreadable item and scan summary. Each line is flushed as it is written. This is what goes to Splunk. |
| `report.events.delivery.json` | Splunk delivery state, only when Splunk is used. |

A hit looks like this (shortened):

```json
{
  "rule": "IRIS_c2_ioc16_named_pipe",
  "file": "/evidence/WEB01/…/Downloads/tools.zip::notes.txt",
  "archive": "/evidence/WEB01/…/Downloads/tools.zip",
  "internal_path": "notes.txt",
  "sha256": "35efde8d…", "md5": "52c27ee9…",
  "matched_strings": [{"identifier": "$ioc0", "offset": 42, "length": 19, "data": "\\\\.\\pipe\\msagent_12"}],
  "metadata": {"iris_case_id": 2, "iris_ioc_type": "named pipe", "…": "…"},
  "entropy": 4.4379
}
```

Hits inside archives use `::` paths. Nested archives chain them
(`backup.zip::logs.tar.gz::app.log`), and `access.log.gz` scans as
`access.log.gz::access.log`.

Unreadable kinds:

| kind | meaning |
|---|---|
| `dir` | folder could not be listed; its contents were **not** scanned |
| `open` / `read` / `mmap` | file could not be opened or read (permissions, I/O error, damaged disk, a mount that dropped the read) |
| `timeout` | the file ran past `--timeout` and was **not fully scanned** |
| `scan` | another YARA error on the file |
| `stat` | file metadata could not be read |
| `archive` / `member` | an archive, or a file inside it, could not be read |

Summarise it: `cut -f1 report.unreadable.tsv | tail -n +2 | sort | uniq -c`.

## Rules from DFIR-IRIS case IOCs

Every IOC in a case becomes one rule, `IRIS_c<case>_ioc<id>_<type>`, in a file
named after the case, `IRIS_case<id>_<name>.yar`. Each rule carries the case
and the IOC in its metadata, so a hit shows which case it belongs to.

```bash
export YARAX_IRIS_API_KEY=...          # or the key saved by the GUI
yarax-scanner --iris-url https://iris:8443 --iris-insecure --iris-list                 # cases
yarax-scanner --iris-url https://iris:8443 --iris-insecure --iris-list --iris-case 12  # its IOCs
yarax-scanner --iris-url https://iris:8443 --iris-insecure --iris-case 12 --iris-case 14 \
    --iris-export ./iris-rules                    # one file per case (--iris-ioc ID to pick IOCs)
yarax-scanner --path /mnt/evidence --rules rules/ --rules ./iris-rules --output r.json
```

The scanner only reads from IRIS (the case list and the case IOCs); it never
writes to it.

### No connection to IRIS from the scanning machine: `iris_snapshot.py`

Forensic workstations are often on an isolated network that cannot reach the
IRIS server. `tools/iris_snapshot.py` solves that: you run it on a machine that
**can** reach IRIS, it saves the cases and their IOCs into one JSON file (the
*snapshot*), and you carry that file to the scanning machine. There you use the
file's path wherever you would type the IRIS URL. The scanner reads the cases
and IOCs from the file and needs no network and no API key.

The snapshot is a copy at one moment: IOCs added to IRIS later are not in it
until you take a new one. The scanner shows when the snapshot was taken. The
script only reads from IRIS.

**Requirements** (on the machine that reaches IRIS): Python 3.8 or later. Only
the standard library is used; there is nothing to install or build. Tested on
Linux; it uses nothing Linux-specific, so macOS and Windows (`python` instead of
`python3`) should work but have not been tested. You need
an IRIS API key: in IRIS, open your user menu (top right) > *My settings*.

**1. Set the IRIS URL once.** The URL is written in the script, so users don't
type it. Open `tools/iris_snapshot.py` and set `IRIS_URL` near the top. Until
you do, the script stops with `IRIS_URL is not set`.

**2. Take the snapshot** (on the machine that reaches IRIS):

```bash
python3 tools/iris_snapshot.py --insecure --out iris-snapshot.json
```

It shows the IRIS URL and asks for the API key:

```
IRIS: https://iris.your-domain:8443
DFIR-IRIS API key (IRIS: user menu > My settings; typing is not shown):
```

Paste or type the key and press Enter. Nothing appears while you type; that is
deliberate, so the key never shows on screen. The key is not saved anywhere and
is not part of the snapshot. Then it lists each case it saved:

```
  #2       11 IOCs  #2 - Web server compromise
  #3        4 IOCs  #3 - Phishing follow-up
2 case(s) -> iris-snapshot.json
```

| Option | Meaning |
|---|---|
| `--out FILE` | Where to write the snapshot (required). An existing file is replaced. |
| `--insecure` | Don't verify the server certificate. IRIS ships with a self-signed one; leave this out if yours has a trusted certificate. |
| `--case ID` | Only this case. Repeat for several; default is every case the key can see. |

**3. Move the file to the scanning machine.** Any way you normally move case
data works: a USB drive, a shared folder, or `scp`. The file contains case
names and IOC values, so treat it like other case data. To refresh, take a new
snapshot and replace the file.

**4. Use it on the scanning machine.** In the GUI, open **Add rules from
DFIR-IRIS case IOCs**, put the snapshot's path (for example
`/home/analyst/iris-snapshot.json`) in the **IRIS URL** field, leave **API key**
empty and press **Load cases**. Everything else works as with a live IRIS. On
the command line:

```bash
yarax-scanner --iris-url ~/iris-snapshot.json --iris-list                  # cases
yarax-scanner --iris-url ~/iris-snapshot.json --iris-case 2 --iris-export ./iris-rules
```

If something goes wrong:

| Message | Meaning |
|---|---|
| `IRIS_URL is not set` | Step 1 hasn't been done. |
| `no API key entered` | The prompt was left empty or cancelled. |
| `HTTP 401 (API key rejected)` | Wrong key, or a key from another IRIS. |
| `cannot reach IRIS … CERTIFICATE_VERIFY_FAILED` | Add `--insecure`, or give IRIS a trusted certificate. |
| `cannot reach IRIS …` (other reasons) | This machine can't reach the URL in `IRIS_URL`. |
| `HTTP 302 (redirect to … not followed - check IRIS_URL)` | The URL points to a redirect, often `http://` instead of `https://`. Use the address it names. The script doesn't follow redirects, so the key is never sent anywhere else. |
| `case(s) not found or not visible to this key` | Wrong `--case` number, or the key's user can't see that case. |

How each IOC type is searched for. The IOC's **type** decides, not the shape of
its value: 32 hex digits are a file hash for `md5`, an import hash for
`imphash`, and nothing for `ja3-fingerprint-md5`.

| IOC type | Matches |
|---|---|
| `ip-*` | the address as a whole word, ASCII and UTF-16 (`10.0.0.5` does not hit `110.0.0.55`); ranges are left out |
| `domain`, `hostname`, `email-*` | whole word, any case (`evil.com` hits `cdn.evil.com`, not `notevil.com`) |
| `md5`, `sha1`, `sha256` | **the file with that hash** (YARA `hash` module), not the hash written as text |
| `imphash` | PE files with that import hash (`pe.imphash()`) |
| `hex` | those bytes (`4d5a9000` → `{ 4D 5A 90 00 }`) |
| `pattern-in-file` | the text exactly, case-sensitive |
| `url`, `filename`, `file-path`, `regkey`, `named pipe`, `mutex`, other text | the text anywhere, any case, ASCII and UTF-16 |
| composite (`filename\|md5`, `ip-dst\|port`, `malware-sample`, …) | each part as above, either part matches; ports are ignored, and a file name next to a hash is dropped (the hash already pins the file) |
| other hashes (`sha512`, `ssdeep`, `tlsh`, `authentihash`, …) | left out: YARA-X can't compute them |
| network/certificate fingerprints (`ja3-*`, `jarm`, `hassh-*`, `x509-fingerprint-*`, `community-id`, …) | left out: not file contents |
| `yara`, `sigma`, `snort`, `zeek`, `stix2-pattern`, `pattern-in-traffic`/`-memory`; values under 4 characters | left out, with the reason (add YARA IOCs as rule files) |

Defanged network IOCs are refanged first: `hxxp://evil[.]com` searches for
`http://evil.com`.

File-name IOCs match the name where it appears **inside** files (logs, scripts,
registry exports), not files with that name: YARA scans content.

Each rule is compiled on its own before it is written, so one odd IOC is left
out and listed instead of breaking the file.

## Splunk

```bash
export YARAX_SPLUNK_TOKEN=<hec-token>
yarax-scanner --splunk-test --splunk-url https://splunk:8088 --splunk-index yarax
yarax-scanner --path /mnt/evidence --rules rules/ --output web01.json \
    --target-host WEB01 --splunk-url https://splunk:8088 --splunk-index yarax
yarax-scanner --splunk-send web01.events.ndjson --splunk-url https://splunk:8088 --splunk-index yarax
```

Events are sent after the scan, with retries. If delivery fails, the scan
still completes and exits 1. Run `--splunk-send` later to resume: events
already accepted are not sent twice. Sourcetypes: `yarax:detection`,
`yarax:match_string`, `yarax:rule`, `yarax:unreadable`, `yarax:scan`.

Event schema, field dictionary, `props.conf` and example searches:
[docs/SPLUNK.md](docs/SPLUNK.md). An analyst dashboard app is in
[splunk/yarax_forensics](splunk/yarax_forensics/README.md).

```spl
index=yarax sourcetype=yarax:detection yara_rule_meta.iris_case_id=12
| stats count values(yara_rule_meta.iris_ioc_value) as iocs by host file_path
```

## Forensic and security notes

**The scanner opens evidence read-only**, and the tests check that scanned
files keep the same contents, size and modification time. It does not enforce
anything beyond that:

- **Access times.** Reading a file can update its access time (atime) on a
  writable mount. Scan a read-only mount (`ro`, for an ext4 journal also
  `noload`), a write-blocked device or a copy. Read-only mount tools for E01
  and raw images do this for you.
- **Report location.** Save reports outside the evidence. The scanner skips its
  own output files if they are inside the target, but writing to an evidence
  mount at all changes it.
- **Hashes are of what was read.** `sha256`/`md5` are computed only for
  matched files, from the bytes that were scanned. Members of huge archives
  scanned in windows (see below) are not hashed.
- **Interrupted scans.** The `.json` report is flushed every 128 hits and is
  valid only after the scan finishes. The `.events.ndjson` file is flushed
  after every event; use it as the record of a stopped or crashed scan.
- **Damaged disks.** Files over 1 MiB are scanned through a memory map. An I/O
  error on a mapped page would kill the process (SIGBUS), so each such file is
  first read through once. A bad sector then shows up as a `read` entry in the
  unreadable list, and the rest of the scan carries on. Limits: those files are
  read twice from disk when they don't fit in RAM, and a device that starts
  failing between the read and the scan can still end the process.
- **Unreadable is not clean.** Anything in `.unreadable.tsv` was not (fully)
  scanned. A permission error usually means you need to run as root or as the
  user that owns the mount; FUSE mounts such as ntfs-3g are often owner-only.
- **Splunk token.** Read only from `YARAX_SPLUNK_TOKEN`, never from a
  command-line argument, so it does not show in `ps` or shell history. The GUI
  keeps it in memory and passes it to the scanner the same way. It is never
  written to the report, the event file or the delivery file.
- **IRIS API key.** Read from `YARAX_IRIS_API_KEY`, or from
  `~/.config/yarax-scanner/iris.json` if you pressed **Save settings** (file
  mode 0600). Delete that file to forget the key. `tools/iris_snapshot.py`
  asks for the key when it runs, without echoing it, and keeps it only in
  memory; it is never an argument or an environment variable, and is not
  written to the snapshot.
- **Certificate checks.** `--splunk-insecure`, `--iris-insecure` and the
  matching GUI boxes turn off TLS verification. Use them only for test servers
  or self-signed certificates on a network you trust.
- **Archive bombs.** Archive depth, member size, total output and compression
  ratio are all capped (see the options above). Encrypted zip members are
  skipped and listed as `member` in the unreadable list; the rest of the
  archive is still scanned.

## Troubleshooting

**Build killed / "signal 9" during `cargo build`.** Not enough memory. Add swap
or use a machine with more RAM; `--fast` builds use far less.

**The self-test fails after building.** The script keeps the report as
`./build-selftest-report.json`. Check that `examples/` is complete.

**"scan path …: No such file or directory" (exit 2).** The path is wrong or the
mount is gone. Nothing was scanned.

**"unexpected argument(s)".** Only `yarax-scanner PATH RULES` works positionally.
For more rule sources use `--rules` once per source.

**Many `open` errors / "Permission denied".** Run as root
(`sudo ./dist/yarax-scanner …`) or as the mount's owner. The GUI never elevates
itself; for root-only evidence, use the command line.

**A rule "worked in yara" but fails here.** Run `--check-rules`; YARA-X is
stricter. The message names the file, line and column.

**Files listed as `timeout`.** Raise the per-file timeout (`--timeout 300`).

**A huge `.ewf_fuse/ewf1` or similar raw image inside the mount tree.** Add
`--exclude '**/.ewf_fuse/**'` so the whole image isn't scanned as one file.

**Splunk test is OK but no events show up.** The index probably doesn't exist
or the token isn't allowed to write to it. HEC accepts the events anyway.

**IRIS "certificate verify failed".** IRIS uses a self-signed certificate by
default: tick *Don't verify* / add `--iris-insecure`, or install a trusted
certificate on IRIS.

**The GUI doesn't appear in the applications menu.** Log out and back in, or
run `./dist/yarax-gui` once; it rewrites its menu entry at start-up.

## Uninstall

```bash
./build-linux.sh --uninstall      # removes the menu entry, the icon and ./dist
```

It leaves your reports, the saved IRIS settings (`~/.config/yarax-scanner`),
Rust (`~/.cargo`, `~/.rustup`; remove with `rustup self uninstall`) and the
system packages it installed. Then delete the source folder.

## How it works

```
walker (1 thread) ──bounded queue──▶ N workers ──channel──▶ streaming JSON writer
                                        │
                                  archives: recursive zip/tar/gz/bz2/xz
                                  (streaming, no temp files, bomb-guarded)
```

- Files up to 1 MiB are read once into a reused per-worker buffer. Larger files
  are read through once (see *Damaged disks*), then scanned from a memory map.
- Rules are compiled once and shared; each worker has its own YARA-X scanner,
  so there is no locking while matching.
- Hashes, timestamps, entropy and file type are computed only for matches.
- The bounded queue keeps memory flat on trees with millions of files.
- The GUI is a front end only: it runs `yarax-scanner` with an argument list
  (no shell, so paths with spaces are safe) and reads its progress lines.

Design trade-offs:

- **Huge archive members** (over `--max-member-size`, or of unknown size) are
  scanned in overlapping 4 MiB windows in constant memory. A match longer than
  64 KiB across a window boundary can be missed, and such members are not
  hashed.
- At `--max-archive-depth`, a nested archive's compressed bytes are scanned
  rather than skipped.
- The memory map assumes the evidence isn't truncated during the scan, which
  holds for read-only mounts.

New archive formats: implement `ArchiveFormat` (`src/archives/mod.rs`) and add
it to `builtin_formats()` (`src/archives/formats.rs`). Depth limits, bomb
budgets, `::` paths, hashing and hit output are handled by `scan_member`.

## Testing

```bash
cargo test --locked --release                      # unit + end-to-end tests
bash tests/integration_cli.sh dist/yarax-scanner   # end-to-end test of the built binary
docker run --rm -v "$PWD:/src:ro" ubuntu:24.04 bash /src/tests/clean_install_test.sh
```

`tests/integration_cli.sh` can also test against a live Splunk and IRIS (see
the top of the script). What was tested and the results:
[docs/TESTING.md](docs/TESTING.md).

`build-gui.ps1` (Windows) is kept from earlier development. Windows is not part
of this release and has not been tested with it.
