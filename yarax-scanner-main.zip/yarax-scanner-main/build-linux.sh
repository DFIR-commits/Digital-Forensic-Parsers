#!/usr/bin/env bash
# Builds yarax-scanner (command line) into ./dist, then checks the build.
#
#   ./build-linux.sh             release build of the CLI scanner (slow, lots of RAM)
#   ./build-linux.sh --gui       also build yarax-gui and add it to your applications menu
#   ./build-linux.sh --fast      dev build: compiles much faster, binaries are huge
#   ./build-linux.sh --uninstall remove the menu entry and icon, and ./dist
#
# Installs missing prerequisites (C compiler, cmake, pkg-config, and Rust via
# rustup). Uses sudo for system packages when not run as root. Run it as the
# user who will use the GUI: the menu entry is made for that user.
set -euo pipefail
cd "$(dirname "$0")"

GUI=0; FAST=0; UNINSTALL=0
for a in "$@"; do
  case "$a" in
    --gui) GUI=1 ;;
    --fast) FAST=1 ;;
    --uninstall) UNINSTALL=1 ;;
    -h|--help) sed -n '2,11p' "$0"; exit 0 ;;
    *) echo "unknown option: $a (use --gui, --fast or --uninstall)"; exit 2 ;;
  esac
done

SHARE="${XDG_DATA_HOME:-$HOME/.local/share}"
APPS="$SHARE/applications"; ICONS="$SHARE/icons/hicolor/256x256/apps"

if [ "$UNINSTALL" = 1 ]; then
  rm -f "$APPS/yarax-gui.desktop" "$ICONS/yarax-gui.png"
  rm -rf dist
  echo "Removed the menu entry, icon and ./dist. Left alone: this source folder, Rust (~/.cargo, ~/.rustup),"
  echo "system packages, saved IRIS settings (~/.config/yarax-scanner) and your reports."
  exit 0
fi

have() { command -v "$1" >/dev/null 2>&1; }
SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
[ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"
if [ "$GUI" = 1 ] && [ "$(id -u)" -eq 0 ]; then
  echo "WARNING: building as root - the menu entry will be root's, not yours. Run without sudo instead."
fi

mem_kb=$(awk '/MemTotal|SwapTotal/ {s += $2} END {print s}' /proc/meminfo 2>/dev/null || echo 0)
if [ "$FAST" = 0 ] && [ "$mem_kb" -gt 0 ] && [ "$mem_kb" -lt 3800000 ]; then
  echo "WARNING: $((mem_kb / 1024)) MB RAM+swap. The release build peaks near 2.8 GB; it may be killed (try --fast)."
fi

install_pkgs() {  # apt-names | dnf-names | pacman-names  (see calls below)
  if have apt-get; then $SUDO apt-get update && $SUDO apt-get install -y $1
  elif have dnf; then $SUDO dnf install -y $2
  elif have pacman; then $SUDO pacman -S --needed --noconfirm $3
  else echo "No supported package manager. Install manually: $1"; exit 1; fi
}

if ! have cc || ! have cmake || ! have pkg-config || ! have curl; then
  echo "Installing build tools..."
  install_pkgs "build-essential cmake pkg-config curl ca-certificates" \
               "gcc gcc-c++ make cmake pkgconf-pkg-config curl" \
               "base-devel cmake pkgconf curl"
fi
if [ "$GUI" = 1 ] && ! pkg-config --exists gtk+-3.0 2>/dev/null; then
  # file-dialog backend (rfd -> GTK3); windowing libraries are loaded at run time
  install_pkgs "libgtk-3-dev" "gtk3-devel" "gtk3"
fi
if ! have cargo; then
  echo "Installing Rust (rustup)..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
  . "$HOME/.cargo/env"
fi

PROFILE=release; ARGS=(--release --locked)   # --locked: exactly the dependency versions in Cargo.lock
[ "$FAST" = 1 ] && { PROFILE=debug; ARGS=(--locked); }
[ "$GUI" = 1 ] && ARGS+=(--features gui)

echo "$(cargo --version); cargo build ${ARGS[*]}"
cargo build "${ARGS[@]}"

mkdir -p dist
cp "target/$PROFILE/yarax-scanner" dist/
if [ "$GUI" = 1 ]; then
  cp "target/$PROFILE/yarax-gui" yarax-scanner.png dist/
  # menu entry + taskbar icon (Wayland docks match it by app_id = file name). yarax-gui
  # rewrites the same two files at start-up, so a moved folder fixes itself on next launch.
  mkdir -p "$APPS" "$ICONS"
  cp yarax-scanner.png "$ICONS/yarax-gui.png"
  cat > "$APPS/yarax-gui.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=YARA-X Scanner
Exec="$PWD/dist/yarax-gui"
Icon=yarax-gui
StartupWMClass=yarax-gui
Categories=Utility;Security;
EOF
fi

# Self-test: the bundled example must give exactly one hit, on malicious_sample.txt.
echo
echo "Checking the build..."
t=$(mktemp -d); trap 'rm -rf "$t"' EXIT
./dist/yarax-scanner --version
if ./dist/yarax-scanner --path examples/samples --rules examples/rules --output "$t/r.json" --quiet \
   && [ "$(grep -c '"file": *"[^"]*/malicious_sample.txt"' "$t/r.json")" = 1 ] \
   && ! grep -q 'clean_sample' "$t/r.json"; then
  echo "  ok    example scan: 1 hit on malicious_sample.txt"
else
  cp "$t/r.json" ./build-selftest-report.json 2>/dev/null || true
  echo "  FAIL  example scan did not give the expected single hit (report: ./build-selftest-report.json)"
  exit 1
fi
if [ "$GUI" = 1 ]; then echo "  ok    yarax-gui built"; fi

echo
echo "Done. Scan:  ./dist/yarax-scanner --path /mnt/evidence --rules /path/to/rules --output report.json"
echo "Rule check:  ./dist/yarax-scanner --check-rules --rules /path/to/rules"
if [ "$GUI" = 1 ]; then echo "GUI:         applications menu > YARA-X Scanner, or ./dist/yarax-gui"; fi
