#!/bin/sh
# Linux/systemd installer for the Python-only capture backend.
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "${PYTHON:-python3}" "$script_dir/install_linux.py" --backend python "$@"
