#!/usr/bin/env python3
"""Send a trigger or read job status without putting a bearer token in argv."""
import argparse
import ipaddress
import json
import os
from pathlib import Path
import re
import ssl
import stat
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, HTTPSHandler, ProxyHandler, Request, build_opener
import uuid


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def send(args):
    if not args.job_id and (not isinstance(args.target_id, str) or
                           not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', args.target_id)):
        raise ValueError('Select one configured VM with --target-id; no default or capture-all target is used')
    url = urlsplit(args.url)
    if (url.scheme not in ('http', 'https') or not url.hostname or url.username or
            url.password or url.query or url.fragment or url.path not in ('', '/')):
        raise ValueError('URL must be an http(s) origin without credentials, path, query or fragment')
    url.port  # Validate a malformed or out-of-range port before reading a token.
    loopback = url.hostname == 'localhost'
    try:
        loopback = loopback or ipaddress.ip_address(url.hostname).is_loopback
    except ValueError:
        pass
    if url.scheme == 'http' and not loopback and not args.allow_plain_http:
        raise ValueError('Non-loopback HTTP exposes the token; specify --allow-plain-http on a trusted network')
    info = args.token_file.lstat()
    if (not stat.S_ISREG(info.st_mode) or info.st_size > 4096 or
            (os.name != 'nt' and info.st_mode & 0o077)):
        raise ValueError('Token must be a private regular file, <=4096 bytes')
    token = args.token_file.read_text(encoding='utf-8').strip()
    if not re.fullmatch(r'[A-Za-z0-9_-]{32,256}', token):
        raise ValueError('Invalid token file; token contents are not displayed')
    endpoint = args.url.rstrip('/') + '/v1/' + args.source
    data = None
    if args.job_id:
        if not re.fullmatch(r'[0-9a-f]{32}', args.job_id):
            raise ValueError('Job ID must be 32 lowercase hexadecimal characters')
        endpoint += '/jobs/' + args.job_id
    else:
        endpoint += '/captures'
        data = json.dumps({'target_id': args.target_id, 'event_id': args.event_id or uuid.uuid4().hex,
                           'reason': args.reason}).encode('utf-8')
        if len(data) > 16384:
            raise ValueError('Trigger is too large')
    opener = build_opener(ProxyHandler({}), NoRedirect(), HTTPSHandler(context=ssl.create_default_context()))
    request = Request(endpoint, data=data,
                      headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json'})
    try:
        with opener.open(request, timeout=15) as response:
            raw = response.read(16385)
            if len(raw) > 16384:
                raise ValueError('Oversized server response')
            return json.loads(raw)
    except HTTPError as error:
        raise ValueError(f'HTTP {error.code}; inspect local job status/logs. '
                         'Do not blindly resubmit with a new event ID.') from None
    except URLError:
        raise ValueError('Connection/TLS failed. The request outcome may be unknown; '
                         'inspect the queue or retry using the SAME event ID.') from None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url', default='http://127.0.0.1:8787')
    parser.add_argument('--source', choices=('splunk', 'crowdstrike'), default='splunk')
    parser.add_argument('--token-file', type=Path, default=Path('/etc/honeypot/secrets/splunk-token'))
    parser.add_argument('--allow-plain-http', action='store_true')
    parser.add_argument('--target-id', help='Required for captures: one administrator-configured VM alias')
    parser.add_argument('--event-id', help='Reuse this ID on retries; omit to generate a new event')
    parser.add_argument('--reason', default='manual trigger')
    parser.add_argument('--job-id', help='Read an existing job instead of triggering a capture')
    args = parser.parse_args(argv)
    if not args.job_id and not args.target_id:
        parser.error('--target-id is required when triggering a capture (not for --job-id status)')
    if not args.job_id and not args.event_id:
        args.event_id = uuid.uuid4().hex
        print('Event ID for retry: ' + args.event_id, file=sys.stderr)
    try:
        print(json.dumps(send(args), indent=2))
        return 0
    except (OSError, ValueError) as error:
        print('Request failed: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
