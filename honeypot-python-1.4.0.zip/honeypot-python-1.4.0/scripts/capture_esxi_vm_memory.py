#!/usr/bin/env python3
"""Capture vSphere snapshot memory from a trusted collector. See docs/python-capture.md.

The sole snapshot-removal call is behind verified transfers, source revalidation,
and a durable evidence manifest. Never clean up a snapshot in an exception handler.
"""
from __future__ import annotations

import argparse
from contextlib import AbstractContextManager
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
import getpass
import gzip
import hashlib
from http.cookies import SimpleCookie
import importlib.metadata
import json
import logging
import math
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import signal
import ssl
import stat
import sys
import time
from urllib.parse import quote, urlencode
from urllib.request import (
    HTTPSHandler,
    HTTPRedirectHandler,
    ProxyHandler,
    Request,
    build_opener,
)
import uuid
import zlib


GIB = 1024**3
CHUNK_SIZE = 4 * 1024**2
LOG = logging.getLogger("capture")


class CaptureError(RuntimeError):
    """An acquisition guard or verification failed."""


class FilesNotReady(CaptureError):
    """Snapshot file layout is visible before the directory entries are ready."""


def utcnow():
    return datetime.now(timezone.utc)


def iso(value=None):
    value = value or utcnow()
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def safe_name(value):
    return (
        re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip().rstrip(".")[:100] or "vm"
    )


def split_ds_path(value):
    match = re.fullmatch(r"\[([^\]]+)\]\s*(.*)", value)
    if not match:
        raise CaptureError(f"Unsupported datastore path: {value!r}")
    relative = match[2].rstrip("/")
    if (
        relative.startswith("/")
        or "\\" in relative
        or any(p in (".", "..") for p in relative.split("/"))
        or any(ord(c) < 32 for c in value)
    ):
        raise CaptureError(f"Unsafe datastore path: {value!r}")
    return match[1], relative


def ds_path(datastore, relative):
    return f"[{datastore}] {relative}".rstrip()


def parent_ds_path(value):
    datastore, relative = split_ds_path(value)
    return ds_path(datastore, relative.rpartition("/")[0])


def validate_basename(name):
    if (
        not name
        or name in (".", "..")
        or name != name.strip().rstrip(".")
        or re.search(r'[<>:"/\\|?*\x00-\x1f]', name)
    ):
        raise CaptureError(f"Unsafe or unsupported evidence filename: {name!r}")
    # Windows device filenames are unsafe even when running the collector on Unix.
    if name.split(".")[0].upper() in {
        "CON",
        "PRN",
        "AUX",
        "NUL",
        *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }:
        raise CaptureError(f"Reserved evidence filename: {name!r}")


def sync_directory(path):
    if os.name != "nt":
        fd = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def atomic_bytes(path, data):
    """Replace a collector-owned state file; leave a partial file on failure."""
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".partial")
    with temporary.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    sync_directory(path.parent)


def atomic_json(path, value):
    atomic_bytes(
        path, (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    )


def hash_file(path, heartbeat=lambda: None):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(CHUNK_SIZE):
            digest.update(block)
            heartbeat()
    return digest.hexdigest()


def verify_local_evidence(records, directory, heartbeat=lambda: None):
    """Recheck earlier downloads after the entire bundle has finished copying."""
    for record in records:
        validate_basename(record["Name"])
        path = directory / record["Name"]
        if (
            path.is_symlink()
            or not path.is_file()
            or path.stat().st_size != record["SizeBytes"]
            or hash_file(path, heartbeat) != record["Sha256"]
        ):
            raise CaptureError(
                f"Local evidence changed before cleanup: {record['Name']}"
            )


def compression_reserve(size):
    """Allow incompressible gzip output plus overhead; never assume a saving."""
    return size + (size + 99) // 100 + 1024**2


def verify_gzip_evidence(path, record, storage, heartbeat=lambda: None):
    """Check stored bytes and round-trip identity using bounded memory/64-bit counts."""
    if (storage.get("Encoding") != "gzip" or path.is_symlink() or not path.is_file()
            or path.stat().st_size != storage["SizeBytes"]
            or hash_file(path, heartbeat) != storage["Sha256"]):
        raise CaptureError(f"Compressed evidence size/hash mismatch: {path.name}")
    digest = hashlib.sha256()
    count = 0
    try:
        with gzip.open(path, "rb") as stream:
            while block := stream.read(CHUNK_SIZE):
                count += len(block)
                if count > record["SizeBytes"]:
                    raise CaptureError(f"Decompressed evidence exceeds expected size: {path.name}")
                digest.update(block)
                heartbeat()
    except (OSError, EOFError, zlib.error) as error:
        raise CaptureError(f"Invalid gzip evidence: {path.name}") from error
    if count != record["SizeBytes"] or digest.hexdigest() != record["Sha256"]:
        raise CaptureError(f"Decompressed evidence size/hash mismatch: {path.name}")


def compress_memory_file(record, directory, heartbeat=lambda: None):
    """Retain the original; publish gzip only after a complete verified round trip."""
    validate_basename(record["Name"])
    source = directory / record["Name"]
    target = directory / (record["Name"] + ".gz")
    partial = target.with_name(target.name + ".partial")
    if source.is_symlink() or not source.is_file():
        raise CaptureError(f"Missing or symlink original: {source.name}")
    if target.exists() or target.is_symlink() or partial.exists() or partial.is_symlink():
        raise CaptureError(f"Refusing to overwrite compressed evidence: {target.name}")
    check_local_space(directory, compression_reserve(record["SizeBytes"]) + GIB)
    LOG.info("Compressing and round-trip verifying %s (gzip fast)", source.name)
    with source.open("rb") as original, partial.open("xb") as output:
        with gzip.GzipFile(filename="", fileobj=output, mode="wb", compresslevel=1, mtime=0) as compressed:
            while block := original.read(CHUNK_SIZE):
                compressed.write(block)
                heartbeat()
        output.flush()
        os.fsync(output.fileno())
    storage = {
        "Encoding": "gzip", "Profile": "fast", "Name": target.name,
        "SizeBytes": partial.stat().st_size, "Sha256": hash_file(partial, heartbeat),
        "DestinationPath": str(target), "VerifiedAtUtc": None,
    }
    verify_gzip_evidence(partial, record, storage, heartbeat)
    os.rename(partial, target)
    sync_directory(directory)
    storage["VerifiedAtUtc"] = iso()
    return storage


def remove_redundant_originals(records, directory, warnings):
    """Only called after the durable checkpoint and successful snapshot handling."""
    for record in records:
        if "Storage" not in record:
            continue
        try:
            (directory / record["Name"]).unlink()
            sync_directory(directory)
        except OSError as error:
            message = f"Compressed evidence is verified; could not remove redundant original {record['Name']}: {error}"
            LOG.warning(message)
            warnings.append(message)


def write_manifest(directory, manifest, stem="capture-manifest"):
    path = directory / f"{stem}.json"
    atomic_json(path, manifest)
    digest = hash_file(path)
    atomic_bytes(
        directory / f"{stem}.sha256", f"{digest}  {path.name}\n".encode("ascii")
    )
    return path


class CaptureLock(AbstractContextManager):
    """OS lock on a persistent inode. Never unlink after unlocking (race hazard)."""

    def __init__(self, path):
        self.path = path
        self.stream = None

    def __enter__(self):
        if self.path.is_symlink():
            raise CaptureError(f"Refusing symlink lock: {self.path}")
        self.stream = self.path.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt

                if self.path.stat().st_size == 0:
                    self.stream.write(b"\0")
                    self.stream.flush()
                self.stream.seek(0)
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            self.stream.close()
            self.stream = None
            raise CaptureError(
                f"Capture already running, or locking unsupported: {self.path}"
            ) from error
        return self

    def __exit__(self, *args):
        if self.stream:
            if os.name == "nt":
                import msvcrt

                self.stream.seek(0)
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_UNLCK, 1)
            self.stream.close()  # POSIX flock is released on close, including process exit.


def check_rate_limit(path, minutes, override=False):
    if override or minutes == 0 or not path.exists():
        return
    try:
        previous = datetime.fromisoformat(
            path.read_text(encoding="utf-8").strip().replace("Z", "+00:00")
        )
        if previous.tzinfo is None:
            raise ValueError("missing timezone")
    except ValueError as error:
        raise CaptureError(f"Invalid rate-limit state; inspect {path}") from error
    allowed = previous + timedelta(minutes=minutes)
    if utcnow() < allowed:
        raise CaptureError(f"Rate limit active until {iso(allowed)}")


def check_local_space(path, required):
    available = shutil.disk_usage(
        path
    ).free  # A failed measurement aborts before cleanup.
    if available < required:
        raise CaptureError(
            f"Destination has {available / GIB:.2f} GiB free; needs {required / GIB:.2f} GiB"
        )


@dataclass(frozen=True)
class FileRecord:
    path: str
    size: int
    modified: str | None
    kind: str = "memory-state"

    @property
    def name(self):
        return PurePosixPath(split_ds_path(self.path)[1]).name

    @property
    def fingerprint(self):
        return self.size, self.modified


def select_memory_files(layout, snapshot_id):
    """Resolve authoritative snapshot keys; do not guess by filename or newest mtime."""
    if layout is None:
        return None
    from pyVmomi import vim

    if not isinstance(snapshot_id, str) or not snapshot_id:
        raise CaptureError("Missing snapshot identity")
    matches = []
    for entry in getattr(layout, "snapshot", None) or []:
        reference = getattr(entry, "key", None)
        if getattr(reference, "_moId", None) == snapshot_id:
            if not isinstance(reference, vim.vm.Snapshot):
                raise CaptureError("Snapshot layout has the wrong managed-object type")
            matches.append(entry)
    if not matches:
        return None  # Layout can lag the completed create task.
    if len(matches) > 1:
        raise CaptureError("Ambiguous snapshot file layout")
    snapshot = matches[0]
    by_key = {}
    for file in getattr(layout, "file", None) or []:
        if file.key in by_key:
            raise CaptureError("Duplicate file key in snapshot layout")
        by_key[file.key] = file
    keys = [snapshot.dataKey]
    memory_key = getattr(snapshot, "memoryKey", None)
    if memory_key is None:
        return None
    if snapshot.dataKey < 0 or memory_key < -1:
        raise CaptureError("Invalid snapshot data/memory key")
    if memory_key >= 0 and memory_key not in keys:
        keys.append(memory_key)
    if any(key not in by_key for key in keys):
        return None
    paths = [by_key[key].name for key in keys]
    if len(set(paths)) != len(paths):
        raise CaptureError("Different snapshot keys reference the same file")
    if sum(p.lower().endswith(".vmsn") for p in paths) != 1:
        raise CaptureError("Snapshot layout must contain exactly one .vmsn")
    if any(not p.lower().endswith((".vmsn", ".vmem")) for p in paths):
        raise CaptureError(
            "Snapshot layout references an unsupported memory-file extension"
        )
    if any(getattr(by_key[k], "accessible", None) is False for k in keys):
        raise CaptureError("Snapshot layout reports inaccessible memory files")
    return sorted(set(paths))


class RejectRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise CaptureError(
            "Datastore endpoint redirected; refusing to forward the session cookie"
        )


def download_file(opener, request, record, directory, timeout, heartbeat=lambda: None):
    validate_basename(record.name)
    target = directory / record.name
    partial = directory / (record.name + ".partial")
    if target.exists() or target.is_symlink():
        raise CaptureError(f"Refusing to overwrite evidence: {target}")
    if record.size <= 0:
        raise CaptureError(f"Source is empty: {record.path}")
    check_local_space(directory, record.size + GIB)
    digest = hashlib.sha256()
    received = 0
    LOG.info("Downloading %s (%.2f MiB)", record.name, record.size / 1024**2)
    with opener.open(request, timeout=timeout) as response, partial.open(
        "xb"
    ) as output:
        if response.status != 200:
            raise CaptureError(
                f"Unexpected HTTP status {response.status} for {record.name}"
            )
        if response.headers.get("Content-Encoding", "identity").lower() not in (
            "",
            "identity",
        ):
            raise CaptureError(
                "Encoded datastore response cannot be verified as raw bytes"
            )
        if "text/html" in response.headers.get("Content-Type", "").lower():
            raise CaptureError("Received an HTML page instead of a datastore file")
        length = response.headers.get("Content-Length")
        if length is not None and int(length) != record.size:
            raise CaptureError(
                f"HTTP length differs from datastore size for {record.name}"
            )
        while block := response.read(CHUNK_SIZE):
            received += len(block)
            if received > record.size:
                raise CaptureError(
                    f"Transfer exceeded expected byte count for {record.name}"
                )
            output.write(block)
            digest.update(block)
            heartbeat()
        output.flush()
        os.fsync(output.fileno())
    if received != record.size or partial.stat().st_size != record.size:
        raise CaptureError(
            f"Size mismatch for {record.name}: expected {record.size}, received {received}"
        )
    local_digest = hash_file(partial, heartbeat)
    if local_digest != digest.hexdigest():
        raise CaptureError(f"Local read-back hash mismatch: {record.name}")
    os.replace(partial, target)
    sync_directory(directory)
    return {
        "Name": record.name,
        "Kind": record.kind,
        "SizeBytes": received,
        "Sha256": local_digest,
        "SourcePath": record.path,
        "SourceLastWriteTimeUtc": record.modified,
        "DestinationPath": str(target),
        "VerifiedAtUtc": iso(),
    }


TLS_BYPASS_WARNING = (
    "TLS CERTIFICATE AND HOSTNAME VERIFICATION DISABLED by explicit opt-in. "
    "HTTPS remains encrypted but does not authenticate the server; credentials "
    "and evidence are vulnerable to interception."
)


def capture_ssl_context(args):
    """One process-local policy shared by SOAP authentication and file downloads."""
    if args.insecure_skip_tls_verify:
        if args.ca_bundle:
            raise CaptureError("--ca-bundle cannot be combined with --insecure-skip-tls-verify")
        LOG.warning(TLS_BYPASS_WARNING)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        return context
    return ssl.create_default_context(cafile=str(args.ca_bundle) if args.ca_bundle else None)


class VsphereBackend:
    def __init__(self, args, password):
        from pyVim.connect import SmartConnect
        from pyVmomi import vim

        self.args, self.vim = args, vim
        self.context = capture_ssl_context(args)
        self.si = SmartConnect(
            host=args.server,
            port=args.port,
            user=args.username,
            pwd=password,
            sslContext=self.context,
            httpConnectionTimeout=args.http_timeout_seconds,
        )
        self.last_heartbeat = time.monotonic()
        self.content = self.si.RetrieveContent()
        self.server_id = self.content.about.instanceUuid or args.server.lower()
        self.opener = build_opener(
            ProxyHandler({}), HTTPSHandler(context=self.context), RejectRedirects()
        )
        self.vm = None
        self.datastores = {}

    def close(self):
        from pyVim.connect import Disconnect

        Disconnect(self.si)

    def heartbeat(self):
        if time.monotonic() - self.last_heartbeat >= 60:
            self.si.CurrentTime()
            self.last_heartbeat = time.monotonic()

    def wait_task(self, task):
        deadline = time.monotonic() + self.args.task_timeout_seconds
        next_log = time.monotonic() + 30
        while True:
            info = task.info
            if info.state == "success":
                return info.result
            if info.state == "error":
                raise info.error or CaptureError(
                    f"Task {task._moId} failed without an error detail"
                )
            if time.monotonic() >= deadline:
                raise CaptureError(
                    f"Task {task._moId} timed out; it may still be running on vSphere"
                )
            if time.monotonic() >= next_log:
                LOG.info("Waiting for task %s (%s%%)", task._moId, info.progress)
                next_log = time.monotonic() + 30
            time.sleep(2)

    def select_vm(self):
        view = self.content.viewManager.CreateContainerView(
            self.content.rootFolder, [self.vim.VirtualMachine], True
        )
        try:
            matches = [vm for vm in view.view if vm.name == self.args.vm_name]
        finally:
            view.Destroy()
        if len(matches) != 1:
            raise CaptureError(
                f"Expected one visible VM named {self.args.vm_name!r}; found {len(matches)}"
            )
        self.vm = matches[0]
        self.datastores = {d._moId: d for d in self.vm.datastore}
        node = self.vm.parent
        while node and not isinstance(node, self.vim.Datacenter):
            node = node.parent
        if node is None:
            raise CaptureError(
                "Cannot resolve the VM's datacenter; check inventory read permissions"
            )
        self.datacenter = node
        parts = [node.name]
        node = node.parent
        while node and node._moId != self.content.rootFolder._moId:
            parts.insert(0, node.name)
            node = node.parent
        self.dc_path = "/".join(parts)
        return self.vm_info()

    def vm_info(self):
        config, runtime = self.vm.config, self.vm.runtime
        if config is None:
            raise CaptureError(
                "VM configuration unavailable; check its state and permissions"
            )
        return {
            "Name": self.vm.name,
            "Id": self.vm._moId,
            "InstanceUuid": config.instanceUuid,
            "BiosUuid": config.uuid,
            "GuestFullName": config.guestFullName,
            "PowerState": str(runtime.powerState),
            "MemoryGB": config.hardware.memoryMB / 1024,
            "Encrypted": config.keyId is not None,
            "VmPathName": config.files.vmPathName,
            "SnapshotDirectory": config.files.snapshotDirectory
            or parent_ds_path(config.files.vmPathName),
            "HostId": runtime.host._moId if runtime.host else None,
            "ConsolidationNeeded": runtime.consolidationNeeded,
            "IndependentDisks": [
                d.deviceInfo.label
                for d in config.hardware.device
                if isinstance(d, self.vim.vm.device.VirtualDisk)
                and getattr(d.backing, "diskMode", "").startswith("independent")
            ],
        }

    def snapshots(self):
        info = self.vm.snapshot
        result = []

        def visit(nodes):
            for node in nodes:
                result.append(
                    {
                        "Id": node.snapshot._moId,
                        "Name": node.name,
                        "CreatedAtUtc": iso(node.createTime),
                        "PowerState": str(getattr(node, "state", "unknown")),
                    }
                )
                visit(node.childSnapshotList or [])

        if info:
            visit(info.rootSnapshotList or [])
        return result

    def datastore(self, name):
        matches = [d for d in self.datastores.values() if d.name == name]
        if not matches:
            # A configured snapshot directory can be on a datastore that does not
            # yet contain any VM files. Resolve it within this VM's datacenter.
            view = self.content.viewManager.CreateContainerView(
                self.datacenter.datastoreFolder, [self.vim.Datastore], True
            )
            try:
                matches = [d for d in view.view if d.name == name]
            finally:
                view.Destroy()
        if len(matches) != 1:
            raise CaptureError(
                f"Expected one VM datastore named {name!r}; found {len(matches)}"
            )
        self.datastores[matches[0]._moId] = matches[0]
        return matches[0]

    def check_datastore_space(self, snapshot_directory, ram_gib):
        snapshot_ds = self.datastore(split_ds_path(snapshot_directory)[0])
        needed = max(self.args.minimum_datastore_free_gb, math.ceil(ram_gib * 1.25 + 5))
        for datastore in self.datastores.values():
            summary = datastore.summary
            floor = (
                needed
                if datastore._moId == snapshot_ds._moId
                else self.args.minimum_datastore_free_gb
            )
            if not summary.accessible or summary.freeSpace < floor * GIB:
                raise CaptureError(
                    f"Datastore {datastore.name!r} inaccessible or below {floor} GiB free"
                )

    def list_files(self, directory):
        name, relative = split_ds_path(directory)
        spec = self.vim.host.DatastoreBrowser.SearchSpec(
            details=self.vim.host.DatastoreBrowser.FileInfo.Details(
                fileSize=True, modification=True, fileType=True
            )
        )
        result = self.wait_task(
            self.datastore(name).browser.SearchDatastore_Task(
                datastorePath=directory, searchSpec=spec
            )
        )
        records = []
        for entry in result.file or []:
            if isinstance(entry, self.vim.host.DatastoreBrowser.FolderInfo):
                continue
            validate_basename(entry.path)
            records.append(
                FileRecord(
                    ds_path(name, "/".join(filter(None, [relative, entry.path]))),
                    entry.fileSize,
                    iso(entry.modification) if entry.modification else None,
                )
            )
        return records

    def stat_files(self, paths):
        found = {}
        for directory in sorted({parent_ds_path(p) for p in paths}):
            found.update({r.path: r for r in self.list_files(directory)})
        if any(p not in found for p in paths):
            raise FilesNotReady(
                "Required snapshot/configuration file is missing from the datastore"
            )
        return [found[p] for p in paths]

    def create_snapshot(self, name, description):
        return self.vm.CreateSnapshot_Task(
            name=name, description=description, memory=True, quiesce=False
        )

    def discover_memory(self, snapshot, before, snapshot_directory):
        deadline = time.monotonic() + self.args.file_discovery_timeout_seconds
        previous, stable = None, 0
        while time.monotonic() < deadline:
            paths = select_memory_files(self.vm.layoutEx, snapshot._moId)
            if paths:
                expected_directory = split_ds_path(snapshot_directory)
                if any(
                    split_ds_path(parent_ds_path(p)) != expected_directory
                    for p in paths
                ):
                    raise CaptureError(
                        "Mapped memory file is outside the configured snapshot directory"
                    )
                try:
                    records = self.stat_files(paths)
                except FilesNotReady:
                    previous, stable = None, 0
                    time.sleep(2)
                    continue
                fingerprint = tuple((r.path, r.fingerprint) for r in records)
                if all(
                    r.size > 0 and before.get(r.path) != r.fingerprint for r in records
                ):
                    stable = stable + 1 if fingerprint == previous else 0
                    previous = fingerprint
                    if stable >= 2:
                        return records
                else:
                    previous, stable = None, 0
            else:
                previous, stable = None, 0
            time.sleep(2)
        raise CaptureError(
            "No complete, new and stable memory-file set appeared before discovery timeout"
        )

    def metadata_files(self, vm_info):
        vmx = vm_info["VmPathName"]
        # Prefer vSphere's VM file membership; check both config and snapshot dirs.
        layout = self.vm.layoutEx
        paths = {
            f.name
            for f in getattr(layout, "file", None) or []
            if f.type == "snapshotList" and f.name.lower().endswith(".vmsd")
        }
        expected = PurePosixPath(split_ds_path(vmx)[1]).stem + ".vmsd"
        for directory in {parent_ds_path(vmx), vm_info["SnapshotDirectory"]}:
            paths.update(
                r.path for r in self.list_files(directory) if r.name == expected
            )
        if not paths:
            raise CaptureError("No .vmsd snapshot metadata found; retaining snapshot")
        return [
            replace(r, kind="snapshot-metadata") for r in self.stat_files(sorted(paths))
        ] + [replace(self.stat_files([vmx])[0], kind="vm-configuration")]

    def request_for(self, path):
        datastore, relative = split_ds_path(path)
        host = f"[{self.args.server}]" if ":" in self.args.server else self.args.server
        query = urlencode({"dcPath": self.dc_path, "dsName": datastore})
        url = f"https://{host}:{self.args.port}/folder/{quote(relative, safe='/')}?{query}"
        cookie = SimpleCookie()
        cookie.load(self.si._stub.cookie)
        if "vmware_soap_session" not in cookie:
            raise CaptureError("vSphere session has no datastore authentication cookie")
        return Request(
            url,
            headers={
                "Cookie": cookie["vmware_soap_session"].OutputString(attrs=[]),
                "Accept-Encoding": "identity",
                "User-Agent": "esxi-honeypot-capture/1.0",
            },
        )

    def download(self, record, directory):
        self.heartbeat()
        return download_file(
            self.opener,
            self.request_for(record.path),
            record,
            directory,
            self.args.http_timeout_seconds,
            self.heartbeat,
        )

    def verify_sources(self, records):
        after = {
            r.path: r.fingerprint for r in self.stat_files([r.path for r in records])
        }
        if any(
            after[r.path][0] != r.size
            or (r.modified is not None and after[r.path][1] != r.modified)
            for r in records
        ):
            raise CaptureError(
                "Source file size or modification time changed during transfer"
            )

    def check_snapshot_context(self, snapshot, original_ids, initial_vm):
        current = self.snapshots()
        if {s["Id"] for s in current} != original_ids | {snapshot._moId}:
            raise CaptureError(
                "Snapshot tree changed outside this capture; manual review required"
            )
        info = self.vm_info()
        if info["PowerState"] != "poweredOn":
            raise CaptureError(
                "VM power state changed during capture; manual review required"
            )
        for key in ("HostId", "VmPathName", "SnapshotDirectory", "InstanceUuid"):
            if info[key] != initial_vm[key]:
                raise CaptureError(
                    f"VM {key} changed during capture; manual review required"
                )
        if self.vm.snapshot.currentSnapshot._moId != snapshot._moId:
            raise CaptureError(
                "Capture snapshot is no longer current; manual review required"
            )

    def remove_snapshot(self, snapshot):
        return snapshot.RemoveSnapshot_Task(removeChildren=False, consolidate=True)

    def check_consolidation(self):
        deadline = time.monotonic() + 60
        while True:
            needed = self.vm.runtime.consolidationNeeded
            if needed is False:
                return False
            if time.monotonic() >= deadline:
                return needed  # None is unknown and must not be treated as success.
            time.sleep(3)


def capture(args, backend):
    root = args.destination_root.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    vm = backend.select_vm()
    identity = f"{backend.server_id}|{vm['InstanceUuid'] or vm['Id']}"
    key = hashlib.sha256(identity.encode()).hexdigest()[:24]
    lock_path = root / f".capture-{key}.lock"
    success_path = root / f".last-success-{key}.utc"
    pending_path = root / f".pending-{key}.json"
    with CaptureLock(lock_path):
        if pending_path.exists():
            raise CaptureError(
                f"An earlier capture needs review. Inspect {pending_path}; do not blindly retry"
            )
        check_rate_limit(
            success_path, args.minimum_interval_minutes, args.override_rate_limit
        )
        existing = backend.snapshots()
        if len(existing) > args.maximum_existing_snapshots:
            raise CaptureError(
                f"Existing snapshot count {len(existing)} exceeds limit {args.maximum_existing_snapshots}"
            )
        if any(
            s["Name"].casefold().startswith(args.snapshot_prefix.casefold() + "-")
            for s in existing
        ):
            raise CaptureError(
                "An earlier capture snapshot still exists; resolve it before capturing again"
            )
        if vm["PowerState"] != "poweredOn":
            raise CaptureError("VM must be powered on for a memory capture")
        if vm["ConsolidationNeeded"] is not False:
            raise CaptureError(
                "VM requires consolidation, or consolidation state is unknown"
            )
        if vm["IndependentDisks"]:
            raise CaptureError(
                "Independent-mode disks are incompatible with this memory-snapshot workflow"
            )
        if vm["Encrypted"] and not args.allow_encrypted_memory:
            raise CaptureError(
                "VM is encrypted; validate decryption/analysis before using --allow-encrypted-memory"
            )
        backend.check_datastore_space(vm["SnapshotDirectory"], vm["MemoryGB"])
        local_multiplier, local_extra = (2.2, 2) if args.compress_memory else (1.10, 1)
        check_local_space(root, math.ceil(vm["MemoryGB"] * local_multiplier + local_extra) * GIB)
        before = {
            r.path: r.fingerprint
            for directory in {vm["SnapshotDirectory"], parent_ds_path(vm["VmPathName"])}
            for r in backend.list_files(directory)
        }
        capture_id = uuid.uuid4().hex
        started = utcnow()
        suffix = f"{started:%Y%m%dT%H%M%SZ}-{capture_id[:8]}"
        snapshot_name = f"{args.snapshot_prefix}-{suffix}"
        directory = root / f"{safe_name(vm['Name'])}_{suffix}"
        directory.mkdir(mode=0o700)
        manifest = {
            "SchemaVersion": 2 if args.compress_memory else 1,
            "Status": "starting",
            "CaptureId": capture_id,
            "StartedAtUtc": iso(started),
            "CompletedAtUtc": None,
            "Trigger": {"Reason": args.trigger_reason},
            "Tool": {
                "ScriptName": Path(__file__).name,
                "Python": platform.python_version(),
                "PyVmomi": importlib.metadata.version("pyvmomi"),
            },
            "Server": args.server,
            "ServerInstanceUuid": backend.server_id,
            "TransportSecurity": {
                "InsecureSkipTlsVerify": args.insecure_skip_tls_verify,
                "CertificateVerificationEnabled": not args.insecure_skip_tls_verify,
                "HostnameVerificationEnabled": not args.insecure_skip_tls_verify,
                "Scope": "capture-process",
                "CABundle": str(args.ca_bundle) if args.ca_bundle else None,
            },
            "VM": vm,
            "Snapshot": {
                "Name": snapshot_name,
                "Id": None,
                "CreatedAtUtc": None,
                "MemoryIncluded": True,
                "Quiesced": False,
                "CreateTaskId": None,
                "CreationRequested": False,
                "CreationIntentPersisted": False,
                "Removed": False,
                "RemovalRequested": False,
                "RemovalIntentPersisted": False,
                "RemoveTaskId": None,
                "RemovalCompletedAtUtc": None,
                "ConsolidationNeededAfterRemoval": None,
            },
            "Files": [],
            "MemoryCompression": "gzip-fast" if args.compress_memory else "none",
            "Warnings": [TLS_BYPASS_WARNING] if args.insecure_skip_tls_verify else [],
            "Error": None,
            "StateFiles": {
                "Lock": str(lock_path),
                "LastSuccess": str(success_path),
                "Pending": str(pending_path),
            },
        }
        snapshot = None
        creation_attempted = False
        removal_attempted = False
        try:
            if vm["Encrypted"]:
                message = "Encrypted VM: captured memory may be unusable without a separately validated decryption workflow."
                LOG.warning(message)
                manifest["Warnings"].append(message)
            write_manifest(directory, manifest)
            # Persist intent BEFORE dispatch, including when the server accepts a request
            # but the connection drops before returning a task/snapshot identifier.
            atomic_json(
                pending_path,
                {
                    "CaptureId": capture_id,
                    "SnapshotName": snapshot_name,
                    "CaptureDirectory": str(directory),
                    "StartedAtUtc": iso(started),
                },
            )
            manifest["Snapshot"]["CreationIntentPersisted"] = True
            write_manifest(directory, manifest)
            LOG.info("Creating memory snapshot %s", snapshot_name)
            creation_attempted = True
            manifest["Snapshot"]["CreationRequested"] = True
            task = backend.create_snapshot(
                snapshot_name,
                f"Honeypot forensic memory capture. CaptureId={capture_id}; Trigger={args.trigger_reason}",
            )
            manifest["Snapshot"]["CreateTaskId"] = task._moId
            write_manifest(directory, manifest)
            snapshot = backend.wait_task(task)
            from pyVmomi import vim

            if not isinstance(snapshot, vim.vm.Snapshot) or not snapshot._moId:
                raise CaptureError("Create task returned an invalid snapshot reference")
            manifest["Snapshot"]["Id"] = snapshot._moId
            tree = [s for s in backend.snapshots() if s["Id"] == snapshot._moId]
            if len(tree) != 1:
                raise CaptureError(
                    "Created snapshot not uniquely present in VM snapshot tree"
                )
            manifest["Snapshot"]["CreatedAtUtc"] = tree[0]["CreatedAtUtc"]
            manifest["Snapshot"]["PowerState"] = tree[0].get("PowerState")
            if tree[0].get("PowerState") != "poweredOn":
                raise CaptureError(
                    "Snapshot does not report a powered-on state; retaining it for review"
                )
            manifest["Status"] = "snapshot-created"
            write_manifest(directory, manifest)
            memory = backend.discover_memory(snapshot, before, vm["SnapshotDirectory"])
            if not any(r.name.lower().endswith(".vmem") for r in memory):
                message = "No separate .vmem: vSphere reports memory combined with snapshot data; validate the .vmsn in your analysis tools."
                LOG.warning(message)
                manifest["Warnings"].append(message)
            records = memory + backend.metadata_files(vm)
            if len({r.name.casefold() for r in records}) != len(records):
                raise CaptureError(
                    "Duplicate evidence basenames across datastores; refusing to overwrite"
                )
            compression_space = sum(compression_reserve(r.size) for r in memory) if args.compress_memory else 0
            check_local_space(directory, sum(r.size for r in records) + compression_space + GIB)
            for record in records:
                manifest["Files"].append(backend.download(record, directory))
                write_manifest(directory, manifest)
            backend.verify_sources(records)
            verify_local_evidence(manifest["Files"], directory, backend.heartbeat)
            if args.compress_memory:
                manifest["Status"] = "compressing"
                write_manifest(directory, manifest)
                for record in manifest["Files"]:
                    if record["Kind"] == "memory-state":
                        record["Storage"] = compress_memory_file(record, directory, backend.heartbeat)
                        write_manifest(directory, manifest)
                # Compression may take a long time: refresh the remote validation gate.
                backend.verify_sources(records)
                verify_local_evidence(manifest["Files"], directory, backend.heartbeat)
            backend.check_snapshot_context(snapshot, {s["Id"] for s in existing}, vm)
            manifest["Status"] = "downloaded-and-verified"
            # Immutable verification checkpoint survives later cleanup/status-write errors.
            write_manifest(directory, manifest, stem="verified-manifest")
            write_manifest(directory, manifest)
            if args.keep_snapshot:
                manifest["Status"] = "complete-snapshot-retained"
                LOG.warning(
                    "Evidence verified; retaining %s (--keep-snapshot)", snapshot_name
                )
            else:
                # Persist intent with Requested=False. A failed local write must
                # not claim the remote method was invoked. A hard crash can leave
                # only intent on disk, so it still requires operator review.
                manifest["Snapshot"]["RemovalIntentPersisted"] = True
                write_manifest(directory, manifest)
                LOG.info("Evidence verified; removing snapshot %s", snapshot_name)
                removal_attempted = True
                manifest["Snapshot"]["RemovalRequested"] = True
                manifest["Snapshot"]["Removed"] = None
                task = backend.remove_snapshot(snapshot)
                manifest["Snapshot"]["RemoveTaskId"] = task._moId
                write_manifest(directory, manifest)
                backend.wait_task(task)
                manifest["Snapshot"]["Removed"] = True
                manifest["Snapshot"]["RemovalCompletedAtUtc"] = iso()
                write_manifest(directory, manifest)
                needed = backend.check_consolidation()
                manifest["Snapshot"]["ConsolidationNeededAfterRemoval"] = needed
                if needed is not False:
                    raise CaptureError(
                        "Snapshot removed, but consolidation remains needed or unknown"
                    )
                manifest["Status"] = "complete"
            if args.compress_memory:
                remove_redundant_originals(manifest["Files"], directory, manifest["Warnings"])
            manifest["CompletedAtUtc"] = iso()
            write_manifest(directory, manifest)
            atomic_bytes(
                success_path, (manifest["CompletedAtUtc"] + "\n").encode("ascii")
            )
            # Kept snapshots continue to block new attempts until an operator reconciles them.
            if not args.keep_snapshot:
                pending_path.unlink()
                sync_directory(root)
            LOG.info("Capture complete: %s", directory)
            return {
                "CaptureId": capture_id,
                "VM": vm["Name"],
                "CaptureDirectory": str(directory),
                "SnapshotName": snapshot_name,
                "SnapshotRemoved": manifest["Snapshot"]["Removed"],
                "Files": manifest["Files"],
            }
        except BaseException as error:
            manifest["Snapshot"]["CreationRequested"] = creation_attempted
            manifest["Snapshot"]["RemovalRequested"] = removal_attempted
            manifest["Status"] = "failed"
            manifest["CompletedAtUtc"] = iso()
            manifest["Error"] = str(error) or type(error).__name__
            try:
                write_manifest(directory, manifest)
            except Exception as save_error:
                LOG.error("Could not save failure manifest: %s", save_error)
            if manifest["Snapshot"]["RemovalRequested"]:
                LOG.error(
                    "Cleanup started; inspect vSphere task/tree for actual removal state. Evidence: %s",
                    directory,
                )
            elif manifest["Snapshot"]["CreationRequested"]:
                LOG.warning(
                    "No removal requested. Snapshot %s may exist or still be creating. Inspect %s",
                    snapshot_name,
                    pending_path,
                )
            raise


def bounded_number(kind, low, high):
    def parse(value):
        number = kind(value)
        if not low <= number <= high:
            raise argparse.ArgumentTypeError(f"must be between {low} and {high}")
        return number

    return parse


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument(
        "--server",
        required=True,
        help="vCenter/ESXi DNS name or IP, without scheme or port",
    )
    parser.add_argument("--port", type=bounded_number(int, 1, 65535), default=443)
    identity = parser.add_mutually_exclusive_group(required=True)
    identity.add_argument("--username", help="Dedicated vSphere service account")
    identity.add_argument(
        "--credential-name", help="Worker-only JSON credential in CREDENTIALS_DIRECTORY"
    )
    parser.add_argument(
        "--vm-name", required=True, help="Exact, unique visible VM name"
    )
    parser.add_argument("--destination-root", required=True, type=Path)
    auth = parser.add_mutually_exclusive_group()
    auth.add_argument(
        "--password-env", help="Name of environment variable containing the password"
    )
    auth.add_argument(
        "--password-file",
        type=Path,
        help="Protected UTF-8 secret file; otherwise prompt securely",
    )
    tls = parser.add_mutually_exclusive_group()
    tls.add_argument(
        "--ca-bundle",
        type=Path,
        help="PEM CA bundle; otherwise use Python's trusted CAs",
    )
    tls.add_argument(
        "--insecure-skip-tls-verify", action="store_true",
        help="DANGER: disable certificate/hostname verification for API and downloads in this capture only",
    )
    parser.add_argument("--trigger-reason", default="manual")
    parser.add_argument("--snapshot-prefix", default="hp-mem")
    parser.add_argument(
        "--maximum-existing-snapshots", type=bounded_number(int, 0, 2), default=1
    )
    parser.add_argument(
        "--minimum-datastore-free-gb",
        type=bounded_number(float, 0, 1000000),
        default=20,
    )
    parser.add_argument(
        "--minimum-interval-minutes", type=bounded_number(int, 0, 10080), default=60
    )
    parser.add_argument(
        "--file-discovery-timeout-seconds",
        type=bounded_number(int, 10, 1800),
        default=180,
    )
    parser.add_argument(
        "--task-timeout-seconds", type=bounded_number(int, 10, 86400), default=3600
    )
    parser.add_argument(
        "--http-timeout-seconds", type=bounded_number(int, 10, 1800), default=60
    )
    parser.add_argument("--allow-encrypted-memory", action="store_true")
    parser.add_argument("--override-rate-limit", action="store_true")
    parser.add_argument("--compress-memory", action="store_true",
                        help="Gzip memory files on the collector, verify a full round trip before snapshot cleanup, then remove redundant raw copies")
    parser.add_argument("--keep-snapshot", "-KeepSnapshot", action="store_true")
    args = parser.parse_args(argv)
    if not re.fullmatch(r"[A-Za-z0-9_.:%-]+", args.server) or args.server.startswith(
        "-"
    ):
        parser.error(
            "--server must be a DNS name or unbracketed IP address without a URL/port"
        )
    if not 1 <= len(args.trigger_reason) <= 512 or any(
        ord(c) < 32 for c in args.trigger_reason
    ):
        parser.error(
            "--trigger-reason must contain 1–512 characters with no control characters"
        )
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", args.snapshot_prefix):
        parser.error(
            "--snapshot-prefix must be 1–80 letters, digits, underscores, periods or hyphens"
        )
    if not args.vm_name or args.username == "":
        parser.error("--vm-name and --username must not be empty")
    if args.credential_name is not None:
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", args.credential_name):
            parser.error("--credential-name must be a safe credential identifier")
        if args.password_env or args.password_file:
            parser.error("--credential-name cannot be combined with password options")
    return args


def read_password(args):
    if args.password_env:
        password = os.environ.get(args.password_env)
        if not password:
            raise CaptureError(
                f"Password environment variable {args.password_env!r} is missing or empty"
            )
    elif args.password_file:
        info = args.password_file.stat()
        if os.name != "nt" and info.st_mode & 0o077:
            raise CaptureError(
                "Password file must have no group/other permissions (e.g. chmod 600)"
            )
        password = args.password_file.read_text(encoding="utf-8").rstrip("\r\n")
    else:
        if not sys.stdin.isatty():
            raise CaptureError(
                "Noninteractive execution requires --password-env or --password-file"
            )
        password = getpass.getpass("vSphere password: ")
    if not password:
        raise CaptureError("Empty password")
    return password


def read_credentials(args):
    if not args.credential_name:
        return args.username, read_password(args)
    try:
        root = Path(os.environ["CREDENTIALS_DIRECTORY"])
        if not root.is_absolute():
            raise ValueError("Credential directory must be absolute")
        path = root / args.credential_name
        if path.is_symlink():
            raise ValueError("Symlink credential")
        info = path.stat()
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_size > 16384
            or (os.name != "nt" and info.st_mode & 0o077)
        ):
            raise ValueError("Credential size/permissions")
        secret = json.loads(path.read_text(encoding="utf-8"))
        username, password = secret["username"], secret["password"]
        if (
            not isinstance(username, str)
            or not username.strip()
            or not isinstance(password, str)
            or not password
        ):
            raise ValueError("Invalid credential fields")
        return username, password
    except (OSError, ValueError, KeyError, TypeError):
        # JSON decoder errors can contain the secret. Do not chain or log them.
        raise CaptureError(
            "Cannot read or parse the configured vSphere credential"
        ) from None


def main(argv=None):
    args = parse_args(argv)
    logging.Formatter.converter = time.gmtime
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)sZ [%(levelname)s] %(message)s"
    )
    os.umask(0o077)

    def interrupted(signum, frame):
        raise KeyboardInterrupt(f"Interrupted by signal {signum}")

    signal.signal(signal.SIGTERM, interrupted)
    backend = None
    try:
        args.username, password = read_credentials(args)
        backend = VsphereBackend(args, password)
        del password
        result = capture(args, backend)
        print(json.dumps(result, indent=2))
        return 0
    except KeyboardInterrupt:
        LOG.error(
            "Capture interrupted; inspect the manifest, pending marker and vSphere tasks before retrying"
        )
        return 130
    except Exception as error:
        privilege = getattr(error, "privilegeId", None)
        message = f"Missing vSphere privilege: {privilege}" if privilege else str(error)
        LOG.error("%s", message or type(error).__name__)
        return 1
    finally:
        if backend:
            try:
                backend.close()
            except Exception:
                LOG.warning(
                    "Could not close vSphere session; it will expire on the server"
                )


if __name__ == "__main__":
    sys.exit(main())
