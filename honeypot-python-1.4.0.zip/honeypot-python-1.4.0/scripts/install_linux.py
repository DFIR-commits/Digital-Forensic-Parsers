#!/usr/bin/env python3
"""Fresh Linux/systemd installation. See README.md beside this script.

Never upgrades an existing deployment, deletes evidence, changes a firewall,
or sends a snapshot request. TLS verification is enabled unless explicitly opted out.
"""
from __future__ import annotations

import argparse
import getpass
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import ssl
import stat
import subprocess
import sys
import time
import warnings

SOURCE = Path(__file__).resolve().parents[1]
PREFIX = Path('/opt/honeypot')
CONFIG = Path('/etc/honeypot')
QUEUE = Path('/var/lib/honeypot-webhook')
WORKER_STATE = Path('/var/lib/honeypot-worker')
UNIT_DIR = Path('/etc/systemd/system')
INSTALLER_LOCK = Path('/run/lock/honeypot-installer.lock')
RECEIVER = 'honeypot-webhook.service'
WORKERS = {'python': 'honeypot-capture-worker-python.service',
           'powershell': 'honeypot-capture-worker.service'}
UNITS = (RECEIVER, *WORKERS.values())
IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\Z')


class InstallError(Exception):
    pass


def run(command, **kwargs):
    return subprocess.run(command, check=True, **kwargs)


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def package_files(backend):
    common = ['scripts/capture_webhook.py', 'scripts/install_linux.py',
              'scripts/trigger_capture.py', 'scripts/README.md',
              'requirements-webhook.txt', 'deploy/gunicorn.conf.py',
              'deploy/honeypot-webhook.service', 'deploy/' + WORKERS[backend]]
    if backend == 'python':
        return common + ['scripts/install-python.sh', 'scripts/capture_esxi_vm_memory.py',
                         'scripts/verify_capture_bundle.py', 'requirements.txt']
    return common + ['scripts/install-powershell.sh', 'scripts/Capture-EsxiVmMemory.ps1',
                     'scripts/Invoke-CaptureFromWebhook.ps1']


def verify_package(source, backend):
    marker = source / 'PACKAGE.json'
    if marker.exists() and json.loads(marker.read_text())['backend'] != backend:
        raise InstallError('This archive contains a different capture backend.')
    checksum_file = source / 'SHA256SUMS'
    checksums = {}
    if checksum_file.exists():
        for line in checksum_file.read_text(encoding='ascii').splitlines():
            digest, name = line.split('  ', 1)
            relative = Path(name)
            if (relative.is_absolute() or '..' in relative.parts or
                    not re.fullmatch(r'[0-9a-f]{64}', digest) or name in checksums):
                raise InstallError('Invalid package checksum manifest.')
            path = source / relative
            if path.is_symlink() or not path.is_file() or path.resolve() != path.absolute():
                raise InstallError('Unsafe or missing package file: ' + name)
            if sha256(path) != digest:
                raise InstallError('Package checksum mismatch: ' + name)
            checksums[name] = digest
    for name in package_files(backend):
        path = source / name
        if path.is_symlink() or not path.is_file() or path.resolve() != path.absolute():
            raise InstallError('Missing or unsafe package file: ' + name)
        if checksum_file.exists() and name not in checksums:
            raise InstallError('Package checksum missing for: ' + name)


def validated_bind(value, allow_network):
    if value.startswith('['):
        match = re.fullmatch(r'\[([^\]]+)\]:(\d+)', value)
    else:
        match = re.fullmatch(r'([^:]+):(\d+)', value)
    if not match:
        raise InstallError('Bind must be an IP:port, or [IPv6]:port.')
    try:
        address = ipaddress.ip_address(match[1])
    except ValueError:
        raise InstallError('Bind must use a literal IP address, not a hostname.') from None
    if not 1024 <= int(match[2]) <= 65535:
        raise InstallError('Use an unprivileged listener port from 1024 through 65535.')
    if not address.is_loopback and not allow_network:
        raise InstallError('A network-facing HTTP listener requires --allow-network-listener; '
                           'configure the source-IP firewall allowlist first.')
    return value


def validated_evidence_path(value):
    path = Path(value)
    if (not path.is_absolute() or str(path) != value or '..' in path.parts or
            not re.fullmatch(r'/[A-Za-z0-9_./-]+', value) or len(path.parts) < 3):
        raise InstallError('Evidence path must be a dedicated absolute directory without '
                           'spaces, special characters, or parent traversals.')
    if path.resolve() != path:
        raise InstallError('Evidence path must not contain symlinks.')
    for reserved in (PREFIX, CONFIG, QUEUE, WORKER_STATE, Path('/etc'), Path('/usr'),
                     Path('/bin'), Path('/sbin'), Path('/proc'), Path('/sys'), Path('/dev'),
                     Path('/root'), Path('/home')):
        if path == reserved or reserved in path.parents or path in reserved.parents:
            raise InstallError('Evidence path overlaps a protected location.')
    return path


def check_private_directory(path):
    if path.is_symlink():
        raise InstallError('Refusing symlink directory: ' + str(path))
    if path.exists():
        info = path.stat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o077:
            raise InstallError('Existing evidence directory must be root-owned and mode 0700: '
                               + str(path) + '. Existing data will not be chmod/chowned.')


def check_safe_parents(path):
    for parent in path.parents:
        if parent.exists():
            info = parent.stat()
            if (parent.is_symlink() or not stat.S_ISDIR(info.st_mode) or
                    info.st_uid != 0 or info.st_mode & 0o022):
                raise InstallError('Installation/evidence parents must be root-owned and not '
                                   'group/world-writable: ' + str(parent))


def validate_target_pairs(pairs):
    aliases, names = set(), set()
    for alias, vm_name in pairs:
        if not IDENTIFIER.fullmatch(alias):
            raise InstallError('Target ID must be a safe 1–64 character identifier.')
        if not vm_name.strip() or len(vm_name) > 200 or any(ord(c) < 32 or ord(c) == 127 for c in vm_name):
            raise InstallError('VM name must contain 1–200 printable characters.')
        # Avoid both duplicate inventory registrations and case-insensitive paths.
        if alias.casefold() in aliases:
            raise InstallError('Each target ID must be unique (case-insensitive).')
        if vm_name.casefold() in names:
            raise InstallError('Use only one target ID per VM on this server.')
        aliases.add(alias.casefold())
        names.add(vm_name.casefold())
    return pairs


def target_specs(args):
    """Fixed inventory names; requests may select aliases, never supply VM names."""
    pairs = [(args.target_id, args.vm_name)]
    for value in args.additional_target:
        alias, separator, vm_name = value.partition('=')
        if not separator:
            raise InstallError('--additional-target must be ID=VM_NAME (quote names containing spaces).')
        pairs.append((alias, vm_name))
    return validate_target_pairs(pairs)


def target_directories(args):
    pairs = target_specs(args)
    # Preserve the original single-target layout. Multi-target fresh installs
    # isolate each VM's evidence and safety markers under its stable alias.
    return {alias: args.evidence_root / alias if len(pairs) > 1 else args.evidence_root
            for alias, _ in pairs}


def validated_server(value):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.:-]{0,252}', value):
        raise InstallError('Server must be a hostname or IP, without a URL, port, or path.')
    # Colon is permitted only in an IPv6 literal, not in host:port.
    if ':' in value:
        try:
            ipaddress.IPv6Address(value)
        except ValueError:
            raise InstallError('Use an IPv6 literal or a hostname/IP without a port.') from None
    return value


def validated_username(value):
    if not value.strip() or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise InstallError('Username must be nonempty and contain no control characters.')
    return value


def validate_args(args):
    if not args.server or not args.vm_name:
        raise InstallError('Supply --server and --vm-name, or run --interactive from a terminal.')
    validated_server(args.server)
    target_specs(args)
    if not 0 <= args.minimum_interval_minutes <= 10080:
        raise InstallError('Capture interval must be 0–10080 minutes.')
    if not 30 <= args.capture_timeout_seconds <= 86400:
        raise InstallError('Capture timeout must be 30–86400 seconds.')
    if not 1 <= args.max_queue_age_seconds <= 3600:
        raise InstallError('Maximum queue age must be 1–3600 seconds.')
    if args.username:
        validated_username(args.username)
    if args.credential_file and args.username:
        raise InstallError('Use --credential-file or --username, not both.')
    if args.insecure_skip_tls_verify and args.ca_bundle:
        raise InstallError('--ca-bundle cannot be combined with --insecure-skip-tls-verify.')
    if args.ca_bundle and args.backend != 'python':
        raise InstallError('--ca-bundle is Python-only; provision PowerCLI trust separately.')
    if args.ca_bundle:
        # Parse certificates without connecting to ESXi or weakening trust.
        ssl.create_default_context(cafile=str(args.ca_bundle))
    validated_bind(args.bind, args.allow_network_listener)
    args.evidence_root = validated_evidence_path(str(args.evidence_root))
    for path in target_directories(args).values():
        validated_evidence_path(str(path))


def ask_value(label, default=None, validate=None, *, strip=True):
    """Non-secret prompt with validation/retry. Passwords must use getpass only."""
    while True:
        suffix = f' [{default}]' if default is not None and str(default) else ''
        value = input(label + suffix + ': ')
        if strip:
            value = value.strip()
        if not value and default is not None:
            value = str(default)
        try:
            return validate(value) if validate else value
        except (InstallError, ValueError, OSError) as error:
            print('Please try again: ' + str(error))


def ask_yes_no(label, default=False):
    while True:
        value = input(label + (' [Y/n]: ' if default else ' [y/N]: ')).strip().lower()
        if not value:
            return default
        if value in ('yes', 'y'):
            return True
        if value in ('no', 'n'):
            return False
        print('Please enter yes or no.')


def ask_integer(label, default, minimum, maximum):
    def validate(value):
        if not value.isascii() or not value.isdigit() or not minimum <= int(value) <= maximum:
            raise InstallError(f'Enter a whole number from {minimum} to {maximum}.')
        return int(value)
    return ask_value(label, default, validate)


def suggested_alias(vm_name, index):
    value = re.sub(r'[^A-Za-z0-9_.-]+', '-', vm_name).strip('-_.')[:64]
    return value or f'vm{index}'


def interactive_setup(args):
    """Collect non-secret settings; no filesystem writes, credentials or API calls."""
    if not sys.stdin.isatty():
        raise InstallError('Interactive setup requires a terminal. For unattended use supply '
                           '--server, --vm-name and --credential-file (or --check).')
    if args.credential_file and args.username:
        raise InstallError('Use --credential-file or --username, not both.')
    print('\nHoneypot installer — ' + args.backend + ' backend')
    print('Fresh Linux/systemd install; receiver and worker run as root.')
    print('All VMs use one ESXi/vCenter endpoint and service account, not guest logins.')
    print('No deployment files are written until you review and confirm. Ctrl+C cancels.')
    args.server = ask_value('ESXi/vCenter hostname or IP', args.server, validated_server)
    if not args.check and not args.credential_file:
        args.username = ask_value('ESXi/vCenter username', args.username, validated_username)
    elif args.check:
        print('Check-only mode: no username/password or credential file will be requested/read.')
    else:
        print('Using the supplied credential file; it will not be read until after confirmation.')

    defaults = [(args.target_id if args.vm_name or args.target_id != 'honeypot' else None, args.vm_name)]
    for raw in args.additional_target:
        alias, separator, vm_name = raw.partition('=')
        if not separator:
            raise InstallError('--additional-target must be ID=VM_NAME.')
        defaults.append((alias, vm_name))
    count = ask_integer('Number of VMs to configure', max(1, len(defaults)), 1, 32)
    pairs = []
    for index in range(1, count + 1):
        old_alias, old_name = defaults[index - 1] if index <= len(defaults) else (None, None)
        def validate_vm(value):
            validate_target_pairs([(f'vm{n}', name) for n, (_, name) in enumerate(pairs)] + [('new', value)])
            return value
        vm_name = ask_value(f'VM {index}: exact inventory name', old_name, validate_vm, strip=False)
        def validate_alias(value):
            validate_target_pairs(pairs + [(value, vm_name)])
            return value
        alias = ask_value(f'VM {index}: trigger target ID', old_alias or suggested_alias(vm_name, index), validate_alias)
        pairs.append((alias, vm_name))
    args.target_id, args.vm_name = pairs[0]
    args.additional_target = [alias + '=' + name for alias, name in pairs[1:]]

    verify_tls = ask_yes_no('Verify ESXi TLS certificates and hostnames for these VMs?', not args.insecure_skip_tls_verify)
    if not verify_tls:
        print('WARNING: disabling verification permits credential theft and evidence substitution. '
              'HTTPS encryption alone does not authenticate ESXi. This is not TOFU/pinning.')
        acknowledgement = input('Type DISABLE to accept this risk (anything else keeps verification enabled): ')
        verify_tls = acknowledgement != 'DISABLE'
        if verify_tls:
            print('TLS verification kept enabled.')
    args.insecure_skip_tls_verify = not verify_tls
    if not verify_tls:
        args.ca_bundle = None
    elif args.backend == 'python':
        def validate_ca(value):
            if value in ('', '-'):
                return None
            path = Path(value)
            if not path.is_absolute():
                raise InstallError('Use an absolute PEM path, or leave blank for default trust.')
            ssl.create_default_context(cafile=str(path))
            return path
        args.ca_bundle = ask_value('CA bundle PEM path (blank=default trust, -=clear supplied path)', args.ca_bundle, validate_ca)
    else:
        args.ca_bundle = None
        print('PowerCLI uses its configured trust. This installer does not change OS/User/AllUsers trust.')

    args.evidence_root = ask_value('Evidence root directory', args.evidence_root, validated_evidence_path)
    bind_default = args.bind
    while True:
        args.bind = ask_value('Collector HTTP listen IP:port', bind_default, lambda value: validated_bind(value, True))
        address = args.bind[1:args.bind.index(']')] if args.bind.startswith('[') else args.bind.split(':')[0]
        args.allow_network_listener = not ipaddress.ip_address(address).is_loopback
        if not args.allow_network_listener:
            break
        print('WARNING: this root-run listener uses plain HTTP. Restrict it to trusted senders with a firewall; '
              'traffic observers can steal its tokens. The installer does not configure a firewall.')
        if ask_yes_no('Allow this network-facing HTTP listener?', False):
            break
        print('Network exposure declined. Choose a loopback address or explicitly approve another bind.')
        bind_default = '127.0.0.1:8787'
    print('Capture modes: dry-run=queue only; keep=capture and retain snapshot; live=verified automatic cleanup.')
    def validate_mode(value):
        if value not in ('dry-run', 'keep', 'live'):
            raise InstallError('Choose dry-run, keep or live.')
        return value
    args.mode = ask_value('Initial capture mode', args.mode, validate_mode)
    args.compress_memory = ask_yes_no('Compress captured memory with gzip (extra CPU/time and temporary disk space)?', args.compress_memory)
    if args.compress_memory:
        print('Gzip is verified before snapshot cleanup. Budget about 150 GiB free per 64 GiB VM capture; '
              'compression does not reduce ESXi space or network transfer. Benchmark before live use.')
    args.minimum_interval_minutes = ask_integer('Per-VM cooldown (minutes; webhook admission floor still applies)',
                                                args.minimum_interval_minutes, 0, 10080)
    args.capture_timeout_seconds = ask_integer('Capture process timeout (seconds)', args.capture_timeout_seconds, 30, 86400)
    args.max_queue_age_seconds = ask_integer('Maximum queued-job age (seconds; captures run sequentially)',
                                             args.max_queue_age_seconds, 1, 3600)
    args.no_start = not ask_yes_no('Enable services at boot and start them after installation?', not args.no_start)
    print('Separate Splunk/CrowdStrike tokens will be generated automatically; each allows the configured VM IDs.')
    return args


def print_install_summary(args):
    print('\nReview installation (no passwords or tokens shown)')
    print('Backend: ' + args.backend + '; endpoint: ' + args.server)
    print('Credential: ' + ('not read in check-only mode' if args.check else
                            'protected JSON file' if args.credential_file else 'username ' + args.username))
    print('TLS verification: ' + ('DISABLED — explicit risk accepted' if args.insecure_skip_tls_verify else 'enabled'))
    if args.ca_bundle:
        print('Python CA bundle: ' + str(args.ca_bundle))
    directories = target_directories(args)
    for alias, name in target_specs(args):
        print('  ' + alias + ' -> ' + name + '; evidence: ' + str(directories[alias]))
    print('Source token allowlists: Splunk and CrowdStrike can each select the VM IDs above.')
    print('Root-run HTTP listener: ' + args.bind + '; mode: ' + args.mode)
    print('Memory compression: ' + ('gzip fast, verified before cleanup' if args.compress_memory else 'disabled'))
    print(f'Cooldown: {args.minimum_interval_minutes} minutes; capture timeout: {args.capture_timeout_seconds}s; '
          f'queue freshness: {args.max_queue_age_seconds}s')
    print('Services: ' + ('install only; not started/enabled' if args.no_start else 'enable at boot and start now'))
    print('Config: ' + str(CONFIG / 'webhook.json') + '; source secrets: root-only mode 0600 (plaintext on disk).')
    print('Installer does not contact ESXi. Active services process authorized triggers in the selected mode.')


def preflight(args):
    if not sys.platform.startswith('linux') or sys.version_info < (3, 10):
        raise InstallError('Installer requires Linux and Python 3.10 or newer.')
    if not args.check and os.geteuid() != 0:
        raise InstallError('Run this installer as root (sudo).')
    if not Path('/run/systemd/system').is_dir():
        raise InstallError('A running systemd service manager is required (not plain Docker).')
    for command in ('systemctl', 'systemd-analyze'):
        if not shutil.which(command):
            raise InstallError('Missing prerequisite: ' + command)
    version = run(['systemctl', '--version'], capture_output=True, text=True).stdout.splitlines()[0]
    if int(version.split()[1]) < 247:
        raise InstallError('systemd 247+ is required for LoadCredential.')
    try:
        import ensurepip  # noqa: F401
        import venv  # noqa: F401
    except ImportError:
        raise InstallError('Install Python venv/ensurepip support (Debian/Ubuntu: python3-venv).') from None
    for path in (PREFIX, CONFIG, QUEUE, WORKER_STATE):
        if path.exists() or path.is_symlink():
            raise InstallError('Fresh installation only; existing path is preserved: ' + str(path))
        if path.parent.resolve() != path.parent:
            raise InstallError('Managed parent directory must not be a symlink: ' + str(path.parent))
        check_safe_parents(path)
    check_safe_parents(UNIT_DIR / RECEIVER)
    check_safe_parents(args.evidence_root)
    for unit in UNITS:
        path = UNIT_DIR / unit
        if path.exists() or path.is_symlink():
            raise InstallError('Existing service is preserved; review migration first: ' + unit)
        loaded = subprocess.run(['systemctl', 'show', '-p', 'LoadState', '--value', unit],
                                capture_output=True, text=True)
        if loaded.returncode != 0 and loaded.stdout.strip() != 'not-found':
            raise InstallError('Cannot query the systemd manager for ' + unit)
        if loaded.stdout.strip() not in ('', 'not-found'):
            raise InstallError('An existing service definition conflicts: ' + unit)
    check_private_directory(args.evidence_root)
    for path in target_directories(args).values():
        check_safe_parents(path)
        check_private_directory(path)
    if args.backend == 'powershell':
        args.pwsh = shutil.which('pwsh')
        if not args.pwsh or not re.fullmatch(r'/[A-Za-z0-9_./-]+', args.pwsh):
            raise InstallError('Install PowerShell 7.4+ (pwsh) first; see README.md.')
        run([args.pwsh, '-NoLogo', '-NoProfile', '-NonInteractive', '-Command',
             "$ErrorActionPreference='Stop'; "
             "if ($PSVersionTable.PSVersion -lt [version]'7.4') { throw 'PowerShell 7.4+ required' }; "
             "Import-Module VMware.VimAutomation.Core; "
             "Write-Output ('PowerCLI Core: ' + (Get-Module VMware.VimAutomation.Core).Version)"])


def read_credential(args):
    if args.credential_file:
        try:
            path = args.credential_file
            info = path.lstat()
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or
                    info.st_mode & 0o077 or info.st_size > 16384):
                raise ValueError('Unsafe credential file')
            secret = json.loads(path.read_text(encoding='utf-8'))
            if (not isinstance(secret['username'], str) or not secret['username'].strip() or
                    not isinstance(secret['password'], str) or not secret['password']):
                raise ValueError('Invalid credential')
            validated_username(secret['username'])
            return {'username': secret['username'], 'password': secret['password']}
        except (OSError, ValueError, KeyError, TypeError, InstallError):
            raise InstallError('Cannot read credential JSON; require a root-owned regular '
                               'file, mode 0600, <=16 KiB, with username/password strings.') from None
    if args.non_interactive or not sys.stdin.isatty():
        raise InstallError('Noninteractive installation requires --credential-file. '
                           'Passwords are never accepted in command arguments.')
    username = args.username or ask_value('ESXi/vCenter username', validate=validated_username)
    validated_username(username)
    while True:
        try:
            # Never fall back to an echoing input stream for a service password.
            with warnings.catch_warnings():
                warnings.simplefilter('error', getpass.GetPassWarning)
                password = getpass.getpass('ESXi/vCenter password (not displayed): ')
                if not password:
                    print('Password cannot be empty. Please try again.')
                    continue
                confirmation = getpass.getpass('Confirm password (not displayed): ')
        except getpass.GetPassWarning:
            raise InstallError('Cannot hide password entry. Use a terminal or a protected --credential-file.') from None
        if password == confirmation:
            return {'username': username, 'password': password}
        print('Passwords did not match. Please try again.')


def make_config(args):
    targets = {}
    directories = target_directories(args)
    for alias, vm_name in target_specs(args):
        target = {'server': args.server, 'vm_name': vm_name,
                  'destination_root': str(directories[alias]), 'credential_name': 'esxi-target',
                  'minimum_interval_minutes': args.minimum_interval_minutes,
                  'insecure_skip_tls_verify': args.insecure_skip_tls_verify,
                  'compress_memory': args.compress_memory,
                  'keep_snapshot': args.mode != 'live'}
        if args.ca_bundle:
            target['ca_bundle'] = str(CONFIG / 'esxi-ca.pem')
        targets[alias] = target
    config = {'dry_run': args.mode == 'dry-run', 'capture_backend': args.backend,
              'state_directory': str(QUEUE), 'max_pending_jobs': 16, 'max_total_jobs': 100000,
              'max_queue_age_seconds': args.max_queue_age_seconds, 'minimum_admission_seconds': 60,
              'capture_timeout_seconds': args.capture_timeout_seconds,
              'sources': {name: {'token_credential': name + '-token',
                                 'allowed_targets': list(targets)}
                          for name in ('splunk', 'crowdstrike')},
              'targets': targets}
    if args.backend == 'python':
        config.update(python=str(PREFIX / '.venv-webhook/bin/python'),
                      capture_script=str(PREFIX / 'scripts/capture_esxi_vm_memory.py'))
    else:
        config.update(pwsh=args.pwsh, wrapper_script=str(PREFIX / 'scripts/Invoke-CaptureFromWebhook.ps1'),
                      capture_script=str(PREFIX / 'scripts/Capture-EsxiVmMemory.ps1'))
    return config


def render_units(args, source=SOURCE):
    result = {}
    for name in (RECEIVER, WORKERS[args.backend]):
        unit = (source / 'deploy' / name).read_text()
        unit = '\n'.join(line for line in unit.splitlines() if not line.startswith('#')) + '\n'
        unit = unit.replace('Environment=HONEYPOT_WEBHOOK_BIND=127.0.0.1:8787',
                            'Environment=HONEYPOT_WEBHOOK_BIND=' + args.bind)
        unit = unit.replace('LoadCredential=esxi-alpine:/etc/honeypot/secrets/esxi-alpine.json',
                            'LoadCredential=esxi-target:/etc/honeypot/secrets/esxi-target.json')
        unit = unit.replace('/srv/honeypot-evidence', str(args.evidence_root))
        if 'User=root\n' not in unit or 'Group=root\n' not in unit:
            raise InstallError('Package service templates must explicitly run as root.')
        result[name] = unit
    return result


def write_new(path, data, mode=0o600):
    """Exclusive creation; never replace another deployment's files."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, mode)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data if isinstance(data, bytes) else data.encode('utf-8'))
        stream.flush()
        os.fsync(stream.fileno())


def json_new(path, value):
    write_new(path, json.dumps(value, indent=2) + '\n')


def install(args, credential):
    os.umask(0o077)
    # The lock is outside the managed installation, so a concurrent installer
    # cannot pass preflight and start populating the same directories.
    import fcntl
    lock_fd = os.open(INSTALLER_LOCK,
                      os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    with os.fdopen(lock_fd, 'a+b') as lock:
        info = os.fstat(lock.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise InstallError('Installer lock must be a private regular file owned by the installer account.')
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise InstallError('Another installer is running.') from None
        preflight(args)  # Recheck after acquiring the lock.
        units = render_units(args)
        for path in (PREFIX, CONFIG, QUEUE, WORKER_STATE):
            path.mkdir(mode=0o700)
        for path in (CONFIG / 'secrets', WORKER_STATE / 'config', WORKER_STATE / 'cache'):
            path.mkdir(mode=0o700)
        args.evidence_root.mkdir(parents=True, mode=0o700, exist_ok=True)
        check_private_directory(args.evidence_root)
        for path in target_directories(args).values():
            check_private_directory(path)
            path.mkdir(mode=0o700, exist_ok=True)
            check_private_directory(path)
        # Retain an explicit incomplete marker on any installation failure.
        json_new(PREFIX / 'INSTALLATION-INCOMPLETE.json',
                 {'backend': args.backend, 'note': 'Do not rerun over these paths; inspect before recovery.'})
        for name in package_files(args.backend):
            destination = PREFIX / name
            destination.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
            write_new(destination, (SOURCE / name).read_bytes(), 0o700 if name.endswith('.sh') else 0o600)
        if args.ca_bundle:
            write_new(CONFIG / 'esxi-ca.pem', args.ca_bundle.read_bytes())
        json_new(CONFIG / 'secrets/esxi-target.json', credential)
        for name in ('splunk-token', 'crowdstrike-token'):
            write_new(CONFIG / 'secrets' / name, secrets.token_urlsafe(48) + '\n')
        config = make_config(args)
        json_new(CONFIG / 'webhook.json', config)
        run([sys.executable, '-m', 'venv', str(PREFIX / '.venv-webhook')])
        python = str(PREFIX / '.venv-webhook/bin/python')
        requirements = ['-r', str(PREFIX / 'requirements-webhook.txt')]
        if args.backend == 'python':
            requirements += ['-r', str(PREFIX / 'requirements.txt')]
        run([python, '-m', 'pip', 'install', '--disable-pip-version-check', *requirements])
        run([python, '-m', 'pip', 'check'])
        env = dict(os.environ, HONEYPOT_WEBHOOK_CONFIG=str(CONFIG / 'webhook.json'),
                   HONEYPOT_WEBHOOK_BIND=args.bind, CREDENTIALS_DIRECTORY=str(CONFIG / 'secrets'),
                   PYTHONDONTWRITEBYTECODE='1')
        run([str(PREFIX / '.venv-webhook/bin/gunicorn'), '--check-config',
             '--config', str(PREFIX / 'deploy/gunicorn.conf.py'), 'capture_webhook:create_app()'],
            cwd=PREFIX / 'scripts', env=env)
        for name, content in units.items():
            write_new(UNIT_DIR / name, content, 0o644)
        run(['systemd-analyze', 'verify', *(str(UNIT_DIR / name) for name in units)])
        run(['systemctl', 'daemon-reload'])
        json_new(PREFIX / 'INSTALLATION.json',
                 {'backend': args.backend, 'mode': args.mode, 'bind': args.bind,
                  'insecure_skip_tls_verify': args.insecure_skip_tls_verify,
                  'compress_memory': args.compress_memory,
                  'config': str(CONFIG / 'webhook.json'), 'evidence_root': str(args.evidence_root),
                  'targets': {alias: {'server': target['server'], 'vm_name': target['vm_name'],
                                      'destination_root': target['destination_root']}
                              for alias, target in config['targets'].items()},
                  'services': list(units),
                  'source_sha256': {name: sha256(SOURCE / name) for name in package_files(args.backend)}})
        # Move only our own fresh marker, keeping an audit record of installation.
        (PREFIX / 'INSTALLATION-INCOMPLETE.json').rename(PREFIX / 'INSTALLATION-PREPARED.json')
        if not args.no_start:
            try:
                run(['systemctl', 'enable', '--now', WORKERS[args.backend], RECEIVER])
                time.sleep(2)
                run(['systemctl', 'is-active', '--quiet', WORKERS[args.backend], RECEIVER])
            except subprocess.CalledProcessError:
                # Leave definitions/config/evidence for diagnosis; no silent cleanup.
                raise InstallError('Installation was prepared, but service startup failed. '
                                   'Inspect systemctl status and journalctl; files are preserved.') from None
        print('Installed backend: ' + args.backend)
        print('Mode: ' + args.mode + '; HTTP bind: ' + args.bind)
        print('ESXi TLS verification for configured targets: ' + ('DISABLED (explicit opt-in)' if args.insecure_skip_tls_verify else 'enabled'))
        for alias, target in config['targets'].items():
            print('Target: ' + alias + ' -> ' + target['vm_name'] + '; evidence: ' + target['destination_root'])
        print('Services: ' + ', '.join(units))
        print('Secrets are root-only under /etc/honeypot/secrets; tokens were not printed.')
        print('Instructions: /opt/honeypot/scripts/README.md')
        print('No ESXi operation was performed by the installer.')
        if args.no_start:
            print('Services are NOT enabled or started (--no-start).')


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--backend', choices=tuple(WORKERS), required=True)
    interaction = p.add_mutually_exclusive_group()
    interaction.add_argument('--interactive', action='store_true', help='Ask all setup questions, then review and confirm')
    interaction.add_argument('--non-interactive', action='store_true', help='Never prompt; install using supplied options and --credential-file')
    p.add_argument('--server', help='ESXi/vCenter hostname or IP; omitted settings launch the terminal wizard')
    p.add_argument('--vm-name', help='Primary VM inventory name; wizard asks if omitted')
    p.add_argument('--target-id', default='honeypot', help='Stable webhook alias; default: honeypot')
    p.add_argument('--additional-target', action='append', default=[], metavar='ID=VM_NAME',
                   help='Add a VM on the same server/account; repeatable; each request selects one target ID')
    p.add_argument('--username', help='Password will be prompted for without echo')
    p.add_argument('--credential-file', type=Path, help='Root-owned mode-0600 JSON, for unattended installation')
    p.add_argument('--bind', default='127.0.0.1:8787')
    p.add_argument('--allow-network-listener', action='store_true')
    p.add_argument('--mode', choices=('dry-run', 'keep', 'live'), default='dry-run')
    p.add_argument('--evidence-root', default='/srv/honeypot-evidence')
    p.add_argument('--ca-bundle', type=Path, help='Python-only verified PEM trust bundle')
    p.add_argument('--insecure-skip-tls-verify', action='store_true',
                   help='DANGER: disable ESXi certificate/hostname verification for all targets configured by this install')
    p.add_argument('--minimum-interval-minutes', type=int, default=60)
    p.add_argument('--compress-memory', action='store_true',
                   help='Enable verified collector-side gzip memory compression for each configured target')
    p.add_argument('--capture-timeout-seconds', type=int, default=3600)
    p.add_argument('--max-queue-age-seconds', type=int, default=300, help='Queued-job freshness limit, 1–3600 seconds')
    p.add_argument('--no-start', action='store_true', help='Install but do not enable/start services')
    p.add_argument('--check', action='store_true', help='Read-only prerequisite checks; no secrets, installs or service changes')
    return p


def main(argv=None):
    try:
        args = parser().parse_args(argv)
        verify_package(SOURCE, args.backend)
        use_wizard = args.interactive or (not args.non_interactive and (not args.server or not args.vm_name))
        if use_wizard:
            interactive_setup(args)
        validate_args(args)
        if args.insecure_skip_tls_verify:
            print('WARNING: ESXi TLS CERTIFICATE AND HOSTNAME VERIFICATION WILL BE DISABLED '
                  'for the targets configured by this install. Credentials and evidence can be intercepted by an '
                  'impersonated endpoint. HTTPS encryption alone does not authenticate the server.',
                  file=sys.stderr)
        preflight(args)
        if use_wizard:
            print_install_summary(args)
        if args.check:
            print('Prerequisites passed. Package downloads, port availability and ESXi access were not tested.')
            return 0
        if use_wizard and not ask_yes_no('Proceed with this installation?', False):
            print('Cancelled. No deployment files or services were changed; no credentials were read.')
            return 0
        credential = read_credential(args)
        install(args, credential)
        return 0
    except (InstallError, OSError, ValueError, subprocess.CalledProcessError) as error:
        # No exception originates from parsing a secret outside the redacting helper.
        print('Installation stopped: ' + str(error), file=sys.stderr)
        print('Existing evidence/configuration is never deleted. See README.md for recovery.', file=sys.stderr)
        return 1
    except (KeyboardInterrupt, EOFError):
        print('Installation interrupted. Inspect preserved files before retrying.', file=sys.stderr)
        return 130


if __name__ == '__main__':
    sys.exit(main())
