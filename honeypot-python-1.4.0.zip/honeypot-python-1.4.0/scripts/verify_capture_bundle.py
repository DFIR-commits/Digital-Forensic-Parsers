#!/usr/bin/env python3
"""Recheck a capture using filenames relative to the bundle, after copying it."""
import argparse
import json
from pathlib import Path
import sys

from capture_esxi_vm_memory import CaptureError, hash_file, validate_basename, verify_gzip_evidence


def verify_bundle(directory):
    directory = directory.expanduser().resolve(strict=True)
    path = directory / "verified-manifest.json"
    checksum = (
        (directory / "verified-manifest.sha256").read_text(encoding="ascii").split()
    )
    if len(checksum) != 2 or checksum[1] != path.name or checksum[0] != hash_file(path):
        raise CaptureError("Verified manifest checksum mismatch")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest["Status"] != "downloaded-and-verified":
        raise CaptureError("Bundle has no completed verification checkpoint")
    files = manifest["Files"]
    if manifest.get("SchemaVersion") not in (1, 2):
        raise CaptureError("Unsupported evidence schema")
    if not {"memory-state", "snapshot-metadata", "vm-configuration"}.issubset(
        {f["Kind"] for f in files}
    ):
        raise CaptureError("Bundle is missing a required evidence class")
    if len({f["Name"].casefold() for f in files}) != len(files):
        raise CaptureError("Manifest contains duplicate evidence filenames")
    stored_names = set()
    for record in files:
        validate_basename(record["Name"])
        storage = record.get("Storage")
        stored_name = storage["Name"] if storage is not None else record["Name"]
        validate_basename(stored_name)
        if stored_name.casefold() in stored_names:
            raise CaptureError("Manifest contains duplicate stored filenames")
        stored_names.add(stored_name.casefold())
        if storage is not None:
            if manifest["SchemaVersion"] != 2 or record["Kind"] != "memory-state":
                raise CaptureError("Unexpected compressed evidence record")
            verify_gzip_evidence(directory / stored_name, record, storage)
            continue
        local = directory / record["Name"]
        if local.is_symlink() or not local.is_file():
            raise CaptureError(f"Missing or symlink evidence file: {record['Name']}")
        if (
            local.stat().st_size != record["SizeBytes"]
            or hash_file(local) != record["Sha256"]
        ):
            raise CaptureError(f"Evidence size/hash mismatch: {record['Name']}")
    return len(files)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundle", type=Path)
    args = parser.parse_args()
    try:
        count = verify_bundle(args.bundle)
        print(f"Verified {count} evidence files and the verification manifest.")
        print(
            "This checks stored bytes; inspect capture-manifest.json and vSphere for cleanup status."
        )
        return 0
    except (OSError, ValueError, KeyError, CaptureError) as error:
        print(f"Verification failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
