#!/usr/bin/env python3
"""Authenticated WSGI receiver + durable queue for Python or PowerShell captures.

Run the WSGI factory with Gunicorn; do not expose a Python development HTTP server.
Only the worker invokes the selected implementation. Webhooks cannot select it.
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time
import uuid

IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\Z")
EVENT_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:@/-]{0,127}\Z")
JOB_ID = re.compile(r"[0-9a-f]{32}\Z")
MAX_BODY = 16384
ACTIVE = ("queued", "running", "needs_review")


class Rejected(Exception):
    def __init__(self, status: int, message: str):
        self.status, self.message = status, message
        super().__init__(message)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def decode_json(raw):
    return json.loads(raw, object_pairs_hook=unique_object)


def bounded_integer(value, minimum, maximum, name):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError(f"Invalid configuration integer: {name}")
    return value


def absolute_path(value, name):
    if not isinstance(value, str) or not Path(value).is_absolute():
        raise ValueError(f"Configuration requires an absolute path: {name}")
    return value


def insecure_tls_requested(target):
    value = target.get("insecure_skip_tls_verify", False)
    if type(value) is not bool:
        raise ValueError("insecure_skip_tls_verify must be a boolean")
    if value and target.get("ca_bundle") is not None:
        raise ValueError("Remove ca_bundle before enabling insecure_skip_tls_verify")
    return value


def load_config(path):
    config = decode_json(Path(path).read_text(encoding="utf-8"))
    # Preserve the original PowerShell configs; new Python configs opt in explicitly.
    config.setdefault("capture_backend", "powershell")
    if config["capture_backend"] not in ("python", "powershell"):
        raise ValueError("capture_backend must be python or powershell")
    for field in ("state_directory", *runtime_fields(config)):
        absolute_path(config[field], field)
    if type(config["dry_run"]) is not bool:
        raise ValueError("dry_run must be a boolean")
    for field, low, high in (("max_pending_jobs", 1, 1000), ("max_total_jobs", 1, 1000000),
                             ("max_queue_age_seconds", 1, 3600),
                             ("minimum_admission_seconds", 1, 86400),
                             ("capture_timeout_seconds", 30, 86400)):
        bounded_integer(config[field], low, high, field)
    if not config["targets"] or not config["sources"]:
        raise ValueError("At least one source and target must be configured")
    identities = set()
    for alias, target in config["targets"].items():
        if not IDENTIFIER.fullmatch(alias):
            raise ValueError("Invalid target alias")
        for field in ("server", "vm_name"):
            if not isinstance(target[field], str) or not target[field].strip() or "\x00" in target[field]:
                raise ValueError(f"Invalid target setting: {field}")
        identity = (target["server"].casefold(), target["vm_name"].casefold())
        if identity in identities:
            raise ValueError("Use one target alias per server/VM")
        identities.add(identity)
        absolute_path(target["destination_root"], "destination_root")
        if not IDENTIFIER.fullmatch(target["credential_name"]):
            raise ValueError("Invalid credential name")
        if type(target["keep_snapshot"]) is not bool:
            raise ValueError("keep_snapshot must be a boolean")
        if type(target.get("compress_memory", False)) is not bool:
            raise ValueError("compress_memory must be a boolean")
        insecure_tls_requested(target)
        bounded_integer(target["minimum_interval_minutes"], 0, 10080, "minimum_interval_minutes")
        if target.get("ca_bundle") is not None:
            if config["capture_backend"] != "python":
                raise ValueError("ca_bundle is a Python setting; configure PowerCLI trust separately")
            absolute_path(target["ca_bundle"], "ca_bundle")
        if "port" in target:
            if config["capture_backend"] != "python":
                raise ValueError("port override is currently supported only by the Python worker")
            bounded_integer(target["port"], 1, 65535, "port")
    for source, settings in config["sources"].items():
        if source not in ("splunk", "crowdstrike"):
            raise ValueError("Unsupported source")
        if not IDENTIFIER.fullmatch(settings["token_credential"]):
            raise ValueError("Invalid token credential name")
        if not isinstance(settings["allowed_targets"], list) or not settings["allowed_targets"]:
            raise ValueError("A source needs an explicit target allowlist")
        if any(alias not in config["targets"] for alias in settings["allowed_targets"]):
            raise ValueError("Source allowlist contains an unknown target")
    return config


def runtime_fields(config):
    backend = config.get("capture_backend", "powershell")
    if backend == "python":
        return ("python", "capture_script")
    if backend == "powershell":
        return ("pwsh", "wrapper_script", "capture_script")
    raise ValueError("Unsupported capture backend")


def normalize_request(config, source, payload):
    # Splunk's native webhook envelope has one triggering/first result. Auth is
    # still mandatory: native URL-only webhooks need an authenticated adapter.
    if source == "splunk" and isinstance(payload, dict) and "result" in payload:
        payload = payload["result"]
    if not isinstance(payload, dict):
        raise Rejected(400, "Expected a JSON object")
    # Only these fields are consumed. Extra Splunk result fields are harmless;
    # no server, path, switch, credential, callback URL, or command is accepted.
    target, event = payload.get("target_id"), payload.get("event_id")
    reason = payload.get("reason", "security alert")
    if not isinstance(target, str) or not IDENTIFIER.fullmatch(target):
        raise Rejected(400, "Invalid target_id")
    if not isinstance(event, str) or not EVENT_ID.fullmatch(event):
        raise Rejected(400, "A stable event_id is required (1-128 safe characters)")
    if not isinstance(reason, str) or len(reason) > 240 or any(ord(c) < 32 or ord(c) == 127 for c in reason):
        raise Rejected(400, "reason must be at most 240 characters without control characters")
    if (target not in config["targets"] or source not in config["sources"] or
            target not in config["sources"][source]["allowed_targets"]):
        raise Rejected(403, "Target is not authorized for this source")
    return {"target_id": target, "event_id": event, "reason": reason}


class Queue:
    def __init__(self, config):
        self.config = config
        self.root = Path(config["state_directory"])
        # Provision a local 0700 directory owned by the one service account.
        # Never put it on NFS/SMB or allow honeypot access.
        if not self.root.is_dir():
            raise ValueError("Provision state_directory before starting the service")
        self.path = self.root / "jobs.sqlite3"
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY, source TEXT NOT NULL, event_id TEXT NOT NULL,
                target_id TEXT NOT NULL, reason TEXT NOT NULL, request_hash TEXT NOT NULL,
                status TEXT NOT NULL, accepted_at REAL NOT NULL, started_at REAL,
                finished_at REAL, outcome TEXT, resolution TEXT,
                UNIQUE(source, event_id))""")
            db.execute("CREATE INDEX IF NOT EXISTS jobs_target ON jobs(target_id, accepted_at)")

    @contextlib.contextmanager
    def connection(self):
        db = sqlite3.connect(self.path, timeout=5, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA synchronous=FULL")
        try:
            yield db
        finally:
            if db.in_transaction:
                db.rollback()
            db.close()

    def admit(self, source, request, now=None):
        request = normalize_request(self.config, source, request)
        now = time.time() if now is None else now
        fingerprint = hashlib.sha256(json.dumps(request, sort_keys=True).encode()).hexdigest()
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT * FROM jobs WHERE source=? AND event_id=?",
                                  (source, request["event_id"])).fetchone()
            if existing:
                if existing["request_hash"] != fingerprint:
                    raise Rejected(409, "event_id was already used for a different request")
                db.commit()
                return dict(existing), True
            blocker = db.execute("SELECT id FROM jobs WHERE target_id=? AND status IN (?,?,?)",
                                 (request["target_id"], *ACTIVE)).fetchone()
            if blocker:
                raise Rejected(409, "Target already has a queued, running, or unresolved job")
            previous = db.execute("SELECT * FROM jobs WHERE target_id=? ORDER BY accepted_at DESC LIMIT 1",
                                  (request["target_id"],)).fetchone()
            minimum = max(self.config["minimum_admission_seconds"],
                          self.config["targets"][request["target_id"]]["minimum_interval_minutes"] * 60)
            if previous and now < max(previous["accepted_at"], previous["finished_at"] or 0) + minimum:
                raise Rejected(429, "Target cooldown is active")
            pending = db.execute("SELECT count(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]
            total = db.execute("SELECT count(*) FROM jobs").fetchone()[0]
            if pending >= self.config["max_pending_jobs"] or total >= self.config["max_total_jobs"]:
                raise Rejected(503, "Queue capacity reached; operator action is required")
            job_id = uuid.uuid4().hex
            db.execute("INSERT INTO jobs(id,source,event_id,target_id,reason,request_hash,status,accepted_at) VALUES(?,?,?,?,?,?,?,?)",
                       (job_id, source, request["event_id"], request["target_id"], request["reason"], fingerprint, "queued", now))
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            db.commit()
            return dict(row), False

    def get(self, job_id):
        with self.connection() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            return dict(row) if row else None

    def recover_interrupted(self):
        # Must be called only while holding the singleton worker lock. Never
        # replay a running capture after a crash: ESXi may still be processing it.
        with self.connection() as db:
            db.execute("UPDATE jobs SET status='needs_review', outcome='worker_interrupted', finished_at=? WHERE status='running'",
                       (time.time(),))

    def claim(self, now=None):
        now = time.time() if now is None else now
        with self.connection() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("UPDATE jobs SET status='expired', outcome='queue_age_exceeded', finished_at=? WHERE status='queued' AND accepted_at<?",
                       (now, now - self.config["max_queue_age_seconds"]))
            row = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY accepted_at LIMIT 1").fetchone()
            if row:
                db.execute("UPDATE jobs SET status='running', started_at=? WHERE id=?", (now, row["id"]))
            db.commit()
            return dict(row, status="running", started_at=now) if row else None

    def finish(self, job_id, status, outcome):
        with self.connection() as db:
            changed = db.execute("UPDATE jobs SET status=?, outcome=?, finished_at=? WHERE id=? AND status='running'",
                                 (status, outcome, time.time(), job_id)).rowcount
            if changed != 1:
                raise RuntimeError("Job state changed unexpectedly; operator review is required")

    def resolve(self, job_id, note):
        if not JOB_ID.fullmatch(job_id) or not note.strip() or len(note) > 500:
            raise ValueError("Supply a job ID and a non-secret resolution note (1-500 characters)")
        with self.connection() as db:
            changed = db.execute("UPDATE jobs SET status='resolved', resolution=? WHERE id=? AND status='needs_review'",
                                 (note, job_id)).rowcount
            if changed != 1:
                raise ValueError("Only a needs_review job can be resolved")


def public_job(job):
    return {key: job[key] for key in ("id", "source", "target_id", "status", "outcome")}


class WebhookApp:
    def __init__(self, config, tokens):
        self.config, self.tokens, self.queue = config, tokens, Queue(config)

    def __call__(self, environ, start_response):
        try:
            parts = environ.get("PATH_INFO", "").strip("/").split("/")
            if len(parts) not in (3, 4) or parts[0] != "v1" or parts[1] not in self.tokens:
                raise Rejected(404, "Not found")
            source = parts[1]
            supplied = environ.get("HTTP_AUTHORIZATION", "")
            expected = "Bearer " + self.tokens[source]
            if len(supplied) > 1024 or not hmac.compare_digest(supplied.encode(), expected.encode()):
                raise Rejected(401, "Authentication required")
            method = environ.get("REQUEST_METHOD")
            if len(parts) == 4 and parts[2] == "jobs" and method == "GET" and JOB_ID.fullmatch(parts[3]):
                job = self.queue.get(parts[3])
                if job is None or job["source"] != source:
                    raise Rejected(404, "Not found")
                status, response = 200, public_job(job)
            elif len(parts) == 3 and parts[2] == "captures" and method == "POST":
                if environ.get("CONTENT_TYPE", "").split(";")[0].strip().lower() != "application/json":
                    raise Rejected(415, "Content-Type must be application/json")
                if environ.get("HTTP_CONTENT_ENCODING") or environ.get("HTTP_TRANSFER_ENCODING"):
                    raise Rejected(400, "Encoded/chunked request bodies are not supported")
                raw_length = environ.get("CONTENT_LENGTH", "")
                if not raw_length.isdigit():
                    raise Rejected(411, "Content-Length is required")
                length = int(raw_length)
                if not 0 < length <= MAX_BODY:
                    raise Rejected(413, "Request body is too large or empty")
                body = environ["wsgi.input"].read(length)
                if len(body) != length:
                    raise Rejected(400, "Incomplete request body")
                try:
                    payload = decode_json(body)
                except (ValueError, UnicodeError, RecursionError):
                    raise Rejected(400, "Invalid JSON") from None
                request = normalize_request(self.config, source, payload)
                job, duplicate = self.queue.admit(source, request)
                status, response = (200 if duplicate else 202), public_job(job)
                response["duplicate"] = duplicate
            else:
                raise Rejected(405, "Unsupported method or route")
        except Rejected as error:
            status, response = error.status, {"error": error.message}
        except Exception:
            # Do not return exceptions, payloads, paths, credentials, or subprocess
            # logs to a caller. A commit with a lost response is resolved by event_id.
            status, response = 503, {"error": "Receiver unavailable; retry with the same event_id"}
        labels = {200: "OK", 202: "Accepted", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden",
                  404: "Not Found", 405: "Method Not Allowed", 409: "Conflict", 411: "Length Required",
                  413: "Content Too Large", 415: "Unsupported Media Type", 429: "Too Many Requests", 503: "Service Unavailable"}
        encoded = json.dumps(response, separators=(",", ":")).encode()
        headers = [("Content-Type", "application/json"), ("Content-Length", str(len(encoded))), ("Cache-Control", "no-store")]
        if status in (429, 503):
            headers.append(("Retry-After", "60"))
        start_response(f"{status} {labels[status]}", headers)
        return [encoded]


def create_app():
    """Gunicorn factory. Credential content is never placed in CLI args/config."""
    os.umask(0o077)  # Receiver and worker share one UID; no group access needed.
    config = load_config(os.environ["HONEYPOT_WEBHOOK_CONFIG"])
    credential_directory = Path(os.environ["CREDENTIALS_DIRECTORY"])
    tokens = {}
    for source, settings in config["sources"].items():
        path = credential_directory / settings["token_credential"]
        if path.stat().st_size > 4096 or path.stat().st_mode & 0o077:
            raise ValueError("Webhook token files must be private and at most 4096 bytes")
        token = path.read_text(encoding="utf-8").strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", token):
            raise ValueError("Use a randomly generated URL-safe webhook token of at least 32 characters")
        tokens[source] = token
    if len(set(tokens.values())) != len(tokens):
        raise ValueError("Each source must have a different webhook token")
    return WebhookApp(config, tokens)


def capture_command(config, job):
    if not JOB_ID.fullmatch(job["id"]):
        raise ValueError("Invalid stored job ID")
    request = normalize_request(config, job["source"], job)
    target = config["targets"][request["target_id"]]
    insecure_tls = insecure_tls_requested(target)
    compress_memory = target.get("compress_memory", False)
    if type(compress_memory) is not bool:
        raise ValueError("compress_memory must be a boolean")
    reason = f"{job['source']}:{request['event_id']} {request['reason']}"
    runtime_fields(config)  # Revalidate selection in the worker, not from a queue row.
    if config.get("capture_backend", "powershell") == "python":
        command = [config["python"], config["capture_script"],
                   "--server", target["server"], "--vm-name", target["vm_name"],
                   "--destination-root", target["destination_root"],
                   "--credential-name", target["credential_name"],
                   "--trigger-reason", reason,
                   "--minimum-interval-minutes", str(target["minimum_interval_minutes"])]
        if target.get("ca_bundle"):
            command += ["--ca-bundle", target["ca_bundle"]]
        if "port" in target:
            command += ["--port", str(target["port"])]
        if target["keep_snapshot"]:
            command.append("--keep-snapshot")
        if insecure_tls:
            command.append("--insecure-skip-tls-verify")
        if compress_memory:
            command.append("--compress-memory")
        return command
    command = [config["pwsh"], "-NoLogo", "-NoProfile", "-NonInteractive", "-File", config["wrapper_script"],
               "-CaptureScript", config["capture_script"], "-Server", target["server"], "-VMName", target["vm_name"],
               "-DestinationRoot", target["destination_root"], "-CredentialName", target["credential_name"],
               "-TriggerReason", reason, "-MinimumIntervalMinutes", str(target["minimum_interval_minutes"])]
    if target["keep_snapshot"]:
        command.append("-KeepSnapshot")
    if insecure_tls:
        command.append("-InsecureSkipTlsVerify")
    if compress_memory:
        command.append("-CompressMemory")
    return command


@contextlib.contextmanager
def worker_lock(queue):
    # Preserve the lock inode; pass its FD to the child so a worker restart cannot
    # overlap a still-running capture child after the worker parent crashes.
    with (queue.root / "worker.lock").open("a+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield lock.fileno()


def run_job(config, queue, job, lock_fd):
    try:
        command = capture_command(config, job)
        if config["dry_run"]:
            queue.finish(job["id"], "dry_run", "not_executed")
            return
        for field in runtime_fields(config):
            if not Path(config[field]).is_file():
                raise ValueError("Capture runtime is not installed")
        logs = queue.root / "worker-logs"
        logs.mkdir(mode=0o700, exist_ok=True)
        fd = os.open(logs / (job["id"] + ".log"), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as log:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                       shell=False, pass_fds=(lock_fd,), cwd=str(logs))
            try:
                code = process.wait(timeout=config["capture_timeout_seconds"])
            except subprocess.TimeoutExpired:
                # Only terminate the local child. ESXi tasks can outlive it;
                # block this target for review and never auto-retry the capture.
                process.kill()
                process.wait()
                queue.finish(job["id"], "needs_review", "timeout_remote_state_unknown")
                return
            log.flush()
            os.fsync(log.fileno())
        if code != 0:
            queue.finish(job["id"], "needs_review", f"capture_exit_{code}")
        elif config["targets"][job["target_id"]]["keep_snapshot"]:
            queue.finish(job["id"], "needs_review", "verified_snapshot_retained")
        else:
            queue.finish(job["id"], "succeeded", "capture_completed")
    except Exception:
        # Even if the local error preceded invocation, conservative review avoids
        # automatically repeating an uncertain, potentially destructive workflow.
        queue.finish(job["id"], "needs_review", "worker_error_check_local_log")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    commands = parser.add_subparsers(dest="action", required=True)
    worker = commands.add_parser("worker")
    worker.add_argument("--once", action="store_true", help="Process at most one job")
    status = commands.add_parser("status")
    status.add_argument("job_id")
    resolve = commands.add_parser("resolve", help="Acknowledge manual review; does not remove snapshots or delete evidence")
    resolve.add_argument("job_id")
    resolve.add_argument("--note", required=True)
    args = parser.parse_args()
    os.umask(0o077)
    config = load_config(args.config)
    queue = Queue(config)
    if args.action == "status":
        job = queue.get(args.job_id)
        if job is None:
            raise ValueError("Job not found")
        print(json.dumps(job, indent=2))
    elif args.action == "resolve":
        queue.resolve(args.job_id, args.note)
        print("Review acknowledged. No ESXi operation was performed.")
    else:
        with worker_lock(queue) as lock_fd:
            queue.recover_interrupted()
            while True:
                job = queue.claim()
                if job:
                    run_job(config, queue, job, lock_fd)
                    print(json.dumps(public_job(queue.get(job["id"]))), flush=True)
                if args.once:
                    break
                if not job:
                    time.sleep(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        # Configuration/OS failures must be visible but cannot expose secret data.
        print(f"Worker stopped ({type(error).__name__}); check configuration, permissions, and queue state.", file=sys.stderr)
        sys.exit(1)
