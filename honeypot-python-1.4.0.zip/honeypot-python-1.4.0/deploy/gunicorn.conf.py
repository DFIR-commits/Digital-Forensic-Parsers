"""Direct HTTP listener on a trusted management network; no reverse proxy/TLS.

Set HONEYPOT_WEBHOOK_BIND to the collector's private IP:8787 in its service.
Loopback is the safe default until that address and the firewall are configured.
"""
import os

bind = os.environ.get("HONEYPOT_WEBHOOK_BIND", "127.0.0.1:8787")
workers = 2
worker_class = "gthread"
threads = 4
worker_connections = 32
backlog = 64
timeout = 15  # Worker health timeout, NOT a hard per-request deadline for gthread.
graceful_timeout = 15
keepalive = 2
limit_request_line = 2048
limit_request_fields = 32
limit_request_field_size = 2048
umask = 0o077

# Direct clients are not trusted proxies. Never trust their forwarded headers.
forwarded_allow_ips = ""
secure_scheme_headers = {}
proxy_protocol = "off"
http_protocols = "h1"

# No access logs (URLs/headers may contain caller mistakes/secrets).
accesslog = None
errorlog = "-"
loglevel = "warning"
